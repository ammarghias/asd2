# pdf_example

Demo for creating a PDF file using syncfusion_flutter_pdf package.
