
import 'dart:io';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
Future<void> editExistingPdf() async {
//   String pathh='assets/Form_example.pdf';
// final PdfDocument document =
//     PdfDocument(inputBytes: File(pathh).readAsBytesSync());
final ByteData data = await rootBundle.load('assets/Form_example.pdf');
    final Uint8List existingPdfBytes = data.buffer.asUint8List();

    // Create a new PDF document.
    final PdfDocument document = PdfDocument(inputBytes: existingPdfBytes);

//Get the form.
PdfForm form = document.form;

//Get text box and fill value.
PdfTextBoxField name = document.form.fields[0] as PdfTextBoxField;
for (var i = 0; i < document.form.fields.count; i++) {
  print('field '+document.form.fields[i].name.toString());
}
print('jhkhjhjk'+name.text.toString());
name.text = 'John';
print('jhkhjhjk'+name.text.toString());
//Get the radio button and select.
PdfRadioButtonListField gender = form.fields[1] as PdfRadioButtonListField;
gender.selectedIndex = 1;
PdfSignatureField signatureField =
    document.form.fields[0] as PdfSignatureField;
signatureField.signature = PdfSignature(
  certificate:
      PdfCertificate(File('certificate.pfx').readAsBytesSync(), 'password@123'),
);
//Save and dispose the document.
File('output.pdf').writeAsBytesSync(await document.save());
document.dispose();
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
    await editExistingPdf();

    print('Error loading existing PDF: ');
  
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  PdfDocument? _pdfDocument;

  @override
  void initState() {
    super.initState();
    _loadPdf();
  }

  Future<void> _loadPdf() async {
    try {
      // Load the existing PDF document from assets.
      final ByteData data = await rootBundle.load('assets/Form_example.pdf');
      final Uint8List existingPdfBytes = data.buffer.asUint8List();

      // Create a new PDF document.
      final PdfDocument document = PdfDocument(inputBytes: existingPdfBytes);

      setState(() {
        _pdfDocument = document;
      });
    } catch (e) {
      print('Error loading PDF: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PDF Viewer'),
      ),
      body:  Container(
          child: SfPdfViewer.asset(
              'assets/Form_example.pdf',
              enableDoubleTapZooming: false)));
    
  }
}
