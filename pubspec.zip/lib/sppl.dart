import 'package:ammar_s_application4/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

import 'core/utils/navigator_service.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  late VideoPlayerController _videoPlayerController;
  late ChewieController _chewieController;
  late Future<void> _future;

  Future<void> initVideoPlayer() async {
    await _videoPlayerController.initialize();
    setState(() {
      print(_videoPlayerController.value.aspectRatio);
      _chewieController = ChewieController(
        videoPlayerController: _videoPlayerController,
       aspectRatio: 0.61,
        autoPlay: true,
        looping: true,
        autoInitialize: true,
        showControls: false,
        showControlsOnInitialize: false
      );
    });
  }

  @override
  void initState() {
    super.initState();
    _videoPlayerController = VideoPlayerController.asset("assets/klj.mp4");
    _future = initVideoPlayer();
      Future.delayed(Duration(seconds: 3), () {
    NavigatorService.pushNamed(
      AppRoutes.loginPagePageLoginScreen,
    );
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _future,
      builder: (context, snapshot) {
        return SizedBox.expand(
          child: Center(
            child: _videoPlayerController.value.isInitialized
                ? Chewie(
                  controller: _chewieController,
                )
                : const CircularProgressIndicator(),
          ),
        );
      }
    );
  }

  @override
  void dispose() {
    _videoPlayerController.dispose();
    _chewieController.dispose();
    super.dispose();
  }
}