import 'package:flutter/material.dart';
import 'package:ammar_s_application4/core/app_export.dart';

class AppStyle {
  static TextStyle txtInterMedium21Bluegray400 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtLEMONMILKMedium65 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      65,
    ),
    fontFamily: 'LEMON MILK',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular18Black90087 = TextStyle(
    color: ColorConstant.black90087,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular10 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular15 = TextStyle(
    color: ColorConstant.red100,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular18 = TextStyle(
    color: ColorConstant.gray80001,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular14Red700 = TextStyle(
    color: ColorConstant.red700,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium17Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular17Pink700 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular19Pink700 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15Gray4007f = TextStyle(
    color: ColorConstant.gray4007f,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold17Gray50075 = TextStyle(
    color: ColorConstant.gray50075,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterMedium21Gray50002 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular11Pink700 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtCaveatBrushRegular20 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Caveat Brush',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18Green90099 = TextStyle(
    color: ColorConstant.green90099,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanBold25 = TextStyle(
    color: ColorConstant.gray60003,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterMedium15Gray40007 = TextStyle(
    color: ColorConstant.gray40007,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtHindVadodaraRegular20WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Hind Vadodara',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular17Gray60075 = TextStyle(
    color: ColorConstant.gray60075,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular35 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      35,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular20WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtKulimParkItalic25 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Kulim Park',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular6Lime800 = TextStyle(
    color: ColorConstant.lime800,
    fontSize: getFontSize(
      6,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular14Green600 = TextStyle(
    color: ColorConstant.green600,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold45 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      45,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold40 = TextStyle(
    color: ColorConstant.green90099,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold18Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtChalkboardBold100 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      100,
    ),
    fontFamily: 'Chalkboard',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtJuraBold18 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Jura',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtJuraBold13 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Jura',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtStaatlichesRegular22 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      22,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold35 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      35,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtStaatlichesRegular25 = TextStyle(
    color: ColorConstant.teal300,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular14Lightgreen500 = TextStyle(
    color: ColorConstant.lightGreen500,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15Pink70090 = TextStyle(
    color: ColorConstant.pink70090,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular16Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold21Cyan200 = TextStyle(
    color: ColorConstant.cyan200,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtLivvicRegular18 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Livvic',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold18Gray80003 = TextStyle(
    color: ColorConstant.gray80003,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterMedium21 = TextStyle(
    color: ColorConstant.gray60009,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtStickNoBillsRegular32 = TextStyle(
    color: ColorConstant.gray90001,
    fontSize: getFontSize(
      32,
    ),
    fontFamily: 'Stick No Bills',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15Green90099 = TextStyle(
    color: ColorConstant.green90099,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular25Pink70075 = TextStyle(
    color: ColorConstant.pink70075,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular9 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      9,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold10Gray50002 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold21Cyan80001 = TextStyle(
    color: ColorConstant.cyan80001,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold23Lime400 = TextStyle(
    color: ColorConstant.lime400,
    fontSize: getFontSize(
      23,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterMedium18 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterMedium19 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtKulimParkBold15 = TextStyle(
    color: ColorConstant.black90090,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Kulim Park',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular17Pink70001 = TextStyle(
    color: ColorConstant.pink70001,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanRegular13Gray60006 = TextStyle(
    color: ColorConstant.gray60006,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtChalkboard20 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Chalkboard',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium13 = TextStyle(
    color: ColorConstant.gray40004,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtLivvicRegular25 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Livvic',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium17 = TextStyle(
    color: ColorConstant.gray800,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterMedium14 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterMedium15 = TextStyle(
    color: ColorConstant.gray400,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterBold9 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      9,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular14Lime400 = TextStyle(
    color: ColorConstant.lime400,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular10Yellow50 = TextStyle(
    color: ColorConstant.yellow50,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular20Pink700 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular14YellowA700 = TextStyle(
    color: ColorConstant.yellowA700,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular19Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium14Gray40006 = TextStyle(
    color: ColorConstant.gray40006,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterBold8 = TextStyle(
    color: ColorConstant.purpleA700,
    fontSize: getFontSize(
      8,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular17Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtLivvicRegular30 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Livvic',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular20Cyan80001 = TextStyle(
    color: ColorConstant.cyan80001,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular10Gray60099 = TextStyle(
    color: ColorConstant.gray60099,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular25Gray50002 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular40Bluegray700 = TextStyle(
    color: ColorConstant.blueGray700,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular20Red300 = TextStyle(
    color: ColorConstant.red300,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular30 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtChalkboard40 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Chalkboard',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular31 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      31,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular17Black9007e = TextStyle(
    color: ColorConstant.black9007e,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular19Green900 = TextStyle(
    color: ColorConstant.green900,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular25Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium21Black90087 = TextStyle(
    color: ColorConstant.black90087,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular17RedA700 = TextStyle(
    color: ColorConstant.redA700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold70 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      70,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterMedium17Gray50001 = TextStyle(
    color: ColorConstant.gray50001,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular6IndigoA700 = TextStyle(
    color: ColorConstant.indigoA700,
    fontSize: getFontSize(
      6,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular35 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      35,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular11Black9007e = TextStyle(
    color: ColorConstant.black9007e,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular40Gray40008 = TextStyle(
    color: ColorConstant.gray40008,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular20 = TextStyle(
    color: ColorConstant.pink70001,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular21 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtChalkboard50 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      50,
    ),
    fontFamily: 'Chalkboard',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtImprimaRegular16 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Imprima',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular17Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtImprimaRegular17 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Imprima',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular12Green90099 = TextStyle(
    color: ColorConstant.green90099,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular6 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      6,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular22 = TextStyle(
    color: ColorConstant.pink70001,
    fontSize: getFontSize(
      22,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular23 = TextStyle(
    color: ColorConstant.green900,
    fontSize: getFontSize(
      23,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular9 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      9,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular25 = TextStyle(
    color: ColorConstant.pink70001,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular8 = TextStyle(
    color: ColorConstant.black90087,
    fontSize: getFontSize(
      8,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular20Green90099 = TextStyle(
    color: ColorConstant.green90099,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular14Bluegray10004 = TextStyle(
    color: ColorConstant.blueGray10004,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium15Gray60002 = TextStyle(
    color: ColorConstant.gray60002,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtIstokWebBold21 = TextStyle(
    color: ColorConstant.black90090,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Istok Web',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtIstokWebBold20 = TextStyle(
    color: ColorConstant.green70090,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Istok Web',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtChalkboard60 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      60,
    ),
    fontFamily: 'Chalkboard',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18Gray60075 = TextStyle(
    color: ColorConstant.gray60075,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular10 = TextStyle(
    color: ColorConstant.gray400,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium15Gray60009 = TextStyle(
    color: ColorConstant.gray60009,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtCaladeaBold30 = TextStyle(
    color: ColorConstant.green500,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Caladea',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular20Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular19 = TextStyle(
    color: ColorConstant.gray400,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtHindVadodaraBold30 = TextStyle(
    color: ColorConstant.gray70002,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Hind Vadodara',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular35Yellow700 = TextStyle(
    color: ColorConstant.yellow700,
    fontSize: getFontSize(
      35,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular11Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular11 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular12 = TextStyle(
    color: ColorConstant.whiteA70099,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular13 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular14 = TextStyle(
    color: ColorConstant.gray400,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15 = TextStyle(
    color: ColorConstant.gray600,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular16 = TextStyle(
    color: ColorConstant.black90095,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular13WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular17 = TextStyle(
    color: ColorConstant.gray60087,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18 = TextStyle(
    color: ColorConstant.gray600,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold15Black90075 = TextStyle(
    color: ColorConstant.black90075,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtCaladeaBold40 = TextStyle(
    color: ColorConstant.green500,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Caladea',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtCastoroRegular19 = TextStyle(
    color: ColorConstant.gray80002,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Castoro',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular25Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular20Cyan200 = TextStyle(
    color: ColorConstant.cyan200,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold20Black9007e = TextStyle(
    color: ColorConstant.black9007e,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular11WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18Gray50002 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold16WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterMedium15Gray40087 = TextStyle(
    color: ColorConstant.gray40087,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtStaatlichesRegular100 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      100,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanRegular23 = TextStyle(
    color: ColorConstant.gray60007,
    fontSize: getFontSize(
      23,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtCastoroRegular21 = TextStyle(
    color: ColorConstant.gray80002,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Castoro',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold15WhiteA70075 = TextStyle(
    color: ColorConstant.whiteA70075,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoRomanRegular16Gray60007 = TextStyle(
    color: ColorConstant.gray60007,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtImprimaRegular20 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Imprima',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular16Gray50002 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular19Gray60008 = TextStyle(
    color: ColorConstant.gray60008,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular16Pink700 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtImprimaRegular23 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      23,
    ),
    fontFamily: 'Imprima',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtImprimaRegular25 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Imprima',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular13Black90087 = TextStyle(
    color: ColorConstant.black90087,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanRegular16Pink700 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.blueGray40001,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtHindVadodaraRegular28 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      28,
    ),
    fontFamily: 'Hind Vadodara',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular20Yellow700 = TextStyle(
    color: ColorConstant.yellow700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtHindVadodaraRegular21 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Hind Vadodara',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtHindVadodaraRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Hind Vadodara',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular17Gray600 = TextStyle(
    color: ColorConstant.gray600,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular50 = TextStyle(
    color: ColorConstant.gray50007,
    fontSize: getFontSize(
      50,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold25 = TextStyle(
    color: ColorConstant.gray50005,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold27 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      27,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold28 = TextStyle(
    color: ColorConstant.green90099,
    fontSize: getFontSize(
      28,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular21Black90075 = TextStyle(
    color: ColorConstant.black90075,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold21 = TextStyle(
    color: ColorConstant.yellow700,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold23 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      23,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold11Black90087 = TextStyle(
    color: ColorConstant.black90087,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold20 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular17Gray60003 = TextStyle(
    color: ColorConstant.gray60003,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtKulimParkItalic40 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Kulim Park',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular14Black9007e = TextStyle(
    color: ColorConstant.black9007e,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular6WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      6,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtImprimaRegular40 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Imprima',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15Black90087 = TextStyle(
    color: ColorConstant.black90087,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold18 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtStaatlichesRegular18Gray30001 = TextStyle(
    color: ColorConstant.gray30001,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18Gray90003 = TextStyle(
    color: ColorConstant.gray90003,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18Gray90002 = TextStyle(
    color: ColorConstant.gray90002,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular40 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular8Black90090 = TextStyle(
    color: ColorConstant.black90090,
    fontSize: getFontSize(
      8,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold15 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtStaatlichesRegular45 = TextStyle(
    color: ColorConstant.gray50003,
    fontSize: getFontSize(
      45,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold18Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold16 = TextStyle(
    color: ColorConstant.gray600,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold17 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold10 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold11 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterMedium15Gray50002 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtStaatlichesRegular50Pink700 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      50,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanRegular16 = TextStyle(
    color: ColorConstant.gray700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular30Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanRegular15 = TextStyle(
    color: ColorConstant.gray60007,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanRegular10 = TextStyle(
    color: ColorConstant.gray60007,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular35Pink700 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      35,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtJockeyOneRegular30 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Jockey One',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanRegular13 = TextStyle(
    color: ColorConstant.gray50004,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtStaatlichesRegular25Pink700 = TextStyle(
    color: ColorConstant.pink700,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold20PurpleA700 = TextStyle(
    color: ColorConstant.purpleA700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular9Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      9,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtIstokWebRegular16 = TextStyle(
    color: ColorConstant.black90090,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Istok Web',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtIstokWebRegular17 = TextStyle(
    color: ColorConstant.black90090,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Istok Web',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold17Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterMedium15Bluegray400 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterBold20Pink70002 = TextStyle(
    color: ColorConstant.pink70002,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular9Gray60004 = TextStyle(
    color: ColorConstant.gray60004,
    fontSize: getFontSize(
      9,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold25Black90099 = TextStyle(
    color: ColorConstant.black90099,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular21Gray80004 = TextStyle(
    color: ColorConstant.gray80004,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold17Gray70003 = TextStyle(
    color: ColorConstant.gray70003,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterRegular18Gray80003 = TextStyle(
    color: ColorConstant.gray80003,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular17WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15Gray80002 = TextStyle(
    color: ColorConstant.gray80002,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium15Bluegray40099 = TextStyle(
    color: ColorConstant.blueGray40099,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular21Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium17Bluegray400 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtStaatlichesRegular15Gray30001 = TextStyle(
    color: ColorConstant.gray30001,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Staatliches',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium8 = TextStyle(
    color: ColorConstant.gray50002,
    fontSize: getFontSize(
      8,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular17Black900a7 = TextStyle(
    color: ColorConstant.black900A7,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtJockeyOneRegular18 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Jockey One',
    fontWeight: FontWeight.w400,
  );
}
