import 'package:flutter/material.dart';
import 'package:ammar_s_application4/core/app_export.dart';

class AppDecoration {
  static BoxDecoration get outlinePink7007e => BoxDecoration(
        color: ColorConstant.whiteA7007e,
        border: Border.all(
          color: ColorConstant.pink7007e,
          width: getHorizontalSize(
            2,
          ),
        ),
      );
  static BoxDecoration get outlineAmber500 => BoxDecoration(
        color: ColorConstant.pink700,
        border: Border.all(
          color: ColorConstant.amber500,
          width: getHorizontalSize(
            2,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.pink70066,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              0,
            ),
          ),
        ],
      );
  static BoxDecoration get outlineCyan8001 => BoxDecoration(
        color: ColorConstant.cyan800,
        border: Border.all(
          color: ColorConstant.cyan800,
          width: getHorizontalSize(
            2,
          ),
        ),
      );
  static BoxDecoration get outlineCyan8002 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.cyan800,
          width: getHorizontalSize(
            3,
          ),
          strokeAlign: strokeAlignOutside,
        ),
      );
  static BoxDecoration get fillRed80001 => BoxDecoration(
        color: ColorConstant.red80001,
      );
  static BoxDecoration get outlineYellow700 => BoxDecoration(
        color: ColorConstant.yellow70019,
        border: Border.all(
          color: ColorConstant.yellow700,
          width: getHorizontalSize(
            2,
          ),
        ),
      );
  static BoxDecoration get txtOutlineWhiteA7001 => BoxDecoration(
        color: ColorConstant.pink700,
        border: Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            3,
          ),
          strokeAlign: strokeAlignOutside,
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get fillBluegray50 => BoxDecoration(
        color: ColorConstant.blueGray50,
      );
  static BoxDecoration get fillDeeporange400 => BoxDecoration(
        color: ColorConstant.deepOrange400,
      );
  static BoxDecoration get outlineGray50006 => BoxDecoration(
        color: ColorConstant.indigo500,
        border: Border.all(
          color: ColorConstant.gray50006,
          width: getHorizontalSize(
            1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.gray50006,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlineGray50003 => BoxDecoration(
        border: Border.all(
          color: ColorConstant.gray50003,
          width: getHorizontalSize(
            2,
          ),
          strokeAlign: strokeAlignOutside,
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.5,
            0,
          ),
          end: Alignment(
            0.5,
            1,
          ),
          colors: [
            ColorConstant.gray30002,
            ColorConstant.gray100,
          ],
        ),
      );
  static BoxDecoration get outlineGray50002 => BoxDecoration(
        color: ColorConstant.red50,
        border: Border.all(
          color: ColorConstant.gray50002,
          width: getHorizontalSize(
            1,
          ),
          strokeAlign: strokeAlignOutside,
        ),
      );
  static BoxDecoration get fillLime800 => BoxDecoration(
        color: ColorConstant.lime800,
      );
  static BoxDecoration get outlineGray50008 => BoxDecoration(
        color: ColorConstant.whiteA700F7,
        border: Border.all(
          color: ColorConstant.gray50008,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get outlineOrange200 => BoxDecoration(
        color: ColorConstant.yellow5001,
        border: Border.all(
          color: ColorConstant.orange200,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get outlineGray500062 => BoxDecoration(
        color: ColorConstant.gray5001,
        border: Border.all(
          color: ColorConstant.gray50006,
          width: getHorizontalSize(
            1,
          ),
          strokeAlign: strokeAlignOutside,
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.gray50006,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlineWhiteA7001 => BoxDecoration(
        color: ColorConstant.pink700,
        border: Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            3,
          ),
        ),
      );
  static BoxDecoration get outlineGray500061 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.gray50006,
          width: getHorizontalSize(
            1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.gray50006,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlineLime800 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.lime800,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get outlineBluegray10003 => BoxDecoration(
        color: ColorConstant.whiteA700Cc,
        border: Border.all(
          color: ColorConstant.blueGray10003,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get outlineBluegray10002 => BoxDecoration(
        color: ColorConstant.gray10001,
        border: Border.all(
          color: ColorConstant.blueGray10002,
          width: getHorizontalSize(
            2,
          ),
          strokeAlign: strokeAlignOutside,
        ),
      );
  static BoxDecoration get outlineGray40005 => BoxDecoration(
        border: Border.all(
          color: ColorConstant.gray40005,
          width: getHorizontalSize(
            1,
          ),
          strokeAlign: strokeAlignOutside,
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.5,
            0,
          ),
          end: Alignment(
            0.5,
            1,
          ),
          colors: [
            ColorConstant.gray100,
            ColorConstant.whiteA700,
          ],
        ),
      );
  static BoxDecoration get outlineBluegray10001 => BoxDecoration(
        border: Border.all(
          color: ColorConstant.blueGray10001,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get outlineBlack90099 => BoxDecoration();
  static BoxDecoration get fillGray10002 => BoxDecoration(
        color: ColorConstant.gray10002,
      );
  static BoxDecoration get txtOutlineWhiteA700 => BoxDecoration(
        color: ColorConstant.pink700,
        border: Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            2,
          ),
          strokeAlign: strokeAlignOutside,
        ),
      );
  static BoxDecoration get fillWhiteA700 => BoxDecoration(
        color: ColorConstant.whiteA700,
      );
  static BoxDecoration get outlineIndigoA700 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.indigoA700,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get txtOutlineWhiteA7002 => BoxDecoration(
        color: ColorConstant.pink700,
        border: Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            4,
          ),
          strokeAlign: strokeAlignOutside,
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlineGray300 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.gray300,
          width: getHorizontalSize(
            1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black90033,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              3,
            ),
          ),
        ],
      );
  static BoxDecoration get outlinePink7008 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.pink700,
          width: getHorizontalSize(
            2,
          ),
          strokeAlign: strokeAlignOutside,
        ),
      );
  static BoxDecoration get outlinePink700 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.pink700,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get outlineBlack9003f => BoxDecoration(
        color: ColorConstant.whiteA700,
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlineBlack9003f1 => BoxDecoration(
        color: ColorConstant.pink700,
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlinePink7004 => BoxDecoration(
        color: ColorConstant.pink700,
        border: Border.all(
          color: ColorConstant.pink700,
          width: getHorizontalSize(
            1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.pink700,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlinePink7005 => BoxDecoration(
        color: ColorConstant.whiteA700,
        boxShadow: [
          BoxShadow(
            color: ColorConstant.pink700,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlinePink7006 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.pink700,
          width: getHorizontalSize(
            3,
          ),
        ),
      );
  static BoxDecoration get outlinePink7007 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.pink700,
          width: getHorizontalSize(
            1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.pink700,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlinePink7001 => BoxDecoration(
        border: Border.all(
          color: ColorConstant.pink700,
          width: getHorizontalSize(
            1,
          ),
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.77,
            0.3,
          ),
          end: Alignment(
            0.1,
            0.78,
          ),
          colors: [
            ColorConstant.pink700,
            ColorConstant.yellowA400,
          ],
        ),
      );
  static BoxDecoration get outlinePink7002 => BoxDecoration(
        border: Border.all(
          color: ColorConstant.pink700,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get outlinePink7003 => BoxDecoration(
        color: ColorConstant.pink700,
        border: Border.all(
          color: ColorConstant.pink700,
          width: getHorizontalSize(
            1,
          ),
          strokeAlign: strokeAlignOutside,
        ),
      );
  static BoxDecoration get outlineCyan800 => BoxDecoration(
        color: ColorConstant.cyan80019,
        border: Border.all(
          color: ColorConstant.cyan800,
          width: getHorizontalSize(
            2,
          ),
        ),
      );
  static BoxDecoration get outlineBlack900 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.black900,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get outlineRedA700 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.redA700,
          width: getHorizontalSize(
            2,
          ),
        ),
      );
  static BoxDecoration get outlinePink90033 => BoxDecoration(
        color: ColorConstant.whiteA700,
        boxShadow: [
          BoxShadow(
            color: ColorConstant.pink90033,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              -2,
            ),
          ),
        ],
      );
  static BoxDecoration get fillBlack900 => BoxDecoration(
        color: ColorConstant.black900,
      );
  static BoxDecoration get fillWhiteA70099 => BoxDecoration(
        color: ColorConstant.whiteA70099,
      );
  static BoxDecoration get fillLightgreen800 => BoxDecoration(
        color: ColorConstant.lightGreen800,
      );
  static BoxDecoration get outlineWhiteA700 => BoxDecoration(
        color: ColorConstant.pink700,
        border: Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            3,
          ),
          strokeAlign: strokeAlignOutside,
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get outlineGray800011 => BoxDecoration(
        color: ColorConstant.deepOrange300,
        border: Border.all(
          color: ColorConstant.gray80001,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get outlineGray800012 => BoxDecoration(
        color: ColorConstant.lime80019,
        border: Border.all(
          color: ColorConstant.gray80001,
          width: getHorizontalSize(
            3,
          ),
        ),
      );
  static BoxDecoration get fillBluegray800 => BoxDecoration(
        color: ColorConstant.blueGray800,
      );
  static BoxDecoration get outlineGray500031 => BoxDecoration(
        border: Border.all(
          color: ColorConstant.gray50003,
          width: getHorizontalSize(
            2,
          ),
          strokeAlign: strokeAlignOutside,
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.5,
            0,
          ),
          end: Alignment(
            0.5,
            1,
          ),
          colors: [
            ColorConstant.gray30002,
            ColorConstant.gray10000,
          ],
        ),
      );
  static BoxDecoration get outlineBlack9001 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.black900,
          width: getHorizontalSize(
            2,
          ),
        ),
      );
  static BoxDecoration get fillPinkA20066 => BoxDecoration(
        color: ColorConstant.pinkA20066,
      );
  static BoxDecoration get txtOutlinePink700 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.pink700,
          width: getHorizontalSize(
            2,
          ),
          strokeAlign: strokeAlignOutside,
        ),
      );
  static BoxDecoration get fillIndigoA700 => BoxDecoration(
        color: ColorConstant.indigoA700,
      );
  static BoxDecoration get fillGray900 => BoxDecoration(
        color: ColorConstant.gray900,
      );
  static BoxDecoration get outlineYellow7002 => BoxDecoration(
        color: ColorConstant.whiteA700,
        border: Border.all(
          color: ColorConstant.yellow700,
          width: getHorizontalSize(
            3,
          ),
          strokeAlign: strokeAlignOutside,
        ),
      );
  static BoxDecoration get outlineYellow7001 => BoxDecoration(
        color: ColorConstant.yellow700,
        border: Border.all(
          color: ColorConstant.yellow700,
          width: getHorizontalSize(
            2,
          ),
        ),
      );
  static BoxDecoration get outlineBlack90026 => BoxDecoration(
        color: ColorConstant.whiteA700,
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black90026,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get fillPink700 => BoxDecoration(
        color: ColorConstant.pink700,
      );
  static BoxDecoration get fillRed800 => BoxDecoration(
        color: ColorConstant.red800,
      );
  static BoxDecoration get outlineGray80001 => BoxDecoration(
        color: ColorConstant.lime800,
        border: Border.all(
          color: ColorConstant.gray80001,
          width: getHorizontalSize(
            1,
          ),
        ),
      );
  static BoxDecoration get fillGray100 => BoxDecoration(
        color: ColorConstant.gray100,
      );
}

class BorderRadiusStyle {
  static BorderRadius customBorderTL30 = BorderRadius.only(
    topLeft: Radius.circular(
      getHorizontalSize(
        30,
      ),
    ),
    topRight: Radius.circular(
      getHorizontalSize(
        30,
      ),
    ),
  );

  static BorderRadius customBorderBL36 = BorderRadius.only(
    topLeft: Radius.circular(
      getHorizontalSize(
        33,
      ),
    ),
    topRight: Radius.circular(
      getHorizontalSize(
        36,
      ),
    ),
    bottomLeft: Radius.circular(
      getHorizontalSize(
        36,
      ),
    ),
    bottomRight: Radius.circular(
      getHorizontalSize(
        33,
      ),
    ),
  );

  static BorderRadius customBorderTL35 = BorderRadius.only(
    topLeft: Radius.circular(
      getHorizontalSize(
        35,
      ),
    ),
  );

  static BorderRadius roundedBorder190 = BorderRadius.circular(
    getHorizontalSize(
      190,
    ),
  );

  static BorderRadius customBorderTL6 = BorderRadius.only(
    topLeft: Radius.circular(
      getHorizontalSize(
        6,
      ),
    ),
    bottomLeft: Radius.circular(
      getHorizontalSize(
        6,
      ),
    ),
  );

  static BorderRadius txtRoundedBorder10 = BorderRadius.circular(
    getHorizontalSize(
      10,
    ),
  );

  static BorderRadius customBorderTL16 = BorderRadius.only(
    topLeft: Radius.circular(
      getHorizontalSize(
        16,
      ),
    ),
    bottomLeft: Radius.circular(
      getHorizontalSize(
        16,
      ),
    ),
  );

  static BorderRadius customBorderTL15 = BorderRadius.only(
    topLeft: Radius.circular(
      getHorizontalSize(
        15,
      ),
    ),
    topRight: Radius.circular(
      getHorizontalSize(
        15,
      ),
    ),
  );

  static BorderRadius customBorderTL7 = BorderRadius.only(
    topLeft: Radius.circular(
      getHorizontalSize(
        7,
      ),
    ),
    topRight: Radius.circular(
      getHorizontalSize(
        7,
      ),
    ),
  );

  static BorderRadius txtRoundedBorder14 = BorderRadius.circular(
    getHorizontalSize(
      14,
    ),
  );

  static BorderRadius roundedBorder15 = BorderRadius.circular(
    getHorizontalSize(
      15,
    ),
  );

  static BorderRadius roundedBorder5 = BorderRadius.circular(
    getHorizontalSize(
      5,
    ),
  );

  static BorderRadius roundedBorder37 = BorderRadius.circular(
    getHorizontalSize(
      37,
    ),
  );

  static BorderRadius roundedBorder26 = BorderRadius.circular(
    getHorizontalSize(
      26,
    ),
  );

  static BorderRadius roundedBorder133 = BorderRadius.circular(
    getHorizontalSize(
      133,
    ),
  );

  static BorderRadius roundedBorder10 = BorderRadius.circular(
    getHorizontalSize(
      10,
    ),
  );

  static BorderRadius roundedBorder21 = BorderRadius.circular(
    getHorizontalSize(
      21,
    ),
  );

  static BorderRadius roundedBorder54 = BorderRadius.circular(
    getHorizontalSize(
      54,
    ),
  );

  static BorderRadius roundedBorder1 = BorderRadius.circular(
    getHorizontalSize(
      1,
    ),
  );

  static BorderRadius roundedBorder33 = BorderRadius.circular(
    getHorizontalSize(
      33,
    ),
  );

  static BorderRadius roundedBorder30 = BorderRadius.circular(
    getHorizontalSize(
      30,
    ),
  );

  static BorderRadius txtRoundedBorder7 = BorderRadius.circular(
    getHorizontalSize(
      7,
    ),
  );

  static BorderRadius roundedBorder40 = BorderRadius.circular(
    getHorizontalSize(
      40,
    ),
  );
}

// Comment/Uncomment the below code based on your Flutter SDK version.
    
// For Flutter SDK Version 3.7.2 or greater.
    
double get strokeAlignInside => BorderSide.strokeAlignInside;

double get strokeAlignCenter => BorderSide.strokeAlignCenter;

double get strokeAlignOutside => BorderSide.strokeAlignOutside;

// For Flutter SDK Version 3.7.1 or less.

// StrokeAlign get strokeAlignInside => StrokeAlign.inside;
//
// StrokeAlign get strokeAlignCenter => StrokeAlign.center;
//
// StrokeAlign get strokeAlignOutside => StrokeAlign.outside;
    