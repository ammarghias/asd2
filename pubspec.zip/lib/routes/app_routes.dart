import 'package:flutter/material.dart';
import 'package:ammar_s_application4/presentation/icon_screen/icon_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_one_screen/splash_screen_one_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_two_screen/splash_screen_two_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_three_screen/splash_screen_three_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_four_screen/splash_screen_four_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_five_screen/splash_screen_five_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_six_screen/splash_screen_six_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_seven_screen/splash_screen_seven_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_eight_screen/splash_screen_eight_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_nine_screen/splash_screen_nine_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_ten_screen/splash_screen_ten_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_eleven_screen/splash_screen_eleven_screen.dart';
import 'package:ammar_s_application4/presentation/login_page_page_login_screen/login_page_page_login_screen.dart';
import 'package:ammar_s_application4/presentation/login_error_page_screen/login_error_page_screen.dart';
import 'package:ammar_s_application4/presentation/password_reset_page_one_screen/password_reset_page_one_screen.dart';
import 'package:ammar_s_application4/presentation/password_reset_page_2_mfa_authentication_screen/password_reset_page_2_mfa_authentication_screen.dart';
import 'package:ammar_s_application4/presentation/password_reset_page_3_update_value_screen/password_reset_page_3_update_value_screen.dart';
import 'package:ammar_s_application4/presentation/password_reset_page_4_updated_screen/password_reset_page_4_updated_screen.dart';
import 'package:ammar_s_application4/presentation/loading_screen_state_loading_screen/loading_screen_state_loading_screen.dart';
import 'package:ammar_s_application4/presentation/menu_bar_page_menu_tabs_screen/menu_bar_page_menu_tabs_screen.dart';
import 'package:ammar_s_application4/presentation/email_help_screen/email_help_screen.dart';
import 'package:ammar_s_application4/presentation/email_non_registry_screen/email_non_registry_screen.dart';
import 'package:ammar_s_application4/presentation/email_partner_one_screen/email_partner_one_screen.dart';
import 'package:ammar_s_application4/presentation/email_partner_screen/email_partner_screen.dart';
import 'package:ammar_s_application4/presentation/registration_one_screen/registration_one_screen.dart';
import 'package:ammar_s_application4/presentation/registration_2_mfa_authentication_screen/registration_2_mfa_authentication_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_twelve_screen/splash_screen_twelve_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_fifteen_screen/splash_screen_fifteen_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_fourteen_screen/splash_screen_fourteen_screen.dart';
import 'package:ammar_s_application4/presentation/registraion_3_welcome_four_screen/registraion_3_welcome_four_screen.dart';
import 'package:ammar_s_application4/presentation/registraion_3_welcome_five_screen/registraion_3_welcome_five_screen.dart';
import 'package:ammar_s_application4/presentation/registraion_3_welcome_six_screen/registraion_3_welcome_six_screen.dart';
import 'package:ammar_s_application4/presentation/registration_terms_and_conditions_screen/registration_terms_and_conditions_screen.dart';
import 'package:ammar_s_application4/presentation/registration_wallet_update_screen/registration_wallet_update_screen.dart';
import 'package:ammar_s_application4/presentation/home_page_container_screen/home_page_container_screen.dart';
import 'package:ammar_s_application4/presentation/card_management_one_screen/card_management_one_screen.dart';
import 'package:ammar_s_application4/presentation/reward_catalog_one_screen/reward_catalog_one_screen.dart';
import 'package:ammar_s_application4/presentation/pay_from_points_screen/pay_from_points_screen.dart';
import 'package:ammar_s_application4/presentation/profile_page_screen/profile_page_screen.dart';
import 'package:ammar_s_application4/presentation/menu_screen/menu_screen.dart';
import 'package:ammar_s_application4/presentation/cashback_card_page_screen/cashback_card_page_screen.dart';
import 'package:ammar_s_application4/presentation/savings_estimator_screen/savings_estimator_screen.dart';
import 'package:ammar_s_application4/presentation/featured_screen/featured_screen.dart';
import 'package:ammar_s_application4/presentation/notification_center_screen/notification_center_screen.dart';
import 'package:ammar_s_application4/presentation/terms_and_disclosures_screen/terms_and_disclosures_screen.dart';
import 'package:ammar_s_application4/presentation/featured_one_screen/featured_one_screen.dart';
import 'package:ammar_s_application4/presentation/card_management_two_screen/card_management_two_screen.dart';
import 'package:ammar_s_application4/presentation/reward_catalog_two_screen/reward_catalog_two_screen.dart';
import 'package:ammar_s_application4/presentation/user_profile_screen/user_profile_screen.dart';
import 'package:ammar_s_application4/presentation/vastwo_screen/vastwo_screen.dart';
import 'package:ammar_s_application4/presentation/annual_credits_screen/annual_credits_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_sixteen_screen/splash_screen_sixteen_screen.dart';
import 'package:ammar_s_application4/presentation/categories_screen/categories_screen.dart';
import 'package:ammar_s_application4/presentation/user_wallet_management_screen/user_wallet_management_screen.dart';
import 'package:ammar_s_application4/presentation/reward_catalog_settings_screen/reward_catalog_settings_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_seventeen_screen/splash_screen_seventeen_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_eighteen_screen/splash_screen_eighteen_screen.dart';
import 'package:ammar_s_application4/presentation/bank_card_management_four_screen/bank_card_management_four_screen.dart';
import 'package:ammar_s_application4/presentation/welcome_bonus_screen/welcome_bonus_screen.dart';
import 'package:ammar_s_application4/presentation/splash_screen_nineteen_screen/splash_screen_nineteen_screen.dart';
import 'package:ammar_s_application4/presentation/frame_205_screen/frame_205_screen.dart';
import 'package:ammar_s_application4/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String iconScreen = '/icon_screen';

  static const String splashScreenOneScreen = '/splash_screen_one_screen';

  static const String splashScreenTwoScreen = '/splash_screen_two_screen';

  static const String splashScreenThreeScreen = '/splash_screen_three_screen';

  static const String splashScreenFourScreen = '/splash_screen_four_screen';

  static const String splashScreenFiveScreen = '/splash_screen_five_screen';

  static const String splashScreenSixScreen = '/splash_screen_six_screen';

  static const String splashScreenSevenScreen = '/splash_screen_seven_screen';

  static const String splashScreenEightScreen = '/splash_screen_eight_screen';

  static const String splashScreenNineScreen = '/splash_screen_nine_screen';

  static const String splashScreenTenScreen = '/splash_screen_ten_screen';

  static const String splashScreenElevenScreen = '/splash_screen_eleven_screen';

  static const String loginPagePageLoginScreen =
      '/login_page_page_login_screen';

  static const String loginErrorPageScreen = '/login_error_page_screen';

  static const String passwordResetPageOneScreen =
      '/password_reset_page_one_screen';

  static const String passwordResetPage2MfaAuthenticationScreen =
      '/password_reset_page_2_mfa_authentication_screen';

  static const String passwordResetPage3UpdateValueScreen =
      '/password_reset_page_3_update_value_screen';

  static const String passwordResetPage4UpdatedScreen =
      '/password_reset_page_4_updated_screen';

  static const String loadingScreenStateLoadingScreen =
      '/loading_screen_state_loading_screen';

  static const String menuBarPageMenuTabsScreen =
      '/menu_bar_page_menu_tabs_screen';

  static const String emailHelpScreen = '/email_help_screen';

  static const String emailNonRegistryScreen = '/email_non_registry_screen';

  static const String emailPartnerOneScreen = '/email_partner_one_screen';

  static const String emailPartnerScreen = '/email_partner_screen';

  static const String registrationOneScreen = '/registration_one_screen';

  static const String registration2MfaAuthenticationScreen =
      '/registration_2_mfa_authentication_screen';

  static const String splashScreenTwelveScreen = '/splash_screen_twelve_screen';

  static const String splashScreenFifteenScreen =
      '/splash_screen_fifteen_screen';

  static const String splashScreenFourteenScreen =
      '/splash_screen_fourteen_screen';

  static const String registraion3WelcomeFourScreen =
      '/registraion_3_welcome_four_screen';

  static const String registraion3WelcomeFiveScreen =
      '/registraion_3_welcome_five_screen';

  static const String registraion3WelcomeSixScreen =
      '/registraion_3_welcome_six_screen';

  static const String registrationTermsAndConditionsScreen =
      '/registration_terms_and_conditions_screen';

  static const String registrationWalletUpdateScreen =
      '/registration_wallet_update_screen';

  static const String homePage = '/home_page';

  static const String homePageContainerScreen = '/home_page_container_screen';

  static const String cardManagementOneScreen = '/card_management_one_screen';

  static const String rewardCatalogOneScreen = '/reward_catalog_one_screen';

  static const String payFromPointsScreen = '/pay_from_points_screen';

  static const String profilePageScreen = '/profile_page_screen';

  static const String menuScreen = '/menu_screen';

  static const String cashbackCardPageScreen = '/cashback_card_page_screen';

  static const String savingsEstimatorScreen = '/savings_estimator_screen';

  static const String featuredScreen = '/featured_screen';

  static const String notificationCenterScreen = '/notification_center_screen';

  static const String termsAndDisclosuresScreen =
      '/terms_and_disclosures_screen';

  static const String featuredOneScreen = '/featured_one_screen';

  static const String cardManagementTwoScreen = '/card_management_two_screen';

  static const String rewardCatalogTwoScreen = '/reward_catalog_two_screen';

  static const String userProfileScreen = '/user_profile_screen';

  static const String vastwoScreen = '/vastwo_screen';

  static const String annualCreditsScreen = '/annual_credits_screen';

  static const String splashScreenSixteenScreen =
      '/splash_screen_sixteen_screen';

  static const String categoriesScreen = '/categories_screen';

  static const String userWalletManagementScreen =
      '/user_wallet_management_screen';

  static const String rewardCatalogSettingsScreen =
      '/reward_catalog_settings_screen';

  static const String splashScreenSeventeenScreen =
      '/splash_screen_seventeen_screen';

  static const String splashScreenEighteenScreen =
      '/splash_screen_eighteen_screen';

  static const String bankCardManagementFourScreen =
      '/bank_card_management_four_screen';

  static const String welcomeBonusScreen = '/welcome_bonus_screen';

  static const String splashScreenNineteenScreen =
      '/splash_screen_nineteen_screen';

  static const String frame205Screen = '/frame_205_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        iconScreen: IconScreen.builder,
        splashScreenOneScreen: SplashScreenOneScreen.builder,
        splashScreenTwoScreen: SplashScreenTwoScreen.builder,
        splashScreenThreeScreen: SplashScreenThreeScreen.builder,
        splashScreenFourScreen: SplashScreenFourScreen.builder,
        splashScreenFiveScreen: SplashScreenFiveScreen.builder,
        splashScreenSixScreen: SplashScreenSixScreen.builder,
        splashScreenSevenScreen: SplashScreenSevenScreen.builder,
        splashScreenEightScreen: SplashScreenEightScreen.builder,
        splashScreenNineScreen: SplashScreenNineScreen.builder,
        splashScreenTenScreen: SplashScreenTenScreen.builder,
        splashScreenElevenScreen: SplashScreenElevenScreen.builder,
        loginPagePageLoginScreen: LoginPagePageLoginScreen.builder,
        loginErrorPageScreen: LoginErrorPageScreen.builder,
        passwordResetPageOneScreen: PasswordResetPageOneScreen.builder,
        passwordResetPage2MfaAuthenticationScreen:
            PasswordResetPage2MfaAuthenticationScreen.builder,
        passwordResetPage3UpdateValueScreen:
            PasswordResetPage3UpdateValueScreen.builder,
        passwordResetPage4UpdatedScreen:
            PasswordResetPage4UpdatedScreen.builder,
        loadingScreenStateLoadingScreen:
            LoadingScreenStateLoadingScreen.builder,
        menuBarPageMenuTabsScreen: MenuBarPageMenuTabsScreen.builder,
        emailHelpScreen: EmailHelpScreen.builder,
        emailNonRegistryScreen: EmailNonRegistryScreen.builder,
        emailPartnerOneScreen: EmailPartnerOneScreen.builder,
        emailPartnerScreen: EmailPartnerScreen.builder,
        registrationOneScreen: RegistrationOneScreen.builder,
        registration2MfaAuthenticationScreen:
            Registration2MfaAuthenticationScreen.builder,
        splashScreenTwelveScreen: SplashScreenTwelveScreen.builder,
        splashScreenFifteenScreen: SplashScreenFifteenScreen.builder,
        splashScreenFourteenScreen: SplashScreenFourteenScreen.builder,
        registraion3WelcomeFourScreen: Registraion3WelcomeFourScreen.builder,
        registraion3WelcomeFiveScreen: Registraion3WelcomeFiveScreen.builder,
        registraion3WelcomeSixScreen: Registraion3WelcomeSixScreen.builder,
        registrationTermsAndConditionsScreen:
            RegistrationTermsAndConditionsScreen.builder,
        registrationWalletUpdateScreen: RegistrationWalletUpdateScreen.builder,
        homePageContainerScreen: HomePageContainerScreen.builder,
        cardManagementOneScreen: CardManagementOneScreen.builder,
        rewardCatalogOneScreen: RewardCatalogOneScreen.builder,
        payFromPointsScreen: PayFromPointsScreen.builder,
        profilePageScreen: ProfilePageScreen.builder,
        menuScreen: MenuScreen.builder,
        cashbackCardPageScreen: CashbackCardPageScreen.builder,
        savingsEstimatorScreen: SavingsEstimatorScreen.builder,
        featuredScreen: FeaturedScreen.builder,
        notificationCenterScreen: NotificationCenterScreen.builder,
        termsAndDisclosuresScreen: TermsAndDisclosuresScreen.builder,
        featuredOneScreen: FeaturedOneScreen.builder,
        cardManagementTwoScreen: CardManagementTwoScreen.builder,
        rewardCatalogTwoScreen: RewardCatalogTwoScreen.builder,
        userProfileScreen: UserProfileScreen.builder,
        vastwoScreen: VastwoScreen.builder,
        annualCreditsScreen: AnnualCreditsScreen.builder,
        splashScreenSixteenScreen: SplashScreenSixteenScreen.builder,
        categoriesScreen: CategoriesScreen.builder,
        userWalletManagementScreen: UserWalletManagementScreen.builder,
        rewardCatalogSettingsScreen: RewardCatalogSettingsScreen.builder,
        splashScreenSeventeenScreen: SplashScreenSeventeenScreen.builder,
        splashScreenEighteenScreen: SplashScreenEighteenScreen.builder,
        bankCardManagementFourScreen: BankCardManagementFourScreen.builder,
        welcomeBonusScreen: WelcomeBonusScreen.builder,
        splashScreenNineteenScreen: SplashScreenNineteenScreen.builder,
        frame205Screen: Frame205Screen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: IconScreen.builder
      };
}
