// ignore_for_file: must_be_immutable

part of 'menu_bar_page_menu_tabs_bloc.dart';

@immutable
abstract class MenuBarPageMenuTabsEvent extends Equatable {}

class MenuBarPageMenuTabsInitialEvent extends MenuBarPageMenuTabsEvent {
  @override
  List<Object?> get props => [];
}
