// ignore_for_file: must_be_immutable

part of 'menu_bar_page_menu_tabs_bloc.dart';

class MenuBarPageMenuTabsState extends Equatable {
  MenuBarPageMenuTabsState({this.menuBarPageMenuTabsModelObj});

  MenuBarPageMenuTabsModel? menuBarPageMenuTabsModelObj;

  @override
  List<Object?> get props => [
        menuBarPageMenuTabsModelObj,
      ];
  MenuBarPageMenuTabsState copyWith(
      {MenuBarPageMenuTabsModel? menuBarPageMenuTabsModelObj}) {
    return MenuBarPageMenuTabsState(
      menuBarPageMenuTabsModelObj:
          menuBarPageMenuTabsModelObj ?? this.menuBarPageMenuTabsModelObj,
    );
  }
}
