import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/menu_bar_page_menu_tabs_screen/models/menu_bar_page_menu_tabs_model.dart';
part 'menu_bar_page_menu_tabs_event.dart';
part 'menu_bar_page_menu_tabs_state.dart';

class MenuBarPageMenuTabsBloc
    extends Bloc<MenuBarPageMenuTabsEvent, MenuBarPageMenuTabsState> {
  MenuBarPageMenuTabsBloc(MenuBarPageMenuTabsState initialState)
      : super(initialState) {
    on<MenuBarPageMenuTabsInitialEvent>(_onInitialize);
  }

  _onInitialize(
    MenuBarPageMenuTabsInitialEvent event,
    Emitter<MenuBarPageMenuTabsState> emit,
  ) async {}
}
