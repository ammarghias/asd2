import 'bloc/menu_bar_page_menu_tabs_bloc.dart';
import 'models/menu_bar_page_menu_tabs_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/presentation/home_page/home_page.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

class MenuBarPageMenuTabsScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<MenuBarPageMenuTabsBloc>(
      create: (context) => MenuBarPageMenuTabsBloc(MenuBarPageMenuTabsState(
        menuBarPageMenuTabsModelObj: MenuBarPageMenuTabsModel(),
      ))
        ..add(MenuBarPageMenuTabsInitialEvent()),
      child: MenuBarPageMenuTabsScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MenuBarPageMenuTabsBloc, MenuBarPageMenuTabsState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: SizedBox(
              width: size.width,
              child: SingleChildScrollView(
                child: Container(
                  height: getVerticalSize(
                    984,
                  ),
                  width: double.maxFinite,
                ),
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group1:
        return AppRoutes.homePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(BuildContext context, String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
