import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class MenuBarPageMenuTabsModel extends Equatable {MenuBarPageMenuTabsModel copyWith() { return MenuBarPageMenuTabsModel(
); } 
@override List<Object?> get props => [];
 }
