import '../models/pay_from_points_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/widgets/custom_checkbox.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class PayFromPointsItemWidget extends StatelessWidget {
  PayFromPointsItemWidget(this.payFromPointsItemModelObj,
      {this.changeCheckBox});

  PayFromPointsItemModel payFromPointsItemModelObj;

  Function(bool)? changeCheckBox;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        CustomImageView(
          svgPath: ImageConstant.imgClose,
          height: getSize(
            29,
          ),
          width: getSize(
            29,
          ),
          radius: BorderRadius.circular(
            getHorizontalSize(
              3,
            ),
          ),
        ),
        Container(
          height: getVerticalSize(
            27,
          ),
          width: getHorizontalSize(
            305,
          ),
          margin: getMargin(
            bottom: 2,
          ),
          child: Stack(
            alignment: Alignment.centerRight,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  padding: getPadding(
                    left: 6,
                    top: 1,
                    right: 6,
                    bottom: 1,
                  ),
                  decoration: AppDecoration.outlineGray50003.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder5,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: getPadding(
                          top: 2,
                        ),
                        child: Text(
                          payFromPointsItemModelObj.typeTxt,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoRomanRegular16,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: CustomCheckbox(
                  alignment: Alignment.centerRight,
                  text: "lbl_999_000".tr,
                  value: payFromPointsItemModelObj.isCheckbox,
                  fontStyle: CheckboxFontStyle.RobotoRomanRegular16,
                  onChange: (value) {
                    changeCheckBox?.call(value);
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
