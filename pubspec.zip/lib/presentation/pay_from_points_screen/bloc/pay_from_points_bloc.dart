import '../models/pay_from_points_item_model.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/pay_from_points_item_model.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/pay_from_points_screen/models/pay_from_points_model.dart';
part 'pay_from_points_event.dart';
part 'pay_from_points_state.dart';

class PayFromPointsBloc extends Bloc<PayFromPointsEvent, PayFromPointsState> {
  PayFromPointsBloc(PayFromPointsState initialState) : super(initialState) {
    on<PayFromPointsInitialEvent>(_onInitialize);
    on<PayFromPointsItemEvent>(_payFromPointsItem);
  }

  _payFromPointsItem(
    PayFromPointsItemEvent event,
    Emitter<PayFromPointsState> emit,
  ) {
    List<PayFromPointsItemModel> newList = List<PayFromPointsItemModel>.from(
        state.payFromPointsModelObj!.payFromPointsItemList);
    newList[event.index] = newList[event.index].copyWith(
      isCheckbox: event.isCheckbox,
    );
    emit(state.copyWith(
        payFromPointsModelObj: state.payFromPointsModelObj
            ?.copyWith(payFromPointsItemList: newList)));
  }

  List<PayFromPointsItemModel> fillPayFromPointsItemList() {
    return List.generate(2, (index) => PayFromPointsItemModel());
  }

  _onInitialize(
    PayFromPointsInitialEvent event,
    Emitter<PayFromPointsState> emit,
  ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      group502Controller: TextEditingController(),
    ));
    emit(state.copyWith(
        payFromPointsModelObj: state.payFromPointsModelObj?.copyWith(
      payFromPointsItemList: fillPayFromPointsItemList(),
    )));
  }
}
