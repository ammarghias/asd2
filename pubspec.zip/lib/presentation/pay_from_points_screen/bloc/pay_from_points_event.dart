// ignore_for_file: must_be_immutable

part of 'pay_from_points_bloc.dart';

@immutable
abstract class PayFromPointsEvent extends Equatable {}

class PayFromPointsInitialEvent extends PayFromPointsEvent {
  @override
  List<Object?> get props => [];
}

class PayFromPointsItemEvent extends PayFromPointsEvent {
  PayFromPointsItemEvent({
    required this.index,
    this.isCheckbox,
  });

  int index;

  bool? isCheckbox;

  @override
  List<Object?> get props => [
        index,
        isCheckbox,
      ];
}
