// ignore_for_file: must_be_immutable

part of 'pay_from_points_bloc.dart';

class PayFromPointsState extends Equatable {
  PayFromPointsState({
    this.nameController,
    this.group502Controller,
    this.payFromPointsModelObj,
  });

  TextEditingController? nameController;

  TextEditingController? group502Controller;

  PayFromPointsModel? payFromPointsModelObj;

  @override
  List<Object?> get props => [
        nameController,
        group502Controller,
        payFromPointsModelObj,
      ];
  PayFromPointsState copyWith({
    TextEditingController? nameController,
    TextEditingController? group502Controller,
    PayFromPointsModel? payFromPointsModelObj,
  }) {
    return PayFromPointsState(
      nameController: nameController ?? this.nameController,
      group502Controller: group502Controller ?? this.group502Controller,
      payFromPointsModelObj:
          payFromPointsModelObj ?? this.payFromPointsModelObj,
    );
  }
}
