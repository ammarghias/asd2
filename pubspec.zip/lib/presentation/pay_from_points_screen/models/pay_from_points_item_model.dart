import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class PayFromPointsItemModel extends Equatable {PayFromPointsItemModel({this.typeTxt = "American Express", this.isCheckbox = false, this.id});

String typeTxt;

bool isCheckbox;

String? id;

PayFromPointsItemModel copyWith({String? typeTxt, bool? isCheckbox, String? id}) { return PayFromPointsItemModel(
typeTxt : typeTxt ?? this.typeTxt,
isCheckbox : isCheckbox ?? this.isCheckbox,
id : id ?? this.id,
); } 
@override List<Object?> get props => [typeTxt,isCheckbox,id];
 }
