import 'package:equatable/equatable.dart';import 'pay_from_points_item_model.dart';
// ignore: must_be_immutable
class PayFromPointsModel extends Equatable {PayFromPointsModel({this.payFromPointsItemList = const []});

List<PayFromPointsItemModel> payFromPointsItemList;

PayFromPointsModel copyWith({List<PayFromPointsItemModel>? payFromPointsItemList}) { return PayFromPointsModel(
payFromPointsItemList : payFromPointsItemList ?? this.payFromPointsItemList,
); } 
@override List<Object?> get props => [payFromPointsItemList];
 }
