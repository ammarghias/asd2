import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class PasswordResetPage2MfaAuthenticationModel extends Equatable {PasswordResetPage2MfaAuthenticationModel copyWith() { return PasswordResetPage2MfaAuthenticationModel(
); } 
@override List<Object?> get props => [];
 }
