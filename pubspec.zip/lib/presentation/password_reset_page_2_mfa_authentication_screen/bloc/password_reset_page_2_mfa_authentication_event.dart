// ignore_for_file: must_be_immutable

part of 'password_reset_page_2_mfa_authentication_bloc.dart';

@immutable
abstract class PasswordResetPage2MfaAuthenticationEvent extends Equatable {}

class PasswordResetPage2MfaAuthenticationInitialEvent
    extends PasswordResetPage2MfaAuthenticationEvent {
  @override
  List<Object?> get props => [];
}
