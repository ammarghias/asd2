// ignore_for_file: must_be_immutable

part of 'password_reset_page_2_mfa_authentication_bloc.dart';

class PasswordResetPage2MfaAuthenticationState extends Equatable {
  PasswordResetPage2MfaAuthenticationState(
      {this.passwordResetPage2MfaAuthenticationModelObj});

  PasswordResetPage2MfaAuthenticationModel?
      passwordResetPage2MfaAuthenticationModelObj;

  @override
  List<Object?> get props => [
        passwordResetPage2MfaAuthenticationModelObj,
      ];
  PasswordResetPage2MfaAuthenticationState copyWith(
      {PasswordResetPage2MfaAuthenticationModel?
          passwordResetPage2MfaAuthenticationModelObj}) {
    return PasswordResetPage2MfaAuthenticationState(
      passwordResetPage2MfaAuthenticationModelObj:
          passwordResetPage2MfaAuthenticationModelObj ??
              this.passwordResetPage2MfaAuthenticationModelObj,
    );
  }
}
