import 'bloc/splash_screen_one_bloc.dart';
import 'models/splash_screen_one_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class SplashScreenOneScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<SplashScreenOneBloc>(
      create: (context) => SplashScreenOneBloc(SplashScreenOneState(
        splashScreenOneModelObj: SplashScreenOneModel(),
      ))
        ..add(SplashScreenOneInitialEvent()),
      child: SplashScreenOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenOneBloc, SplashScreenOneState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: CustomButton(
              width: double.maxFinite,
              text: "lbl_cashback".tr,
              variant: ButtonVariant.FillWhiteA700,
              shape: ButtonShape.Square,
              padding: ButtonPadding.PaddingT383,
              fontStyle: ButtonFontStyle.LEMONMILKMedium65,
            ),
          ),
        );
      },
    );
  }
}
