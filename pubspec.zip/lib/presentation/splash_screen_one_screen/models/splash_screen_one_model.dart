import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenOneModel extends Equatable {SplashScreenOneModel copyWith() { return SplashScreenOneModel(
); } 
@override List<Object?> get props => [];
 }
