// ignore_for_file: must_be_immutable

part of 'splash_screen_one_bloc.dart';

@immutable
abstract class SplashScreenOneEvent extends Equatable {}

class SplashScreenOneInitialEvent extends SplashScreenOneEvent {
  @override
  List<Object?> get props => [];
}
