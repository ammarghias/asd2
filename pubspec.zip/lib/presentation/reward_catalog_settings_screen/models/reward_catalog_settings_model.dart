import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class RewardCatalogSettingsModel extends Equatable {RewardCatalogSettingsModel copyWith() { return RewardCatalogSettingsModel(
); } 
@override List<Object?> get props => [];
 }
