// ignore_for_file: must_be_immutable

part of 'reward_catalog_settings_bloc.dart';

@immutable
abstract class RewardCatalogSettingsEvent extends Equatable {}

class RewardCatalogSettingsInitialEvent extends RewardCatalogSettingsEvent {
  @override
  List<Object?> get props => [];
}
