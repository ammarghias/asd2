import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class EmailNonRegistryModel extends Equatable {EmailNonRegistryModel copyWith() { return EmailNonRegistryModel(
); } 
@override List<Object?> get props => [];
 }
