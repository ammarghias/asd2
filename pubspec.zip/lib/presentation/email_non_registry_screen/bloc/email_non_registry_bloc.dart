import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application4/presentation/email_non_registry_screen/models/email_non_registry_model.dart';part 'email_non_registry_event.dart';part 'email_non_registry_state.dart';class EmailNonRegistryBloc extends Bloc<EmailNonRegistryEvent, EmailNonRegistryState> {EmailNonRegistryBloc(EmailNonRegistryState initialState) : super(initialState) { on<EmailNonRegistryInitialEvent>(_onInitialize); }

_onInitialize(EmailNonRegistryInitialEvent event, Emitter<EmailNonRegistryState> emit, ) async  { emit(state.copyWith(usernameController: TextEditingController())); } 
 }
