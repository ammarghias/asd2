// ignore_for_file: must_be_immutable

part of 'email_non_registry_bloc.dart';

@immutable
abstract class EmailNonRegistryEvent extends Equatable {}

class EmailNonRegistryInitialEvent extends EmailNonRegistryEvent {
  @override
  List<Object?> get props => [];
}
