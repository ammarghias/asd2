import 'bloc/splash_screen_five_bloc.dart';
import 'models/splash_screen_five_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

class SplashScreenFiveScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<SplashScreenFiveBloc>(
      create: (context) => SplashScreenFiveBloc(SplashScreenFiveState(
        splashScreenFiveModelObj: SplashScreenFiveModel(),
      ))
        ..add(SplashScreenFiveInitialEvent()),
      child: SplashScreenFiveScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenFiveBloc, SplashScreenFiveState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: getPadding(
                          left: 13,
                          right: 13,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
