// ignore_for_file: must_be_immutable

part of 'splash_screen_five_bloc.dart';

class SplashScreenFiveState extends Equatable {
  SplashScreenFiveState({this.splashScreenFiveModelObj});

  SplashScreenFiveModel? splashScreenFiveModelObj;

  @override
  List<Object?> get props => [
        splashScreenFiveModelObj,
      ];
  SplashScreenFiveState copyWith(
      {SplashScreenFiveModel? splashScreenFiveModelObj}) {
    return SplashScreenFiveState(
      splashScreenFiveModelObj:
          splashScreenFiveModelObj ?? this.splashScreenFiveModelObj,
    );
  }
}
