import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_five_screen/models/splash_screen_five_model.dart';
part 'splash_screen_five_event.dart';
part 'splash_screen_five_state.dart';

class SplashScreenFiveBloc
    extends Bloc<SplashScreenFiveEvent, SplashScreenFiveState> {
  SplashScreenFiveBloc(SplashScreenFiveState initialState)
      : super(initialState) {
    on<SplashScreenFiveInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenFiveInitialEvent event,
    Emitter<SplashScreenFiveState> emit,
  ) async {}
}
