// ignore_for_file: must_be_immutable

part of 'splash_screen_five_bloc.dart';

@immutable
abstract class SplashScreenFiveEvent extends Equatable {}

class SplashScreenFiveInitialEvent extends SplashScreenFiveEvent {
  @override
  List<Object?> get props => [];
}
