import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenFiveModel extends Equatable {SplashScreenFiveModel copyWith() { return SplashScreenFiveModel(
); } 
@override List<Object?> get props => [];
 }
