import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/profile_page_screen/models/profile_page_model.dart';
part 'profile_page_event.dart';
part 'profile_page_state.dart';

class ProfilePageBloc extends Bloc<ProfilePageEvent, ProfilePageState> {
  ProfilePageBloc(ProfilePageState initialState) : super(initialState) {
    on<ProfilePageInitialEvent>(_onInitialize);
  }

  _onInitialize(
    ProfilePageInitialEvent event,
    Emitter<ProfilePageState> emit,
  ) async {}
}
