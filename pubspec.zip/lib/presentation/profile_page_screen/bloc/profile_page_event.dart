// ignore_for_file: must_be_immutable

part of 'profile_page_bloc.dart';

@immutable
abstract class ProfilePageEvent extends Equatable {}

class ProfilePageInitialEvent extends ProfilePageEvent {
  @override
  List<Object?> get props => [];
}
