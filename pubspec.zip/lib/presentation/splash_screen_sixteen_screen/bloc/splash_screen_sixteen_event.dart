// ignore_for_file: must_be_immutable

part of 'splash_screen_sixteen_bloc.dart';

@immutable
abstract class SplashScreenSixteenEvent extends Equatable {}

class SplashScreenSixteenInitialEvent extends SplashScreenSixteenEvent {
  @override
  List<Object?> get props => [];
}
