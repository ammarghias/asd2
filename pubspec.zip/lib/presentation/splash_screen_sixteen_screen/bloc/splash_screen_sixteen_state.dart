// ignore_for_file: must_be_immutable

part of 'splash_screen_sixteen_bloc.dart';

class SplashScreenSixteenState extends Equatable {
  SplashScreenSixteenState({this.splashScreenSixteenModelObj});

  SplashScreenSixteenModel? splashScreenSixteenModelObj;

  @override
  List<Object?> get props => [
        splashScreenSixteenModelObj,
      ];
  SplashScreenSixteenState copyWith(
      {SplashScreenSixteenModel? splashScreenSixteenModelObj}) {
    return SplashScreenSixteenState(
      splashScreenSixteenModelObj:
          splashScreenSixteenModelObj ?? this.splashScreenSixteenModelObj,
    );
  }
}
