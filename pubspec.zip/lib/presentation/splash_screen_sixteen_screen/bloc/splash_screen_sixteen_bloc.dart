import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_sixteen_screen/models/splash_screen_sixteen_model.dart';
part 'splash_screen_sixteen_event.dart';
part 'splash_screen_sixteen_state.dart';

class SplashScreenSixteenBloc
    extends Bloc<SplashScreenSixteenEvent, SplashScreenSixteenState> {
  SplashScreenSixteenBloc(SplashScreenSixteenState initialState)
      : super(initialState) {
    on<SplashScreenSixteenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenSixteenInitialEvent event,
    Emitter<SplashScreenSixteenState> emit,
  ) async {}
}
