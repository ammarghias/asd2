import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenSixteenModel extends Equatable {SplashScreenSixteenModel copyWith() { return SplashScreenSixteenModel(
); } 
@override List<Object?> get props => [];
 }
