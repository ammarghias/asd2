import '../models/gridname_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class GridnameItemWidget extends StatelessWidget {
  GridnameItemWidget(this.gridnameItemModelObj);

  GridnameItemModel gridnameItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        padding: getPadding(
          all: 3,
        ),
        decoration: AppDecoration.outlineGray300.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder10,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgImage7370x93,
              height: getVerticalSize(
                70,
              ),
              width: getHorizontalSize(
                93,
              ),
              radius: BorderRadius.circular(
                getHorizontalSize(
                  7,
                ),
              ),
            ),
            Padding(
              padding: getPadding(
                top: 9,
                bottom: 8,
              ),
              child: Text(
                gridnameItemModelObj.nameTxt,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtInterRegular11,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
