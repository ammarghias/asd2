import 'package:equatable/equatable.dart';import 'gridname_item_model.dart';import 'gridname1_item_model.dart';
// ignore: must_be_immutable
class CardManagementOneModel extends Equatable {CardManagementOneModel({this.gridnameItemList = const [], this.gridname1ItemList = const []});

List<GridnameItemModel> gridnameItemList;

List<Gridname1ItemModel> gridname1ItemList;

CardManagementOneModel copyWith({List<GridnameItemModel>? gridnameItemList, List<Gridname1ItemModel>? gridname1ItemList}) { return CardManagementOneModel(
gridnameItemList : gridnameItemList ?? this.gridnameItemList,
gridname1ItemList : gridname1ItemList ?? this.gridname1ItemList,
); } 
@override List<Object?> get props => [gridnameItemList,gridname1ItemList];
 }
