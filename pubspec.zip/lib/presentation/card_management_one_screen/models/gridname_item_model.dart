class GridnameItemModel {String nameTxt = "Chase";

String? id = "";

 }
