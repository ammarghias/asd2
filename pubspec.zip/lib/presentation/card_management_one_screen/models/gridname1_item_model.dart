class Gridname1ItemModel {String nameTxt = "Synchrony Bank";

String? id = "";

 }
