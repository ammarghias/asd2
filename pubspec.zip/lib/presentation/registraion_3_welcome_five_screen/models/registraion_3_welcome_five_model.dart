import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class Registraion3WelcomeFiveModel extends Equatable {Registraion3WelcomeFiveModel copyWith() { return Registraion3WelcomeFiveModel(
); } 
@override List<Object?> get props => [];
 }
