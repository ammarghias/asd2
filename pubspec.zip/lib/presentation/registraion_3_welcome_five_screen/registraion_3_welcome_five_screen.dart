import 'bloc/registraion_3_welcome_five_bloc.dart';
import 'models/registraion_3_welcome_five_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class Registraion3WelcomeFiveScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<Registraion3WelcomeFiveBloc>(
      create: (context) =>
          Registraion3WelcomeFiveBloc(Registraion3WelcomeFiveState(
        registraion3WelcomeFiveModelObj: Registraion3WelcomeFiveModel(),
      ))
            ..add(Registraion3WelcomeFiveInitialEvent()),
      child: Registraion3WelcomeFiveScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<Registraion3WelcomeFiveBloc,
        Registraion3WelcomeFiveState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            appBar: CustomAppBar(
              height: getVerticalSize(
                79,
              ),
              centerTitle: true,
              title: Container(
                height: getVerticalSize(
                  48,
                ),
                width: getHorizontalSize(
                  268,
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    AppbarImage(
                      height: getVerticalSize(
                        47,
                      ),
                      width: getHorizontalSize(
                        268,
                      ),
                      svgPath: ImageConstant.imgGroupWhiteA70047x276,
                    ),
                    AppbarImage(
                      height: getVerticalSize(
                        48,
                      ),
                      width: getHorizontalSize(
                        42,
                      ),
                      svgPath: ImageConstant.imgVectorWhiteA700,
                      margin: getMargin(
                        left: 30,
                        right: 195,
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                AppbarImage(
                  height: getVerticalSize(
                    48,
                  ),
                  width: getHorizontalSize(
                    42,
                  ),
                  svgPath: ImageConstant.imgVectorWhiteA700,
                  margin: getMargin(
                    left: 120,
                    right: 120,
                  ),
                ),
              ],
            ),
            body: SizedBox(
              width: size.width,
              child: SingleChildScrollView(
                child: Container(
                  height: size.height,
                  width: getHorizontalSize(
                    380,
                  ),
                  child: Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      Align(
                        alignment: Alignment.topCenter,
                        child: Text(
                          "lbl_cashback".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtLEMONMILKMedium65,
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Padding(
                          padding: getPadding(
                            left: 13,
                            right: 3,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 176,
                                ),
                                child: Text(
                                  "lbl_cashback".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtLEMONMILKMedium65,
                                ),
                              ),
                              Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 260,
                                ),
                                child: Text(
                                  "lbl_cashback".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtLEMONMILKMedium65,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          height: size.height,
                          width: getHorizontalSize(
                            380,
                          ),
                          child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgEllipse17,
                                height: getVerticalSize(
                                  844,
                                ),
                                width: getHorizontalSize(
                                  380,
                                ),
                                alignment: Alignment.center,
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: getPadding(
                                        right: 65,
                                      ),
                                      child: Text(
                                        "lbl_wait_for_it".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtImprimaRegular20,
                                      ),
                                    ),
                                    Container(
                                      width: double.maxFinite,
                                      child: Container(
                                        margin: getMargin(
                                          top: 26,
                                        ),
                                        padding: getPadding(
                                          left: 22,
                                          top: 7,
                                          right: 22,
                                          bottom: 7,
                                        ),
                                        decoration: AppDecoration
                                            .outlineBlack900
                                            .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .customBorderTL30,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                right: 2,
                                              ),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Padding(
                                                    padding: getPadding(
                                                      bottom: 1,
                                                    ),
                                                    child: Text(
                                                      "lbl_back".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtHindVadodaraRegular20
                                                          .copyWith(
                                                        decoration:
                                                            TextDecoration
                                                                .underline,
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: getPadding(
                                                      top: 1,
                                                    ),
                                                    child: Text(
                                                      "lbl_skip".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtHindVadodaraRegular20
                                                          .copyWith(
                                                        decoration:
                                                            TextDecoration
                                                                .underline,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                left: 5,
                                                top: 45,
                                              ),
                                              child: Text(
                                                "lbl_step_1".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtImprimaRegular40,
                                              ),
                                            ),
                                            Container(
                                              width: getHorizontalSize(
                                                273,
                                              ),
                                              margin: getMargin(
                                                left: 5,
                                                top: 36,
                                                right: 55,
                                              ),
                                              child: Text(
                                                "msg_welcome_screen_about2".tr,
                                                maxLines: null,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular25Black900,
                                              ),
                                            ),
                                            Container(
                                              width: getHorizontalSize(
                                                175,
                                              ),
                                              margin: getMargin(
                                                left: 68,
                                                top: 78,
                                              ),
                                              child: Text(
                                                "lbl_graphic_screen".tr,
                                                maxLines: null,
                                                textAlign: TextAlign.center,
                                                style: AppStyle.txtInterBold45,
                                              ),
                                            ),
                                            CustomImageView(
                                              svgPath: ImageConstant.imgFrame68,
                                              height: getVerticalSize(
                                                18,
                                              ),
                                              width: getHorizontalSize(
                                                126,
                                              ),
                                              alignment: Alignment.center,
                                              margin: getMargin(
                                                top: 184,
                                                bottom: 27,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
