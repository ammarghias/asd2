import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/registraion_3_welcome_five_screen/models/registraion_3_welcome_five_model.dart';
part 'registraion_3_welcome_five_event.dart';
part 'registraion_3_welcome_five_state.dart';

class Registraion3WelcomeFiveBloc
    extends Bloc<Registraion3WelcomeFiveEvent, Registraion3WelcomeFiveState> {
  Registraion3WelcomeFiveBloc(Registraion3WelcomeFiveState initialState)
      : super(initialState) {
    on<Registraion3WelcomeFiveInitialEvent>(_onInitialize);
  }

  _onInitialize(
    Registraion3WelcomeFiveInitialEvent event,
    Emitter<Registraion3WelcomeFiveState> emit,
  ) async {}
}
