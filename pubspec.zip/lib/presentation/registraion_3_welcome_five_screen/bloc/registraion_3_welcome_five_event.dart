// ignore_for_file: must_be_immutable

part of 'registraion_3_welcome_five_bloc.dart';

@immutable
abstract class Registraion3WelcomeFiveEvent extends Equatable {}

class Registraion3WelcomeFiveInitialEvent extends Registraion3WelcomeFiveEvent {
  @override
  List<Object?> get props => [];
}
