// ignore_for_file: must_be_immutable

part of 'registraion_3_welcome_five_bloc.dart';

class Registraion3WelcomeFiveState extends Equatable {
  Registraion3WelcomeFiveState({this.registraion3WelcomeFiveModelObj});

  Registraion3WelcomeFiveModel? registraion3WelcomeFiveModelObj;

  @override
  List<Object?> get props => [
        registraion3WelcomeFiveModelObj,
      ];
  Registraion3WelcomeFiveState copyWith(
      {Registraion3WelcomeFiveModel? registraion3WelcomeFiveModelObj}) {
    return Registraion3WelcomeFiveState(
      registraion3WelcomeFiveModelObj: registraion3WelcomeFiveModelObj ??
          this.registraion3WelcomeFiveModelObj,
    );
  }
}
