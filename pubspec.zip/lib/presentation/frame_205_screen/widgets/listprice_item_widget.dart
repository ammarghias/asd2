import '../models/listprice_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListpriceItemWidget extends StatelessWidget {
  ListpriceItemWidget(this.listpriceItemModelObj);

  ListpriceItemModel listpriceItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: getVerticalSize(
        40,
      ),
      width: getHorizontalSize(
        301,
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: getPadding(
                left: 68,
              ),
              child: Text(
                "lbl_xx_xxx_4575".tr,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtInterMedium15Gray40087,
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Container(
              height: getVerticalSize(
                40,
              ),
              width: getHorizontalSize(
                301,
              ),
              child: Stack(
                alignment: Alignment.centerLeft,
                children: [
                  CustomImageView(
                    svgPath: ImageConstant.imgGroup1182,
                    height: getVerticalSize(
                      40,
                    ),
                    width: getHorizontalSize(
                      301,
                    ),
                    radius: BorderRadius.circular(
                      getHorizontalSize(
                        15,
                      ),
                    ),
                    alignment: Alignment.center,
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Card(
                      clipBehavior: Clip.antiAlias,
                      elevation: 0,
                      margin: EdgeInsets.all(0),
                      color: ColorConstant.blueGray50,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadiusStyle.customBorderTL16,
                      ),
                      child: Container(
                        height: getVerticalSize(
                          40,
                        ),
                        width: getHorizontalSize(
                          48,
                        ),
                        padding: getPadding(
                          left: 17,
                          top: 13,
                          right: 17,
                          bottom: 13,
                        ),
                        decoration: AppDecoration.fillBluegray50.copyWith(
                          borderRadius: BorderRadiusStyle.customBorderTL16,
                        ),
                        child: Stack(
                          children: [
                            CustomImageView(
                              svgPath: ImageConstant.imgPhoneicon,
                              height: getSize(
                                14,
                              ),
                              width: getSize(
                                14,
                              ),
                              alignment: Alignment.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
