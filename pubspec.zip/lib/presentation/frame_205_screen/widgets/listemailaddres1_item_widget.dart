import '../models/listemailaddres1_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class Listemailaddres1ItemWidget extends StatelessWidget {
  Listemailaddres1ItemWidget(this.listemailaddres1ItemModelObj);

  Listemailaddres1ItemModel listemailaddres1ItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: getPadding(
            bottom: 8,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                listemailaddres1ItemModelObj.emailaddressTxt,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtInterRegular19Pink700,
              ),
              Text(
                listemailaddres1ItemModelObj.emailaddressTxt1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtInterMedium15Gray50002,
              ),
            ],
          ),
        ),
        Container(
          height: getVerticalSize(
            51,
          ),
          width: getHorizontalSize(
            140,
          ),
          margin: getMargin(
            left: 64,
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: getPadding(
                    left: 16,
                  ),
                  child: Row(
                    children: [
                      Padding(
                        padding: getPadding(
                          bottom: 1,
                        ),
                        child: Text(
                          "lbl2".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterMedium15Gray60009,
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          left: 6,
                          top: 1,
                        ),
                        child: Text(
                          "lbl_87_432".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterMedium15Gray60009,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              CustomImageView(
                svgPath: ImageConstant.imgGroup1182,
                height: getVerticalSize(
                  51,
                ),
                width: getHorizontalSize(
                  140,
                ),
                radius: BorderRadius.circular(
                  getHorizontalSize(
                    15,
                  ),
                ),
                alignment: Alignment.center,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
