import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/listemailaddres1_item_model.dart';
import '../models/listprice_item_model.dart';
import 'package:ammar_s_application4/presentation/frame_205_screen/models/frame_205_model.dart';
part 'frame_205_event.dart';
part 'frame_205_state.dart';

class Frame205Bloc extends Bloc<Frame205Event, Frame205State> {
  Frame205Bloc(Frame205State initialState) : super(initialState) {
    on<Frame205InitialEvent>(_onInitialize);
  }

  List<Listemailaddres1ItemModel> fillListemailaddres1ItemList() {
    return List.generate(2, (index) => Listemailaddres1ItemModel());
  }

  List<ListpriceItemModel> fillListpriceItemList() {
    return List.generate(2, (index) => ListpriceItemModel());
  }

  _onInitialize(
    Frame205InitialEvent event,
    Emitter<Frame205State> emit,
  ) async {
    emit(state.copyWith(
      zipcodeController: TextEditingController(),
    ));
    emit(state.copyWith(
        frame205ModelObj: state.frame205ModelObj?.copyWith(
      listemailaddres1ItemList: fillListemailaddres1ItemList(),
      listpriceItemList: fillListpriceItemList(),
    )));
  }
}
