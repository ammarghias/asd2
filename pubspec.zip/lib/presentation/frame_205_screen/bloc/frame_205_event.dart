// ignore_for_file: must_be_immutable

part of 'frame_205_bloc.dart';

@immutable
abstract class Frame205Event extends Equatable {}

class Frame205InitialEvent extends Frame205Event {
  @override
  List<Object?> get props => [];
}
