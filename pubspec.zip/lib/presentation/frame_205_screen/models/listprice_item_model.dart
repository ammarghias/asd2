class ListpriceItemModel {String? id = "";

 }
