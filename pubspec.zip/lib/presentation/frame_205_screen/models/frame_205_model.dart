import 'package:equatable/equatable.dart';import 'listemailaddres1_item_model.dart';import 'listprice_item_model.dart';
// ignore: must_be_immutable
class Frame205Model extends Equatable {Frame205Model({this.listemailaddres1ItemList = const [], this.listpriceItemList = const []});

List<Listemailaddres1ItemModel> listemailaddres1ItemList;

List<ListpriceItemModel> listpriceItemList;

Frame205Model copyWith({List<Listemailaddres1ItemModel>? listemailaddres1ItemList, List<ListpriceItemModel>? listpriceItemList}) { return Frame205Model(
listemailaddres1ItemList : listemailaddres1ItemList ?? this.listemailaddres1ItemList,
listpriceItemList : listpriceItemList ?? this.listpriceItemList,
); } 
@override List<Object?> get props => [listemailaddres1ItemList,listpriceItemList];
 }
