import '../frame_205_screen/widgets/listemailaddres1_item_widget.dart';
import '../frame_205_screen/widgets/listprice_item_widget.dart';
import 'bloc/frame_205_bloc.dart';
import 'models/frame_205_model.dart';
import 'models/listemailaddres1_item_model.dart';
import 'models/listprice_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application4/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class Frame205Screen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<Frame205Bloc>(
      create: (context) => Frame205Bloc(Frame205State(
        frame205ModelObj: Frame205Model(),
      ))
        ..add(Frame205InitialEvent()),
      child: Frame205Screen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        appBar: CustomAppBar(
          height: getVerticalSize(
            97,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink700,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: Container(
          width: getHorizontalSize(
            393,
          ),
          padding: getPadding(
            left: 3,
            right: 3,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: getVerticalSize(
                  30,
                ),
                width: getHorizontalSize(
                  219,
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        height: getVerticalSize(
                          27,
                        ),
                        width: getHorizontalSize(
                          219,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.pink700,
                          borderRadius: BorderRadius.circular(
                            getHorizontalSize(
                              10,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: Text(
                        "lbl_welcome2".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtHindVadodaraRegular20WhiteA700,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                height: getVerticalSize(
                  710,
                ),
                width: getHorizontalSize(
                  379,
                ),
                margin: getMargin(
                  top: 25,
                ),
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    Align(
                      alignment: Alignment.centerRight,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            width: getHorizontalSize(
                              311,
                            ),
                            margin: getMargin(
                              right: 44,
                            ),
                            child: Text(
                              "msg_we_love_your_interest".tr,
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium18,
                            ),
                          ),
                          Container(
                            width: getHorizontalSize(
                              311,
                            ),
                            margin: getMargin(
                              top: 18,
                              right: 44,
                            ),
                            child: Text(
                              "msg_just_making_sure2".tr,
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium18,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 27,
                            ),
                            child: Text(
                              "msg_first_and_last_name".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17Bluegray400,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 5,
                            ),
                            child: Text(
                              "lbl_jane_doe".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 4,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray200,
                              indent: getHorizontalSize(
                                3,
                              ),
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 20,
                            ),
                            child: Text(
                              "lbl_email_address".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17Bluegray400,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 6,
                            ),
                            child: Text(
                              "msg_janedoe_cashback_financial".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 3,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray200,
                              indent: getHorizontalSize(
                                3,
                              ),
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 43,
                            ),
                            child: SizedBox(
                              width: getHorizontalSize(
                                183,
                              ),
                              child: Divider(
                                height: getVerticalSize(
                                  1,
                                ),
                                thickness: getVerticalSize(
                                  1,
                                ),
                                color: ColorConstant.whiteA700,
                                indent: getHorizontalSize(
                                  133,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 1,
                            ),
                            child: SizedBox(
                              width: getHorizontalSize(
                                187,
                              ),
                              child: Divider(
                                height: getVerticalSize(
                                  1,
                                ),
                                thickness: getVerticalSize(
                                  1,
                                ),
                                color: ColorConstant.whiteA700,
                                indent: getHorizontalSize(
                                  130,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 26,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray200,
                              indent: getHorizontalSize(
                                3,
                              ),
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 20,
                            ),
                            child: Text(
                              "msg_street_address_line".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17Bluegray400,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 30,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray200,
                              indent: getHorizontalSize(
                                3,
                              ),
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 21,
                            ),
                            child: Text(
                              "msg_street_address_line2".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17Bluegray400,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 3,
                            ),
                            child: Text(
                              "lbl_house_36".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 5,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray200,
                              indent: getHorizontalSize(
                                3,
                              ),
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 20,
                            ),
                            child: Row(
                              children: [
                                Padding(
                                  padding: getPadding(
                                    top: 2,
                                  ),
                                  child: Text(
                                    "lbl_zip_code".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterMedium17Bluegray400,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 103,
                                    bottom: 2,
                                  ),
                                  child: Text(
                                    "lbl_state".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterMedium17Bluegray400,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 2,
                              right: 34,
                            ),
                            child: Row(
                              children: [
                                BlocSelector<Frame205Bloc, Frame205State,
                                    TextEditingController?>(
                                  selector: (state) => state.zipcodeController,
                                  builder: (context, zipcodeController) {
                                    return CustomTextFormField(
                                      width: getHorizontalSize(
                                        142,
                                      ),
                                      focusNode: FocusNode(),
                                      controller: zipcodeController,
                                      hintText: "lbl_84832".tr,
                                      margin: getMargin(
                                        top: 1,
                                      ),
                                      textInputAction: TextInputAction.done,
                                    );
                                  },
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 35,
                                    bottom: 1,
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Text(
                                        "lbl_va".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterMedium17,
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          top: 4,
                                        ),
                                        child: SizedBox(
                                          width: getHorizontalSize(
                                            142,
                                          ),
                                          child: Divider(
                                            height: getVerticalSize(
                                              1,
                                            ),
                                            thickness: getVerticalSize(
                                              1,
                                            ),
                                            color: ColorConstant.gray200,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 26,
                              right: 28,
                            ),
                            child: BlocSelector<Frame205Bloc, Frame205State,
                                Frame205Model?>(
                              selector: (state) => state.frame205ModelObj,
                              builder: (context, frame205ModelObj) {
                                return ListView.separated(
                                  physics: NeverScrollableScrollPhysics(),
                                  shrinkWrap: true,
                                  separatorBuilder: (context, index) {
                                    return SizedBox(
                                      height: getVerticalSize(
                                        16,
                                      ),
                                    );
                                  },
                                  itemCount: frame205ModelObj
                                          ?.listemailaddres1ItemList.length ??
                                      0,
                                  itemBuilder: (context, index) {
                                    Listemailaddres1ItemModel model =
                                        frame205ModelObj
                                                    ?.listemailaddres1ItemList[
                                                index] ??
                                            Listemailaddres1ItemModel();
                                    return Listemailaddres1ItemWidget(
                                      model,
                                    );
                                  },
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        height: getVerticalSize(
                          528,
                        ),
                        width: getHorizontalSize(
                          376,
                        ),
                        margin: getMargin(
                          top: 50,
                        ),
                        padding: getPadding(
                          top: 6,
                          bottom: 6,
                        ),
                        decoration: AppDecoration.fillWhiteA700,
                        child: Stack(
                          alignment: Alignment.topRight,
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Container(
                                padding: getPadding(
                                  left: 6,
                                  top: 17,
                                  right: 6,
                                  bottom: 17,
                                ),
                                decoration:
                                    AppDecoration.outlineBlack9001.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder15,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Padding(
                                      padding: getPadding(
                                        top: 1,
                                      ),
                                      child: Text(
                                        "msg_referral_rewards".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtImprimaRegular25,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 11,
                                      ),
                                      child: Text(
                                        "msg_because_deals_get".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtImprimaRegular17,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        left: 23,
                                        top: 21,
                                        right: 22,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "msg_save_upto_an_additional"
                                                    .tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular16Black90099,
                                              ),
                                              Padding(
                                                padding: getPadding(
                                                  top: 3,
                                                ),
                                                child: Text(
                                                  "msg_when_you_refer_a".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular16Black90099,
                                                ),
                                              ),
                                            ],
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              left: 11,
                                              top: 4,
                                              bottom: 1,
                                            ),
                                            child: Text(
                                              "lbl2".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular30Black90099,
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              left: 2,
                                              top: 4,
                                              bottom: 1,
                                            ),
                                            child: Text(
                                              "lbl_791_97".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular30Black90099,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Padding(
                                        padding: getPadding(
                                          left: 23,
                                          top: 30,
                                          right: 22,
                                        ),
                                        child: BlocSelector<Frame205Bloc,
                                            Frame205State, Frame205Model?>(
                                          selector: (state) =>
                                              state.frame205ModelObj,
                                          builder: (context, frame205ModelObj) {
                                            return ListView.separated(
                                              physics: BouncingScrollPhysics(),
                                              shrinkWrap: true,
                                              separatorBuilder:
                                                  (context, index) {
                                                return SizedBox(
                                                  height: getVerticalSize(
                                                    10,
                                                  ),
                                                );
                                              },
                                              itemCount: frame205ModelObj
                                                      ?.listpriceItemList
                                                      .length ??
                                                  0,
                                              itemBuilder: (context, index) {
                                                ListpriceItemModel model =
                                                    frame205ModelObj
                                                                ?.listpriceItemList[
                                                            index] ??
                                                        ListpriceItemModel();
                                                return ListpriceItemWidget(
                                                  model,
                                                );
                                              },
                                            );
                                          },
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                        padding: getPadding(
                                          left: 23,
                                          top: 3,
                                        ),
                                        child: Text(
                                          "lbl3".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle.txtCaladeaBold30,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: getHorizontalSize(
                                        267,
                                      ),
                                      margin: getMargin(
                                        top: 21,
                                      ),
                                      padding: getPadding(
                                        left: 30,
                                        top: 2,
                                        right: 107,
                                        bottom: 2,
                                      ),
                                      decoration: AppDecoration
                                          .txtOutlineWhiteA7002
                                          .copyWith(
                                        borderRadius: BorderRadiusStyle
                                            .txtRoundedBorder10,
                                      ),
                                      child: Text(
                                        "lbl_invite".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtHindVadodaraRegular21,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 29,
                                      ),
                                      child: Text(
                                        "msg_i_want_to_try_this".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtInterRegular16Black90099
                                            .copyWith(
                                          decoration: TextDecoration.underline,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: getHorizontalSize(
                                        346,
                                      ),
                                      margin: getMargin(
                                        top: 27,
                                      ),
                                      child: Text(
                                        "msg_additional_referral".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style:
                                            AppStyle.txtInterRegular10Gray60099,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            CustomImageView(
                              svgPath: ImageConstant.imgClose,
                              height: getVerticalSize(
                                30,
                              ),
                              width: getHorizontalSize(
                                33,
                              ),
                              alignment: Alignment.topRight,
                              margin: getMargin(
                                top: 6,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
