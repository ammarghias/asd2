import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class MenuModel extends Equatable {MenuModel copyWith() { return MenuModel(
); } 
@override List<Object?> get props => [];
 }
