import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class RegistrationOneModel extends Equatable {RegistrationOneModel copyWith() { return RegistrationOneModel(
); } 
@override List<Object?> get props => [];
 }
