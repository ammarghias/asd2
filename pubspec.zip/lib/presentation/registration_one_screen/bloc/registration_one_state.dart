// ignore_for_file: must_be_immutable

part of 'registration_one_bloc.dart';

class RegistrationOneState extends Equatable {
  RegistrationOneState({
    this.rectangle628Controller,
    this.groupeightynineController,
    this.groupseventyninController,
    this.groupeightysixController,
    this.groupeightyseveController,
    this.registrationOneModelObj,
  });

  TextEditingController? rectangle628Controller;

  TextEditingController? groupeightynineController;

  TextEditingController? groupseventyninController;

  TextEditingController? groupeightysixController;

  TextEditingController? groupeightyseveController;

  RegistrationOneModel? registrationOneModelObj;

  @override
  List<Object?> get props => [
        rectangle628Controller,
        groupeightynineController,
        groupseventyninController,
        groupeightysixController,
        groupeightyseveController,
        registrationOneModelObj,
      ];
  RegistrationOneState copyWith({
    TextEditingController? rectangle628Controller,
    TextEditingController? groupeightynineController,
    TextEditingController? groupseventyninController,
    TextEditingController? groupeightysixController,
    TextEditingController? groupeightyseveController,
    RegistrationOneModel? registrationOneModelObj,
  }) {
    return RegistrationOneState(
      rectangle628Controller:
          rectangle628Controller ?? this.rectangle628Controller,
      groupeightynineController:
          groupeightynineController ?? this.groupeightynineController,
      groupseventyninController:
          groupseventyninController ?? this.groupseventyninController,
      groupeightysixController:
          groupeightysixController ?? this.groupeightysixController,
      groupeightyseveController:
          groupeightyseveController ?? this.groupeightyseveController,
      registrationOneModelObj:
          registrationOneModelObj ?? this.registrationOneModelObj,
    );
  }
}
