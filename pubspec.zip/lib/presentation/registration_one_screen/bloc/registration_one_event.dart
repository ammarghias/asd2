// ignore_for_file: must_be_immutable

part of 'registration_one_bloc.dart';

@immutable
abstract class RegistrationOneEvent extends Equatable {}

class RegistrationOneInitialEvent extends RegistrationOneEvent {
  @override
  List<Object?> get props => [];
}
