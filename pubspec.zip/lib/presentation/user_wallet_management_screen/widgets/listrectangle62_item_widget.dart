import '../models/listrectangle62_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class Listrectangle62ItemWidget extends StatelessWidget {
  Listrectangle62ItemWidget(this.listrectangle62ItemModelObj);

  Listrectangle62ItemModel listrectangle62ItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: getMargin(
              top: 8,
              bottom: 25,
            ),
            padding: getPadding(
              all: 2,
            ),
            decoration: AppDecoration.outlinePink700.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder5,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: getSize(
                    16,
                  ),
                  width: getSize(
                    16,
                  ),
                  decoration: BoxDecoration(
                    color: ColorConstant.pink700,
                    borderRadius: BorderRadius.circular(
                      getHorizontalSize(
                        5,
                      ),
                    ),
                    border: Border.all(
                      color: ColorConstant.pink700,
                      width: getHorizontalSize(
                        1,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: getPadding(
                left: 16,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      right: 12,
                    ),
                    child: Row(
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgPullcreditcard2,
                          height: getVerticalSize(
                            42,
                          ),
                          width: getHorizontalSize(
                            69,
                          ),
                          radius: BorderRadius.circular(
                            getHorizontalSize(
                              3,
                            ),
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 8,
                            bottom: 1,
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    listrectangle62ItemModelObj.pullcardnameTxt,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterBold11Black90087,
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      left: 82,
                                      bottom: 3,
                                    ),
                                    child: Text(
                                      "lbl_annual_fee_0".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtInterRegular9Black90099,
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: getPadding(
                                      bottom: 5,
                                    ),
                                    child: Text(
                                      listrectangle62ItemModelObj
                                          .pullcardnameTxt1,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtInterRegular16Black90099,
                                    ),
                                  ),
                                  Container(
                                    width: getHorizontalSize(
                                      44,
                                    ),
                                    margin: getMargin(
                                      left: 99,
                                      top: 2,
                                    ),
                                    child: Text(
                                      "msg_cashback_1".tr,
                                      maxLines: null,
                                      textAlign: TextAlign.center,
                                      style:
                                          AppStyle.txtInterRegular9Black90099,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 9,
                    ),
                    child: Divider(
                      height: getVerticalSize(
                        2,
                      ),
                      thickness: getVerticalSize(
                        2,
                      ),
                      color: ColorConstant.gray40003,
                      indent: getHorizontalSize(
                        10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
