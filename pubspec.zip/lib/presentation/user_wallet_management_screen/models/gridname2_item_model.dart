class Gridname2ItemModel {String nameTxt = "Chase";

String? id = "";

 }
