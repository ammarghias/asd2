import 'package:equatable/equatable.dart';import 'gridname2_item_model.dart';import 'listrectangle62_item_model.dart';
// ignore: must_be_immutable
class UserWalletManagementModel extends Equatable {UserWalletManagementModel({this.gridname2ItemList = const [], this.listrectangle62ItemList = const []});

List<Gridname2ItemModel> gridname2ItemList;

List<Listrectangle62ItemModel> listrectangle62ItemList;

UserWalletManagementModel copyWith({List<Gridname2ItemModel>? gridname2ItemList, List<Listrectangle62ItemModel>? listrectangle62ItemList}) { return UserWalletManagementModel(
gridname2ItemList : gridname2ItemList ?? this.gridname2ItemList,
listrectangle62ItemList : listrectangle62ItemList ?? this.listrectangle62ItemList,
); } 
@override List<Object?> get props => [gridname2ItemList,listrectangle62ItemList];
 }
