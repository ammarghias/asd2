class Listrectangle62ItemModel {String pullcardnameTxt = "Capital One";

String pullcardnameTxt1 = "Venture";

String? id = "";

 }
