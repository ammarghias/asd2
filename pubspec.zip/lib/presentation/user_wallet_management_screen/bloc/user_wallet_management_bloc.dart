import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/gridname2_item_model.dart';
import '../models/listrectangle62_item_model.dart';
import 'package:ammar_s_application4/presentation/user_wallet_management_screen/models/user_wallet_management_model.dart';
part 'user_wallet_management_event.dart';
part 'user_wallet_management_state.dart';

class UserWalletManagementBloc
    extends Bloc<UserWalletManagementEvent, UserWalletManagementState> {
  UserWalletManagementBloc(UserWalletManagementState initialState)
      : super(initialState) {
    on<UserWalletManagementInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<UserWalletManagementState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<Gridname2ItemModel> fillGridname2ItemList() {
    return List.generate(12, (index) => Gridname2ItemModel());
  }

  List<Listrectangle62ItemModel> fillListrectangle62ItemList() {
    return List.generate(3, (index) => Listrectangle62ItemModel());
  }

  _onInitialize(
    UserWalletManagementInitialEvent event,
    Emitter<UserWalletManagementState> emit,
  ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        userWalletManagementModelObj:
            state.userWalletManagementModelObj?.copyWith(
      gridname2ItemList: fillGridname2ItemList(),
      listrectangle62ItemList: fillListrectangle62ItemList(),
    )));
  }
}
