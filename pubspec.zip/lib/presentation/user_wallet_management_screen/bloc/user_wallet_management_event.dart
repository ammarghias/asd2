// ignore_for_file: must_be_immutable

part of 'user_wallet_management_bloc.dart';

@immutable
abstract class UserWalletManagementEvent extends Equatable {}

class UserWalletManagementInitialEvent extends UserWalletManagementEvent {
  @override
  List<Object?> get props => [];
}

///event for change switch
class ChangeSwitchEvent extends UserWalletManagementEvent {
  ChangeSwitchEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
