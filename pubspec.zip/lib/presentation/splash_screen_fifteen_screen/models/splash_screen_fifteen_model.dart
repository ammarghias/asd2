import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenFifteenModel extends Equatable {SplashScreenFifteenModel copyWith() { return SplashScreenFifteenModel(
); } 
@override List<Object?> get props => [];
 }
