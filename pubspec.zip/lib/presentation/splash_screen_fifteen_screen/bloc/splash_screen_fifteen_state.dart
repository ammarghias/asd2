// ignore_for_file: must_be_immutable

part of 'splash_screen_fifteen_bloc.dart';

class SplashScreenFifteenState extends Equatable {
  SplashScreenFifteenState({this.splashScreenFifteenModelObj});

  SplashScreenFifteenModel? splashScreenFifteenModelObj;

  @override
  List<Object?> get props => [
        splashScreenFifteenModelObj,
      ];
  SplashScreenFifteenState copyWith(
      {SplashScreenFifteenModel? splashScreenFifteenModelObj}) {
    return SplashScreenFifteenState(
      splashScreenFifteenModelObj:
          splashScreenFifteenModelObj ?? this.splashScreenFifteenModelObj,
    );
  }
}
