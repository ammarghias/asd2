// ignore_for_file: must_be_immutable

part of 'splash_screen_fifteen_bloc.dart';

@immutable
abstract class SplashScreenFifteenEvent extends Equatable {}

class SplashScreenFifteenInitialEvent extends SplashScreenFifteenEvent {
  @override
  List<Object?> get props => [];
}
