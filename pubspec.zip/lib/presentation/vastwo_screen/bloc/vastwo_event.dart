// ignore_for_file: must_be_immutable

part of 'vastwo_bloc.dart';

@immutable
abstract class VastwoEvent extends Equatable {}

class VastwoInitialEvent extends VastwoEvent {
  @override
  List<Object?> get props => [];
}
