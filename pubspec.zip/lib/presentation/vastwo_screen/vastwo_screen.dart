import 'bloc/vastwo_bloc.dart';
import 'models/vastwo_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/presentation/home_page/home_page.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

class VastwoScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<VastwoBloc>(
      create: (context) => VastwoBloc(VastwoState(
        vastwoModelObj: VastwoModel(),
      ))
        ..add(VastwoInitialEvent()),
      child: VastwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<VastwoBloc, VastwoState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            appBar: CustomAppBar(
              height: getVerticalSize(
                80,
              ),
              leadingWidth: 50,
              leading: AppbarImage(
                height: getSize(
                  25,
                ),
                width: getSize(
                  25,
                ),
                svgPath: ImageConstant.imgButtonnotification,
                margin: getMargin(
                  left: 25,
                  top: 14,
                  bottom: 16,
                ),
              ),
              centerTitle: true,
              title: Text(
                "lbl_menu".tr,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtStaatlichesRegular40Bluegray700,
              ),
              actions: [
                Container(
                  margin: getMargin(
                    left: 42,
                    top: 17,
                    right: 42,
                    bottom: 17,
                  ),
                  decoration: AppDecoration.fillWhiteA700,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      AppbarImage(
                        height: getVerticalSize(
                          21,
                        ),
                        width: getHorizontalSize(
                          29,
                        ),
                        svgPath: ImageConstant.imgMenu,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            body: SizedBox(
              width: size.width,
              child: SingleChildScrollView(
                padding: getPadding(
                  top: 16,
                ),
                child: Container(
                  height: getVerticalSize(
                    1134,
                  ),
                  width: getHorizontalSize(
                    602,
                  ),
                  child: Stack(
                    alignment: Alignment.topRight,
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          height: getVerticalSize(
                            35,
                          ),
                          width: getHorizontalSize(
                            28,
                          ),
                          margin: getMargin(
                            right: 10,
                          ),
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage(
                                ImageConstant.imgFrame212,
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: Stack(
                            children: [
                              CustomImageView(
                                svgPath: ImageConstant.imgVolumeWhiteA70035x28,
                                height: getVerticalSize(
                                  35,
                                ),
                                width: getHorizontalSize(
                                  28,
                                ),
                                alignment: Alignment.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          386,
                        ),
                        width: getHorizontalSize(
                          390,
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 270,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          400,
                        ),
                        width: getHorizontalSize(
                          393,
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 225,
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          height: getVerticalSize(
                            397,
                          ),
                          width: getHorizontalSize(
                            264,
                          ),
                          margin: getMargin(
                            top: 124,
                            right: 128,
                          ),
                          padding: getPadding(
                            top: 10,
                            bottom: 10,
                          ),
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage(
                                ImageConstant.imgGroup386x390,
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: Stack(
                            alignment: Alignment.topLeft,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgVector232x66,
                                height: getVerticalSize(
                                  232,
                                ),
                                width: getHorizontalSize(
                                  66,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    33,
                                  ),
                                ),
                                alignment: Alignment.topLeft,
                              ),
                              CustomImageView(
                                imagePath: ImageConstant.imgVector232x66,
                                height: getVerticalSize(
                                  232,
                                ),
                                width: getHorizontalSize(
                                  100,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    40,
                                  ),
                                ),
                                alignment: Alignment.topLeft,
                                margin: getMargin(
                                  top: 50,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          26,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            13,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 175,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          59,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            29,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 219,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          120,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 224,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          55,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            27,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 420,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          117,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 362,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          47,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            23,
                          ),
                        ),
                        alignment: Alignment.centerLeft,
                        margin: getMargin(
                          left: 209,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          151,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 413,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          77,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            38,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 403,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          109,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.centerLeft,
                        margin: getMargin(
                          left: 209,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          170,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.center,
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          34,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            17,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 403,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          397,
                        ),
                        width: getHorizontalSize(
                          217,
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 338,
                          right: 175,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          397,
                        ),
                        width: getHorizontalSize(
                          345,
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 308,
                          right: 47,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          397,
                        ),
                        width: getHorizontalSize(
                          393,
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 55,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          32,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            16,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 332,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          65,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            32,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 383,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          85,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 422,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          226,
                        ),
                        width: getHorizontalSize(
                          187,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 172,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          226,
                        ),
                        width: getHorizontalSize(
                          131,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 229,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          226,
                        ),
                        width: getHorizontalSize(
                          194,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 149,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          226,
                        ),
                        width: getHorizontalSize(
                          98,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 178,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          214,
                        ),
                        width: getHorizontalSize(
                          232,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          226,
                        ),
                        width: getHorizontalSize(
                          167,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 189,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          226,
                        ),
                        width: getHorizontalSize(
                          136,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 145,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          161,
                        ),
                        width: getHorizontalSize(
                          205,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          171,
                        ),
                        width: getHorizontalSize(
                          253,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          345,
                        ),
                        width: getHorizontalSize(
                          321,
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          397,
                        ),
                        width: getHorizontalSize(
                          368,
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          right: 24,
                          bottom: 210,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          109,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 306,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          170,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomCenter,
                        margin: getMargin(
                          bottom: 365,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          100,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 282,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          204,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomCenter,
                        margin: getMargin(
                          bottom: 314,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          60,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            30,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 281,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          130,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 324,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          163,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 280,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          224,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          right: 168,
                          bottom: 274,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          87,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 228,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          159,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 78,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          208,
                        ),
                        width: getHorizontalSize(
                          221,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          right: 171,
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          151,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 54,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          157,
                        ),
                        width: getHorizontalSize(
                          255,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          right: 137,
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          111,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 53,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          181,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomCenter,
                        margin: getMargin(
                          bottom: 96,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          123,
                        ),
                        width: getHorizontalSize(
                          213,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomCenter,
                        margin: getMargin(
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          117,
                        ),
                        width: getHorizontalSize(
                          274,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          right: 118,
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          138,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          69,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            34,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 4,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          324,
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          right: 68,
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          313,
                        ),
                        width: getHorizontalSize(
                          393,
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 160,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          397,
                        ),
                        width: getHorizontalSize(
                          393,
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 278,
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Container(
                          height: getVerticalSize(
                            554,
                          ),
                          width: getHorizontalSize(
                            393,
                          ),
                          margin: getMargin(
                            bottom: 119,
                          ),
                          child: Stack(
                            alignment: Alignment.topCenter,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgGroup386x390,
                                height: getVerticalSize(
                                  513,
                                ),
                                width: getHorizontalSize(
                                  393,
                                ),
                                alignment: Alignment.topCenter,
                              ),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Padding(
                                  padding: getPadding(
                                    top: 245,
                                  ),
                                  child: Text(
                                    "lbl3".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtIstokWebBold21,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          55,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            27,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 103,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          136,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 167,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          47,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            23,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 79,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          305,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          bottom: 126,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          128,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 81,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          305,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          right: 53,
                          bottom: 90,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgGroup386x390,
                        height: getVerticalSize(
                          395,
                        ),
                        width: getHorizontalSize(
                          393,
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 109,
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          margin: getMargin(
                            top: 188,
                            right: 56,
                          ),
                          padding: getPadding(
                            left: 140,
                            top: 77,
                            right: 140,
                            bottom: 77,
                          ),
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage(
                                ImageConstant.imgGroup386x390,
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: getPadding(
                                  top: 193,
                                ),
                                child: Text(
                                  "lbl2".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterBold40,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          57,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            28,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 262,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          77,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            38,
                          ),
                        ),
                        alignment: Alignment.topLeft,
                        margin: getMargin(
                          left: 209,
                          top: 302,
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          33,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            16,
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 209,
                          bottom: 24,
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          height: getVerticalSize(
                            54,
                          ),
                          width: getHorizontalSize(
                            55,
                          ),
                          margin: getMargin(
                            top: 285,
                            right: 10,
                          ),
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage(
                                ImageConstant.imgGroup1221,
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: Stack(
                            alignment: Alignment.bottomLeft,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgVector29x33,
                                height: getVerticalSize(
                                  29,
                                ),
                                width: getHorizontalSize(
                                  33,
                                ),
                                alignment: Alignment.bottomRight,
                                margin: getMargin(
                                  bottom: 3,
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  height: getVerticalSize(
                                    49,
                                  ),
                                  width: getHorizontalSize(
                                    47,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.bottomLeft,
                                    children: [
                                      CustomImageView(
                                        imagePath: ImageConstant.imgVector49x47,
                                        height: getVerticalSize(
                                          49,
                                        ),
                                        width: getHorizontalSize(
                                          47,
                                        ),
                                        alignment: Alignment.center,
                                      ),
                                      CustomImageView(
                                        imagePath: ImageConstant.imgVector20x20,
                                        height: getSize(
                                          20,
                                        ),
                                        width: getSize(
                                          20,
                                        ),
                                        alignment: Alignment.bottomLeft,
                                        margin: getMargin(
                                          left: 8,
                                          bottom: 9,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              CustomImageView(
                                imagePath: ImageConstant.imgVector19x21,
                                height: getVerticalSize(
                                  19,
                                ),
                                width: getHorizontalSize(
                                  21,
                                ),
                                alignment: Alignment.topLeft,
                                margin: getMargin(
                                  left: 14,
                                ),
                              ),
                              CustomImageView(
                                imagePath: ImageConstant.imgVector46x41,
                                height: getVerticalSize(
                                  46,
                                ),
                                width: getHorizontalSize(
                                  41,
                                ),
                                alignment: Alignment.bottomLeft,
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Container(
                                  padding: getPadding(
                                    left: 9,
                                    top: 4,
                                    right: 9,
                                    bottom: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(
                                        ImageConstant.imgGroup1221,
                                      ),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: getVerticalSize(
                                          33,
                                        ),
                                        width: getHorizontalSize(
                                          31,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.topLeft,
                                          children: [
                                            CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgGroupWhiteA70028x22,
                                              height: getVerticalSize(
                                                28,
                                              ),
                                              width: getHorizontalSize(
                                                22,
                                              ),
                                              alignment: Alignment.bottomRight,
                                              margin: getMargin(
                                                right: 2,
                                              ),
                                            ),
                                            CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgGroupWhiteA70028x22,
                                              height: getVerticalSize(
                                                10,
                                              ),
                                              width: getHorizontalSize(
                                                8,
                                              ),
                                              alignment: Alignment.topLeft,
                                              margin: getMargin(
                                                top: 8,
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                height: getVerticalSize(
                                                  5,
                                                ),
                                                width: getHorizontalSize(
                                                  6,
                                                ),
                                                margin: getMargin(
                                                  left: 2,
                                                  top: 6,
                                                ),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgGroupAmber3005x6,
                                                      height: getVerticalSize(
                                                        5,
                                                      ),
                                                      width: getHorizontalSize(
                                                        6,
                                                      ),
                                                      alignment:
                                                          Alignment.center,
                                                    ),
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgGroupAmber3005x6,
                                                      height: getVerticalSize(
                                                        5,
                                                      ),
                                                      width: getHorizontalSize(
                                                        6,
                                                      ),
                                                      alignment:
                                                          Alignment.center,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            CustomImageView(
                                              svgPath: ImageConstant.imgCar,
                                              height: getVerticalSize(
                                                24,
                                              ),
                                              width: getHorizontalSize(
                                                20,
                                              ),
                                              alignment: Alignment.topRight,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.centerRight,
                                        child: Container(
                                          height: getVerticalSize(
                                            7,
                                          ),
                                          width: getHorizontalSize(
                                            8,
                                          ),
                                          margin: getMargin(
                                            right: 13,
                                            bottom: 3,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.bottomLeft,
                                            children: [
                                              CustomImageView(
                                                svgPath: ImageConstant
                                                    .imgGroupWhiteA7006x5,
                                                height: getVerticalSize(
                                                  6,
                                                ),
                                                width: getHorizontalSize(
                                                  5,
                                                ),
                                                alignment: Alignment.topRight,
                                              ),
                                              CustomImageView(
                                                svgPath: ImageConstant
                                                    .imgGroupWhiteA7005x5,
                                                height: getSize(
                                                  5,
                                                ),
                                                width: getSize(
                                                  5,
                                                ),
                                                alignment: Alignment.bottomLeft,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Padding(
                          padding: getPadding(
                            top: 462,
                          ),
                          child: Text(
                            "lbl_save_more_than".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterBold20Black9007e,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          height: getVerticalSize(
                            670,
                          ),
                          width: getHorizontalSize(
                            382,
                          ),
                          margin: getMargin(
                            top: 194,
                            right: 6,
                          ),
                          child: Stack(
                            alignment: Alignment.topCenter,
                            children: [
                              Align(
                                alignment: Alignment.center,
                                child: Container(
                                  margin: getMargin(
                                    right: 1,
                                  ),
                                  padding: getPadding(
                                    left: 6,
                                    top: 55,
                                    right: 6,
                                    bottom: 55,
                                  ),
                                  decoration:
                                      AppDecoration.outlineGray50008.copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder26,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Padding(
                                        padding: getPadding(
                                          left: 3,
                                          top: 55,
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Container(
                                              height: getVerticalSize(
                                                41,
                                              ),
                                              width: getHorizontalSize(
                                                157,
                                              ),
                                              margin: getMargin(
                                                top: 1,
                                                bottom: 3,
                                              ),
                                              child: Stack(
                                                alignment: Alignment.topCenter,
                                                children: [
                                                  Align(
                                                    alignment:
                                                        Alignment.bottomLeft,
                                                    child: Padding(
                                                      padding: getPadding(
                                                        left: 1,
                                                      ),
                                                      child: Text(
                                                        "msg_on_literally_everything"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular14Black9007e,
                                                      ),
                                                    ),
                                                  ),
                                                  Align(
                                                    alignment:
                                                        Alignment.topCenter,
                                                    child: Text(
                                                      "lbl_save_more_than".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterBold20Black9007e,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                left: 30,
                                              ),
                                              child: Text(
                                                "lbl_5_643_57".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle.txtInterBold40,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          66,
                                        ),
                                        width: getHorizontalSize(
                                          357,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.bottomLeft,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Padding(
                                                padding: getPadding(
                                                  top: 10,
                                                ),
                                                child: Text(
                                                  "lbl_step_12".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtStaatlichesRegular25,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Text(
                                                "msg_shop_everyday_like".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtIstokWebRegular16,
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Text(
                                                "msg_in_annualized_savings".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular13Black90087,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.centerLeft,
                                        child: Padding(
                                          padding: getPadding(
                                            left: 9,
                                            top: 18,
                                            right: 24,
                                          ),
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: getPadding(
                                                  bottom: 39,
                                                ),
                                                child: Text(
                                                  "lbl_step_2".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtStaatlichesRegular25,
                                                ),
                                              ),
                                              Expanded(
                                                child: Container(
                                                  width: getHorizontalSize(
                                                    263,
                                                  ),
                                                  margin: getMargin(
                                                    left: 15,
                                                    top: 1,
                                                  ),
                                                  child: Text(
                                                    "msg_cashback_will_automatically"
                                                        .tr,
                                                    maxLines: null,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtIstokWebRegular16,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.centerRight,
                                        child: Padding(
                                          padding: getPadding(
                                            left: 59,
                                            top: 13,
                                            right: 16,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: getPadding(
                                                  bottom: 20,
                                                ),
                                                child: Text(
                                                  "lbl3".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtIstokWebBold20,
                                                ),
                                              ),
                                              Expanded(
                                                child: Container(
                                                  width: getHorizontalSize(
                                                    270,
                                                  ),
                                                  margin: getMargin(
                                                    left: 11,
                                                    top: 5,
                                                  ),
                                                  child: Text(
                                                    "msg_from_all_the_reward"
                                                        .tr,
                                                    maxLines: null,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtIstokWebRegular16,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          top: 2,
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              "lbl3".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle.txtIstokWebBold20,
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                left: 8,
                                                top: 4,
                                              ),
                                              child: Text(
                                                "msg_cashback_elite_partner".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtIstokWebRegular16,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.centerRight,
                                        child: Padding(
                                          padding: getPadding(
                                            left: 59,
                                            top: 4,
                                            right: 19,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: getPadding(
                                                  bottom: 18,
                                                ),
                                                child: Text(
                                                  "lbl3".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtIstokWebBold20,
                                                ),
                                              ),
                                              Padding(
                                                padding: getPadding(
                                                  left: 10,
                                                  bottom: 21,
                                                ),
                                                child: Text(
                                                  "lbl_stacked".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterBold20PurpleA700,
                                                ),
                                              ),
                                              Container(
                                                width: getHorizontalSize(
                                                  182,
                                                ),
                                                margin: getMargin(
                                                  left: 5,
                                                  top: 1,
                                                ),
                                                child: Text(
                                                  "msg_with_1_000_s_of".tr,
                                                  maxLines: null,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtIstokWebRegular17,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          top: 20,
                                        ),
                                        child: Text(
                                          "msg_automatically_applied".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtStaatlichesRegular25Pink700
                                              .copyWith(
                                            decoration:
                                                TextDecoration.underline,
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 14,
                                          top: 17,
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                bottom: 16,
                                              ),
                                              child: Text(
                                                "lbl_step_32".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtStaatlichesRegular25,
                                              ),
                                            ),
                                            Expanded(
                                              child: Container(
                                                width: getHorizontalSize(
                                                  288,
                                                ),
                                                margin: getMargin(
                                                  left: 6,
                                                  top: 1,
                                                ),
                                                child: Text(
                                                  "msg_and_that_s_it_folks_no"
                                                      .tr,
                                                  maxLines: null,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtIstokWebRegular16,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                  margin: getMargin(
                                    left: 1,
                                    top: 27,
                                  ),
                                  padding: getPadding(
                                    left: 8,
                                    top: 5,
                                    right: 8,
                                    bottom: 5,
                                  ),
                                  decoration:
                                      AppDecoration.outlinePink7004.copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder15,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CustomImageView(
                                        svgPath: ImageConstant
                                            .imgGroupWhiteA70029x180,
                                        height: getVerticalSize(
                                          33,
                                        ),
                                        width: getHorizontalSize(
                                          205,
                                        ),
                                        margin: getMargin(
                                          left: 1,
                                          top: 7,
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          top: 2,
                                        ),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                bottom: 8,
                                              ),
                                              child: Text(
                                                "lbl_reward_lines".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtKulimParkItalic25,
                                              ),
                                            ),
                                            Container(
                                              width: getHorizontalSize(
                                                104,
                                              ),
                                              margin: getMargin(
                                                left: 3,
                                                top: 7,
                                              ),
                                              child: Text(
                                                "msg_maximize_savings_minimize"
                                                    .tr,
                                                maxLines: null,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtInterRegular12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  margin: getMargin(
                                    left: 38,
                                    right: 39,
                                  ),
                                  padding: getPadding(
                                    left: 25,
                                    top: 2,
                                    right: 25,
                                    bottom: 2,
                                  ),
                                  decoration:
                                      AppDecoration.outlineWhiteA700.copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder10,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding: getPadding(
                                          top: 4,
                                        ),
                                        child: Text(
                                          "msg_i_want_to_estimate".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular18WhiteA700,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgFileWhiteA700,
                                height: getVerticalSize(
                                  68,
                                ),
                                width: getHorizontalSize(
                                  55,
                                ),
                                alignment: Alignment.topRight,
                                margin: getMargin(
                                  right: 9,
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgBag,
                                height: getVerticalSize(
                                  62,
                                ),
                                width: getHorizontalSize(
                                  55,
                                ),
                                alignment: Alignment.topRight,
                                margin: getMargin(
                                  top: 3,
                                  right: 33,
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgAirplane,
                                height: getVerticalSize(
                                  59,
                                ),
                                width: getHorizontalSize(
                                  52,
                                ),
                                alignment: Alignment.topRight,
                                margin: getMargin(
                                  top: 4,
                                  right: 57,
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgLocationAmber300,
                                height: getVerticalSize(
                                  62,
                                ),
                                width: getHorizontalSize(
                                  55,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    27,
                                  ),
                                ),
                                alignment: Alignment.topRight,
                                margin: getMargin(
                                  top: 6,
                                  right: 81,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              width: double.maxFinite,
                              child: Container(
                                width: getHorizontalSize(
                                  393,
                                ),
                                padding: getPadding(
                                  left: 9,
                                  top: 11,
                                  right: 9,
                                  bottom: 11,
                                ),
                                decoration: AppDecoration.fillWhiteA70099,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "msg_reward_catalog_settings".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtCastoroRegular19.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 17,
                                        right: 11,
                                      ),
                                      child: Row(
                                        children: [
                                          Padding(
                                            padding: getPadding(
                                              top: 1,
                                            ),
                                            child: Text(
                                              "lbl_welcome_offers".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtCastoroRegular19
                                                  .copyWith(
                                                decoration:
                                                    TextDecoration.underline,
                                              ),
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgButtonnotification,
                                            height: getSize(
                                              25,
                                            ),
                                            width: getSize(
                                              25,
                                            ),
                                            margin: getMargin(
                                              left: 195,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 19,
                                        right: 11,
                                      ),
                                      child: Row(
                                        children: [
                                          Padding(
                                            padding: getPadding(
                                              top: 4,
                                            ),
                                            child: Text(
                                              "msg_track_your_annual".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtCastoroRegular19
                                                  .copyWith(
                                                decoration:
                                                    TextDecoration.underline,
                                              ),
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgButtonnotification,
                                            height: getSize(
                                              25,
                                            ),
                                            width: getSize(
                                              25,
                                            ),
                                            margin: getMargin(
                                              left: 112,
                                              bottom: 3,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 20,
                                        bottom: 12,
                                      ),
                                      child: Text(
                                        "msg_referral_rewards".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtCastoroRegular19
                                            .copyWith(
                                          decoration: TextDecoration.underline,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                            ),
                          ],
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector232x66,
                        height: getVerticalSize(
                          232,
                        ),
                        width: getHorizontalSize(
                          305,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                        margin: getMargin(
                          bottom: 125,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group1:
        return AppRoutes.homePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(BuildContext context, String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
