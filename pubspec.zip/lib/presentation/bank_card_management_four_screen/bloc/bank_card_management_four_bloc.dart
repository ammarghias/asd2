import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/gridname3_item_model.dart';
import '../models/listpullcreditc_item_model.dart';
import 'package:ammar_s_application4/presentation/bank_card_management_four_screen/models/bank_card_management_four_model.dart';
part 'bank_card_management_four_event.dart';
part 'bank_card_management_four_state.dart';

class BankCardManagementFourBloc
    extends Bloc<BankCardManagementFourEvent, BankCardManagementFourState> {
  BankCardManagementFourBloc(BankCardManagementFourState initialState)
      : super(initialState) {
    on<BankCardManagementFourInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<BankCardManagementFourState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<Gridname3ItemModel> fillGridname3ItemList() {
    return List.generate(12, (index) => Gridname3ItemModel());
  }

  List<ListpullcreditcItemModel> fillListpullcreditcItemList() {
    return List.generate(4, (index) => ListpullcreditcItemModel());
  }

  _onInitialize(
    BankCardManagementFourInitialEvent event,
    Emitter<BankCardManagementFourState> emit,
  ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        bankCardManagementFourModelObj:
            state.bankCardManagementFourModelObj?.copyWith(
      gridname3ItemList: fillGridname3ItemList(),
      listpullcreditcItemList: fillListpullcreditcItemList(),
    )));
  }
}
