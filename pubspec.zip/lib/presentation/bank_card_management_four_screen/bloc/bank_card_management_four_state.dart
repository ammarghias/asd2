// ignore_for_file: must_be_immutable

part of 'bank_card_management_four_bloc.dart';

class BankCardManagementFourState extends Equatable {
  BankCardManagementFourState({
    this.nameController,
    this.isSelectedSwitch = false,
    this.bankCardManagementFourModelObj,
  });

  TextEditingController? nameController;

  BankCardManagementFourModel? bankCardManagementFourModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        nameController,
        isSelectedSwitch,
        bankCardManagementFourModelObj,
      ];
  BankCardManagementFourState copyWith({
    TextEditingController? nameController,
    bool? isSelectedSwitch,
    BankCardManagementFourModel? bankCardManagementFourModelObj,
  }) {
    return BankCardManagementFourState(
      nameController: nameController ?? this.nameController,
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      bankCardManagementFourModelObj:
          bankCardManagementFourModelObj ?? this.bankCardManagementFourModelObj,
    );
  }
}
