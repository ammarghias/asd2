// ignore_for_file: must_be_immutable

part of 'bank_card_management_four_bloc.dart';

@immutable
abstract class BankCardManagementFourEvent extends Equatable {}

class BankCardManagementFourInitialEvent extends BankCardManagementFourEvent {
  @override
  List<Object?> get props => [];
}

///event for change switch
class ChangeSwitchEvent extends BankCardManagementFourEvent {
  ChangeSwitchEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
