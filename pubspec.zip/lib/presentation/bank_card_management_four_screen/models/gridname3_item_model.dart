class Gridname3ItemModel {String nameTxt = "Chase";

String? id = "";

 }
