class ListpullcreditcItemModel {String? id = "";

 }
