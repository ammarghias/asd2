import 'package:equatable/equatable.dart';import 'gridname3_item_model.dart';import 'listpullcreditc_item_model.dart';
// ignore: must_be_immutable
class BankCardManagementFourModel extends Equatable {BankCardManagementFourModel({this.gridname3ItemList = const [], this.listpullcreditcItemList = const []});

List<Gridname3ItemModel> gridname3ItemList;

List<ListpullcreditcItemModel> listpullcreditcItemList;

BankCardManagementFourModel copyWith({List<Gridname3ItemModel>? gridname3ItemList, List<ListpullcreditcItemModel>? listpullcreditcItemList}) { return BankCardManagementFourModel(
gridname3ItemList : gridname3ItemList ?? this.gridname3ItemList,
listpullcreditcItemList : listpullcreditcItemList ?? this.listpullcreditcItemList,
); } 
@override List<Object?> get props => [gridname3ItemList,listpullcreditcItemList];
 }
