import 'bloc/splash_screen_nine_bloc.dart';
import 'models/splash_screen_nine_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

class SplashScreenNineScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<SplashScreenNineBloc>(
      create: (context) => SplashScreenNineBloc(SplashScreenNineState(
        splashScreenNineModelObj: SplashScreenNineModel(),
      ))
        ..add(SplashScreenNineInitialEvent()),
      child: SplashScreenNineScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenNineBloc, SplashScreenNineState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Container(
                        height: size.height,
                        width: double.maxFinite,
                        child: Stack(
                          alignment: Alignment.bottomCenter,
                          children: [
                            Align(
                              alignment: Alignment.topCenter,
                              child: Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Padding(
                                padding: getPadding(
                                  left: 13,
                                  right: 13,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 176,
                                      ),
                                      child: Text(
                                        "lbl_cashback".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtLEMONMILKMedium65,
                                      ),
                                    ),
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 172,
                                      ),
                                      child: Text(
                                        "lbl_cashback".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtLEMONMILKMedium65,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Container(
                                height: size.height,
                                width: double.maxFinite,
                                child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    CustomImageView(
                                      imagePath: ImageConstant.imgEllipse11,
                                      height: getVerticalSize(
                                        844,
                                      ),
                                      width: getHorizontalSize(
                                        390,
                                      ),
                                      alignment: Alignment.center,
                                    ),
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Padding(
                                        padding: getPadding(
                                          left: 13,
                                          right: 18,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgGroupWhiteA70047x276,
                                              height: getVerticalSize(
                                                47,
                                              ),
                                              width: getHorizontalSize(
                                                276,
                                              ),
                                            ),
                                            Container(
                                              height: getVerticalSize(
                                                203,
                                              ),
                                              width: getHorizontalSize(
                                                358,
                                              ),
                                              margin: getMargin(
                                                top: 218,
                                              ),
                                              child: Stack(
                                                alignment:
                                                    Alignment.centerRight,
                                                children: [
                                                  CustomImageView(
                                                    svgPath: ImageConstant
                                                        .imgVectorWhiteA700,
                                                    height: getVerticalSize(
                                                      203,
                                                    ),
                                                    width: getHorizontalSize(
                                                      189,
                                                    ),
                                                    alignment:
                                                        Alignment.centerLeft,
                                                  ),
                                                  CustomImageView(
                                                    svgPath: ImageConstant
                                                        .imgVectorWhiteA700,
                                                    height: getVerticalSize(
                                                      203,
                                                    ),
                                                    width: getHorizontalSize(
                                                      189,
                                                    ),
                                                    alignment:
                                                        Alignment.centerRight,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
