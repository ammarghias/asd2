// ignore_for_file: must_be_immutable

part of 'splash_screen_nine_bloc.dart';

class SplashScreenNineState extends Equatable {
  SplashScreenNineState({this.splashScreenNineModelObj});

  SplashScreenNineModel? splashScreenNineModelObj;

  @override
  List<Object?> get props => [
        splashScreenNineModelObj,
      ];
  SplashScreenNineState copyWith(
      {SplashScreenNineModel? splashScreenNineModelObj}) {
    return SplashScreenNineState(
      splashScreenNineModelObj:
          splashScreenNineModelObj ?? this.splashScreenNineModelObj,
    );
  }
}
