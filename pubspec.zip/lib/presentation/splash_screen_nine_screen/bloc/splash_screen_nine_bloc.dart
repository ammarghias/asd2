import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_nine_screen/models/splash_screen_nine_model.dart';
part 'splash_screen_nine_event.dart';
part 'splash_screen_nine_state.dart';

class SplashScreenNineBloc
    extends Bloc<SplashScreenNineEvent, SplashScreenNineState> {
  SplashScreenNineBloc(SplashScreenNineState initialState)
      : super(initialState) {
    on<SplashScreenNineInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenNineInitialEvent event,
    Emitter<SplashScreenNineState> emit,
  ) async {}
}
