import 'bloc/loading_screen_state_loading_bloc.dart';
import 'models/loading_screen_state_loading_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

class LoadingScreenStateLoadingScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<LoadingScreenStateLoadingBloc>(
      create: (context) =>
          LoadingScreenStateLoadingBloc(LoadingScreenStateLoadingState(
        loadingScreenStateLoadingModelObj: LoadingScreenStateLoadingModel(),
      ))
            ..add(LoadingScreenStateLoadingInitialEvent()),
      child: LoadingScreenStateLoadingScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoadingScreenStateLoadingBloc,
        LoadingScreenStateLoadingState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: double.maxFinite,
              padding: getPadding(
                top: 25,
                bottom: 25,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    "lbl_loading".tr,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtInterRegular20Red300,
                  ),
                  Spacer(),
                  Container(
                    width: double.maxFinite,
                    child: Container(
                      margin: getMargin(
                        bottom: 287,
                      ),
                      padding: getPadding(
                        left: 54,
                        top: 27,
                        right: 54,
                        bottom: 27,
                      ),
                      decoration: AppDecoration.fillWhiteA700.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder15,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgRectangle,
                            height: getSize(
                              100,
                            ),
                            width: getSize(
                              100,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              bottom: 21,
                            ),
                            child: Text(
                              "msg_some_chimken_would".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular20Red300,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
