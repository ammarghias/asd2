import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class LoadingScreenStateLoadingModel extends Equatable {LoadingScreenStateLoadingModel copyWith() { return LoadingScreenStateLoadingModel(
); } 
@override List<Object?> get props => [];
 }
