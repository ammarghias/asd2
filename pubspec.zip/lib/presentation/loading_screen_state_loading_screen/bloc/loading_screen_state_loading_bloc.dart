import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/loading_screen_state_loading_screen/models/loading_screen_state_loading_model.dart';
part 'loading_screen_state_loading_event.dart';
part 'loading_screen_state_loading_state.dart';

class LoadingScreenStateLoadingBloc extends Bloc<LoadingScreenStateLoadingEvent,
    LoadingScreenStateLoadingState> {
  LoadingScreenStateLoadingBloc(LoadingScreenStateLoadingState initialState)
      : super(initialState) {
    on<LoadingScreenStateLoadingInitialEvent>(_onInitialize);
  }

  _onInitialize(
    LoadingScreenStateLoadingInitialEvent event,
    Emitter<LoadingScreenStateLoadingState> emit,
  ) async {}
}
