// ignore_for_file: must_be_immutable

part of 'loading_screen_state_loading_bloc.dart';

class LoadingScreenStateLoadingState extends Equatable {
  LoadingScreenStateLoadingState({this.loadingScreenStateLoadingModelObj});

  LoadingScreenStateLoadingModel? loadingScreenStateLoadingModelObj;

  @override
  List<Object?> get props => [
        loadingScreenStateLoadingModelObj,
      ];
  LoadingScreenStateLoadingState copyWith(
      {LoadingScreenStateLoadingModel? loadingScreenStateLoadingModelObj}) {
    return LoadingScreenStateLoadingState(
      loadingScreenStateLoadingModelObj: loadingScreenStateLoadingModelObj ??
          this.loadingScreenStateLoadingModelObj,
    );
  }
}
