// ignore_for_file: must_be_immutable

part of 'loading_screen_state_loading_bloc.dart';

@immutable
abstract class LoadingScreenStateLoadingEvent extends Equatable {}

class LoadingScreenStateLoadingInitialEvent
    extends LoadingScreenStateLoadingEvent {
  @override
  List<Object?> get props => [];
}
