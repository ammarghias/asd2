import 'package:lottie/lottie.dart';

import 'bloc/icon_bloc.dart';
import 'models/icon_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';
import 'dart:async';


class IconScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<IconBloc>(
        create: (context) => IconBloc(IconState(iconModelObj: IconModel()))
          ..add(IconInitialEvent()),
        child: IconScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<IconBloc, IconState>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              backgroundColor: ColorConstant.whiteA700,
              body: Container(
                  width: double.maxFinite,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomImageView(
                            imagePath: ImageConstant.imgIcon,
                            height: getSize(390),
                            width: getSize(390),
                            onTap: () {
                              onTapImgIcon(context);
                            })
                      ]))));
    });
  }

  onTapImgIcon(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.splashScreenOneScreen,
    );
  }
}


class MySplash extends StatefulWidget {
  @override
  _MySplashState createState() => _MySplashState();
}

class _MySplashState extends State<MySplash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 2), () {
    NavigatorService.pushNamed(
      AppRoutes.splashScreenOneScreen,
    );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Lottie.asset(
  'assets/klj.json',
  width: 200,
  height: 200,
  fit: BoxFit.fill,
)
    );
  }
}