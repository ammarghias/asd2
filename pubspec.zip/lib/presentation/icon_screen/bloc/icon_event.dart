// ignore_for_file: must_be_immutable

part of 'icon_bloc.dart';

@immutable
abstract class IconEvent extends Equatable {}

class IconInitialEvent extends IconEvent {
  @override
  List<Object?> get props => [];
}
