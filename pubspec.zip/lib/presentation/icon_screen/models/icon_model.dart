import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class IconModel extends Equatable {IconModel copyWith() { return IconModel(
); } 
@override List<Object?> get props => [];
 }
