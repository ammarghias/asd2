// ignore_for_file: must_be_immutable

part of 'splash_screen_six_bloc.dart';

class SplashScreenSixState extends Equatable {
  SplashScreenSixState({this.splashScreenSixModelObj});

  SplashScreenSixModel? splashScreenSixModelObj;

  @override
  List<Object?> get props => [
        splashScreenSixModelObj,
      ];
  SplashScreenSixState copyWith(
      {SplashScreenSixModel? splashScreenSixModelObj}) {
    return SplashScreenSixState(
      splashScreenSixModelObj:
          splashScreenSixModelObj ?? this.splashScreenSixModelObj,
    );
  }
}
