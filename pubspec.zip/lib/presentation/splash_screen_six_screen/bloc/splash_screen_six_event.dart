// ignore_for_file: must_be_immutable

part of 'splash_screen_six_bloc.dart';

@immutable
abstract class SplashScreenSixEvent extends Equatable {}

class SplashScreenSixInitialEvent extends SplashScreenSixEvent {
  @override
  List<Object?> get props => [];
}
