import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_six_screen/models/splash_screen_six_model.dart';
part 'splash_screen_six_event.dart';
part 'splash_screen_six_state.dart';

class SplashScreenSixBloc
    extends Bloc<SplashScreenSixEvent, SplashScreenSixState> {
  SplashScreenSixBloc(SplashScreenSixState initialState) : super(initialState) {
    on<SplashScreenSixInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenSixInitialEvent event,
    Emitter<SplashScreenSixState> emit,
  ) async {}
}
