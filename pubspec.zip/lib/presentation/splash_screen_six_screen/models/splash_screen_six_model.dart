import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenSixModel extends Equatable {SplashScreenSixModel copyWith() { return SplashScreenSixModel(
); } 
@override List<Object?> get props => [];
 }
