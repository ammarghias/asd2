import '../models/card_management_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class CardManagementItemWidget extends StatelessWidget {
  CardManagementItemWidget(this.cardManagementItemModelObj);

  CardManagementItemModel cardManagementItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: getPadding(
        left: 16,
        top: 6,
        right: 16,
        bottom: 6,
      ),
      decoration: AppDecoration.outlinePink7005.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder10,
      ),
      child: Row(
        children: [
          Container(
            height: getSize(
              20,
            ),
            width: getSize(
              20,
            ),
            margin: getMargin(
              top: 14,
              bottom: 14,
            ),
            decoration: BoxDecoration(
              color: ColorConstant.whiteA700,
              borderRadius: BorderRadius.circular(
                getHorizontalSize(
                  5,
                ),
              ),
              border: Border.all(
                color: ColorConstant.pink700,
                width: getHorizontalSize(
                  1,
                ),
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgImage7445x45,
            height: getSize(
              45,
            ),
            width: getSize(
              45,
            ),
            radius: BorderRadius.circular(
              getHorizontalSize(
                22,
              ),
            ),
            margin: getMargin(
              left: 13,
              top: 3,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgPullcreditcard2,
            height: getVerticalSize(
              42,
            ),
            width: getHorizontalSize(
              69,
            ),
            radius: BorderRadius.circular(
              getHorizontalSize(
                3,
              ),
            ),
            margin: getMargin(
              left: 13,
              top: 3,
              bottom: 3,
            ),
          ),
          Padding(
            padding: getPadding(
              left: 18,
              top: 1,
              bottom: 2,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  "lbl_discover_it".tr,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtInterBold17Black90099,
                ),
                Padding(
                  padding: getPadding(
                    top: 2,
                  ),
                  child: Text(
                    "lbl_venture".tr,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtInterRegular17Black90099,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
