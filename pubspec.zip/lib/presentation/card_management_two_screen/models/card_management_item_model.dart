class CardManagementItemModel {String? id = "";

 }
