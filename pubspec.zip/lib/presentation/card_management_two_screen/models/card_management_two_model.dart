import 'package:equatable/equatable.dart';import 'card_management_item_model.dart';
// ignore: must_be_immutable
class CardManagementTwoModel extends Equatable {CardManagementTwoModel({this.cardManagementItemList = const []});

List<CardManagementItemModel> cardManagementItemList;

CardManagementTwoModel copyWith({List<CardManagementItemModel>? cardManagementItemList}) { return CardManagementTwoModel(
cardManagementItemList : cardManagementItemList ?? this.cardManagementItemList,
); } 
@override List<Object?> get props => [cardManagementItemList];
 }
