// ignore_for_file: must_be_immutable

part of 'card_management_two_bloc.dart';

class CardManagementTwoState extends Equatable {
  CardManagementTwoState({
    this.nameController,
    this.isSelectedSwitch = false,
    this.cardManagementTwoModelObj,
  });

  TextEditingController? nameController;

  CardManagementTwoModel? cardManagementTwoModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        nameController,
        isSelectedSwitch,
        cardManagementTwoModelObj,
      ];
  CardManagementTwoState copyWith({
    TextEditingController? nameController,
    bool? isSelectedSwitch,
    CardManagementTwoModel? cardManagementTwoModelObj,
  }) {
    return CardManagementTwoState(
      nameController: nameController ?? this.nameController,
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      cardManagementTwoModelObj:
          cardManagementTwoModelObj ?? this.cardManagementTwoModelObj,
    );
  }
}
