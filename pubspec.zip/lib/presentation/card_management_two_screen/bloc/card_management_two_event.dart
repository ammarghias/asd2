// ignore_for_file: must_be_immutable

part of 'card_management_two_bloc.dart';

@immutable
abstract class CardManagementTwoEvent extends Equatable {}

class CardManagementTwoInitialEvent extends CardManagementTwoEvent {
  @override
  List<Object?> get props => [];
}

///event for change switch
class ChangeSwitchEvent extends CardManagementTwoEvent {
  ChangeSwitchEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
