import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/card_management_item_model.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/card_management_two_screen/models/card_management_two_model.dart';
part 'card_management_two_event.dart';
part 'card_management_two_state.dart';

class CardManagementTwoBloc
    extends Bloc<CardManagementTwoEvent, CardManagementTwoState> {
  CardManagementTwoBloc(CardManagementTwoState initialState)
      : super(initialState) {
    on<CardManagementTwoInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<CardManagementTwoState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<CardManagementItemModel> fillCardManagementItemList() {
    return List.generate(3, (index) => CardManagementItemModel());
  }

  _onInitialize(
    CardManagementTwoInitialEvent event,
    Emitter<CardManagementTwoState> emit,
  ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        cardManagementTwoModelObj: state.cardManagementTwoModelObj?.copyWith(
      cardManagementItemList: fillCardManagementItemList(),
    )));
  }
}
