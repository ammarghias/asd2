import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class TermsAndDisclosuresModel extends Equatable {TermsAndDisclosuresModel copyWith() { return TermsAndDisclosuresModel(
); } 
@override List<Object?> get props => [];
 }
