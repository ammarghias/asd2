// ignore_for_file: must_be_immutable

part of 'terms_and_disclosures_bloc.dart';

@immutable
abstract class TermsAndDisclosuresEvent extends Equatable {}

class TermsAndDisclosuresInitialEvent extends TermsAndDisclosuresEvent {
  @override
  List<Object?> get props => [];
}
