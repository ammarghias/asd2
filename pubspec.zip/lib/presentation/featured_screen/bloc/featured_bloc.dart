import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/featured_item_model.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/featured_screen/models/featured_model.dart';
part 'featured_event.dart';
part 'featured_state.dart';

class FeaturedBloc extends Bloc<FeaturedEvent, FeaturedState> {
  FeaturedBloc(FeaturedState initialState) : super(initialState) {
    on<FeaturedInitialEvent>(_onInitialize);
  }

  List<FeaturedItemModel> fillFeaturedItemList() {
    return List.generate(4, (index) => FeaturedItemModel());
  }

  _onInitialize(
    FeaturedInitialEvent event,
    Emitter<FeaturedState> emit,
  ) async {
    emit(state.copyWith(
      group488Controller: TextEditingController(),
      group490Controller: TextEditingController(),
      emailController: TextEditingController(),
      mobilenoController: TextEditingController(),
      group496Controller: TextEditingController(),
      zipcodeController: TextEditingController(),
    ));
    emit(state.copyWith(
        featuredModelObj: state.featuredModelObj?.copyWith(
      featuredItemList: fillFeaturedItemList(),
    )));
  }
}
