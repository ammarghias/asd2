// ignore_for_file: must_be_immutable

part of 'featured_bloc.dart';

class FeaturedState extends Equatable {
  FeaturedState({
    this.group488Controller,
    this.group490Controller,
    this.emailController,
    this.mobilenoController,
    this.group496Controller,
    this.zipcodeController,
    this.featuredModelObj,
  });

  TextEditingController? group488Controller;

  TextEditingController? group490Controller;

  TextEditingController? emailController;

  TextEditingController? mobilenoController;

  TextEditingController? group496Controller;

  TextEditingController? zipcodeController;

  FeaturedModel? featuredModelObj;

  @override
  List<Object?> get props => [
        group488Controller,
        group490Controller,
        emailController,
        mobilenoController,
        group496Controller,
        zipcodeController,
        featuredModelObj,
      ];
  FeaturedState copyWith({
    TextEditingController? group488Controller,
    TextEditingController? group490Controller,
    TextEditingController? emailController,
    TextEditingController? mobilenoController,
    TextEditingController? group496Controller,
    TextEditingController? zipcodeController,
    FeaturedModel? featuredModelObj,
  }) {
    return FeaturedState(
      group488Controller: group488Controller ?? this.group488Controller,
      group490Controller: group490Controller ?? this.group490Controller,
      emailController: emailController ?? this.emailController,
      mobilenoController: mobilenoController ?? this.mobilenoController,
      group496Controller: group496Controller ?? this.group496Controller,
      zipcodeController: zipcodeController ?? this.zipcodeController,
      featuredModelObj: featuredModelObj ?? this.featuredModelObj,
    );
  }
}
