class FeaturedItemModel {String emailaddressTxt = "Net Income";

String emailaddressTxt1 = "Per year, Pre-tax";

String? id = "";

 }
