import 'package:equatable/equatable.dart';import 'featured_item_model.dart';
// ignore: must_be_immutable
class FeaturedModel extends Equatable {FeaturedModel({this.featuredItemList = const []});

List<FeaturedItemModel> featuredItemList;

FeaturedModel copyWith({List<FeaturedItemModel>? featuredItemList}) { return FeaturedModel(
featuredItemList : featuredItemList ?? this.featuredItemList,
); } 
@override List<Object?> get props => [featuredItemList];
 }
