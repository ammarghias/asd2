import '../featured_screen/widgets/featured_item_widget.dart';
import 'bloc/featured_bloc.dart';
import 'models/featured_item_model.dart';
import 'models/featured_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/core/utils/validation_functions.dart';
import 'package:ammar_s_application4/presentation/home_page/home_page.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/widgets/custom_button.dart';
import 'package:ammar_s_application4/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class FeaturedScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<FeaturedBloc>(
      create: (context) => FeaturedBloc(FeaturedState(
        featuredModelObj: FeaturedModel(),
      ))
        ..add(FeaturedInitialEvent()),
      child: FeaturedScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        appBar: CustomAppBar(
          height: getVerticalSize(
            56,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink700,
          ),
          actions: [
            Container(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  AppbarImage(
                    height: getVerticalSize(
                      21,
                    ),
                    width: getHorizontalSize(
                      29,
                    ),
                    svgPath: ImageConstant.imgMenu,
                  ),
                  AppbarImage(
                    height: getVerticalSize(
                      21,
                    ),
                    width: getHorizontalSize(
                      29,
                    ),
                    svgPath: ImageConstant.imgMenu,
                  ),
                ],
              ),
            ),
          ],
        ),
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Padding(
              padding: getPadding(
                right: 3,
                bottom: 5,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      height: getVerticalSize(
                        30,
                      ),
                      width: getHorizontalSize(
                        219,
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                              height: getVerticalSize(
                                27,
                              ),
                              width: getHorizontalSize(
                                219,
                              ),
                              decoration: BoxDecoration(
                                color: ColorConstant.pink700,
                                borderRadius: BorderRadius.circular(
                                  getHorizontalSize(
                                    10,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: Text(
                              "lbl_pre_enrollment".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtHindVadodaraRegular20WhiteA700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      width: getHorizontalSize(
                        311,
                      ),
                      margin: getMargin(
                        left: 37,
                        top: 28,
                        right: 41,
                      ),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "msg_we_love_your_interest2".tr,
                              style: TextStyle(
                                color: ColorConstant.gray50002,
                                fontSize: getFontSize(
                                  18,
                                ),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            TextSpan(
                              text: "msg_follow_us_for_all".tr,
                              style: TextStyle(
                                color: ColorConstant.pink700,
                                fontSize: getFontSize(
                                  18,
                                ),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w500,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ],
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 42,
                      top: 39,
                      right: 76,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: getPadding(
                            bottom: 1,
                          ),
                          child: Text(
                            "lbl_first_name".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterMedium17Bluegray400,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            top: 1,
                          ),
                          child: Text(
                            "lbl_last_name".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterMedium17Bluegray400,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: getPadding(
                        left: 42,
                        top: 3,
                        right: 14,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          BlocSelector<FeaturedBloc, FeaturedState,
                              TextEditingController?>(
                            selector: (state) => state.group488Controller,
                            builder: (context, group488Controller) {
                              return CustomTextFormField(
                                width: getHorizontalSize(
                                  150,
                                ),
                                focusNode: FocusNode(),
                                controller: group488Controller,
                                hintText: "lbl_jane".tr,
                              );
                            },
                          ),
                          BlocSelector<FeaturedBloc, FeaturedState,
                              TextEditingController?>(
                            selector: (state) => state.group490Controller,
                            builder: (context, group490Controller) {
                              return CustomTextFormField(
                                width: getHorizontalSize(
                                  150,
                                ),
                                focusNode: FocusNode(),
                                controller: group490Controller,
                                hintText: "lbl_doe".tr,
                                margin: getMargin(
                                  left: 34,
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 42,
                      top: 20,
                    ),
                    child: Text(
                      "lbl_email_address".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium17Bluegray400,
                    ),
                  ),
                  BlocSelector<FeaturedBloc, FeaturedState,
                      TextEditingController?>(
                    selector: (state) => state.emailController,
                    builder: (context, emailController) {
                      return CustomTextFormField(
                        focusNode: FocusNode(),
                        controller: emailController,
                        hintText: "msg_janedoe_cashback_financial".tr,
                        margin: getMargin(
                          left: 42,
                          top: 6,
                          right: 14,
                        ),
                        textInputType: TextInputType.emailAddress,
                        alignment: Alignment.centerRight,
                        validator: (value) {
                          if (value == null ||
                              (!isValidEmail(value, isRequired: true))) {
                            return "Please enter valid email";
                          }
                          return null;
                        },
                      );
                    },
                  ),
                  Padding(
                    padding: getPadding(
                      left: 42,
                      top: 20,
                    ),
                    child: Text(
                      "lbl_phone_number2".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium17Bluegray400,
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: getPadding(
                        top: 1,
                      ),
                      child: SizedBox(
                        width: getHorizontalSize(
                          50,
                        ),
                        child: Divider(
                          height: getVerticalSize(
                            1,
                          ),
                          thickness: getVerticalSize(
                            1,
                          ),
                          color: ColorConstant.whiteA700,
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: getPadding(
                        top: 1,
                      ),
                      child: SizedBox(
                        width: getHorizontalSize(
                          57,
                        ),
                        child: Divider(
                          height: getVerticalSize(
                            1,
                          ),
                          thickness: getVerticalSize(
                            1,
                          ),
                          color: ColorConstant.whiteA700,
                        ),
                      ),
                    ),
                  ),
                  BlocSelector<FeaturedBloc, FeaturedState,
                      TextEditingController?>(
                    selector: (state) => state.mobilenoController,
                    builder: (context, mobilenoController) {
                      return CustomTextFormField(
                        focusNode: FocusNode(),
                        controller: mobilenoController,
                        hintText: "lbl_1_3456542993".tr,
                        margin: getMargin(
                          left: 42,
                          right: 14,
                        ),
                        alignment: Alignment.centerRight,
                      );
                    },
                  ),
                  Padding(
                    padding: getPadding(
                      left: 42,
                      top: 20,
                    ),
                    child: Text(
                      "msg_street_address_line".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium17Bluegray400,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 42,
                      top: 6,
                    ),
                    child: Text(
                      "msg_3678_montgomery".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium17,
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: getPadding(
                        top: 2,
                      ),
                      child: Divider(
                        height: getVerticalSize(
                          1,
                        ),
                        thickness: getVerticalSize(
                          1,
                        ),
                        color: ColorConstant.gray200,
                        indent: getHorizontalSize(
                          42,
                        ),
                        endIndent: getHorizontalSize(
                          14,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 42,
                      top: 21,
                    ),
                    child: Text(
                      "msg_street_address_line2".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium17Bluegray400,
                    ),
                  ),
                  BlocSelector<FeaturedBloc, FeaturedState,
                      TextEditingController?>(
                    selector: (state) => state.group496Controller,
                    builder: (context, group496Controller) {
                      return CustomTextFormField(
                        focusNode: FocusNode(),
                        controller: group496Controller,
                        hintText: "lbl_house_36".tr,
                        margin: getMargin(
                          left: 42,
                          top: 3,
                          right: 14,
                        ),
                        alignment: Alignment.centerRight,
                      );
                    },
                  ),
                  Padding(
                    padding: getPadding(
                      left: 42,
                      top: 20,
                    ),
                    child: Row(
                      children: [
                        Padding(
                          padding: getPadding(
                            top: 2,
                          ),
                          child: Text(
                            "lbl_zip_code".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterMedium17Bluegray400,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 114,
                            bottom: 2,
                          ),
                          child: Text(
                            "lbl_state".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterMedium17Bluegray400,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: getPadding(
                        left: 42,
                        top: 2,
                        right: 18,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: BlocSelector<FeaturedBloc, FeaturedState,
                                TextEditingController?>(
                              selector: (state) => state.zipcodeController,
                              builder: (context, zipcodeController) {
                                return CustomTextFormField(
                                  focusNode: FocusNode(),
                                  controller: zipcodeController,
                                  hintText: "lbl_84832".tr,
                                  margin: getMargin(
                                    top: 1,
                                    right: 23,
                                  ),
                                  textInputAction: TextInputAction.done,
                                );
                              },
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: getPadding(
                                left: 23,
                                bottom: 1,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(
                                    "lbl_va".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterMedium17,
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      top: 4,
                                    ),
                                    child: SizedBox(
                                      width: getHorizontalSize(
                                        142,
                                      ),
                                      child: Divider(
                                        height: getVerticalSize(
                                          1,
                                        ),
                                        thickness: getVerticalSize(
                                          1,
                                        ),
                                        color: ColorConstant.gray200,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: getPadding(
                        left: 42,
                        top: 26,
                        right: 23,
                      ),
                      child: BlocSelector<FeaturedBloc, FeaturedState,
                          FeaturedModel?>(
                        selector: (state) => state.featuredModelObj,
                        builder: (context, featuredModelObj) {
                          return ListView.separated(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            separatorBuilder: (context, index) {
                              return SizedBox(
                                height: getVerticalSize(
                                  16,
                                ),
                              );
                            },
                            itemCount:
                                featuredModelObj?.featuredItemList.length ?? 0,
                            itemBuilder: (context, index) {
                              FeaturedItemModel model =
                                  featuredModelObj?.featuredItemList[index] ??
                                      FeaturedItemModel();
                              return FeaturedItemWidget(
                                model,
                              );
                            },
                          );
                        },
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 40,
                      top: 30,
                      right: 71,
                    ),
                    child: Row(
                      children: [
                        Container(
                          height: getVerticalSize(
                            20,
                          ),
                          width: getHorizontalSize(
                            22,
                          ),
                          decoration: BoxDecoration(
                            color: ColorConstant.whiteA700,
                            borderRadius: BorderRadius.circular(
                              getHorizontalSize(
                                5,
                              ),
                            ),
                            border: Border.all(
                              color: ColorConstant.pink700,
                              width: getHorizontalSize(
                                1,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 12,
                            top: 1,
                          ),
                          child: RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "lbl_i_understand".tr,
                                  style: TextStyle(
                                    color: ColorConstant.blueGray400,
                                    fontSize: getFontSize(
                                      15,
                                    ),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                TextSpan(
                                  text: "msg_what_this_form_is".tr,
                                  style: TextStyle(
                                    color: ColorConstant.pink700,
                                    fontSize: getFontSize(
                                      15,
                                    ),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w700,
                                    decoration: TextDecoration.underline,
                                  ),
                                ),
                              ],
                            ),
                            textAlign: TextAlign.left,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: getPadding(
                        left: 39,
                        top: 33,
                        right: 19,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: getHorizontalSize(
                                      106,
                                    ),
                                    child: RichText(
                                      text: TextSpan(
                                        children: [
                                          TextSpan(
                                            text: "lbl_apply".tr,
                                            style: TextStyle(
                                              color: ColorConstant.gray50007,
                                              fontSize: getFontSize(
                                                50,
                                              ),
                                              fontFamily: 'Staatliches',
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                          TextSpan(
                                            text: "lbl_for".tr,
                                            style: TextStyle(
                                              color: ColorConstant.gray50007,
                                              fontSize: getFontSize(
                                                30,
                                              ),
                                              fontFamily: 'Staatliches',
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ],
                                      ),
                                      textAlign: TextAlign.right,
                                    ),
                                  ),
                                  Container(
                                    height: getVerticalSize(
                                      20,
                                    ),
                                    width: getHorizontalSize(
                                      22,
                                    ),
                                    margin: getMargin(
                                      left: 26,
                                      top: 11,
                                      bottom: 66,
                                    ),
                                    decoration: BoxDecoration(
                                      color: ColorConstant.whiteA700,
                                      borderRadius: BorderRadius.circular(
                                        getHorizontalSize(
                                          5,
                                        ),
                                      ),
                                      border: Border.all(
                                        color: ColorConstant.pink700,
                                        width: getHorizontalSize(
                                          1,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 59,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      height: getVerticalSize(
                                        20,
                                      ),
                                      width: getHorizontalSize(
                                        22,
                                      ),
                                      margin: getMargin(
                                        top: 22,
                                        bottom: 25,
                                      ),
                                      decoration: BoxDecoration(
                                        color: ColorConstant.whiteA700,
                                        borderRadius: BorderRadius.circular(
                                          getHorizontalSize(
                                            5,
                                          ),
                                        ),
                                        border: Border.all(
                                          color: ColorConstant.pink700,
                                          width: getHorizontalSize(
                                            1,
                                          ),
                                        ),
                                      ),
                                    ),
                                    CustomImageView(
                                      svgPath: ImageConstant.imgGroup44,
                                      height: getVerticalSize(
                                        67,
                                      ),
                                      width: getHorizontalSize(
                                        112,
                                      ),
                                      margin: getMargin(
                                        left: 19,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 22,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      height: getVerticalSize(
                                        20,
                                      ),
                                      width: getHorizontalSize(
                                        22,
                                      ),
                                      margin: getMargin(
                                        top: 21,
                                        bottom: 26,
                                      ),
                                      decoration: BoxDecoration(
                                        color: ColorConstant.whiteA700,
                                        borderRadius: BorderRadius.circular(
                                          getHorizontalSize(
                                            5,
                                          ),
                                        ),
                                        border: Border.all(
                                          color: ColorConstant.pink700,
                                          width: getHorizontalSize(
                                            1,
                                          ),
                                        ),
                                      ),
                                    ),
                                    CustomImageView(
                                      svgPath: ImageConstant.imgGroup8,
                                      height: getVerticalSize(
                                        67,
                                      ),
                                      width: getHorizontalSize(
                                        112,
                                      ),
                                      margin: getMargin(
                                        left: 19,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: getPadding(
                              left: 2,
                              top: 13,
                              bottom: 5,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: Container(
                                    height: getVerticalSize(
                                      58,
                                    ),
                                    width: getHorizontalSize(
                                      82,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.topCenter,
                                      children: [
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                            padding: getPadding(
                                              right: 1,
                                            ),
                                            child: RichText(
                                              text: TextSpan(
                                                children: [
                                                  TextSpan(
                                                    text: "lbl_875".tr,
                                                    style: TextStyle(
                                                      color: ColorConstant
                                                          .gray50002,
                                                      fontSize: getFontSize(
                                                        15,
                                                      ),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: "lbl_year".tr,
                                                    style: TextStyle(
                                                      color: ColorConstant
                                                          .gray50002,
                                                      fontSize: getFontSize(
                                                        10,
                                                      ),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              textAlign: TextAlign.left,
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topCenter,
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.end,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              CustomImageView(
                                                svgPath: ImageConstant
                                                    .imgClockPink700,
                                                height: getVerticalSize(
                                                  14,
                                                ),
                                                width: getHorizontalSize(
                                                  80,
                                                ),
                                                margin: getMargin(
                                                  right: 2,
                                                ),
                                              ),
                                              Padding(
                                                padding: getPadding(
                                                  top: 1,
                                                ),
                                                child: Text(
                                                  "lbl_blaze".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterBold20Pink70002,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: Padding(
                                    padding: getPadding(
                                      right: 2,
                                    ),
                                    child: Text(
                                      "lbl_starting_from".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterMedium8,
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgClockPink700,
                                  height: getVerticalSize(
                                    14,
                                  ),
                                  width: getHorizontalSize(
                                    80,
                                  ),
                                  margin: getMargin(
                                    top: 77,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 1,
                                  ),
                                  child: Text(
                                    "lbl_gold".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular20Yellow700,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 1,
                                  ),
                                  child: RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "lbl_02".tr,
                                          style: TextStyle(
                                            color: ColorConstant.gray50002,
                                            fontSize: getFontSize(
                                              18,
                                            ),
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        TextSpan(
                                          text: "lbl_year".tr,
                                          style: TextStyle(
                                            color: ColorConstant.gray50002,
                                            fontSize: getFontSize(
                                              10,
                                            ),
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                    textAlign: TextAlign.left,
                                  ),
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgClockPink700,
                                  height: getVerticalSize(
                                    14,
                                  ),
                                  width: getHorizontalSize(
                                    80,
                                  ),
                                  margin: getMargin(
                                    left: 3,
                                    top: 28,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 3,
                                  ),
                                  child: Text(
                                    "lbl_blu2".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular20Cyan80001,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 3,
                                  ),
                                  child: RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "lbl_65".tr,
                                          style: TextStyle(
                                            color: ColorConstant.gray50002,
                                            fontSize: getFontSize(
                                              18,
                                            ),
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        TextSpan(
                                          text: "lbl_year".tr,
                                          style: TextStyle(
                                            color: ColorConstant.gray50002,
                                            fontSize: getFontSize(
                                              10,
                                            ),
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                    textAlign: TextAlign.left,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: getMargin(
                              left: 7,
                              top: 8,
                              bottom: 191,
                            ),
                            padding: getPadding(
                              top: 1,
                              bottom: 1,
                            ),
                            decoration:
                                AppDecoration.outlineBlack90099.copyWith(
                              borderRadius: BorderRadiusStyle.customBorderBL36,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Card(
                                  clipBehavior: Clip.antiAlias,
                                  elevation: 0,
                                  margin: getMargin(
                                    bottom: 6,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadiusStyle.customBorderBL36,
                                  ),
                                  child: Container(
                                    height: getVerticalSize(
                                      104,
                                    ),
                                    width: getHorizontalSize(
                                      71,
                                    ),
                                    padding: getPadding(
                                      left: 5,
                                      top: 6,
                                      right: 5,
                                      bottom: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadiusStyle.customBorderBL36,
                                      image: DecorationImage(
                                        image: AssetImage(
                                          ImageConstant.imgGroup818,
                                        ),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    child: Stack(
                                      alignment: Alignment.bottomRight,
                                      children: [
                                        CustomImageView(
                                          svgPath:
                                              ImageConstant.imgSignalWhiteA700,
                                          height: getVerticalSize(
                                            9,
                                          ),
                                          width: getHorizontalSize(
                                            55,
                                          ),
                                          alignment: Alignment.bottomLeft,
                                          margin: getMargin(
                                            bottom: 6,
                                          ),
                                        ),
                                        CustomImageView(
                                          svgPath:
                                              ImageConstant.imgGroupAmber300,
                                          height: getVerticalSize(
                                            83,
                                          ),
                                          width: getHorizontalSize(
                                            16,
                                          ),
                                          alignment: Alignment.bottomRight,
                                          margin: getMargin(
                                            right: 4,
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topLeft,
                                          child: Padding(
                                            padding: getPadding(
                                              top: 8,
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgGroupWhiteA7002x27,
                                                  height: getVerticalSize(
                                                    2,
                                                  ),
                                                  width: getHorizontalSize(
                                                    27,
                                                  ),
                                                ),
                                                CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgGroupWhiteA7003x29,
                                                  height: getVerticalSize(
                                                    3,
                                                  ),
                                                  width: getHorizontalSize(
                                                    29,
                                                  ),
                                                  margin: getMargin(
                                                    top: 2,
                                                  ),
                                                ),
                                                CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgGroupWhiteA7002x17,
                                                  height: getVerticalSize(
                                                    2,
                                                  ),
                                                  width: getHorizontalSize(
                                                    17,
                                                  ),
                                                  margin: getMargin(
                                                    left: 1,
                                                    top: 10,
                                                  ),
                                                ),
                                                CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgGroupWhiteA7004x13,
                                                  height: getVerticalSize(
                                                    4,
                                                  ),
                                                  width: getHorizontalSize(
                                                    13,
                                                  ),
                                                  margin: getMargin(
                                                    left: 1,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 39,
                      top: 22,
                    ),
                    child: Row(
                      children: [
                        Container(
                          height: getVerticalSize(
                            20,
                          ),
                          width: getHorizontalSize(
                            22,
                          ),
                          margin: getMargin(
                            top: 20,
                            bottom: 28,
                          ),
                          decoration: BoxDecoration(
                            color: ColorConstant.whiteA700,
                            borderRadius: BorderRadius.circular(
                              getHorizontalSize(
                                5,
                              ),
                            ),
                            border: Border.all(
                              color: ColorConstant.pink700,
                              width: getHorizontalSize(
                                1,
                              ),
                            ),
                          ),
                        ),
                        CustomImageView(
                          svgPath: ImageConstant.imgGroup8,
                          height: getVerticalSize(
                            68,
                          ),
                          width: getHorizontalSize(
                            111,
                          ),
                          margin: getMargin(
                            left: 19,
                          ),
                        ),
                        Container(
                          height: getVerticalSize(
                            60,
                          ),
                          width: getHorizontalSize(
                            80,
                          ),
                          margin: getMargin(
                            left: 8,
                            top: 4,
                            bottom: 4,
                          ),
                          child: Stack(
                            alignment: Alignment.topCenter,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Padding(
                                  padding: getPadding(
                                    left: 2,
                                  ),
                                  child: RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "lbl_150".tr,
                                          style: TextStyle(
                                            color: ColorConstant.gray50002,
                                            fontSize: getFontSize(
                                              18,
                                            ),
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        TextSpan(
                                          text: "lbl_year".tr,
                                          style: TextStyle(
                                            color: ColorConstant.gray50002,
                                            fontSize: getFontSize(
                                              10,
                                            ),
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                    textAlign: TextAlign.left,
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    CustomImageView(
                                      svgPath: ImageConstant.imgClockPink700,
                                      height: getVerticalSize(
                                        14,
                                      ),
                                      width: getHorizontalSize(
                                        80,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 4,
                                      ),
                                      child: Text(
                                        "lbl_skye2".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular20Cyan200,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: getPadding(
                        top: 57,
                      ),
                      child: Text(
                        "msg_preferred_form_of".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtInterBold18,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: getPadding(
                        left: 40,
                        top: 13,
                        right: 36,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: getVerticalSize(
                              20,
                            ),
                            width: getHorizontalSize(
                              22,
                            ),
                            margin: getMargin(
                              top: 2,
                              bottom: 3,
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.whiteA700,
                              borderRadius: BorderRadius.circular(
                                getHorizontalSize(
                                  5,
                                ),
                              ),
                              border: Border.all(
                                color: ColorConstant.pink700,
                                width: getHorizontalSize(
                                  1,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 14,
                            ),
                            child: Text(
                              "lbl_email2".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium21Gray50002,
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              20,
                            ),
                            width: getHorizontalSize(
                              22,
                            ),
                            margin: getMargin(
                              left: 37,
                              top: 2,
                              bottom: 3,
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.whiteA700,
                              borderRadius: BorderRadius.circular(
                                getHorizontalSize(
                                  5,
                                ),
                              ),
                              border: Border.all(
                                color: ColorConstant.pink700,
                                width: getHorizontalSize(
                                  1,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 14,
                            ),
                            child: Text(
                              "lbl_phone_number2".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium21Gray50002,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      39,
                    ),
                    width: double.maxFinite,
                    margin: getMargin(
                      top: 41,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Padding(
                            padding: getPadding(
                              bottom: 16,
                            ),
                            child: SizedBox(
                              width: double.maxFinite,
                              child: Divider(
                                height: getVerticalSize(
                                  2,
                                ),
                                thickness: getVerticalSize(
                                  2,
                                ),
                                color: ColorConstant.gray40003,
                              ),
                            ),
                          ),
                        ),
                        CustomButton(
                          height: getVerticalSize(
                            39,
                          ),
                          width: getHorizontalSize(
                            267,
                          ),
                          text: "msg_submit_application".tr,
                          variant: ButtonVariant.OutlineWhiteA700_8,
                          shape: ButtonShape.RoundedBorder10,
                          padding: ButtonPadding.PaddingAll3,
                          fontStyle: ButtonFontStyle.HindVadodaraBold21,
                          alignment: Alignment.center,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group1:
        return AppRoutes.homePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(BuildContext context, String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
