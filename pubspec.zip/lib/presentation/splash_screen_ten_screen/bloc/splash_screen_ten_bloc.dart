import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_ten_screen/models/splash_screen_ten_model.dart';
part 'splash_screen_ten_event.dart';
part 'splash_screen_ten_state.dart';

class SplashScreenTenBloc
    extends Bloc<SplashScreenTenEvent, SplashScreenTenState> {
  SplashScreenTenBloc(SplashScreenTenState initialState) : super(initialState) {
    on<SplashScreenTenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenTenInitialEvent event,
    Emitter<SplashScreenTenState> emit,
  ) async {}
}
