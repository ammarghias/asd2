// ignore_for_file: must_be_immutable

part of 'splash_screen_ten_bloc.dart';

@immutable
abstract class SplashScreenTenEvent extends Equatable {}

class SplashScreenTenInitialEvent extends SplashScreenTenEvent {
  @override
  List<Object?> get props => [];
}
