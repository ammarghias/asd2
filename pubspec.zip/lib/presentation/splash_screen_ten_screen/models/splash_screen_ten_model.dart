import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenTenModel extends Equatable {SplashScreenTenModel copyWith() { return SplashScreenTenModel(
); } 
@override List<Object?> get props => [];
 }
