import 'bloc/splash_screen_ten_bloc.dart';
import 'models/splash_screen_ten_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

class SplashScreenTenScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<SplashScreenTenBloc>(
      create: (context) => SplashScreenTenBloc(SplashScreenTenState(
        splashScreenTenModelObj: SplashScreenTenModel(),
      ))
        ..add(SplashScreenTenInitialEvent()),
      child: SplashScreenTenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenTenBloc, SplashScreenTenState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Container(
                        height: size.height,
                        width: double.maxFinite,
                        child: Stack(
                          alignment: Alignment.bottomCenter,
                          children: [
                            Align(
                              alignment: Alignment.topCenter,
                              child: Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Padding(
                                padding: getPadding(
                                  left: 13,
                                  right: 13,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 176,
                                      ),
                                      child: Text(
                                        "lbl_cashback".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtLEMONMILKMedium65,
                                      ),
                                    ),
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 172,
                                      ),
                                      child: Text(
                                        "lbl_cashback".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtLEMONMILKMedium65,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Container(
                                height: size.height,
                                width: double.maxFinite,
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    CustomImageView(
                                      imagePath: ImageConstant.imgEllipse12,
                                      height: getVerticalSize(
                                        844,
                                      ),
                                      width: getHorizontalSize(
                                        390,
                                      ),
                                      alignment: Alignment.center,
                                    ),
                                    Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                        height: getVerticalSize(
                                          48,
                                        ),
                                        width: getHorizontalSize(
                                          276,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.centerLeft,
                                          children: [
                                            CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgGroupWhiteA70047x276,
                                              height: getVerticalSize(
                                                47,
                                              ),
                                              width: getHorizontalSize(
                                                276,
                                              ),
                                              alignment: Alignment.center,
                                            ),
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Padding(
                                                padding: getPadding(
                                                  left: 31,
                                                  right: 66,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgFrame,
                                                      height: getVerticalSize(
                                                        48,
                                                      ),
                                                      width: getHorizontalSize(
                                                        44,
                                                      ),
                                                    ),
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgFrame,
                                                      height: getVerticalSize(
                                                        48,
                                                      ),
                                                      width: getHorizontalSize(
                                                        44,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
