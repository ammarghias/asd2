import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/listgroup_item_model.dart';
import '../models/listemailaddres_item_model.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/savings_estimator_screen/models/savings_estimator_model.dart';
part 'savings_estimator_event.dart';
part 'savings_estimator_state.dart';

class SavingsEstimatorBloc
    extends Bloc<SavingsEstimatorEvent, SavingsEstimatorState> {
  SavingsEstimatorBloc(SavingsEstimatorState initialState)
      : super(initialState) {
    on<SavingsEstimatorInitialEvent>(_onInitialize);
    on<ChangeCheckBoxEvent>(_changeCheckBox);
    on<ChangeCheckBox1Event>(_changeCheckBox1);
  }

  _changeCheckBox(
    ChangeCheckBoxEvent event,
    Emitter<SavingsEstimatorState> emit,
  ) {
    emit(state.copyWith(
      isCheckbox: event.value,
    ));
  }

  _changeCheckBox1(
    ChangeCheckBox1Event event,
    Emitter<SavingsEstimatorState> emit,
  ) {
    emit(state.copyWith(
      isCheckbox1: event.value,
    ));
  }

  List<ListgroupItemModel> fillListgroupItemList() {
    return List.generate(4, (index) => ListgroupItemModel());
  }

  List<ListemailaddresItemModel> fillListemailaddresItemList() {
    return List.generate(5, (index) => ListemailaddresItemModel());
  }

  _onInitialize(
    SavingsEstimatorInitialEvent event,
    Emitter<SavingsEstimatorState> emit,
  ) async {
    emit(state.copyWith(
      isCheckbox: false,
      isCheckbox1: false,
    ));
    emit(state.copyWith(
        savingsEstimatorModelObj: state.savingsEstimatorModelObj?.copyWith(
      listgroupItemList: fillListgroupItemList(),
      listemailaddresItemList: fillListemailaddresItemList(),
    )));
  }
}
