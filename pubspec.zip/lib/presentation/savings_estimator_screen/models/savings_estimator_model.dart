import 'package:equatable/equatable.dart';import 'listgroup_item_model.dart';import 'listemailaddres_item_model.dart';
// ignore: must_be_immutable
class SavingsEstimatorModel extends Equatable {SavingsEstimatorModel({this.listgroupItemList = const [], this.listemailaddresItemList = const []});

List<ListgroupItemModel> listgroupItemList;

List<ListemailaddresItemModel> listemailaddresItemList;

SavingsEstimatorModel copyWith({List<ListgroupItemModel>? listgroupItemList, List<ListemailaddresItemModel>? listemailaddresItemList}) { return SavingsEstimatorModel(
listgroupItemList : listgroupItemList ?? this.listgroupItemList,
listemailaddresItemList : listemailaddresItemList ?? this.listemailaddresItemList,
); } 
@override List<Object?> get props => [listgroupItemList,listemailaddresItemList];
 }
