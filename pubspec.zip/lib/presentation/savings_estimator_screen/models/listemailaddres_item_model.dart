class ListemailaddresItemModel {String emailaddressTxt = "Yearly Net Income";

String descriptionTxt = "Your Annual Take home income";

String amountTxt = "87,432";

String? id = "";

 }
