class ListgroupItemModel {String typeTxt = "Gold:";

String valueTxt = "1,131.57";

String? id = "";

 }
