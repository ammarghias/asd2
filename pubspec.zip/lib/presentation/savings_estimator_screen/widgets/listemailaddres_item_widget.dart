import '../models/listemailaddres_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

// ignore: must_be_immutable
class ListemailaddresItemWidget extends StatelessWidget {
  ListemailaddresItemWidget(this.listemailaddresItemModelObj);

  ListemailaddresItemModel listemailaddresItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              listemailaddresItemModelObj.emailaddressTxt,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
              style: AppStyle.txtInterRegular17Pink700,
            ),
            Container(
              width: getHorizontalSize(
                157,
              ),
              margin: getMargin(
                top: 1,
              ),
              child: Text(
                listemailaddresItemModelObj.descriptionTxt,
                maxLines: null,
                textAlign: TextAlign.left,
                style: AppStyle.txtInterMedium14,
              ),
            ),
          ],
        ),
        Container(
          height: getVerticalSize(
            51,
          ),
          width: getHorizontalSize(
            157,
          ),
          margin: getMargin(
            left: 41,
            bottom: 5,
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: getPadding(
                    bottom: 8,
                  ),
                  child: SizedBox(
                    width: getHorizontalSize(
                      135,
                    ),
                    child: Divider(
                      height: getVerticalSize(
                        2,
                      ),
                      thickness: getVerticalSize(
                        2,
                      ),
                      color: ColorConstant.blueGray10005,
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  width: getHorizontalSize(
                    157,
                  ),
                  padding: getPadding(
                    all: 10,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadiusStyle.roundedBorder15,
                    image: DecorationImage(
                      image: fs.Svg(
                        ImageConstant.imgGroup1182,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        height: getVerticalSize(
                          26,
                        ),
                        width: getHorizontalSize(
                          12,
                        ),
                        margin: getMargin(
                          top: 1,
                          bottom: 1,
                        ),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                "lbl2".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterMedium21,
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                "lbl2".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterMedium21,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          left: 38,
                          top: 3,
                        ),
                        child: Text(
                          listemailaddresItemModelObj.amountTxt,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterMedium21,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
