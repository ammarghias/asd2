import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class PasswordResetPage4UpdatedModel extends Equatable {PasswordResetPage4UpdatedModel copyWith() { return PasswordResetPage4UpdatedModel(
); } 
@override List<Object?> get props => [];
 }
