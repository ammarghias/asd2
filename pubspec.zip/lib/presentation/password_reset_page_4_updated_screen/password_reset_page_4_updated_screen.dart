import 'bloc/password_reset_page_4_updated_bloc.dart';
import 'models/password_reset_page_4_updated_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

class PasswordResetPage4UpdatedScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<PasswordResetPage4UpdatedBloc>(
      create: (context) =>
          PasswordResetPage4UpdatedBloc(PasswordResetPage4UpdatedState(
        passwordResetPage4UpdatedModelObj: PasswordResetPage4UpdatedModel(),
      ))
            ..add(PasswordResetPage4UpdatedInitialEvent()),
      child: PasswordResetPage4UpdatedScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PasswordResetPage4UpdatedBloc,
        PasswordResetPage4UpdatedState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            appBar: CustomAppBar(
              height: getVerticalSize(
                146,
              ),
              leadingWidth: 48,
              leading: AppbarImage(
                height: getVerticalSize(
                  31,
                ),
                width: getHorizontalSize(
                  29,
                ),
                svgPath: ImageConstant.imgClock,
                margin: getMargin(
                  left: 19,
                  bottom: 51,
                ),
              ),
              centerTitle: true,
              title: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        height: getVerticalSize(
                          30.129997,
                        ),
                        width: getHorizontalSize(
                          63.350006,
                        ),
                        child: Stack(
                          alignment: Alignment.centerRight,
                          children: [
                            AppbarImage(
                              height: getVerticalSize(
                                30,
                              ),
                              width: getHorizontalSize(
                                25,
                              ),
                              svgPath: ImageConstant.imgContrast,
                              margin: getMargin(
                                right: 38,
                              ),
                            ),
                            AppbarImage(
                              height: getVerticalSize(
                                30,
                              ),
                              width: getHorizontalSize(
                                19,
                              ),
                              svgPath: ImageConstant.imgReply,
                              margin: getMargin(
                                left: 44,
                              ),
                            ),
                            AppbarImage(
                              height: getVerticalSize(
                                30,
                              ),
                              width: getHorizontalSize(
                                27,
                              ),
                              svgPath: ImageConstant.imgVectorPink7000130x27,
                              margin: getMargin(
                                left: 20,
                                right: 15,
                              ),
                            ),
                          ],
                        ),
                      ),
                      AppbarImage(
                        height: getVerticalSize(
                          29,
                        ),
                        width: getHorizontalSize(
                          22,
                        ),
                        svgPath: ImageConstant.imgComputer,
                        margin: getMargin(
                          left: 3,
                        ),
                      ),
                      Container(
                        height: getVerticalSize(
                          30.129997,
                        ),
                        width: getHorizontalSize(
                          60.569977,
                        ),
                        margin: getMargin(
                          left: 5,
                        ),
                        child: Stack(
                          alignment: Alignment.centerRight,
                          children: [
                            AppbarImage(
                              height: getVerticalSize(
                                29,
                              ),
                              width: getHorizontalSize(
                                17,
                              ),
                              svgPath: ImageConstant.imgVectorPink70001,
                              margin: getMargin(
                                right: 43,
                              ),
                            ),
                            AppbarImage(
                              height: getVerticalSize(
                                30,
                              ),
                              width: getHorizontalSize(
                                24,
                              ),
                              svgPath: ImageConstant.imgPlay,
                              margin: getMargin(
                                left: 36,
                              ),
                            ),
                            AppbarImage(
                              height: getVerticalSize(
                                30,
                              ),
                              width: getHorizontalSize(
                                27,
                              ),
                              svgPath: ImageConstant.imgVectorPink7000130x27,
                              margin: getMargin(
                                left: 14,
                                right: 18,
                              ),
                            ),
                          ],
                        ),
                      ),
                      AppbarImage(
                        height: getVerticalSize(
                          29,
                        ),
                        width: getHorizontalSize(
                          21,
                        ),
                        svgPath: ImageConstant.imgLocation,
                        margin: getMargin(
                          left: 3,
                        ),
                      ),
                    ],
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: getPadding(
                        top: 30,
                      ),
                      child: Text(
                        "msg_make_sure_it_s_strong".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtInterRegular18Gray60075,
                      ),
                    ),
                  ),
                ],
              ),
              actions: [
                AppbarImage(
                  height: getSize(
                    25,
                  ),
                  width: getSize(
                    25,
                  ),
                  svgPath: ImageConstant.imgFile,
                  margin: getMargin(
                    left: 30,
                    top: 4,
                    right: 30,
                    bottom: 53,
                  ),
                ),
              ],
            ),
            body: Container(
              height: getVerticalSize(
                660,
              ),
              width: double.maxFinite,
              padding: getPadding(
                top: 41,
                bottom: 41,
              ),
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  Align(
                    alignment: Alignment.topCenter,
                    child: Padding(
                      padding: getPadding(
                        left: 19,
                        right: 15,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            "msg_let_s_get_ya_ll".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular20,
                          ),
                          Padding(
                            padding: getPadding(
                              left: 3,
                              top: 29,
                            ),
                            child: Text(
                              "lbl_new_password".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17,
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              51,
                            ),
                            width: getHorizontalSize(
                              353,
                            ),
                            margin: getMargin(
                              left: 3,
                              top: 10,
                            ),
                            child: Stack(
                              alignment: Alignment.centerLeft,
                              children: [
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    padding: getPadding(
                                      left: 17,
                                      top: 11,
                                      right: 17,
                                      bottom: 11,
                                    ),
                                    decoration:
                                        AppDecoration.fillBluegray50.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.customBorderTL16,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        CustomImageView(
                                          svgPath: ImageConstant.imgLock,
                                          height: getVerticalSize(
                                            12,
                                          ),
                                          width: getHorizontalSize(
                                            10,
                                          ),
                                          margin: getMargin(
                                            top: 5,
                                          ),
                                        ),
                                        Container(
                                          height: getVerticalSize(
                                            8,
                                          ),
                                          width: getHorizontalSize(
                                            24,
                                          ),
                                          margin: getMargin(
                                            top: 1,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              CustomImageView(
                                                svgPath: ImageConstant
                                                    .imgTicketGray800,
                                                height: getVerticalSize(
                                                  8,
                                                ),
                                                width: getHorizontalSize(
                                                  24,
                                                ),
                                                alignment: Alignment.center,
                                              ),
                                              Align(
                                                alignment: Alignment.center,
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgVectorGray800,
                                                      height: getSize(
                                                        3,
                                                      ),
                                                      width: getSize(
                                                        3,
                                                      ),
                                                    ),
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgVectorGray800,
                                                      height: getSize(
                                                        3,
                                                      ),
                                                      width: getSize(
                                                        3,
                                                      ),
                                                      margin: getMargin(
                                                        left: 1,
                                                      ),
                                                    ),
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgVectorGray800,
                                                      height: getSize(
                                                        3,
                                                      ),
                                                      width: getSize(
                                                        3,
                                                      ),
                                                      margin: getMargin(
                                                        left: 1,
                                                      ),
                                                    ),
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgVectorGray800,
                                                      height: getSize(
                                                        3,
                                                      ),
                                                      width: getSize(
                                                        3,
                                                      ),
                                                      margin: getMargin(
                                                        left: 1,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: getPadding(
                                      left: 69,
                                    ),
                                    child: Text(
                                      "lbl_enter_password2".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterMedium15Gray40087,
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgGroup1182,
                                  height: getVerticalSize(
                                    51,
                                  ),
                                  width: getHorizontalSize(
                                    353,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      15,
                                    ),
                                  ),
                                  alignment: Alignment.center,
                                ),
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: getPadding(
                                      left: 58,
                                    ),
                                    child: SizedBox(
                                      height: getVerticalSize(
                                        51,
                                      ),
                                      child: VerticalDivider(
                                        width: getHorizontalSize(
                                          1,
                                        ),
                                        thickness: getVerticalSize(
                                          1,
                                        ),
                                        color: ColorConstant.gray200,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 4,
                              top: 17,
                            ),
                            child: Text(
                              "msg_confirm_password".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17,
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              51,
                            ),
                            width: getHorizontalSize(
                              352,
                            ),
                            margin: getMargin(
                              left: 4,
                              top: 6,
                            ),
                            child: Stack(
                              alignment: Alignment.centerLeft,
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                    width: getHorizontalSize(
                                      352,
                                    ),
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder15,
                                      image: DecorationImage(
                                        image: fs.Svg(
                                          ImageConstant.imgGroup1182,
                                        ),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          padding: getPadding(
                                            left: 17,
                                            top: 14,
                                            right: 17,
                                            bottom: 14,
                                          ),
                                          decoration: AppDecoration
                                              .fillBluegray50
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .customBorderTL16,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              CustomImageView(
                                                svgPath: ImageConstant.imgLock,
                                                height: getVerticalSize(
                                                  12,
                                                ),
                                                width: getHorizontalSize(
                                                  10,
                                                ),
                                              ),
                                              Container(
                                                height: getVerticalSize(
                                                  8,
                                                ),
                                                width: getHorizontalSize(
                                                  24,
                                                ),
                                                margin: getMargin(
                                                  top: 1,
                                                  bottom: 1,
                                                ),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgTicketGray800,
                                                      height: getVerticalSize(
                                                        8,
                                                      ),
                                                      width: getHorizontalSize(
                                                        24,
                                                      ),
                                                      alignment:
                                                          Alignment.center,
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: [
                                                          CustomImageView(
                                                            svgPath: ImageConstant
                                                                .imgVectorGray800,
                                                            height: getSize(
                                                              3,
                                                            ),
                                                            width: getSize(
                                                              3,
                                                            ),
                                                          ),
                                                          CustomImageView(
                                                            svgPath: ImageConstant
                                                                .imgVectorGray800,
                                                            height: getSize(
                                                              3,
                                                            ),
                                                            width: getSize(
                                                              3,
                                                            ),
                                                            margin: getMargin(
                                                              left: 1,
                                                            ),
                                                          ),
                                                          CustomImageView(
                                                            svgPath: ImageConstant
                                                                .imgVectorGray800,
                                                            height: getSize(
                                                              3,
                                                            ),
                                                            width: getSize(
                                                              3,
                                                            ),
                                                            margin: getMargin(
                                                              left: 1,
                                                            ),
                                                          ),
                                                          CustomImageView(
                                                            svgPath: ImageConstant
                                                                .imgVectorGray800,
                                                            height: getSize(
                                                              3,
                                                            ),
                                                            width: getSize(
                                                              3,
                                                            ),
                                                            margin: getMargin(
                                                              left: 1,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 10,
                                            top: 15,
                                            bottom: 16,
                                          ),
                                          child: Text(
                                            "msg_confirm_password".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtInterMedium15Gray40087,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: getPadding(
                                      left: 58,
                                    ),
                                    child: SizedBox(
                                      height: getVerticalSize(
                                        51,
                                      ),
                                      child: VerticalDivider(
                                        width: getHorizontalSize(
                                          1,
                                        ),
                                        thickness: getVerticalSize(
                                          1,
                                        ),
                                        color: ColorConstant.gray200,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 4,
                              top: 44,
                            ),
                            child: Text(
                              "msg_password_recommendations".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterBold16,
                            ),
                          ),
                          Container(
                            width: getHorizontalSize(
                              280,
                            ),
                            margin: getMargin(
                              left: 5,
                              top: 6,
                              right: 69,
                            ),
                            child: Text(
                              "msg_should_be_at_least".tr,
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular15,
                            ),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                              margin: getMargin(
                                top: 41,
                              ),
                              padding: getPadding(
                                left: 47,
                                top: 14,
                                right: 47,
                                bottom: 14,
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadiusStyle.roundedBorder15,
                                image: DecorationImage(
                                  image: fs.Svg(
                                    ImageConstant.imgPasswordresetbutton,
                                  ),
                                  fit: BoxFit.cover,
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding: getPadding(
                                      top: 3,
                                    ),
                                    child: Text(
                                      "lbl_update_password".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold15,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      margin: getMargin(
                        top: 38,
                      ),
                      padding: getPadding(
                        left: 17,
                        top: 10,
                        right: 17,
                        bottom: 10,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadiusStyle.roundedBorder15,
                        image: DecorationImage(
                          image: AssetImage(
                            ImageConstant.imgFrame67,
                          ),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: getPadding(
                              top: 4,
                            ),
                            child: Text(
                              "msg_password_updated".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterBold20,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
