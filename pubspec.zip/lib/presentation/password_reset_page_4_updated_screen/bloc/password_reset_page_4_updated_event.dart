// ignore_for_file: must_be_immutable

part of 'password_reset_page_4_updated_bloc.dart';

@immutable
abstract class PasswordResetPage4UpdatedEvent extends Equatable {}

class PasswordResetPage4UpdatedInitialEvent
    extends PasswordResetPage4UpdatedEvent {
  @override
  List<Object?> get props => [];
}
