import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/password_reset_page_4_updated_screen/models/password_reset_page_4_updated_model.dart';
part 'password_reset_page_4_updated_event.dart';
part 'password_reset_page_4_updated_state.dart';

class PasswordResetPage4UpdatedBloc extends Bloc<PasswordResetPage4UpdatedEvent,
    PasswordResetPage4UpdatedState> {
  PasswordResetPage4UpdatedBloc(PasswordResetPage4UpdatedState initialState)
      : super(initialState) {
    on<PasswordResetPage4UpdatedInitialEvent>(_onInitialize);
  }

  _onInitialize(
    PasswordResetPage4UpdatedInitialEvent event,
    Emitter<PasswordResetPage4UpdatedState> emit,
  ) async {}
}
