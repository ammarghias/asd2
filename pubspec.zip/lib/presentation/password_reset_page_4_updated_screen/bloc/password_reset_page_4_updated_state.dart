// ignore_for_file: must_be_immutable

part of 'password_reset_page_4_updated_bloc.dart';

class PasswordResetPage4UpdatedState extends Equatable {
  PasswordResetPage4UpdatedState({this.passwordResetPage4UpdatedModelObj});

  PasswordResetPage4UpdatedModel? passwordResetPage4UpdatedModelObj;

  @override
  List<Object?> get props => [
        passwordResetPage4UpdatedModelObj,
      ];
  PasswordResetPage4UpdatedState copyWith(
      {PasswordResetPage4UpdatedModel? passwordResetPage4UpdatedModelObj}) {
    return PasswordResetPage4UpdatedState(
      passwordResetPage4UpdatedModelObj: passwordResetPage4UpdatedModelObj ??
          this.passwordResetPage4UpdatedModelObj,
    );
  }
}
