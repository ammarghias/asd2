import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class LoginPagePageLoginModel extends Equatable {LoginPagePageLoginModel copyWith() { return LoginPagePageLoginModel(
); } 
@override List<Object?> get props => [];
 }
