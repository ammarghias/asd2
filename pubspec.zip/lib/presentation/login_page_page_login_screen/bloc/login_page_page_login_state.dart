// ignore_for_file: must_be_immutable

part of 'login_page_page_login_bloc.dart';

class LoginPagePageLoginState extends Equatable {
  LoginPagePageLoginState({this.loginPagePageLoginModelObj});

  LoginPagePageLoginModel? loginPagePageLoginModelObj;

  @override
  List<Object?> get props => [
        loginPagePageLoginModelObj,
      ];
  LoginPagePageLoginState copyWith(
      {LoginPagePageLoginModel? loginPagePageLoginModelObj}) {
    return LoginPagePageLoginState(
      loginPagePageLoginModelObj:
          loginPagePageLoginModelObj ?? this.loginPagePageLoginModelObj,
    );
  }
}
