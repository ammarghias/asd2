import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application4/presentation/login_page_page_login_screen/models/login_page_page_login_model.dart';part 'login_page_page_login_event.dart';part 'login_page_page_login_state.dart';class LoginPagePageLoginBloc extends Bloc<LoginPagePageLoginEvent, LoginPagePageLoginState> {LoginPagePageLoginBloc(LoginPagePageLoginState initialState) : super(initialState) { on<LoginPagePageLoginInitialEvent>(_onInitialize); }

_onInitialize(LoginPagePageLoginInitialEvent event, Emitter<LoginPagePageLoginState> emit, ) async  {  } 
 }
