// ignore_for_file: must_be_immutable

part of 'login_page_page_login_bloc.dart';

@immutable
abstract class LoginPagePageLoginEvent extends Equatable {}

class LoginPagePageLoginInitialEvent extends LoginPagePageLoginEvent {
  @override
  List<Object?> get props => [];
}
