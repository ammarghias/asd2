import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_eighteen_screen/models/splash_screen_eighteen_model.dart';
part 'splash_screen_eighteen_event.dart';
part 'splash_screen_eighteen_state.dart';

class SplashScreenEighteenBloc
    extends Bloc<SplashScreenEighteenEvent, SplashScreenEighteenState> {
  SplashScreenEighteenBloc(SplashScreenEighteenState initialState)
      : super(initialState) {
    on<SplashScreenEighteenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenEighteenInitialEvent event,
    Emitter<SplashScreenEighteenState> emit,
  ) async {}
}
