// ignore_for_file: must_be_immutable

part of 'splash_screen_eighteen_bloc.dart';

class SplashScreenEighteenState extends Equatable {
  SplashScreenEighteenState({this.splashScreenEighteenModelObj});

  SplashScreenEighteenModel? splashScreenEighteenModelObj;

  @override
  List<Object?> get props => [
        splashScreenEighteenModelObj,
      ];
  SplashScreenEighteenState copyWith(
      {SplashScreenEighteenModel? splashScreenEighteenModelObj}) {
    return SplashScreenEighteenState(
      splashScreenEighteenModelObj:
          splashScreenEighteenModelObj ?? this.splashScreenEighteenModelObj,
    );
  }
}
