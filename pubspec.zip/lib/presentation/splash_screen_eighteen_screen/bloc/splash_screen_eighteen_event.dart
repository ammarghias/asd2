// ignore_for_file: must_be_immutable

part of 'splash_screen_eighteen_bloc.dart';

@immutable
abstract class SplashScreenEighteenEvent extends Equatable {}

class SplashScreenEighteenInitialEvent extends SplashScreenEighteenEvent {
  @override
  List<Object?> get props => [];
}
