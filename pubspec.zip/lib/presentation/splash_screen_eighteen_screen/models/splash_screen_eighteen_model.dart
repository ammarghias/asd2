import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenEighteenModel extends Equatable {SplashScreenEighteenModel copyWith() { return SplashScreenEighteenModel(
); } 
@override List<Object?> get props => [];
 }
