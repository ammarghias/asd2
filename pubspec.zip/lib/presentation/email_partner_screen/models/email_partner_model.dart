import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class EmailPartnerModel extends Equatable {EmailPartnerModel copyWith() { return EmailPartnerModel(
); } 
@override List<Object?> get props => [];
 }
