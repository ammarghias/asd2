// ignore_for_file: must_be_immutable

part of 'email_partner_bloc.dart';

@immutable
abstract class EmailPartnerEvent extends Equatable {}

class EmailPartnerInitialEvent extends EmailPartnerEvent {
  @override
  List<Object?> get props => [];
}
