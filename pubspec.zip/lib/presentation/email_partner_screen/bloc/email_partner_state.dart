// ignore_for_file: must_be_immutable

part of 'email_partner_bloc.dart';

class EmailPartnerState extends Equatable {
  EmailPartnerState({
    this.usernameController,
    this.emailPartnerModelObj,
  });

  TextEditingController? usernameController;

  EmailPartnerModel? emailPartnerModelObj;

  @override
  List<Object?> get props => [
        usernameController,
        emailPartnerModelObj,
      ];
  EmailPartnerState copyWith({
    TextEditingController? usernameController,
    EmailPartnerModel? emailPartnerModelObj,
  }) {
    return EmailPartnerState(
      usernameController: usernameController ?? this.usernameController,
      emailPartnerModelObj: emailPartnerModelObj ?? this.emailPartnerModelObj,
    );
  }
}
