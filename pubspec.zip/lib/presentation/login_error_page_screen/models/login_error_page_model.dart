import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class LoginErrorPageModel extends Equatable {LoginErrorPageModel copyWith() { return LoginErrorPageModel(
); } 
@override List<Object?> get props => [];
 }
