import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application4/presentation/login_error_page_screen/models/login_error_page_model.dart';part 'login_error_page_event.dart';part 'login_error_page_state.dart';class LoginErrorPageBloc extends Bloc<LoginErrorPageEvent, LoginErrorPageState> {LoginErrorPageBloc(LoginErrorPageState initialState) : super(initialState) { on<LoginErrorPageInitialEvent>(_onInitialize); }

_onInitialize(LoginErrorPageInitialEvent event, Emitter<LoginErrorPageState> emit, ) async  { emit(state.copyWith(groupninetytwoController: TextEditingController())); } 
 }
