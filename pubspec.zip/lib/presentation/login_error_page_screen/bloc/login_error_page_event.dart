// ignore_for_file: must_be_immutable

part of 'login_error_page_bloc.dart';

@immutable
abstract class LoginErrorPageEvent extends Equatable {}

class LoginErrorPageInitialEvent extends LoginErrorPageEvent {
  @override
  List<Object?> get props => [];
}
