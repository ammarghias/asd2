// ignore_for_file: must_be_immutable

part of 'login_error_page_bloc.dart';

class LoginErrorPageState extends Equatable {
  LoginErrorPageState({
    this.groupninetytwoController,
    this.loginErrorPageModelObj,
  });

  TextEditingController? groupninetytwoController;

  LoginErrorPageModel? loginErrorPageModelObj;

  @override
  List<Object?> get props => [
        groupninetytwoController,
        loginErrorPageModelObj,
      ];
  LoginErrorPageState copyWith({
    TextEditingController? groupninetytwoController,
    LoginErrorPageModel? loginErrorPageModelObj,
  }) {
    return LoginErrorPageState(
      groupninetytwoController:
          groupninetytwoController ?? this.groupninetytwoController,
      loginErrorPageModelObj:
          loginErrorPageModelObj ?? this.loginErrorPageModelObj,
    );
  }
}
