import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class PasswordResetPageOneModel extends Equatable {PasswordResetPageOneModel copyWith() { return PasswordResetPageOneModel(
); } 
@override List<Object?> get props => [];
 }
