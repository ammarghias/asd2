// ignore_for_file: must_be_immutable

part of 'password_reset_page_one_bloc.dart';

@immutable
abstract class PasswordResetPageOneEvent extends Equatable {}

class PasswordResetPageOneInitialEvent extends PasswordResetPageOneEvent {
  @override
  List<Object?> get props => [];
}
