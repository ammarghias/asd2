import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application4/presentation/password_reset_page_one_screen/models/password_reset_page_one_model.dart';part 'password_reset_page_one_event.dart';part 'password_reset_page_one_state.dart';class PasswordResetPageOneBloc extends Bloc<PasswordResetPageOneEvent, PasswordResetPageOneState> {PasswordResetPageOneBloc(PasswordResetPageOneState initialState) : super(initialState) { on<PasswordResetPageOneInitialEvent>(_onInitialize); }

_onInitialize(PasswordResetPageOneInitialEvent event, Emitter<PasswordResetPageOneState> emit, ) async  { emit(state.copyWith(rectangle622Controller: TextEditingController(), group292Controller: TextEditingController())); } 
 }
