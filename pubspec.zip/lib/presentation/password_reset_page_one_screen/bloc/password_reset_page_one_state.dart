// ignore_for_file: must_be_immutable

part of 'password_reset_page_one_bloc.dart';

class PasswordResetPageOneState extends Equatable {
  PasswordResetPageOneState({
    this.rectangle622Controller,
    this.group292Controller,
    this.passwordResetPageOneModelObj,
  });

  TextEditingController? rectangle622Controller;

  TextEditingController? group292Controller;

  PasswordResetPageOneModel? passwordResetPageOneModelObj;

  @override
  List<Object?> get props => [
        rectangle622Controller,
        group292Controller,
        passwordResetPageOneModelObj,
      ];
  PasswordResetPageOneState copyWith({
    TextEditingController? rectangle622Controller,
    TextEditingController? group292Controller,
    PasswordResetPageOneModel? passwordResetPageOneModelObj,
  }) {
    return PasswordResetPageOneState(
      rectangle622Controller:
          rectangle622Controller ?? this.rectangle622Controller,
      group292Controller: group292Controller ?? this.group292Controller,
      passwordResetPageOneModelObj:
          passwordResetPageOneModelObj ?? this.passwordResetPageOneModelObj,
    );
  }
}
