import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_eight_screen/models/splash_screen_eight_model.dart';
part 'splash_screen_eight_event.dart';
part 'splash_screen_eight_state.dart';

class SplashScreenEightBloc
    extends Bloc<SplashScreenEightEvent, SplashScreenEightState> {
  SplashScreenEightBloc(SplashScreenEightState initialState)
      : super(initialState) {
    on<SplashScreenEightInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenEightInitialEvent event,
    Emitter<SplashScreenEightState> emit,
  ) async {}
}
