// ignore_for_file: must_be_immutable

part of 'splash_screen_eight_bloc.dart';

class SplashScreenEightState extends Equatable {
  SplashScreenEightState({this.splashScreenEightModelObj});

  SplashScreenEightModel? splashScreenEightModelObj;

  @override
  List<Object?> get props => [
        splashScreenEightModelObj,
      ];
  SplashScreenEightState copyWith(
      {SplashScreenEightModel? splashScreenEightModelObj}) {
    return SplashScreenEightState(
      splashScreenEightModelObj:
          splashScreenEightModelObj ?? this.splashScreenEightModelObj,
    );
  }
}
