// ignore_for_file: must_be_immutable

part of 'registration_wallet_update_bloc.dart';

@immutable
abstract class RegistrationWalletUpdateEvent extends Equatable {}

class RegistrationWalletUpdateInitialEvent
    extends RegistrationWalletUpdateEvent {
  @override
  List<Object?> get props => [];
}
