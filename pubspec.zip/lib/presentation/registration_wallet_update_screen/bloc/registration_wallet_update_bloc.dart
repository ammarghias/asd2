import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application4/presentation/registration_wallet_update_screen/models/registration_wallet_update_model.dart';part 'registration_wallet_update_event.dart';part 'registration_wallet_update_state.dart';class RegistrationWalletUpdateBloc extends Bloc<RegistrationWalletUpdateEvent, RegistrationWalletUpdateState> {RegistrationWalletUpdateBloc(RegistrationWalletUpdateState initialState) : super(initialState) { on<RegistrationWalletUpdateInitialEvent>(_onInitialize); }

_onInitialize(RegistrationWalletUpdateInitialEvent event, Emitter<RegistrationWalletUpdateState> emit, ) async  {  } 
 }
