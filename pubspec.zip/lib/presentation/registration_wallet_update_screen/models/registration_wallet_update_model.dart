import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class RegistrationWalletUpdateModel extends Equatable {RegistrationWalletUpdateModel copyWith() { return RegistrationWalletUpdateModel(
); } 
@override List<Object?> get props => [];
 }
