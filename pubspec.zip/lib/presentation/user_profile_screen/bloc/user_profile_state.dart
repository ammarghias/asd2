// ignore_for_file: must_be_immutable

part of 'user_profile_bloc.dart';

class UserProfileState extends Equatable {
  UserProfileState({
    this.group510Controller,
    this.emailController,
    this.mobilenoController,
    this.group516Controller,
    this.zipcodeController,
    this.userProfileModelObj,
  });

  TextEditingController? group510Controller;

  TextEditingController? emailController;

  TextEditingController? mobilenoController;

  TextEditingController? group516Controller;

  TextEditingController? zipcodeController;

  UserProfileModel? userProfileModelObj;

  @override
  List<Object?> get props => [
        group510Controller,
        emailController,
        mobilenoController,
        group516Controller,
        zipcodeController,
        userProfileModelObj,
      ];
  UserProfileState copyWith({
    TextEditingController? group510Controller,
    TextEditingController? emailController,
    TextEditingController? mobilenoController,
    TextEditingController? group516Controller,
    TextEditingController? zipcodeController,
    UserProfileModel? userProfileModelObj,
  }) {
    return UserProfileState(
      group510Controller: group510Controller ?? this.group510Controller,
      emailController: emailController ?? this.emailController,
      mobilenoController: mobilenoController ?? this.mobilenoController,
      group516Controller: group516Controller ?? this.group516Controller,
      zipcodeController: zipcodeController ?? this.zipcodeController,
      userProfileModelObj: userProfileModelObj ?? this.userProfileModelObj,
    );
  }
}
