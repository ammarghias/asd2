import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class UserProfileModel extends Equatable {UserProfileModel copyWith() { return UserProfileModel(
); } 
@override List<Object?> get props => [];
 }
