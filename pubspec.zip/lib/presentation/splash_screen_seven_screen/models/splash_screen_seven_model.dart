import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenSevenModel extends Equatable {SplashScreenSevenModel copyWith() { return SplashScreenSevenModel(
); } 
@override List<Object?> get props => [];
 }
