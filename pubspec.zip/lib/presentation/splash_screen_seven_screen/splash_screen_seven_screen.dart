import 'bloc/splash_screen_seven_bloc.dart';
import 'models/splash_screen_seven_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

class SplashScreenSevenScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<SplashScreenSevenBloc>(
      create: (context) => SplashScreenSevenBloc(SplashScreenSevenState(
        splashScreenSevenModelObj: SplashScreenSevenModel(),
      ))
        ..add(SplashScreenSevenInitialEvent()),
      child: SplashScreenSevenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenSevenBloc, SplashScreenSevenState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Container(
                        height: size.height,
                        width: double.maxFinite,
                        child: Stack(
                          alignment: Alignment.bottomCenter,
                          children: [
                            Align(
                              alignment: Alignment.topCenter,
                              child: Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Padding(
                                padding: getPadding(
                                  left: 13,
                                  right: 13,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 176,
                                      ),
                                      child: Text(
                                        "lbl_cashback".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtLEMONMILKMedium65,
                                      ),
                                    ),
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 172,
                                      ),
                                      child: Text(
                                        "lbl_cashback".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtLEMONMILKMedium65,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            CustomImageView(
                              imagePath: ImageConstant.imgEllipse1,
                              height: getVerticalSize(
                                844,
                              ),
                              width: getHorizontalSize(
                                390,
                              ),
                              alignment: Alignment.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
