// ignore_for_file: must_be_immutable

part of 'splash_screen_seven_bloc.dart';

class SplashScreenSevenState extends Equatable {
  SplashScreenSevenState({this.splashScreenSevenModelObj});

  SplashScreenSevenModel? splashScreenSevenModelObj;

  @override
  List<Object?> get props => [
        splashScreenSevenModelObj,
      ];
  SplashScreenSevenState copyWith(
      {SplashScreenSevenModel? splashScreenSevenModelObj}) {
    return SplashScreenSevenState(
      splashScreenSevenModelObj:
          splashScreenSevenModelObj ?? this.splashScreenSevenModelObj,
    );
  }
}
