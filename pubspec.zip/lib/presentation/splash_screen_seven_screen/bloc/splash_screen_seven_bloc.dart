import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_seven_screen/models/splash_screen_seven_model.dart';
part 'splash_screen_seven_event.dart';
part 'splash_screen_seven_state.dart';

class SplashScreenSevenBloc
    extends Bloc<SplashScreenSevenEvent, SplashScreenSevenState> {
  SplashScreenSevenBloc(SplashScreenSevenState initialState)
      : super(initialState) {
    on<SplashScreenSevenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenSevenInitialEvent event,
    Emitter<SplashScreenSevenState> emit,
  ) async {}
}
