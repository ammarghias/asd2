// ignore_for_file: must_be_immutable

part of 'splash_screen_seven_bloc.dart';

@immutable
abstract class SplashScreenSevenEvent extends Equatable {}

class SplashScreenSevenInitialEvent extends SplashScreenSevenEvent {
  @override
  List<Object?> get props => [];
}
