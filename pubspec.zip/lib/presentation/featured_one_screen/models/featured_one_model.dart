import 'package:equatable/equatable.dart';import 'featured_one_item_model.dart';
// ignore: must_be_immutable
class FeaturedOneModel extends Equatable {FeaturedOneModel({this.featuredOneItemList = const []});

List<FeaturedOneItemModel> featuredOneItemList;

FeaturedOneModel copyWith({List<FeaturedOneItemModel>? featuredOneItemList}) { return FeaturedOneModel(
featuredOneItemList : featuredOneItemList ?? this.featuredOneItemList,
); } 
@override List<Object?> get props => [featuredOneItemList];
 }
