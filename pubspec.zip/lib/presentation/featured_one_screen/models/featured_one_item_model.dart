class FeaturedOneItemModel {String pullrewardtypeTxt = "Reward Points";

String rewardpointsvalTxt = "3.6";

String cardtypeTxt = "American Express";

String cardnameTxt = "Blue Cash Preferred";

String servicerTxt = "Servicer | Highest";

String? id = "";

 }
