// ignore_for_file: must_be_immutable

part of 'featured_one_bloc.dart';

class FeaturedOneState extends Equatable {
  FeaturedOneState({
    this.isSelectedSwitch = false,
    this.featuredOneModelObj,
  });

  FeaturedOneModel? featuredOneModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        isSelectedSwitch,
        featuredOneModelObj,
      ];
  FeaturedOneState copyWith({
    bool? isSelectedSwitch,
    FeaturedOneModel? featuredOneModelObj,
  }) {
    return FeaturedOneState(
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      featuredOneModelObj: featuredOneModelObj ?? this.featuredOneModelObj,
    );
  }
}
