import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/featured_one_item_model.dart';
import 'package:ammar_s_application4/presentation/featured_one_screen/models/featured_one_model.dart';
part 'featured_one_event.dart';
part 'featured_one_state.dart';

class FeaturedOneBloc extends Bloc<FeaturedOneEvent, FeaturedOneState> {
  FeaturedOneBloc(FeaturedOneState initialState) : super(initialState) {
    on<FeaturedOneInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<FeaturedOneState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<FeaturedOneItemModel> fillFeaturedOneItemList() {
    return List.generate(2, (index) => FeaturedOneItemModel());
  }

  _onInitialize(
    FeaturedOneInitialEvent event,
    Emitter<FeaturedOneState> emit,
  ) async {
    emit(state.copyWith(
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        featuredOneModelObj: state.featuredOneModelObj?.copyWith(
      featuredOneItemList: fillFeaturedOneItemList(),
    )));
  }
}
