// ignore_for_file: must_be_immutable

part of 'featured_one_bloc.dart';

@immutable
abstract class FeaturedOneEvent extends Equatable {}

class FeaturedOneInitialEvent extends FeaturedOneEvent {
  @override
  List<Object?> get props => [];
}

///event for change switch
class ChangeSwitchEvent extends FeaturedOneEvent {
  ChangeSwitchEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
