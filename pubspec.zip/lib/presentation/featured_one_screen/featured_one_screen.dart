import '../featured_one_screen/widgets/featured_one_item_widget.dart';
import 'bloc/featured_one_bloc.dart';
import 'models/featured_one_item_model.dart';
import 'models/featured_one_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application4/widgets/custom_switch.dart';
import 'package:flutter/material.dart';

class FeaturedOneScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<FeaturedOneBloc>(
      create: (context) => FeaturedOneBloc(FeaturedOneState(
        featuredOneModelObj: FeaturedOneModel(),
      ))
        ..add(FeaturedOneInitialEvent()),
      child: FeaturedOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        appBar: CustomAppBar(
          height: getVerticalSize(
            97,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink700,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: SizedBox(
          width: size.width,
          child: SingleChildScrollView(
            padding: getPadding(
              top: 2,
            ),
            child: Padding(
              padding: getPadding(
                left: 7,
                right: 7,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      left: 1,
                    ),
                    child: Text(
                      "lbl_featured".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtStaatlichesRegular22,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 1,
                      top: 2,
                      right: 4,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "msg_specially_curated".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterRegular14,
                        ),
                        Padding(
                          padding: getPadding(
                            top: 7,
                            bottom: 8,
                          ),
                          child: SizedBox(
                            width: getHorizontalSize(
                              200,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: getPadding(
                      left: 1,
                      top: 17,
                      right: 2,
                    ),
                    child: IntrinsicWidth(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            margin: getMargin(
                              top: 13,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 2,
                              right: 3,
                              bottom: 2,
                            ),
                            decoration: AppDecoration.outlineGray300.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgImage67,
                                  height: getVerticalSize(
                                    70,
                                  ),
                                  width: getHorizontalSize(
                                    93,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      7,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: getHorizontalSize(
                                    36,
                                  ),
                                  margin: getMargin(
                                    top: 3,
                                  ),
                                  child: Text(
                                    "msg_walmart_superstores".tr,
                                    maxLines: null,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              121,
                            ),
                            width: getHorizontalSize(
                              68,
                            ),
                            child: Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    decoration:
                                        AppDecoration.outlinePink700.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder5,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: getPadding(
                                            right: 3,
                                          ),
                                          child: Text(
                                            "lbl_cashback2".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular9,
                                          ),
                                        ),
                                        Container(
                                          height: getVerticalSize(
                                            18,
                                          ),
                                          width: getHorizontalSize(
                                            66,
                                          ),
                                          decoration: BoxDecoration(
                                            color: ColorConstant.pink700,
                                            borderRadius: BorderRadius.circular(
                                              getHorizontalSize(
                                                4,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Padding(
                                    padding: getPadding(
                                      left: 24,
                                      top: 7,
                                    ),
                                    child: Text(
                                      "lbl_5".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold20,
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topRight,
                                  child: Padding(
                                    padding: getPadding(
                                      top: 7,
                                      right: 13,
                                    ),
                                    child: Text(
                                      "lbl".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtInterRegular20WhiteA700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: getHorizontalSize(
                              210,
                            ),
                            margin: getMargin(
                              left: 12,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  height: getVerticalSize(
                                    121,
                                  ),
                                  width: getHorizontalSize(
                                    99,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.topRight,
                                    children: [
                                      Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Container(
                                          padding: getPadding(
                                            all: 3,
                                          ),
                                          decoration: AppDecoration
                                              .outlineGray300
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder10,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Card(
                                                clipBehavior: Clip.antiAlias,
                                                elevation: 0,
                                                margin: EdgeInsets.all(0),
                                                color: ColorConstant.red800,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder5,
                                                ),
                                                child: Container(
                                                  height: getVerticalSize(
                                                    70,
                                                  ),
                                                  width: getHorizontalSize(
                                                    93,
                                                  ),
                                                  padding: getPadding(
                                                    left: 5,
                                                    right: 5,
                                                  ),
                                                  decoration: AppDecoration
                                                      .fillRed800
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder5,
                                                  ),
                                                  child: Stack(
                                                    children: [
                                                      CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgImage73,
                                                        height: getVerticalSize(
                                                          57,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          82,
                                                        ),
                                                        alignment: Alignment
                                                            .bottomCenter,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Padding(
                                                padding: getPadding(
                                                  left: 1,
                                                  top: 9,
                                                  bottom: 8,
                                                ),
                                                child: Text(
                                                  "lbl_mcdonald_s".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular11,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          height: getVerticalSize(
                                            32,
                                          ),
                                          width: getHorizontalSize(
                                            66,
                                          ),
                                          margin: getMargin(
                                            right: 9,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.bottomRight,
                                            children: [
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  decoration: AppDecoration
                                                      .outlinePink700
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder5,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Padding(
                                                        padding: getPadding(
                                                          right: 3,
                                                        ),
                                                        child: Text(
                                                          "lbl_cashback2".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular9,
                                                        ),
                                                      ),
                                                      Container(
                                                        height: getVerticalSize(
                                                          18,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          66,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .pink700,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                            getHorizontalSize(
                                                              4,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                  padding: getPadding(
                                                    right: 22,
                                                  ),
                                                  child: Text(
                                                    "lbl_2".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style:
                                                        AppStyle.txtInterBold20,
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                  padding: getPadding(
                                                    right: 4,
                                                  ),
                                                  child: Text(
                                                    "lbl".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtInterRegular20WhiteA700,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: getVerticalSize(
                                    121,
                                  ),
                                  width: getHorizontalSize(
                                    99,
                                  ),
                                  margin: getMargin(
                                    left: 12,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.topRight,
                                    children: [
                                      Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Container(
                                          padding: getPadding(
                                            all: 3,
                                          ),
                                          decoration: AppDecoration
                                              .outlineGray300
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder10,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgImage70,
                                                height: getVerticalSize(
                                                  70,
                                                ),
                                                width: getHorizontalSize(
                                                  93,
                                                ),
                                                radius: BorderRadius.circular(
                                                  getHorizontalSize(
                                                    7,
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: getHorizontalSize(
                                                  57,
                                                ),
                                                margin: getMargin(
                                                  left: 1,
                                                  top: 3,
                                                  bottom: 2,
                                                ),
                                                child: Text(
                                                  "msg_ikea_north_america".tr,
                                                  maxLines: null,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular11,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          height: getVerticalSize(
                                            32,
                                          ),
                                          width: getHorizontalSize(
                                            66,
                                          ),
                                          margin: getMargin(
                                            right: 9,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.bottomRight,
                                            children: [
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  decoration: AppDecoration
                                                      .outlinePink700
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder5,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Padding(
                                                        padding: getPadding(
                                                          right: 3,
                                                        ),
                                                        child: Text(
                                                          "lbl_cashback2".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular9,
                                                        ),
                                                      ),
                                                      Container(
                                                        height: getVerticalSize(
                                                          18,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          66,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .pink700,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                            getHorizontalSize(
                                                              4,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                  padding: getPadding(
                                                    right: 22,
                                                  ),
                                                  child: Text(
                                                    "lbl_5".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style:
                                                        AppStyle.txtInterBold20,
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                  padding: getPadding(
                                                    right: 4,
                                                  ),
                                                  child: Text(
                                                    "lbl".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtInterRegular20WhiteA700,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              121,
                            ),
                            width: getHorizontalSize(
                              74,
                            ),
                            margin: getMargin(
                              left: 12,
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              121,
                            ),
                            width: getHorizontalSize(
                              99,
                            ),
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Container(
                                    padding: getPadding(
                                      all: 3,
                                    ),
                                    decoration:
                                        AppDecoration.outlineGray300.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder10,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        CustomImageView(
                                          imagePath: ImageConstant.imgImage72,
                                          height: getVerticalSize(
                                            70,
                                          ),
                                          width: getHorizontalSize(
                                            93,
                                          ),
                                          radius: BorderRadius.circular(
                                            getHorizontalSize(
                                              7,
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 1,
                                            top: 10,
                                            bottom: 7,
                                          ),
                                          child: Text(
                                            "lbl_best_buy".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular11,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topRight,
                                  child: Container(
                                    height: getVerticalSize(
                                      32,
                                    ),
                                    width: getHorizontalSize(
                                      66,
                                    ),
                                    margin: getMargin(
                                      right: 9,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.bottomRight,
                                      children: [
                                        Align(
                                          alignment: Alignment.topCenter,
                                          child: Container(
                                            decoration: AppDecoration
                                                .outlinePink700
                                                .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .roundedBorder5,
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding: getPadding(
                                                    right: 15,
                                                  ),
                                                  child: Text(
                                                    "lbl_cashback2".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.right,
                                                    style: AppStyle
                                                        .txtInterRegular9,
                                                  ),
                                                ),
                                                Container(
                                                  height: getVerticalSize(
                                                    18,
                                                  ),
                                                  width: getHorizontalSize(
                                                    66,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color:
                                                        ColorConstant.pink700,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                      getHorizontalSize(
                                                        4,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                            padding: getPadding(
                                              right: 22,
                                            ),
                                            child: Text(
                                              "lbl_5".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle.txtInterBold20,
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                            padding: getPadding(
                                              right: 14,
                                            ),
                                            child: Text(
                                              "lbl".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular20WhiteA700,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      404,
                    ),
                    width: getHorizontalSize(
                      379,
                    ),
                    margin: getMargin(
                      top: 22,
                    ),
                    child: Stack(
                      alignment: Alignment.topCenter,
                      children: [
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            height: getVerticalSize(
                              124,
                            ),
                            width: getHorizontalSize(
                              374,
                            ),
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Container(
                                    margin: getMargin(
                                      top: 11,
                                      right: 12,
                                    ),
                                    padding: getPadding(
                                      top: 2,
                                      bottom: 2,
                                    ),
                                    decoration:
                                        AppDecoration.outlinePink700.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder10,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: getPadding(
                                            top: 11,
                                          ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Card(
                                                clipBehavior: Clip.antiAlias,
                                                elevation: 0,
                                                margin: EdgeInsets.all(0),
                                                color: ColorConstant.gray900,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder30,
                                                ),
                                                child: Container(
                                                  height: getVerticalSize(
                                                    61,
                                                  ),
                                                  width: getHorizontalSize(
                                                    60,
                                                  ),
                                                  padding: getPadding(
                                                    top: 9,
                                                    bottom: 9,
                                                  ),
                                                  decoration: AppDecoration
                                                      .fillGray900
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder30,
                                                  ),
                                                  child: Stack(
                                                    children: [
                                                      CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgImage76,
                                                        height: getVerticalSize(
                                                          43,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          60,
                                                        ),
                                                        radius: BorderRadius
                                                            .circular(
                                                          getHorizontalSize(
                                                            21,
                                                          ),
                                                        ),
                                                        alignment:
                                                            Alignment.center,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: getHorizontalSize(
                                                  48,
                                                ),
                                                margin: getMargin(
                                                  top: 1,
                                                ),
                                                child: Text(
                                                  "lbl_marriott_bonvoy".tr,
                                                  maxLines: null,
                                                  textAlign: TextAlign.center,
                                                  style: AppStyle
                                                      .txtInterRegular13,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            top: 4,
                                            bottom: 11,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Container(
                                                height: getVerticalSize(
                                                  91,
                                                ),
                                                width: getHorizontalSize(
                                                  113,
                                                ),
                                                child: Stack(
                                                  alignment:
                                                      Alignment.bottomCenter,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      child: Container(
                                                        height: getVerticalSize(
                                                          25,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          113,
                                                        ),
                                                        margin: getMargin(
                                                          top: 1,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .pink700,
                                                          borderRadius:
                                                              BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                15,
                                                              ),
                                                            ),
                                                            topRight:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                15,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment
                                                          .bottomCenter,
                                                      child: Container(
                                                        padding: getPadding(
                                                          left: 2,
                                                          top: 3,
                                                          right: 2,
                                                          bottom: 3,
                                                        ),
                                                        decoration: AppDecoration
                                                            .outlineBlack9003f
                                                            .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder10,
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  getPadding(
                                                                top: 3,
                                                              ),
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Container(
                                                                    height:
                                                                        getVerticalSize(
                                                                      35,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      61,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 2,
                                                                    ),
                                                                    child:
                                                                        Stack(
                                                                      alignment:
                                                                          Alignment
                                                                              .center,
                                                                      children: [
                                                                        CustomImageView(
                                                                          imagePath:
                                                                              ImageConstant.imgPullcreditcard,
                                                                          height:
                                                                              getVerticalSize(
                                                                            34,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            60,
                                                                          ),
                                                                          radius:
                                                                              BorderRadius.circular(
                                                                            getHorizontalSize(
                                                                              3,
                                                                            ),
                                                                          ),
                                                                          alignment:
                                                                              Alignment.centerLeft,
                                                                        ),
                                                                        CustomImageView(
                                                                          svgPath:
                                                                              ImageConstant.imgTicketAmber300,
                                                                          height:
                                                                              getVerticalSize(
                                                                            35,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            61,
                                                                          ),
                                                                          alignment:
                                                                              Alignment.center,
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      left: 1,
                                                                    ),
                                                                    child:
                                                                        Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .end,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Container(
                                                                          height:
                                                                              getVerticalSize(
                                                                            26,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            44,
                                                                          ),
                                                                          child:
                                                                              Stack(
                                                                            alignment:
                                                                                Alignment.topLeft,
                                                                            children: [
                                                                              Align(
                                                                                alignment: Alignment.bottomCenter,
                                                                                child: Container(
                                                                                  decoration: AppDecoration.outlinePink700.copyWith(
                                                                                    borderRadius: BorderRadiusStyle.roundedBorder5,
                                                                                  ),
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.min,
                                                                                    crossAxisAlignment: CrossAxisAlignment.end,
                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                    children: [
                                                                                      Container(
                                                                                        height: getVerticalSize(
                                                                                          16,
                                                                                        ),
                                                                                        width: getHorizontalSize(
                                                                                          44,
                                                                                        ),
                                                                                        decoration: BoxDecoration(
                                                                                          color: ColorConstant.pink700,
                                                                                          borderRadius: BorderRadius.circular(
                                                                                            getHorizontalSize(
                                                                                              4,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      Padding(
                                                                                        padding: getPadding(
                                                                                          right: 2,
                                                                                        ),
                                                                                        child: Text(
                                                                                          "lbl_cashback2".tr,
                                                                                          overflow: TextOverflow.ellipsis,
                                                                                          textAlign: TextAlign.left,
                                                                                          style: AppStyle.txtInterRegular6,
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Align(
                                                                                alignment: Alignment.topLeft,
                                                                                child: Padding(
                                                                                  padding: getPadding(
                                                                                    left: 4,
                                                                                  ),
                                                                                  child: Text(
                                                                                    "lbl_6_3".tr,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                    textAlign: TextAlign.left,
                                                                                    style: AppStyle.txtInterRegular17WhiteA700,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Align(
                                                                                alignment: Alignment.topRight,
                                                                                child: Text(
                                                                                  "lbl".tr,
                                                                                  overflow: TextOverflow.ellipsis,
                                                                                  textAlign: TextAlign.left,
                                                                                  style: AppStyle.txtInterRegular17WhiteA700,
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              getPadding(
                                                                            right:
                                                                                2,
                                                                          ),
                                                                          child:
                                                                              Text(
                                                                            "lbl_stacked".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterBold8,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  getPadding(
                                                                top: 3,
                                                              ),
                                                              child: Text(
                                                                "lbl_cashback2"
                                                                    .tr,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtInterBold11,
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  getPadding(
                                                                top: 1,
                                                              ),
                                                              child: Text(
                                                                "lbl_blaze".tr,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtInterRegular11Black90099,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Padding(
                                                        padding: getPadding(
                                                          right: 10,
                                                        ),
                                                        child: Text(
                                                          "lbl_cashback2".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtStaatlichesRegular10,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                height: getVerticalSize(
                                                  91,
                                                ),
                                                width: getHorizontalSize(
                                                  113,
                                                ),
                                                margin: getMargin(
                                                  left: 17,
                                                ),
                                                child: Stack(
                                                  alignment:
                                                      Alignment.bottomCenter,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      child: Container(
                                                        height: getVerticalSize(
                                                          25,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          113,
                                                        ),
                                                        margin: getMargin(
                                                          top: 1,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .lime800,
                                                          borderRadius:
                                                              BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                15,
                                                              ),
                                                            ),
                                                            topRight:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                15,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment
                                                          .bottomCenter,
                                                      child: Container(
                                                        padding: getPadding(
                                                          left: 2,
                                                          top: 3,
                                                          right: 2,
                                                          bottom: 3,
                                                        ),
                                                        decoration: AppDecoration
                                                            .outlineBlack9003f
                                                            .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder10,
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  getPadding(
                                                                top: 3,
                                                              ),
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgPullcreditcard34x60,
                                                                    height:
                                                                        getVerticalSize(
                                                                      34,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      60,
                                                                    ),
                                                                    radius: BorderRadius
                                                                        .circular(
                                                                      getHorizontalSize(
                                                                        3,
                                                                      ),
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 2,
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    height:
                                                                        getVerticalSize(
                                                                      26,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      44,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      left: 3,
                                                                      bottom:
                                                                          10,
                                                                    ),
                                                                    child:
                                                                        Stack(
                                                                      alignment:
                                                                          Alignment
                                                                              .topRight,
                                                                      children: [
                                                                        Align(
                                                                          alignment:
                                                                              Alignment.bottomCenter,
                                                                          child:
                                                                              Container(
                                                                            decoration:
                                                                                AppDecoration.outlineLime800.copyWith(
                                                                              borderRadius: BorderRadiusStyle.roundedBorder5,
                                                                            ),
                                                                            child:
                                                                                Column(
                                                                              mainAxisSize: MainAxisSize.min,
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              children: [
                                                                                Container(
                                                                                  height: getVerticalSize(
                                                                                    16,
                                                                                  ),
                                                                                  width: getHorizontalSize(
                                                                                    44,
                                                                                  ),
                                                                                  decoration: BoxDecoration(
                                                                                    color: ColorConstant.lime800,
                                                                                    borderRadius: BorderRadius.circular(
                                                                                      getHorizontalSize(
                                                                                        4,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                Text(
                                                                                  "lbl_reward_points".tr,
                                                                                  overflow: TextOverflow.ellipsis,
                                                                                  textAlign: TextAlign.left,
                                                                                  style: AppStyle.txtInterRegular6Lime800,
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Align(
                                                                          alignment:
                                                                              Alignment.topRight,
                                                                          child:
                                                                              Padding(
                                                                            padding:
                                                                                getPadding(
                                                                              right: 14,
                                                                            ),
                                                                            child:
                                                                                Text(
                                                                              "lbl_3".tr,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtInterRegular17WhiteA700,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Align(
                                                                          alignment:
                                                                              Alignment.bottomRight,
                                                                          child:
                                                                              Padding(
                                                                            padding:
                                                                                getPadding(
                                                                              right: 4,
                                                                              bottom: 4,
                                                                            ),
                                                                            child:
                                                                                Text(
                                                                              "lbl_x".tr,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtInterRegular17WhiteA700,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  getPadding(
                                                                top: 4,
                                                              ),
                                                              child: Text(
                                                                "msg_american_express"
                                                                    .tr,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtInterBold11,
                                                              ),
                                                            ),
                                                            Text(
                                                              "lbl_gold_card"
                                                                  .tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterRegular11Black90099,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Padding(
                                                        padding: getPadding(
                                                          right: 13,
                                                        ),
                                                        child: Text(
                                                          "lbl_your_wallet".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtStaatlichesRegular10Yellow50,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgStar22,
                                  height: getVerticalSize(
                                    25,
                                  ),
                                  width: getHorizontalSize(
                                    26,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      1,
                                    ),
                                  ),
                                  alignment: Alignment.topRight,
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topCenter,
                          child: Padding(
                            padding: getPadding(
                              top: 1,
                              right: 1,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    left: 1,
                                  ),
                                  child: Text(
                                    "lbl_categories".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtStaatlichesRegular22,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 1,
                                    top: 1,
                                    right: 2,
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "msg_compare_and_save".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular14,
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          top: 7,
                                          bottom: 8,
                                        ),
                                        child: SizedBox(
                                          width: getHorizontalSize(
                                            205,
                                          ),
                                          child: Divider(
                                            height: getVerticalSize(
                                              1,
                                            ),
                                            thickness: getVerticalSize(
                                              1,
                                            ),
                                            color: ColorConstant.gray400,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  padding: getPadding(
                                    left: 1,
                                    top: 18,
                                    right: 2,
                                  ),
                                  child: IntrinsicWidth(
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Container(
                                          height: getVerticalSize(
                                            112,
                                          ),
                                          width: getHorizontalSize(
                                            72,
                                          ),
                                          margin: getMargin(
                                            bottom: 2,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              Align(
                                                alignment: Alignment.topRight,
                                                child: Container(
                                                  height: getVerticalSize(
                                                    75,
                                                  ),
                                                  width: getHorizontalSize(
                                                    52,
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.center,
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: [
                                                        CustomImageView(
                                                          imagePath:
                                                              ImageConstant
                                                                  .imgImage75,
                                                          height:
                                                              getVerticalSize(
                                                            75,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            72,
                                                          ),
                                                          radius:
                                                              BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                33,
                                                              ),
                                                            ),
                                                            topRight:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                36,
                                                              ),
                                                            ),
                                                            bottomLeft:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                36,
                                                              ),
                                                            ),
                                                            bottomRight:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                33,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        CustomImageView(
                                                          imagePath: ImageConstant
                                                              .imgPullcategorylogo,
                                                          height:
                                                              getVerticalSize(
                                                            75,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            74,
                                                          ),
                                                          radius: BorderRadius
                                                              .circular(
                                                            getHorizontalSize(
                                                              37,
                                                            ),
                                                          ),
                                                          margin: getMargin(
                                                            left: 290,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Container(
                                                      width: getHorizontalSize(
                                                        47,
                                                      ),
                                                      margin: getMargin(
                                                        top: 10,
                                                        right: 5,
                                                      ),
                                                      child: Text(
                                                        "msg_groceries_essential"
                                                            .tr,
                                                        maxLines: null,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: AppStyle
                                                            .txtInterRegular11,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 17,
                                            bottom: 2,
                                          ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgPullcategorylogo75x74,
                                                height: getVerticalSize(
                                                  75,
                                                ),
                                                width: getHorizontalSize(
                                                  74,
                                                ),
                                                radius: BorderRadius.circular(
                                                  getHorizontalSize(
                                                    37,
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: getHorizontalSize(
                                                  62,
                                                ),
                                                margin: getMargin(
                                                  top: 10,
                                                ),
                                                child: Text(
                                                  "msg_dining_restaurants".tr,
                                                  maxLines: null,
                                                  textAlign: TextAlign.center,
                                                  style: AppStyle
                                                      .txtInterRegular11,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 17,
                                          ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgPullcategorylogo1,
                                                height: getVerticalSize(
                                                  75,
                                                ),
                                                width: getHorizontalSize(
                                                  74,
                                                ),
                                                radius: BorderRadius.circular(
                                                  getHorizontalSize(
                                                    37,
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: getHorizontalSize(
                                                  43,
                                                ),
                                                margin: getMargin(
                                                  top: 10,
                                                ),
                                                child: Text(
                                                  "lbl_retail_therapy".tr,
                                                  maxLines: null,
                                                  textAlign: TextAlign.center,
                                                  style: AppStyle
                                                      .txtInterRegular11,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 17,
                                          ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgPullcategorylogo2,
                                                height: getVerticalSize(
                                                  75,
                                                ),
                                                width: getHorizontalSize(
                                                  74,
                                                ),
                                                radius: BorderRadius.circular(
                                                  getHorizontalSize(
                                                    37,
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: getHorizontalSize(
                                                  59,
                                                ),
                                                margin: getMargin(
                                                  top: 11,
                                                ),
                                                child: Text(
                                                  "lbl_gas_commuting".tr,
                                                  maxLines: null,
                                                  textAlign: TextAlign.center,
                                                  style: AppStyle
                                                      .txtInterRegular11,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: getHorizontalSize(
                                            30,
                                          ),
                                          margin: getMargin(
                                            left: 20,
                                            top: 85,
                                            bottom: 2,
                                          ),
                                          child: Text(
                                            "msg_exploration_adventure".tr,
                                            maxLines: null,
                                            textAlign: TextAlign.center,
                                            style: AppStyle.txtInterRegular11,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 20,
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        margin: getMargin(
                                          top: 1,
                                        ),
                                        padding: getPadding(
                                          left: 16,
                                          top: 4,
                                          right: 16,
                                          bottom: 4,
                                        ),
                                        decoration:
                                            AppDecoration.fillPink700.copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder10,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                bottom: 17,
                                              ),
                                              child: Text(
                                                "lbl_catalog".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtStaatlichesRegular15,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          top: 14,
                                          bottom: 30,
                                        ),
                                        child: SizedBox(
                                          width: getHorizontalSize(
                                            117,
                                          ),
                                          child: Divider(
                                            height: getVerticalSize(
                                              1,
                                            ),
                                            thickness: getVerticalSize(
                                              1,
                                            ),
                                            color: ColorConstant.gray400,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          29,
                                        ),
                                        width: getHorizontalSize(
                                          54,
                                        ),
                                        margin: getMargin(
                                          bottom: 17,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.centerLeft,
                                          children: [
                                            BlocSelector<FeaturedOneBloc,
                                                FeaturedOneState, bool?>(
                                              selector: (state) =>
                                                  state.isSelectedSwitch,
                                              builder:
                                                  (context, isSelectedSwitch) {
                                                return CustomSwitch(
                                                  alignment: Alignment.center,
                                                  value: isSelectedSwitch,
                                                  onChanged: (value) {
                                                    context
                                                        .read<FeaturedOneBloc>()
                                                        .add(ChangeSwitchEvent(
                                                            value: value));
                                                  },
                                                );
                                              },
                                            ),
                                            CustomImageView(
                                              svgPath: ImageConstant.imgLogo,
                                              height: getVerticalSize(
                                                6,
                                              ),
                                              width: getHorizontalSize(
                                                42,
                                              ),
                                              alignment: Alignment.centerLeft,
                                              margin: getMargin(
                                                left: 4,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 5,
                                    top: 2,
                                  ),
                                  child: Text(
                                    "msg_savings_all_year".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            height: getVerticalSize(
                              287,
                            ),
                            width: getHorizontalSize(
                              359,
                            ),
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    margin: getMargin(
                                      top: 12,
                                      right: 11,
                                    ),
                                    padding: getPadding(
                                      left: 14,
                                      top: 16,
                                      right: 14,
                                      bottom: 16,
                                    ),
                                    decoration:
                                        AppDecoration.outlinePink700.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder10,
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: getPadding(
                                            top: 3,
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Align(
                                                alignment:
                                                    Alignment.centerRight,
                                                child: Text(
                                                  "lbl_7_eleven".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterBold18Black900,
                                                ),
                                              ),
                                              Padding(
                                                padding: getPadding(
                                                  top: 20,
                                                  right: 8,
                                                ),
                                                child: BlocSelector<
                                                    FeaturedOneBloc,
                                                    FeaturedOneState,
                                                    FeaturedOneModel?>(
                                                  selector: (state) =>
                                                      state.featuredOneModelObj,
                                                  builder: (context,
                                                      featuredOneModelObj) {
                                                    return ListView.separated(
                                                      physics:
                                                          NeverScrollableScrollPhysics(),
                                                      shrinkWrap: true,
                                                      separatorBuilder:
                                                          (context, index) {
                                                        return SizedBox(
                                                          height:
                                                              getVerticalSize(
                                                            16,
                                                          ),
                                                        );
                                                      },
                                                      itemCount: featuredOneModelObj
                                                              ?.featuredOneItemList
                                                              .length ??
                                                          0,
                                                      itemBuilder:
                                                          (context, index) {
                                                        FeaturedOneItemModel
                                                            model =
                                                            featuredOneModelObj
                                                                        ?.featuredOneItemList[
                                                                    index] ??
                                                                FeaturedOneItemModel();
                                                        return FeaturedOneItemWidget(
                                                          model,
                                                        );
                                                      },
                                                    );
                                                  },
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 14,
                                          ),
                                          child: SizedBox(
                                            height: getVerticalSize(
                                              243,
                                            ),
                                            child: VerticalDivider(
                                              width: getHorizontalSize(
                                                1,
                                              ),
                                              thickness: getVerticalSize(
                                                1,
                                              ),
                                              color: ColorConstant.gray400,
                                              indent: getHorizontalSize(
                                                50,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 11,
                                            top: 40,
                                            bottom: 78,
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: getPadding(
                                                  left: 5,
                                                ),
                                                child: Text(
                                                  "lbl_bonus_deals".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterBold17Black90099,
                                                ),
                                              ),
                                              Padding(
                                                padding: getPadding(
                                                  top: 11,
                                                ),
                                                child: Row(
                                                  children: [
                                                    Container(
                                                      height: getVerticalSize(
                                                        22,
                                                      ),
                                                      width: getHorizontalSize(
                                                        75,
                                                      ),
                                                      child: Stack(
                                                        alignment:
                                                            Alignment.center,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Text(
                                                              "lbl_rakutten".tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterRegular18Black90099,
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Text(
                                                              "lbl_rakutten".tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterRegular18Black90099,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      height: getVerticalSize(
                                                        22,
                                                      ),
                                                      width: getHorizontalSize(
                                                        30,
                                                      ),
                                                      margin: getMargin(
                                                        left: 20,
                                                      ),
                                                      child: Stack(
                                                        alignment:
                                                            Alignment.center,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Text(
                                                              "lbl_100".tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterRegular18Black900,
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Text(
                                                              "lbl_100".tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterRegular18Black900,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      height: getVerticalSize(
                                                        22,
                                                      ),
                                                      width: getHorizontalSize(
                                                        15,
                                                      ),
                                                      margin: getMargin(
                                                        left: 2,
                                                      ),
                                                      child: Stack(
                                                        alignment:
                                                            Alignment.center,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Text(
                                                              "lbl".tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterRegular18Black900,
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Text(
                                                              "lbl".tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterRegular18Black900,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                height: getVerticalSize(
                                                  14,
                                                ),
                                                width: getHorizontalSize(
                                                  84,
                                                ),
                                                margin: getMargin(
                                                  left: 1,
                                                  top: 2,
                                                ),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Text(
                                                        "lbl_exp_12_31_2023".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular11Black9007e,
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Text(
                                                        "lbl_exp_12_31_2023".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular11Black9007e,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding: getPadding(
                                                  top: 13,
                                                ),
                                                child: Row(
                                                  children: [
                                                    Text(
                                                      "lbl_rakutten".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterRegular18Black90099,
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        left: 20,
                                                      ),
                                                      child: Text(
                                                        "lbl_100".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular18Black900,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        left: 2,
                                                      ),
                                                      child: Text(
                                                        "lbl".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular18Black900,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding: getPadding(
                                                  left: 1,
                                                  top: 2,
                                                ),
                                                child: Text(
                                                  "lbl_exp_12_31_2023".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular11Black9007e,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgClose,
                                  height: getVerticalSize(
                                    20,
                                  ),
                                  width: getHorizontalSize(
                                    23,
                                  ),
                                  alignment: Alignment.topRight,
                                  margin: getMargin(
                                    top: 2,
                                  ),
                                ),
                                CustomImageView(
                                  imagePath: ImageConstant.imgPullmerchantlogo,
                                  height: getVerticalSize(
                                    61,
                                  ),
                                  width: getHorizontalSize(
                                    60,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      30,
                                    ),
                                  ),
                                  alignment: Alignment.topLeft,
                                  margin: getMargin(
                                    left: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      124,
                    ),
                    width: getHorizontalSize(
                      374,
                    ),
                    margin: getMargin(
                      left: 5,
                      top: 144,
                    ),
                    child: Stack(
                      alignment: Alignment.topRight,
                      children: [
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Container(
                            margin: getMargin(
                              top: 11,
                              right: 12,
                            ),
                            padding: getPadding(
                              left: 10,
                              right: 10,
                            ),
                            decoration: AppDecoration.outlinePink700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    top: 12,
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Card(
                                        clipBehavior: Clip.antiAlias,
                                        elevation: 0,
                                        margin: EdgeInsets.all(0),
                                        color: ColorConstant.gray100,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder30,
                                        ),
                                        child: Container(
                                          height: getVerticalSize(
                                            61,
                                          ),
                                          width: getHorizontalSize(
                                            60,
                                          ),
                                          padding: getPadding(
                                            top: 10,
                                            bottom: 10,
                                          ),
                                          decoration: AppDecoration.fillGray100
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder30,
                                          ),
                                          child: Stack(
                                            children: [
                                              CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgImage78,
                                                height: getVerticalSize(
                                                  40,
                                                ),
                                                width: getHorizontalSize(
                                                  60,
                                                ),
                                                radius: BorderRadius.circular(
                                                  getHorizontalSize(
                                                    20,
                                                  ),
                                                ),
                                                alignment: Alignment.center,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Container(
                                        width: getHorizontalSize(
                                          89,
                                        ),
                                        margin: getMargin(
                                          top: 1,
                                        ),
                                        child: Text(
                                          "lbl_delta_airlines".tr,
                                          maxLines: null,
                                          textAlign: TextAlign.center,
                                          style: AppStyle.txtInterRegular13,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: getPadding(
                                      left: 8,
                                      top: 9,
                                      bottom: 14,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Container(
                                          height: getVerticalSize(
                                            90,
                                          ),
                                          width: getHorizontalSize(
                                            113,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.bottomCenter,
                                            children: [
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  padding: getPadding(
                                                    left: 10,
                                                    right: 10,
                                                  ),
                                                  decoration: AppDecoration
                                                      .fillPink700
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .customBorderTL15,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Padding(
                                                        padding: getPadding(
                                                          bottom: 16,
                                                        ),
                                                        child: Text(
                                                          "lbl_cashback2".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.right,
                                                          style: AppStyle
                                                              .txtStaatlichesRegular10,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                child: Container(
                                                  padding: getPadding(
                                                    top: 5,
                                                    bottom: 5,
                                                  ),
                                                  decoration: AppDecoration
                                                      .outlineBlack9003f
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder10,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Padding(
                                                        padding: getPadding(
                                                          top: 4,
                                                        ),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Container(
                                                              height:
                                                                  getVerticalSize(
                                                                35,
                                                              ),
                                                              width:
                                                                  getHorizontalSize(
                                                                60,
                                                              ),
                                                              child: Stack(
                                                                alignment:
                                                                    Alignment
                                                                        .center,
                                                                children: [
                                                                  CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgPullcreditcard,
                                                                    height:
                                                                        getVerticalSize(
                                                                      34,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      60,
                                                                    ),
                                                                    radius: BorderRadius
                                                                        .circular(
                                                                      getHorizontalSize(
                                                                        3,
                                                                      ),
                                                                    ),
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                  ),
                                                                  CustomImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgTicketAmber300,
                                                                    height:
                                                                        getVerticalSize(
                                                                      35,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      60,
                                                                    ),
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  getPadding(
                                                                left: 3,
                                                                top: 1,
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Container(
                                                                    decoration: AppDecoration
                                                                        .outlinePink700
                                                                        .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .roundedBorder5,
                                                                    ),
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .center,
                                                                      children: [
                                                                        Container(
                                                                          decoration: AppDecoration
                                                                              .fillPink700
                                                                              .copyWith(
                                                                            borderRadius:
                                                                                BorderRadiusStyle.roundedBorder5,
                                                                          ),
                                                                          child:
                                                                              Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.center,
                                                                            mainAxisSize:
                                                                                MainAxisSize.min,
                                                                            children: [
                                                                              Text(
                                                                                "lbl_7_5".tr,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                textAlign: TextAlign.right,
                                                                                style: AppStyle.txtInterRegular17WhiteA700,
                                                                              ),
                                                                              Text(
                                                                                "lbl".tr,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                textAlign: TextAlign.left,
                                                                                style: AppStyle.txtInterRegular17WhiteA700,
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              getPadding(
                                                                            bottom:
                                                                                1,
                                                                          ),
                                                                          child:
                                                                              Text(
                                                                            "lbl_cashback2".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.right,
                                                                            style:
                                                                                AppStyle.txtInterRegular6,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      top: 1,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_stacked"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .right,
                                                                      style: AppStyle
                                                                          .txtInterBold8,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding: getPadding(
                                                          top: 3,
                                                        ),
                                                        child: Text(
                                                          "lbl_cashback2".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppStyle
                                                              .txtInterBold11,
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding: getPadding(
                                                          top: 1,
                                                        ),
                                                        child: Text(
                                                          "lbl_blaze".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppStyle
                                                              .txtInterRegular11Black90099,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          height: getVerticalSize(
                                            90,
                                          ),
                                          width: getHorizontalSize(
                                            113,
                                          ),
                                          margin: getMargin(
                                            left: 17,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.bottomCenter,
                                            children: [
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  padding: getPadding(
                                                    left: 8,
                                                    right: 8,
                                                  ),
                                                  decoration: AppDecoration
                                                      .fillLime800
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .customBorderTL15,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Padding(
                                                        padding: getPadding(
                                                          bottom: 16,
                                                        ),
                                                        child: Text(
                                                          "lbl_your_wallet".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.right,
                                                          style: AppStyle
                                                              .txtStaatlichesRegular10Yellow50,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                child: Container(
                                                  padding: getPadding(
                                                    top: 5,
                                                    bottom: 5,
                                                  ),
                                                  decoration: AppDecoration
                                                      .outlineBlack9003f
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder10,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Padding(
                                                        padding: getPadding(
                                                          top: 5,
                                                        ),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            CustomImageView(
                                                              imagePath:
                                                                  ImageConstant
                                                                      .imgPullcreditcard2,
                                                              height:
                                                                  getVerticalSize(
                                                                34,
                                                              ),
                                                              width:
                                                                  getHorizontalSize(
                                                                60,
                                                              ),
                                                              radius:
                                                                  BorderRadius
                                                                      .circular(
                                                                getHorizontalSize(
                                                                  3,
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: getMargin(
                                                                left: 3,
                                                                bottom: 10,
                                                              ),
                                                              decoration:
                                                                  AppDecoration
                                                                      .outlineLime800
                                                                      .copyWith(
                                                                borderRadius:
                                                                    BorderRadiusStyle
                                                                        .roundedBorder5,
                                                              ),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Container(
                                                                    decoration: AppDecoration
                                                                        .fillLime800
                                                                        .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .roundedBorder5,
                                                                    ),
                                                                    child: Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .center,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      children: [
                                                                        Text(
                                                                          "lbl_2"
                                                                              .tr,
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          textAlign:
                                                                              TextAlign.right,
                                                                          style:
                                                                              AppStyle.txtInterRegular17WhiteA700,
                                                                        ),
                                                                        Text(
                                                                          "lbl_x"
                                                                              .tr,
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          textAlign:
                                                                              TextAlign.left,
                                                                          style:
                                                                              AppStyle.txtInterRegular17WhiteA700,
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      bottom: 1,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_reward_type"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .right,
                                                                      style: AppStyle
                                                                          .txtInterRegular6Lime800,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding: getPadding(
                                                          top: 4,
                                                        ),
                                                        child: Text(
                                                          "lbl_capital_one".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppStyle
                                                              .txtInterBold11,
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding: getPadding(
                                                          top: 1,
                                                        ),
                                                        child: Text(
                                                          "lbl_venture".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppStyle
                                                              .txtInterRegular11Black90099,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        CustomImageView(
                          svgPath: ImageConstant.imgStar23,
                          height: getVerticalSize(
                            25,
                          ),
                          width: getHorizontalSize(
                            26,
                          ),
                          radius: BorderRadius.circular(
                            getHorizontalSize(
                              1,
                            ),
                          ),
                          alignment: Alignment.topRight,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
