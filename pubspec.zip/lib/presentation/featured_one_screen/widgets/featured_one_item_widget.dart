import '../models/featured_one_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class FeaturedOneItemWidget extends StatelessWidget {
  FeaturedOneItemWidget(this.featuredOneItemModelObj);

  FeaturedOneItemModel featuredOneItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: getVerticalSize(
        89,
      ),
      width: getHorizontalSize(
        113,
      ),
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Align(
            alignment: Alignment.center,
            child: Container(
              decoration: AppDecoration.fillIndigoA700.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder10,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    margin: getMargin(
                      top: 8,
                    ),
                    padding: getPadding(
                      left: 2,
                      top: 4,
                      right: 2,
                      bottom: 4,
                    ),
                    decoration: AppDecoration.outlineBlack9003f.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder10,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: getHorizontalSize(
                            107,
                          ),
                          margin: getMargin(
                            left: 2,
                            top: 3,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgPullcreditcard3,
                                height: getVerticalSize(
                                  34,
                                ),
                                width: getHorizontalSize(
                                  60,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    3,
                                  ),
                                ),
                                margin: getMargin(
                                  top: 2,
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  26,
                                ),
                                width: getHorizontalSize(
                                  44,
                                ),
                                margin: getMargin(
                                  bottom: 10,
                                ),
                                child: Stack(
                                  alignment: Alignment.topLeft,
                                  children: [
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Container(
                                        decoration: AppDecoration
                                            .outlineIndigoA700
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder5,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Container(
                                              height: getVerticalSize(
                                                16,
                                              ),
                                              width: getHorizontalSize(
                                                44,
                                              ),
                                              decoration: BoxDecoration(
                                                color:
                                                    ColorConstant.indigoA70001,
                                                borderRadius:
                                                    BorderRadius.circular(
                                                  getHorizontalSize(
                                                    4,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              featuredOneItemModelObj
                                                  .pullrewardtypeTxt,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular6IndigoA700,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Padding(
                                        padding: getPadding(
                                          left: 4,
                                        ),
                                        child: Text(
                                          featuredOneItemModelObj
                                              .rewardpointsvalTxt,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular17WhiteA700,
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Text(
                                        "lbl".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular17WhiteA700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: getVerticalSize(
                            27,
                          ),
                          width: getHorizontalSize(
                            103,
                          ),
                          margin: getMargin(
                            top: 4,
                          ),
                          child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Align(
                                alignment: Alignment.topCenter,
                                child: Text(
                                  featuredOneItemModelObj.cardtypeTxt,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterBold11,
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Text(
                                  featuredOneItemModelObj.cardnameTxt,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular11Black90099,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.topRight,
            child: Padding(
              padding: getPadding(
                right: 9,
              ),
              child: Text(
                featuredOneItemModelObj.servicerTxt,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtInterRegular6WhiteA700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
