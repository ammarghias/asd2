import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AnnualCreditsModel extends Equatable {AnnualCreditsModel copyWith() { return AnnualCreditsModel(
); } 
@override List<Object?> get props => [];
 }
