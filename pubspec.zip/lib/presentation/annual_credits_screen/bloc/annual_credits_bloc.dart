import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/annual_credits_screen/models/annual_credits_model.dart';
part 'annual_credits_event.dart';
part 'annual_credits_state.dart';

class AnnualCreditsBloc extends Bloc<AnnualCreditsEvent, AnnualCreditsState> {
  AnnualCreditsBloc(AnnualCreditsState initialState) : super(initialState) {
    on<AnnualCreditsInitialEvent>(_onInitialize);
  }

  _onInitialize(
    AnnualCreditsInitialEvent event,
    Emitter<AnnualCreditsState> emit,
  ) async {}
}
