// ignore_for_file: must_be_immutable

part of 'annual_credits_bloc.dart';

@immutable
abstract class AnnualCreditsEvent extends Equatable {}

class AnnualCreditsInitialEvent extends AnnualCreditsEvent {
  @override
  List<Object?> get props => [];
}
