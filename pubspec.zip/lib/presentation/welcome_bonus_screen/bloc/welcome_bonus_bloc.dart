import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/welcome_bonus_item_model.dart';
import 'package:ammar_s_application4/presentation/welcome_bonus_screen/models/welcome_bonus_model.dart';
part 'welcome_bonus_event.dart';
part 'welcome_bonus_state.dart';

class WelcomeBonusBloc extends Bloc<WelcomeBonusEvent, WelcomeBonusState> {
  WelcomeBonusBloc(WelcomeBonusState initialState) : super(initialState) {
    on<WelcomeBonusInitialEvent>(_onInitialize);
  }

  _onInitialize(
    WelcomeBonusInitialEvent event,
    Emitter<WelcomeBonusState> emit,
  ) async {
    emit(state.copyWith(
        welcomeBonusModelObj: state.welcomeBonusModelObj?.copyWith(
      welcomeBonusItemList: fillWelcomeBonusItemList(),
    )));
  }

  List<WelcomeBonusItemModel> fillWelcomeBonusItemList() {
    return List.generate(2, (index) => WelcomeBonusItemModel());
  }
}
