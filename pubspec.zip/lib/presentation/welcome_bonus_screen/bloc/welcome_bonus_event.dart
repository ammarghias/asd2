// ignore_for_file: must_be_immutable

part of 'welcome_bonus_bloc.dart';

@immutable
abstract class WelcomeBonusEvent extends Equatable {}

class WelcomeBonusInitialEvent extends WelcomeBonusEvent {
  @override
  List<Object?> get props => [];
}
