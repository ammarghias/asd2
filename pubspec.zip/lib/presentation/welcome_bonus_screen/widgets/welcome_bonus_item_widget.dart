import '../models/welcome_bonus_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class WelcomeBonusItemWidget extends StatelessWidget {
  WelcomeBonusItemWidget(this.welcomeBonusItemModelObj);

  WelcomeBonusItemModel welcomeBonusItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          padding: getPadding(
            left: 2,
            top: 4,
            right: 2,
            bottom: 4,
          ),
          decoration: AppDecoration.outlineBlack9003f.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder5,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgPullcreditcard2,
                height: getVerticalSize(
                  54,
                ),
                width: getHorizontalSize(
                  90,
                ),
                radius: BorderRadius.circular(
                  getHorizontalSize(
                    3,
                  ),
                ),
                margin: getMargin(
                  bottom: 1,
                ),
              ),
              Container(
                height: getVerticalSize(
                  53,
                ),
                width: getHorizontalSize(
                  82,
                ),
                margin: getMargin(
                  left: 2,
                  bottom: 2,
                ),
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        margin: getMargin(
                          top: 3,
                        ),
                        padding: getPadding(
                          left: 2,
                          right: 2,
                        ),
                        decoration: AppDecoration.outlineBluegray10001.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder5,
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 38,
                              ),
                              child: Text(
                                "lbl_expires".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular9Gray60004,
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                left: 1,
                                top: 37,
                                bottom: 1,
                              ),
                              child: Text(
                                "lbl_12_31_23".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular9Gray60004,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        height: getVerticalSize(
                          24,
                        ),
                        width: getHorizontalSize(
                          82,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.pink700,
                          borderRadius: BorderRadius.circular(
                            getHorizontalSize(
                              5,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        margin: getMargin(
                          top: 3,
                        ),
                        padding: getPadding(
                          left: 2,
                          top: 1,
                          right: 2,
                          bottom: 1,
                        ),
                        decoration: AppDecoration.outlinePink7002.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder5,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 21,
                              ),
                              child: Text(
                                "lbl_reward_points2".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular11Pink700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: Padding(
                        padding: getPadding(
                          top: 2,
                          right: 2,
                        ),
                        child: Text(
                          "lbl_x".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterRegular17WhiteA700,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        "lbl_60_000".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtInterRegular21,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: getPadding(
            top: 8,
            bottom: 8,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                "msg_american_express".tr,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtInterBold17Gray70003,
              ),
              Padding(
                padding: getPadding(
                  left: 3,
                  top: 1,
                ),
                child: Text(
                  "lbl_venture".tr,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtInterRegular19Black900,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
