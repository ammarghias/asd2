import 'package:equatable/equatable.dart';import 'welcome_bonus_item_model.dart';
// ignore: must_be_immutable
class WelcomeBonusModel extends Equatable {WelcomeBonusModel({this.welcomeBonusItemList = const []});

List<WelcomeBonusItemModel> welcomeBonusItemList;

WelcomeBonusModel copyWith({List<WelcomeBonusItemModel>? welcomeBonusItemList}) { return WelcomeBonusModel(
welcomeBonusItemList : welcomeBonusItemList ?? this.welcomeBonusItemList,
); } 
@override List<Object?> get props => [welcomeBonusItemList];
 }
