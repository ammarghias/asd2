class WelcomeBonusItemModel {String? id = "";

 }
