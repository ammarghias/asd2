import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/notification_item_model.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/notification_center_screen/models/notification_center_model.dart';
part 'notification_center_event.dart';
part 'notification_center_state.dart';

class NotificationCenterBloc
    extends Bloc<NotificationCenterEvent, NotificationCenterState> {
  NotificationCenterBloc(NotificationCenterState initialState)
      : super(initialState) {
    on<NotificationCenterInitialEvent>(_onInitialize);
  }

  _onInitialize(
    NotificationCenterInitialEvent event,
    Emitter<NotificationCenterState> emit,
  ) async {
    emit(state.copyWith(
        notificationCenterModelObj: state.notificationCenterModelObj?.copyWith(
      notificationItemList: fillNotificationItemList(),
    )));
  }

  List<NotificationItemModel> fillNotificationItemList() {
    return List.generate(4, (index) => NotificationItemModel());
  }
}
