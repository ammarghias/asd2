// ignore_for_file: must_be_immutable

part of 'notification_center_bloc.dart';

@immutable
abstract class NotificationCenterEvent extends Equatable {}

class NotificationCenterInitialEvent extends NotificationCenterEvent {
  @override
  List<Object?> get props => [];
}
