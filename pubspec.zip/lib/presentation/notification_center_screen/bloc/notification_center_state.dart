// ignore_for_file: must_be_immutable

part of 'notification_center_bloc.dart';

class NotificationCenterState extends Equatable {
  NotificationCenterState({this.notificationCenterModelObj});

  NotificationCenterModel? notificationCenterModelObj;

  @override
  List<Object?> get props => [
        notificationCenterModelObj,
      ];
  NotificationCenterState copyWith(
      {NotificationCenterModel? notificationCenterModelObj}) {
    return NotificationCenterState(
      notificationCenterModelObj:
          notificationCenterModelObj ?? this.notificationCenterModelObj,
    );
  }
}
