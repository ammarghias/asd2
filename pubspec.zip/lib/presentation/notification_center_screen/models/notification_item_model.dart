class NotificationItemModel {String? id = "";

 }
