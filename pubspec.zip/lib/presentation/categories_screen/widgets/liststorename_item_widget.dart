import '../models/liststorename_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListstorenameItemWidget extends StatelessWidget {
  ListstorenameItemWidget(this.liststorenameItemModelObj);

  ListstorenameItemModel liststorenameItemModelObj;

  @override
  Widget build(BuildContext context) {
    return IntrinsicWidth(
      child: Container(
        height: getVerticalSize(
          121,
        ),
        width: getHorizontalSize(
          99,
        ),
        margin: getMargin(
          right: 12,
        ),
        child: Stack(
          alignment: Alignment.topRight,
          children: [
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                padding: getPadding(
                  all: 3,
                ),
                decoration: AppDecoration.outlineGray300.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder10,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Card(
                      clipBehavior: Clip.antiAlias,
                      elevation: 0,
                      margin: EdgeInsets.all(0),
                      color: ColorConstant.lightGreen800,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadiusStyle.roundedBorder5,
                      ),
                      child: Container(
                        height: getVerticalSize(
                          70,
                        ),
                        width: getHorizontalSize(
                          93,
                        ),
                        padding: getPadding(
                          left: 12,
                          right: 12,
                        ),
                        decoration: AppDecoration.fillLightgreen800.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder5,
                        ),
                        child: Stack(
                          children: [
                            CustomImageView(
                              imagePath: ImageConstant.imgImage6756x68,
                              height: getVerticalSize(
                                56,
                              ),
                              width: getHorizontalSize(
                                68,
                              ),
                              radius: BorderRadius.circular(
                                getHorizontalSize(
                                  7,
                                ),
                              ),
                              alignment: Alignment.bottomCenter,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: getPadding(
                        top: 9,
                        right: 22,
                        bottom: 8,
                      ),
                      child: Text(
                        liststorenameItemModelObj.storenameTxt,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtInterRegular11,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Container(
                height: getVerticalSize(
                  32,
                ),
                width: getHorizontalSize(
                  66,
                ),
                margin: getMargin(
                  right: 9,
                ),
                child: Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        decoration: AppDecoration.outlinePink700.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder5,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: getPadding(
                                right: 3,
                              ),
                              child: Text(
                                "lbl_cashback2".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.right,
                                style: AppStyle.txtInterRegular9,
                              ),
                            ),
                            Container(
                              height: getVerticalSize(
                                18,
                              ),
                              width: getHorizontalSize(
                                66,
                              ),
                              decoration: BoxDecoration(
                                color: ColorConstant.pink700,
                                borderRadius: BorderRadius.circular(
                                  getHorizontalSize(
                                    4,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Padding(
                        padding: getPadding(
                          right: 22,
                        ),
                        child: Text(
                          "lbl_5".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.right,
                          style: AppStyle.txtInterBold20,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Padding(
                        padding: getPadding(
                          right: 4,
                        ),
                        child: Text(
                          "lbl".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterRegular20WhiteA700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
