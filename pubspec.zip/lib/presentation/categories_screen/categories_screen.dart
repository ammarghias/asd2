import '../categories_screen/widgets/listpullmerchan_item_widget.dart';
import '../categories_screen/widgets/liststorename_item_widget.dart';
import 'bloc/categories_bloc.dart';
import 'models/categories_model.dart';
import 'models/listpullmerchan_item_model.dart';
import 'models/liststorename_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/presentation/home_page/home_page.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/widgets/custom_switch.dart';
import 'package:flutter/material.dart';

class CategoriesScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<CategoriesBloc>(
      create: (context) => CategoriesBloc(CategoriesState(
        categoriesModelObj: CategoriesModel(),
      ))
        ..add(CategoriesInitialEvent()),
      child: CategoriesScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        appBar: CustomAppBar(
          height: getVerticalSize(
            73,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink700,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: Container(
          height: getVerticalSize(
            917,
          ),
          width: getHorizontalSize(
            393,
          ),
          child: Stack(
            alignment: Alignment.bottomLeft,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  margin: getMargin(
                    left: 5,
                    right: 8,
                  ),
                  decoration: AppDecoration.fillWhiteA700,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          height: getVerticalSize(
                            30,
                          ),
                          width: getHorizontalSize(
                            180,
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                  height: getVerticalSize(
                                    27,
                                  ),
                                  width: getHorizontalSize(
                                    180,
                                  ),
                                  decoration: BoxDecoration(
                                    color: ColorConstant.pink700,
                                    borderRadius: BorderRadius.circular(
                                      getHorizontalSize(
                                        10,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Text(
                                  "lbl_card_management".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle
                                      .txtHindVadodaraRegular20WhiteA700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          top: 26,
                          right: 11,
                        ),
                        child: Row(
                          children: [
                            Text(
                              "lbl_categories".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtStaatlichesRegular25Black900,
                            ),
                            Padding(
                              padding: getPadding(
                                top: 16,
                                bottom: 14,
                              ),
                              child: SizedBox(
                                width: getHorizontalSize(
                                  206,
                                ),
                                child: Divider(
                                  height: getVerticalSize(
                                    1,
                                  ),
                                  thickness: getVerticalSize(
                                    1,
                                  ),
                                  color: ColorConstant.gray40009,
                                  indent: getHorizontalSize(
                                    9,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              height: getVerticalSize(
                                29,
                              ),
                              width: getHorizontalSize(
                                54,
                              ),
                              margin: getMargin(
                                left: 6,
                                top: 1,
                                bottom: 1,
                              ),
                              child: Stack(
                                alignment: Alignment.centerLeft,
                                children: [
                                  BlocSelector<CategoriesBloc, CategoriesState,
                                      bool?>(
                                    selector: (state) => state.isSelectedSwitch,
                                    builder: (context, isSelectedSwitch) {
                                      return CustomSwitch(
                                        alignment: Alignment.center,
                                        value: isSelectedSwitch,
                                        onChanged: (value) {
                                          context.read<CategoriesBloc>().add(
                                              ChangeSwitchEvent(value: value));
                                        },
                                      );
                                    },
                                  ),
                                  CustomImageView(
                                    svgPath: ImageConstant.imgLogo,
                                    height: getVerticalSize(
                                      6,
                                    ),
                                    width: getHorizontalSize(
                                      42,
                                    ),
                                    alignment: Alignment.centerLeft,
                                    margin: getMargin(
                                      left: 4,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Text(
                        "msg_compare_and_save".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtInterRegular14,
                      ),
                      Padding(
                        padding: getPadding(
                          top: 19,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              padding: getPadding(
                                bottom: 2,
                              ),
                              child: IntrinsicWidth(
                                child: Container(
                                  height: getVerticalSize(
                                    112,
                                  ),
                                  width: getHorizontalSize(
                                    55,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.bottomLeft,
                                    children: [
                                      Align(
                                        alignment: Alignment.topCenter,
                                        child: Container(
                                          height: getVerticalSize(
                                            75,
                                          ),
                                          width: getHorizontalSize(
                                            55,
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Container(
                                          width: getHorizontalSize(
                                            50,
                                          ),
                                          child: Text(
                                            "msg_groceries_essential".tr,
                                            maxLines: null,
                                            textAlign: TextAlign.center,
                                            style: AppStyle.txtInterRegular11,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                bottom: 2,
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  CustomImageView(
                                    imagePath:
                                        ImageConstant.imgPullcategorylogo3,
                                    height: getVerticalSize(
                                      75,
                                    ),
                                    width: getHorizontalSize(
                                      74,
                                    ),
                                    radius: BorderRadius.circular(
                                      getHorizontalSize(
                                        37,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      top: 5,
                                    ),
                                    child: SizedBox(
                                      width: getHorizontalSize(
                                        74,
                                      ),
                                      child: Divider(
                                        height: getVerticalSize(
                                          5,
                                        ),
                                        thickness: getVerticalSize(
                                          5,
                                        ),
                                        color: ColorConstant.pink700,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: getHorizontalSize(
                                      62,
                                    ),
                                    child: Text(
                                      "msg_dining_restaurants".tr,
                                      maxLines: null,
                                      textAlign: TextAlign.center,
                                      style: AppStyle.txtInterRegular11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              height: getVerticalSize(
                                115,
                              ),
                              width: getHorizontalSize(
                                74,
                              ),
                              child: Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  Align(
                                    alignment: Alignment.center,
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      padding: getPadding(
                                        bottom: 3,
                                      ),
                                      child: IntrinsicWidth(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage7575x72,
                                              height: getVerticalSize(
                                                75,
                                              ),
                                              width: getHorizontalSize(
                                                72,
                                              ),
                                              radius: BorderRadius.only(
                                                topLeft: Radius.circular(
                                                  getHorizontalSize(
                                                    33,
                                                  ),
                                                ),
                                                topRight: Radius.circular(
                                                  getHorizontalSize(
                                                    36,
                                                  ),
                                                ),
                                                bottomLeft: Radius.circular(
                                                  getHorizontalSize(
                                                    36,
                                                  ),
                                                ),
                                                bottomRight: Radius.circular(
                                                  getHorizontalSize(
                                                    33,
                                                  ),
                                                ),
                                              ),
                                              margin: getMargin(
                                                bottom: 37,
                                              ),
                                            ),
                                            CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgPullcategorylogo1,
                                              height: getVerticalSize(
                                                75,
                                              ),
                                              width: getHorizontalSize(
                                                74,
                                              ),
                                              radius: BorderRadius.circular(
                                                getHorizontalSize(
                                                  37,
                                                ),
                                              ),
                                              margin: getMargin(
                                                left: 108,
                                                bottom: 37,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Container(
                                      width: getHorizontalSize(
                                        43,
                                      ),
                                      child: Text(
                                        "lbl_retail_therapy".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtInterRegular11,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              height: getVerticalSize(
                                115,
                              ),
                              width: getHorizontalSize(
                                74,
                              ),
                              child: Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  CustomImageView(
                                    imagePath:
                                        ImageConstant.imgPullcategorylogo2,
                                    height: getVerticalSize(
                                      75,
                                    ),
                                    width: getHorizontalSize(
                                      74,
                                    ),
                                    radius: BorderRadius.circular(
                                      getHorizontalSize(
                                        37,
                                      ),
                                    ),
                                    alignment: Alignment.topCenter,
                                  ),
                                  Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Container(
                                      width: getHorizontalSize(
                                        59,
                                      ),
                                      child: Text(
                                        "lbl_gas_commuting".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtInterRegular11,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              width: getHorizontalSize(
                                32,
                              ),
                              margin: getMargin(
                                top: 85,
                                bottom: 2,
                              ),
                              child: Text(
                                "msg_exploration_adventure".tr,
                                maxLines: null,
                                textAlign: TextAlign.center,
                                style: AppStyle.txtInterRegular11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          top: 18,
                        ),
                        child: Text(
                          "lbl_featured".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtStaatlichesRegular22,
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          top: 2,
                          right: 1,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "msg_specially_curated".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular14,
                            ),
                            Padding(
                              padding: getPadding(
                                top: 7,
                                bottom: 9,
                              ),
                              child: SizedBox(
                                width: getHorizontalSize(
                                  205,
                                ),
                                child: Divider(
                                  height: getVerticalSize(
                                    1,
                                  ),
                                  thickness: getVerticalSize(
                                    1,
                                  ),
                                  color: ColorConstant.gray400,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          left: 2,
                          top: 6,
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Container(
                                height: getVerticalSize(
                                  121,
                                ),
                                child: BlocSelector<CategoriesBloc,
                                    CategoriesState, CategoriesModel?>(
                                  selector: (state) => state.categoriesModelObj,
                                  builder: (context, categoriesModelObj) {
                                    return ListView.separated(
                                      scrollDirection: Axis.horizontal,
                                      separatorBuilder: (context, index) {
                                        return SizedBox(
                                          height: getVerticalSize(
                                            12,
                                          ),
                                        );
                                      },
                                      itemCount: categoriesModelObj
                                              ?.liststorenameItemList.length ??
                                          0,
                                      itemBuilder: (context, index) {
                                        ListstorenameItemModel model =
                                            categoriesModelObj
                                                        ?.liststorenameItemList[
                                                    index] ??
                                                ListstorenameItemModel();
                                        return ListstorenameItemWidget(
                                          model,
                                        );
                                      },
                                    );
                                  },
                                ),
                              ),
                            ),
                            Container(
                              height: getVerticalSize(
                                121,
                              ),
                              width: getHorizontalSize(
                                52,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          left: 1,
                          top: 26,
                        ),
                        child: Text(
                          "msg_all_your_favourite".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtStaatlichesRegular22,
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          left: 1,
                          top: 2,
                          right: 2,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "lbl_browse_away".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular14,
                            ),
                            Padding(
                              padding: getPadding(
                                top: 7,
                                bottom: 8,
                              ),
                              child: SizedBox(
                                width: getHorizontalSize(
                                  273,
                                ),
                                child: Divider(
                                  height: getVerticalSize(
                                    1,
                                  ),
                                  thickness: getVerticalSize(
                                    1,
                                  ),
                                  color: ColorConstant.gray400,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.bottomLeft,
                child: Padding(
                  padding: getPadding(
                    top: 508,
                    right: 10,
                  ),
                  child: BlocSelector<CategoriesBloc, CategoriesState,
                      CategoriesModel?>(
                    selector: (state) => state.categoriesModelObj,
                    builder: (context, categoriesModelObj) {
                      return ListView.separated(
                        physics: NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        separatorBuilder: (context, index) {
                          return SizedBox(
                            height: getVerticalSize(
                              9,
                            ),
                          );
                        },
                        itemCount: categoriesModelObj
                                ?.listpullmerchanItemList.length ??
                            0,
                        itemBuilder: (context, index) {
                          ListpullmerchanItemModel model = categoriesModelObj
                                  ?.listpullmerchanItemList[index] ??
                              ListpullmerchanItemModel();
                          return ListpullmerchanItemWidget(
                            model,
                          );
                        },
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group1:
        return AppRoutes.homePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(BuildContext context, String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
