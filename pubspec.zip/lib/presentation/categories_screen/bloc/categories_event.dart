// ignore_for_file: must_be_immutable

part of 'categories_bloc.dart';

@immutable
abstract class CategoriesEvent extends Equatable {}

class CategoriesInitialEvent extends CategoriesEvent {
  @override
  List<Object?> get props => [];
}

///event for change switch
class ChangeSwitchEvent extends CategoriesEvent {
  ChangeSwitchEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
