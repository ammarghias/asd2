import 'package:equatable/equatable.dart';import 'liststorename_item_model.dart';import 'listpullmerchan_item_model.dart';
// ignore: must_be_immutable
class CategoriesModel extends Equatable {CategoriesModel({this.liststorenameItemList = const [], this.listpullmerchanItemList = const []});

List<ListstorenameItemModel> liststorenameItemList;

List<ListpullmerchanItemModel> listpullmerchanItemList;

CategoriesModel copyWith({List<ListstorenameItemModel>? liststorenameItemList, List<ListpullmerchanItemModel>? listpullmerchanItemList}) { return CategoriesModel(
liststorenameItemList : liststorenameItemList ?? this.liststorenameItemList,
listpullmerchanItemList : listpullmerchanItemList ?? this.listpullmerchanItemList,
); } 
@override List<Object?> get props => [liststorenameItemList,listpullmerchanItemList];
 }
