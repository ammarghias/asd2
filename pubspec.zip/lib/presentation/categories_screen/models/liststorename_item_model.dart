class ListstorenameItemModel {String storenameTxt = "Panera Bread";

String? id = "";

 }
