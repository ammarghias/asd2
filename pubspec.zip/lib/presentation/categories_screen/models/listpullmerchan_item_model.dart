class ListpullmerchanItemModel {String pullmerchantnamTxt = "Dunkin Donuts";

String cashbackvalueTxt = "6.3";

String rewardpointsvalTxt = "3";

String cardtypeTxt = "American Express";

String cardnameTxt = "Gold Card";

String? id = "";

 }
