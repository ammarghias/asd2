import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application4/presentation/email_help_screen/models/email_help_model.dart';part 'email_help_event.dart';part 'email_help_state.dart';class EmailHelpBloc extends Bloc<EmailHelpEvent, EmailHelpState> {EmailHelpBloc(EmailHelpState initialState) : super(initialState) { on<EmailHelpInitialEvent>(_onInitialize); }

_onInitialize(EmailHelpInitialEvent event, Emitter<EmailHelpState> emit, ) async  { emit(state.copyWith(usernameController: TextEditingController())); } 
 }
