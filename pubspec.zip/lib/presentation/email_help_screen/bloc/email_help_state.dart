// ignore_for_file: must_be_immutable

part of 'email_help_bloc.dart';

class EmailHelpState extends Equatable {
  EmailHelpState({
    this.usernameController,
    this.emailHelpModelObj,
  });

  TextEditingController? usernameController;

  EmailHelpModel? emailHelpModelObj;

  @override
  List<Object?> get props => [
        usernameController,
        emailHelpModelObj,
      ];
  EmailHelpState copyWith({
    TextEditingController? usernameController,
    EmailHelpModel? emailHelpModelObj,
  }) {
    return EmailHelpState(
      usernameController: usernameController ?? this.usernameController,
      emailHelpModelObj: emailHelpModelObj ?? this.emailHelpModelObj,
    );
  }
}
