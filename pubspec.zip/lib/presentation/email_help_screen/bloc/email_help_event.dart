// ignore_for_file: must_be_immutable

part of 'email_help_bloc.dart';

@immutable
abstract class EmailHelpEvent extends Equatable {}

class EmailHelpInitialEvent extends EmailHelpEvent {
  @override
  List<Object?> get props => [];
}
