import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class EmailHelpModel extends Equatable {EmailHelpModel copyWith() { return EmailHelpModel(
); } 
@override List<Object?> get props => [];
 }
