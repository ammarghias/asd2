// ignore_for_file: must_be_immutable

part of 'registration_terms_and_conditions_bloc.dart';

class RegistrationTermsAndConditionsState extends Equatable {
  RegistrationTermsAndConditionsState(
      {this.registrationTermsAndConditionsModelObj});

  RegistrationTermsAndConditionsModel? registrationTermsAndConditionsModelObj;

  @override
  List<Object?> get props => [
        registrationTermsAndConditionsModelObj,
      ];
  RegistrationTermsAndConditionsState copyWith(
      {RegistrationTermsAndConditionsModel?
          registrationTermsAndConditionsModelObj}) {
    return RegistrationTermsAndConditionsState(
      registrationTermsAndConditionsModelObj:
          registrationTermsAndConditionsModelObj ??
              this.registrationTermsAndConditionsModelObj,
    );
  }
}
