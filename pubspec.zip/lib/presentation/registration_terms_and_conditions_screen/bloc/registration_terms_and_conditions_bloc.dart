import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application4/presentation/registration_terms_and_conditions_screen/models/registration_terms_and_conditions_model.dart';part 'registration_terms_and_conditions_event.dart';part 'registration_terms_and_conditions_state.dart';class RegistrationTermsAndConditionsBloc extends Bloc<RegistrationTermsAndConditionsEvent, RegistrationTermsAndConditionsState> {RegistrationTermsAndConditionsBloc(RegistrationTermsAndConditionsState initialState) : super(initialState) { on<RegistrationTermsAndConditionsInitialEvent>(_onInitialize); }

_onInitialize(RegistrationTermsAndConditionsInitialEvent event, Emitter<RegistrationTermsAndConditionsState> emit, ) async  {  } 
 }
