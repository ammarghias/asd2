// ignore_for_file: must_be_immutable

part of 'registration_terms_and_conditions_bloc.dart';

@immutable
abstract class RegistrationTermsAndConditionsEvent extends Equatable {}

class RegistrationTermsAndConditionsInitialEvent
    extends RegistrationTermsAndConditionsEvent {
  @override
  List<Object?> get props => [];
}
