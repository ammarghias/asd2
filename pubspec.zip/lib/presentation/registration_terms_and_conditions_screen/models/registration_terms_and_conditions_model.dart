import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class RegistrationTermsAndConditionsModel extends Equatable {RegistrationTermsAndConditionsModel copyWith() { return RegistrationTermsAndConditionsModel(
); } 
@override List<Object?> get props => [];
 }
