import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class HomePageContainerModel extends Equatable {HomePageContainerModel copyWith() { return HomePageContainerModel(
); } 
@override List<Object?> get props => [];
 }
