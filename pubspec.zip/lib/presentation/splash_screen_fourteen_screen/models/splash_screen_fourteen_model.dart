import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenFourteenModel extends Equatable {SplashScreenFourteenModel copyWith() { return SplashScreenFourteenModel(
); } 
@override List<Object?> get props => [];
 }
