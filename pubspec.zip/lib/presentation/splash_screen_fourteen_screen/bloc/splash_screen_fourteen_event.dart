// ignore_for_file: must_be_immutable

part of 'splash_screen_fourteen_bloc.dart';

@immutable
abstract class SplashScreenFourteenEvent extends Equatable {}

class SplashScreenFourteenInitialEvent extends SplashScreenFourteenEvent {
  @override
  List<Object?> get props => [];
}
