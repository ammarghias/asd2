// ignore_for_file: must_be_immutable

part of 'splash_screen_fourteen_bloc.dart';

class SplashScreenFourteenState extends Equatable {
  SplashScreenFourteenState({this.splashScreenFourteenModelObj});

  SplashScreenFourteenModel? splashScreenFourteenModelObj;

  @override
  List<Object?> get props => [
        splashScreenFourteenModelObj,
      ];
  SplashScreenFourteenState copyWith(
      {SplashScreenFourteenModel? splashScreenFourteenModelObj}) {
    return SplashScreenFourteenState(
      splashScreenFourteenModelObj:
          splashScreenFourteenModelObj ?? this.splashScreenFourteenModelObj,
    );
  }
}
