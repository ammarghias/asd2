import 'bloc/splash_screen_two_bloc.dart';
import 'models/splash_screen_two_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

class SplashScreenTwoScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<SplashScreenTwoBloc>(
      create: (context) => SplashScreenTwoBloc(SplashScreenTwoState(
        splashScreenTwoModelObj: SplashScreenTwoModel(),
      ))
        ..add(SplashScreenTwoInitialEvent()),
      child: SplashScreenTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenTwoBloc, SplashScreenTwoState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: getPadding(
                          left: 13,
                          right: 13,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Padding(
                              padding: getPadding(
                                top: 352,
                              ),
                              child: Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                top: 260,
                              ),
                              child: Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
