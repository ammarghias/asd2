import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenTwoModel extends Equatable {SplashScreenTwoModel copyWith() { return SplashScreenTwoModel(
); } 
@override List<Object?> get props => [];
 }
