import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_four_screen/models/splash_screen_four_model.dart';
part 'splash_screen_four_event.dart';
part 'splash_screen_four_state.dart';

class SplashScreenFourBloc
    extends Bloc<SplashScreenFourEvent, SplashScreenFourState> {
  SplashScreenFourBloc(SplashScreenFourState initialState)
      : super(initialState) {
    on<SplashScreenFourInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenFourInitialEvent event,
    Emitter<SplashScreenFourState> emit,
  ) async {}
}
