// ignore_for_file: must_be_immutable

part of 'splash_screen_four_bloc.dart';

class SplashScreenFourState extends Equatable {
  SplashScreenFourState({this.splashScreenFourModelObj});

  SplashScreenFourModel? splashScreenFourModelObj;

  @override
  List<Object?> get props => [
        splashScreenFourModelObj,
      ];
  SplashScreenFourState copyWith(
      {SplashScreenFourModel? splashScreenFourModelObj}) {
    return SplashScreenFourState(
      splashScreenFourModelObj:
          splashScreenFourModelObj ?? this.splashScreenFourModelObj,
    );
  }
}
