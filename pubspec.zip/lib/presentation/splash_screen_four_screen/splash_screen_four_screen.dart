import 'bloc/splash_screen_four_bloc.dart';
import 'models/splash_screen_four_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

class SplashScreenFourScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<SplashScreenFourBloc>(
      create: (context) => SplashScreenFourBloc(SplashScreenFourState(
        splashScreenFourModelObj: SplashScreenFourModel(),
      ))
        ..add(SplashScreenFourInitialEvent()),
      child: SplashScreenFourScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenFourBloc, SplashScreenFourState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: getPadding(
                          left: 13,
                          right: 13,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Container(
                              height: getVerticalSize(
                                175,
                              ),
                              width: getHorizontalSize(
                                363,
                              ),
                              margin: getMargin(
                                top: 88,
                              ),
                              child: Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  Align(
                                    alignment: Alignment.topCenter,
                                    child: Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topCenter,
                                    child: Container(
                                      height: getSize(
                                        60,
                                      ),
                                      width: getSize(
                                        60,
                                      ),
                                      margin: getMargin(
                                        top: 51,
                                      ),
                                      decoration: BoxDecoration(
                                        color: ColorConstant.pink70005,
                                        borderRadius: BorderRadius.circular(
                                          getHorizontalSize(
                                            30,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Text(
                              "lbl_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLEMONMILKMedium65,
                            ),
                            Padding(
                              padding: getPadding(
                                top: 84,
                              ),
                              child: Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
