import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenFourModel extends Equatable {SplashScreenFourModel copyWith() { return SplashScreenFourModel(
); } 
@override List<Object?> get props => [];
 }
