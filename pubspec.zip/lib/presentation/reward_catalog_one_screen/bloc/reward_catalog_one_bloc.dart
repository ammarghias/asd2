import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/reward_catalog_one_screen/models/reward_catalog_one_model.dart';
part 'reward_catalog_one_event.dart';
part 'reward_catalog_one_state.dart';

class RewardCatalogOneBloc
    extends Bloc<RewardCatalogOneEvent, RewardCatalogOneState> {
  RewardCatalogOneBloc(RewardCatalogOneState initialState)
      : super(initialState) {
    on<RewardCatalogOneInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<RewardCatalogOneState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  _onInitialize(
    RewardCatalogOneInitialEvent event,
    Emitter<RewardCatalogOneState> emit,
  ) async {
    emit(state.copyWith(
      searchController: TextEditingController(),
      isSelectedSwitch: false,
    ));
  }
}
