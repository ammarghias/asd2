import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class RewardCatalogOneModel extends Equatable {RewardCatalogOneModel copyWith() { return RewardCatalogOneModel(
); } 
@override List<Object?> get props => [];
 }
