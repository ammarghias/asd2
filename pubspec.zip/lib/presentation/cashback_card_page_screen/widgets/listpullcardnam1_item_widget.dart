import '../models/listpullcardnam1_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class Listpullcardnam1ItemWidget extends StatelessWidget {
  Listpullcardnam1ItemWidget(this.listpullcardnam1ItemModelObj);

  Listpullcardnam1ItemModel listpullcardnam1ItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: getPadding(
        left: 7,
        top: 3,
        right: 7,
        bottom: 3,
      ),
      decoration: AppDecoration.outlineCyan8002.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder5,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: getVerticalSize(
              47,
            ),
            width: getHorizontalSize(
              54,
            ),
            margin: getMargin(
              top: 6,
            ),
            child: Stack(
              alignment: Alignment.topLeft,
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Text(
                    listpullcardnam1ItemModelObj.pullcardnameTxt,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtInterRegular35Pink700,
                  ),
                ),
                Align(
                  alignment: Alignment.topLeft,
                  child: Padding(
                    padding: getPadding(
                      left: 3,
                    ),
                    child: Text(
                      "lbl_upto2".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterRegular9,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: getHorizontalSize(
              83,
            ),
            margin: getMargin(
              left: 20,
              top: 12,
              bottom: 12,
            ),
            child: Text(
              listpullcardnam1ItemModelObj.pullcardnameTxt1,
              maxLines: null,
              textAlign: TextAlign.left,
              style: AppStyle.txtInterRegular8Black90090,
            ),
          ),
          Container(
            width: getHorizontalSize(
              89,
            ),
            margin: getMargin(
              left: 4,
              top: 12,
              bottom: 12,
            ),
            child: Text(
              listpullcardnam1ItemModelObj.pullcardnameTxt12,
              maxLines: null,
              textAlign: TextAlign.left,
              style: AppStyle.txtInterRegular8Black90090,
            ),
          ),
        ],
      ),
    );
  }
}
