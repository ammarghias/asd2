import '../models/listautomatical_item_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListautomaticalItemWidget extends StatelessWidget {
  ListautomaticalItemWidget(this.listautomaticalItemModelObj);

  ListautomaticalItemModel listautomaticalItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          child: Container(
            margin: getMargin(
              right: 4,
            ),
            padding: getPadding(
              left: 14,
              top: 5,
              right: 14,
              bottom: 5,
            ),
            decoration: AppDecoration.outlineAmber500.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder10,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: getHorizontalSize(
                    84,
                  ),
                  child: Text(
                    listautomaticalItemModelObj.automaticallyauTxt,
                    maxLines: null,
                    textAlign: TextAlign.center,
                    style: AppStyle.txtInterRegular13WhiteA700,
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: Container(
            margin: getMargin(
              left: 4,
              right: 4,
            ),
            padding: getPadding(
              left: 10,
              top: 5,
              right: 10,
              bottom: 5,
            ),
            decoration: AppDecoration.outlineAmber500.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder10,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: getHorizontalSize(
                    91,
                  ),
                  child: Text(
                    listautomaticalItemModelObj.whereyougettheTxt,
                    maxLines: null,
                    textAlign: TextAlign.center,
                    style: AppStyle.txtInterRegular13WhiteA700,
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: Container(
            margin: getMargin(
              left: 4,
            ),
            padding: getPadding(
              left: 15,
              top: 13,
              right: 15,
              bottom: 13,
            ),
            decoration: AppDecoration.outlineAmber500.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder10,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: getHorizontalSize(
                    80,
                  ),
                  child: Text(
                    listautomaticalItemModelObj.consolidatedcreTxt,
                    maxLines: null,
                    textAlign: TextAlign.center,
                    style: AppStyle.txtInterRegular13WhiteA700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
