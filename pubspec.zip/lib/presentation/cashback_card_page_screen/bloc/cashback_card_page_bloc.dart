import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/listdatatype_item_model.dart';
import '../models/listautomatical_item_model.dart';
import '../models/listpullcardnam_item_model.dart';
import '../models/listpullcardnam1_item_model.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/cashback_card_page_screen/models/cashback_card_page_model.dart';
part 'cashback_card_page_event.dart';
part 'cashback_card_page_state.dart';

class CashbackCardPageBloc
    extends Bloc<CashbackCardPageEvent, CashbackCardPageState> {
  CashbackCardPageBloc(CashbackCardPageState initialState)
      : super(initialState) {
    on<CashbackCardPageInitialEvent>(_onInitialize);
    on<ChangeCheckBoxEvent>(_changeCheckBox);
  }

  _changeCheckBox(
    ChangeCheckBoxEvent event,
    Emitter<CashbackCardPageState> emit,
  ) {
    emit(state.copyWith(
      isCheckbox: event.value,
    ));
  }

  List<ListdatatypeItemModel> fillListdatatypeItemList() {
    return List.generate(3, (index) => ListdatatypeItemModel());
  }

  List<ListautomaticalItemModel> fillListautomaticalItemList() {
    return List.generate(3, (index) => ListautomaticalItemModel());
  }

  List<ListpullcardnamItemModel> fillListpullcardnamItemList() {
    return List.generate(3, (index) => ListpullcardnamItemModel());
  }

  List<Listpullcardnam1ItemModel> fillListpullcardnam1ItemList() {
    return List.generate(2, (index) => Listpullcardnam1ItemModel());
  }

  _onInitialize(
    CashbackCardPageInitialEvent event,
    Emitter<CashbackCardPageState> emit,
  ) async {
    emit(state.copyWith(
      grouptwentyseveController: TextEditingController(),
      isCheckbox: false,
    ));
    emit(state.copyWith(
        cashbackCardPageModelObj: state.cashbackCardPageModelObj?.copyWith(
      listdatatypeItemList: fillListdatatypeItemList(),
      listautomaticalItemList: fillListautomaticalItemList(),
      listpullcardnamItemList: fillListpullcardnamItemList(),
      listpullcardnam1ItemList: fillListpullcardnam1ItemList(),
    )));
  }
}
