// ignore_for_file: must_be_immutable

part of 'cashback_card_page_bloc.dart';

class CashbackCardPageState extends Equatable {
  CashbackCardPageState({
    this.grouptwentyseveController,
    this.isCheckbox = false,
    this.cashbackCardPageModelObj,
  });

  TextEditingController? grouptwentyseveController;

  CashbackCardPageModel? cashbackCardPageModelObj;

  bool isCheckbox;

  @override
  List<Object?> get props => [
        grouptwentyseveController,
        isCheckbox,
        cashbackCardPageModelObj,
      ];
  CashbackCardPageState copyWith({
    TextEditingController? grouptwentyseveController,
    bool? isCheckbox,
    CashbackCardPageModel? cashbackCardPageModelObj,
  }) {
    return CashbackCardPageState(
      grouptwentyseveController:
          grouptwentyseveController ?? this.grouptwentyseveController,
      isCheckbox: isCheckbox ?? this.isCheckbox,
      cashbackCardPageModelObj:
          cashbackCardPageModelObj ?? this.cashbackCardPageModelObj,
    );
  }
}
