// ignore_for_file: must_be_immutable

part of 'cashback_card_page_bloc.dart';

@immutable
abstract class CashbackCardPageEvent extends Equatable {}

class CashbackCardPageInitialEvent extends CashbackCardPageEvent {
  @override
  List<Object?> get props => [];
}

///event for change checkbox
class ChangeCheckBoxEvent extends CashbackCardPageEvent {
  ChangeCheckBoxEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
