class Listpullcardnam1ItemModel {String pullcardnameTxt = "3%";

String pullcardnameTxt1 = "Groceries\nUtilities & Hygiene\nPersonal Projects";

String pullcardnameTxt12 = "Outlets & Shopping\nHome Improvement\nCrafts & Supplies";

String? id = "";

 }
