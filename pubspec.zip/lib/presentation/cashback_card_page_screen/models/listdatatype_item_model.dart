class ListdatatypeItemModel {String monthTxt = "apr";

String? id = "";

 }
