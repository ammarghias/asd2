import 'package:equatable/equatable.dart';import 'listdatatype_item_model.dart';import 'listautomatical_item_model.dart';import 'listpullcardnam_item_model.dart';import 'listpullcardnam1_item_model.dart';
// ignore: must_be_immutable
class CashbackCardPageModel extends Equatable {CashbackCardPageModel({this.listdatatypeItemList = const [], this.listautomaticalItemList = const [], this.listpullcardnamItemList = const [], this.listpullcardnam1ItemList = const []});

List<ListdatatypeItemModel> listdatatypeItemList;

List<ListautomaticalItemModel> listautomaticalItemList;

List<ListpullcardnamItemModel> listpullcardnamItemList;

List<Listpullcardnam1ItemModel> listpullcardnam1ItemList;

CashbackCardPageModel copyWith({List<ListdatatypeItemModel>? listdatatypeItemList, List<ListautomaticalItemModel>? listautomaticalItemList, List<ListpullcardnamItemModel>? listpullcardnamItemList, List<Listpullcardnam1ItemModel>? listpullcardnam1ItemList}) { return CashbackCardPageModel(
listdatatypeItemList : listdatatypeItemList ?? this.listdatatypeItemList,
listautomaticalItemList : listautomaticalItemList ?? this.listautomaticalItemList,
listpullcardnamItemList : listpullcardnamItemList ?? this.listpullcardnamItemList,
listpullcardnam1ItemList : listpullcardnam1ItemList ?? this.listpullcardnam1ItemList,
); } 
@override List<Object?> get props => [listdatatypeItemList,listautomaticalItemList,listpullcardnamItemList,listpullcardnam1ItemList];
 }
