class ListautomaticalItemModel {String automaticallyauTxt = "Automatically authorize transactions";

String whereyougettheTxt = "Where You get the Maximum reward";

String consolidatedcreTxt = "Consolidated Credit limits";

String? id = "";

 }
