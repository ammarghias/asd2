import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenTwelveModel extends Equatable {SplashScreenTwelveModel copyWith() { return SplashScreenTwelveModel(
); } 
@override List<Object?> get props => [];
 }
