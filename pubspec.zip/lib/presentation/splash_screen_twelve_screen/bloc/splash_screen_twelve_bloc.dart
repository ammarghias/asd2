import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_twelve_screen/models/splash_screen_twelve_model.dart';
part 'splash_screen_twelve_event.dart';
part 'splash_screen_twelve_state.dart';

class SplashScreenTwelveBloc
    extends Bloc<SplashScreenTwelveEvent, SplashScreenTwelveState> {
  SplashScreenTwelveBloc(SplashScreenTwelveState initialState)
      : super(initialState) {
    on<SplashScreenTwelveInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenTwelveInitialEvent event,
    Emitter<SplashScreenTwelveState> emit,
  ) async {}
}
