// ignore_for_file: must_be_immutable

part of 'splash_screen_twelve_bloc.dart';

class SplashScreenTwelveState extends Equatable {
  SplashScreenTwelveState({this.splashScreenTwelveModelObj});

  SplashScreenTwelveModel? splashScreenTwelveModelObj;

  @override
  List<Object?> get props => [
        splashScreenTwelveModelObj,
      ];
  SplashScreenTwelveState copyWith(
      {SplashScreenTwelveModel? splashScreenTwelveModelObj}) {
    return SplashScreenTwelveState(
      splashScreenTwelveModelObj:
          splashScreenTwelveModelObj ?? this.splashScreenTwelveModelObj,
    );
  }
}
