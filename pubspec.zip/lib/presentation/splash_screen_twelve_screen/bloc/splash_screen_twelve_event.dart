// ignore_for_file: must_be_immutable

part of 'splash_screen_twelve_bloc.dart';

@immutable
abstract class SplashScreenTwelveEvent extends Equatable {}

class SplashScreenTwelveInitialEvent extends SplashScreenTwelveEvent {
  @override
  List<Object?> get props => [];
}
