import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_three_screen/models/splash_screen_three_model.dart';
part 'splash_screen_three_event.dart';
part 'splash_screen_three_state.dart';

class SplashScreenThreeBloc
    extends Bloc<SplashScreenThreeEvent, SplashScreenThreeState> {
  SplashScreenThreeBloc(SplashScreenThreeState initialState)
      : super(initialState) {
    on<SplashScreenThreeInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenThreeInitialEvent event,
    Emitter<SplashScreenThreeState> emit,
  ) async {}
}
