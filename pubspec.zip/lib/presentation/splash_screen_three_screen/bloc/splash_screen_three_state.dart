// ignore_for_file: must_be_immutable

part of 'splash_screen_three_bloc.dart';

class SplashScreenThreeState extends Equatable {
  SplashScreenThreeState({this.splashScreenThreeModelObj});

  SplashScreenThreeModel? splashScreenThreeModelObj;

  @override
  List<Object?> get props => [
        splashScreenThreeModelObj,
      ];
  SplashScreenThreeState copyWith(
      {SplashScreenThreeModel? splashScreenThreeModelObj}) {
    return SplashScreenThreeState(
      splashScreenThreeModelObj:
          splashScreenThreeModelObj ?? this.splashScreenThreeModelObj,
    );
  }
}
