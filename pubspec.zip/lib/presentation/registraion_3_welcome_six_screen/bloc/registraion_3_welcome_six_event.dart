// ignore_for_file: must_be_immutable

part of 'registraion_3_welcome_six_bloc.dart';

@immutable
abstract class Registraion3WelcomeSixEvent extends Equatable {}

class Registraion3WelcomeSixInitialEvent extends Registraion3WelcomeSixEvent {
  @override
  List<Object?> get props => [];
}
