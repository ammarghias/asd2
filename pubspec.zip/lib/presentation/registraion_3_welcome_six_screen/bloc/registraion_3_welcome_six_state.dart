// ignore_for_file: must_be_immutable

part of 'registraion_3_welcome_six_bloc.dart';

class Registraion3WelcomeSixState extends Equatable {
  Registraion3WelcomeSixState({this.registraion3WelcomeSixModelObj});

  Registraion3WelcomeSixModel? registraion3WelcomeSixModelObj;

  @override
  List<Object?> get props => [
        registraion3WelcomeSixModelObj,
      ];
  Registraion3WelcomeSixState copyWith(
      {Registraion3WelcomeSixModel? registraion3WelcomeSixModelObj}) {
    return Registraion3WelcomeSixState(
      registraion3WelcomeSixModelObj:
          registraion3WelcomeSixModelObj ?? this.registraion3WelcomeSixModelObj,
    );
  }
}
