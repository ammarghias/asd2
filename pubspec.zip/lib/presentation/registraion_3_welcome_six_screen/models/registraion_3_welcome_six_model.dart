import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class Registraion3WelcomeSixModel extends Equatable {Registraion3WelcomeSixModel copyWith() { return Registraion3WelcomeSixModel(
); } 
@override List<Object?> get props => [];
 }
