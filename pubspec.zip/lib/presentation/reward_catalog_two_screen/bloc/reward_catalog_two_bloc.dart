import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/reward_catalog_item_model.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/reward_catalog_two_screen/models/reward_catalog_two_model.dart';
part 'reward_catalog_two_event.dart';
part 'reward_catalog_two_state.dart';

class RewardCatalogTwoBloc
    extends Bloc<RewardCatalogTwoEvent, RewardCatalogTwoState> {
  RewardCatalogTwoBloc(RewardCatalogTwoState initialState)
      : super(initialState) {
    on<RewardCatalogTwoInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<RewardCatalogTwoState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<RewardCatalogItemModel> fillRewardCatalogItemList() {
    return List.generate(4, (index) => RewardCatalogItemModel());
  }

  _onInitialize(
    RewardCatalogTwoInitialEvent event,
    Emitter<RewardCatalogTwoState> emit,
  ) async {
    emit(state.copyWith(
      searchController: TextEditingController(),
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        rewardCatalogTwoModelObj: state.rewardCatalogTwoModelObj?.copyWith(
      rewardCatalogItemList: fillRewardCatalogItemList(),
    )));
  }
}
