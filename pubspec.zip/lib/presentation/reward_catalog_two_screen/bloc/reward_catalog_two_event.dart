// ignore_for_file: must_be_immutable

part of 'reward_catalog_two_bloc.dart';

@immutable
abstract class RewardCatalogTwoEvent extends Equatable {}

class RewardCatalogTwoInitialEvent extends RewardCatalogTwoEvent {
  @override
  List<Object?> get props => [];
}

///event for change switch
class ChangeSwitchEvent extends RewardCatalogTwoEvent {
  ChangeSwitchEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
