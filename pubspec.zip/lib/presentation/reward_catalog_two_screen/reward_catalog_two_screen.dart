import '../reward_catalog_two_screen/widgets/reward_catalog_item_widget.dart';
import 'bloc/reward_catalog_two_bloc.dart';
import 'models/reward_catalog_item_model.dart';
import 'models/reward_catalog_two_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/presentation/home_page/home_page.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/widgets/custom_switch.dart';
import 'package:ammar_s_application4/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class RewardCatalogTwoScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<RewardCatalogTwoBloc>(
      create: (context) => RewardCatalogTwoBloc(RewardCatalogTwoState(
        rewardCatalogTwoModelObj: RewardCatalogTwoModel(),
      ))
        ..add(RewardCatalogTwoInitialEvent()),
      child: RewardCatalogTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        appBar: CustomAppBar(
          height: getVerticalSize(
            83,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink700,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: Container(
          width: getHorizontalSize(
            393,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: getPadding(
                  left: 95,
                ),
                child: Text(
                  "lbl_reward_catalog".tr,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtHindVadodaraRegular28,
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Padding(
                  padding: getPadding(
                    left: 19,
                    top: 17,
                    right: 14,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Container(
                          padding: getPadding(
                            all: 3,
                          ),
                          decoration: AppDecoration.outlineGray50002.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder15,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: getHorizontalSize(
                                  130,
                                ),
                                padding: getPadding(
                                  left: 25,
                                  top: 1,
                                  right: 25,
                                  bottom: 1,
                                ),
                                decoration:
                                    AppDecoration.txtOutlinePink700.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.txtRoundedBorder14,
                                ),
                                child: Text(
                                  "lbl_detailed".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular20Pink700,
                                ),
                              ),
                              Container(
                                width: getHorizontalSize(
                                  130,
                                ),
                                margin: getMargin(
                                  left: 21,
                                ),
                                padding: getPadding(
                                  left: 19,
                                  top: 1,
                                  right: 19,
                                  bottom: 1,
                                ),
                                decoration:
                                    AppDecoration.txtOutlineWhiteA700.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.txtRoundedBorder14,
                                ),
                                child: Text(
                                  "lbl_summary".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular20WhiteA700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        height: getVerticalSize(
                          29,
                        ),
                        width: getHorizontalSize(
                          54,
                        ),
                        margin: getMargin(
                          left: 19,
                          top: 2,
                          bottom: 4,
                        ),
                        child: Stack(
                          alignment: Alignment.centerLeft,
                          children: [
                            BlocSelector<RewardCatalogTwoBloc,
                                RewardCatalogTwoState, bool?>(
                              selector: (state) => state.isSelectedSwitch,
                              builder: (context, isSelectedSwitch) {
                                return CustomSwitch(
                                  alignment: Alignment.center,
                                  value: isSelectedSwitch,
                                  onChanged: (value) {
                                    context
                                        .read<RewardCatalogTwoBloc>()
                                        .add(ChangeSwitchEvent(value: value));
                                  },
                                );
                              },
                            ),
                            CustomImageView(
                              svgPath: ImageConstant.imgLogo,
                              height: getVerticalSize(
                                6,
                              ),
                              width: getHorizontalSize(
                                42,
                              ),
                              alignment: Alignment.centerLeft,
                              margin: getMargin(
                                left: 4,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                height: getVerticalSize(
                  705,
                ),
                width: getHorizontalSize(
                  387,
                ),
                margin: getMargin(
                  left: 6,
                  top: 21,
                  bottom: 8,
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        height: getVerticalSize(
                          704,
                        ),
                        width: getHorizontalSize(
                          387,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.pink700,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(
                              getHorizontalSize(
                                44,
                              ),
                            ),
                            bottomLeft: Radius.circular(
                              getHorizontalSize(
                                44,
                              ),
                            ),
                            bottomRight: Radius.circular(
                              getHorizontalSize(
                                44,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        padding: getPadding(
                          left: 3,
                          top: 23,
                          right: 3,
                          bottom: 23,
                        ),
                        decoration: AppDecoration.outlinePink90033.copyWith(
                          borderRadius: BorderRadiusStyle.customBorderTL35,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            BlocSelector<RewardCatalogTwoBloc,
                                RewardCatalogTwoState, TextEditingController?>(
                              selector: (state) => state.searchController,
                              builder: (context, searchController) {
                                return CustomTextFormField(
                                  focusNode: FocusNode(),
                                  controller: searchController,
                                  hintText: "msg_search_reward_catalog".tr,
                                  margin: getMargin(
                                    left: 7,
                                    right: 42,
                                  ),
                                  variant: TextFormFieldVariant.OutlinePink700,
                                  padding: TextFormFieldPadding.PaddingT10,
                                  fontStyle:
                                      TextFormFieldFontStyle.InterRegular18,
                                  textInputAction: TextInputAction.done,
                                  suffix: Container(
                                    padding: getPadding(
                                      left: 13,
                                      top: 7,
                                      right: 12,
                                      bottom: 5,
                                    ),
                                    margin: getMargin(
                                      left: 30,
                                      top: 4,
                                      right: 5,
                                      bottom: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: ColorConstant.pink700,
                                      borderRadius: BorderRadius.circular(
                                        getHorizontalSize(
                                          17,
                                        ),
                                      ),
                                      border: Border.all(
                                        color: ColorConstant.whiteA700,
                                        width: getHorizontalSize(
                                          3,
                                        ),
                                      ),
                                    ),
                                    child: CustomImageView(
                                      svgPath: ImageConstant.imgSignal,
                                    ),
                                  ),
                                  suffixConstraints: BoxConstraints(
                                    maxHeight: getVerticalSize(
                                      43,
                                    ),
                                  ),
                                );
                              },
                            ),
                            Padding(
                              padding: getPadding(
                                left: 10,
                                top: 11,
                              ),
                              child: Text(
                                "lbl_search_results".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular25Black900,
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: getPadding(
                                  right: 1,
                                  bottom: 43,
                                ),
                                child: BlocSelector<
                                    RewardCatalogTwoBloc,
                                    RewardCatalogTwoState,
                                    RewardCatalogTwoModel?>(
                                  selector: (state) =>
                                      state.rewardCatalogTwoModelObj,
                                  builder: (context, rewardCatalogTwoModelObj) {
                                    return ListView.separated(
                                      physics: BouncingScrollPhysics(),
                                      shrinkWrap: true,
                                      separatorBuilder: (context, index) {
                                        return SizedBox(
                                          height: getVerticalSize(
                                            9,
                                          ),
                                        );
                                      },
                                      itemCount: rewardCatalogTwoModelObj
                                              ?.rewardCatalogItemList.length ??
                                          0,
                                      itemBuilder: (context, index) {
                                        RewardCatalogItemModel model =
                                            rewardCatalogTwoModelObj
                                                        ?.rewardCatalogItemList[
                                                    index] ??
                                                RewardCatalogItemModel();
                                        return RewardCatalogItemWidget(
                                          model,
                                        );
                                      },
                                    );
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group1:
        return AppRoutes.homePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(BuildContext context, String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
