class RewardCatalogItemModel {String loyaltyprogramTxt = "Marriott Bonvoy";

String cashbackrateTxt = "6.3";

String rewardrateTxt = "3";

String cardproviderTxt = "American Express";

String cardtypeTxt = "Gold Card";

String? id = "";

 }
