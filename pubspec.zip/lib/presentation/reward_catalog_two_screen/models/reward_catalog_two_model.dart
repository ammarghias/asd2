import 'package:equatable/equatable.dart';import 'reward_catalog_item_model.dart';
// ignore: must_be_immutable
class RewardCatalogTwoModel extends Equatable {RewardCatalogTwoModel({this.rewardCatalogItemList = const []});

List<RewardCatalogItemModel> rewardCatalogItemList;

RewardCatalogTwoModel copyWith({List<RewardCatalogItemModel>? rewardCatalogItemList}) { return RewardCatalogTwoModel(
rewardCatalogItemList : rewardCatalogItemList ?? this.rewardCatalogItemList,
); } 
@override List<Object?> get props => [rewardCatalogItemList];
 }
