import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class Registration2MfaAuthenticationModel extends Equatable {Registration2MfaAuthenticationModel copyWith() { return Registration2MfaAuthenticationModel(
); } 
@override List<Object?> get props => [];
 }
