// ignore_for_file: must_be_immutable

part of 'registration_2_mfa_authentication_bloc.dart';

@immutable
abstract class Registration2MfaAuthenticationEvent extends Equatable {}

class Registration2MfaAuthenticationInitialEvent
    extends Registration2MfaAuthenticationEvent {
  @override
  List<Object?> get props => [];
}
