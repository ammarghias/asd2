import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application4/presentation/registration_2_mfa_authentication_screen/models/registration_2_mfa_authentication_model.dart';part 'registration_2_mfa_authentication_event.dart';part 'registration_2_mfa_authentication_state.dart';class Registration2MfaAuthenticationBloc extends Bloc<Registration2MfaAuthenticationEvent, Registration2MfaAuthenticationState> {Registration2MfaAuthenticationBloc(Registration2MfaAuthenticationState initialState) : super(initialState) { on<Registration2MfaAuthenticationInitialEvent>(_onInitialize); }

_onInitialize(Registration2MfaAuthenticationInitialEvent event, Emitter<Registration2MfaAuthenticationState> emit, ) async  {  } 
 }
