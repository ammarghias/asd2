import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class EmailPartnerOneModel extends Equatable {EmailPartnerOneModel copyWith() { return EmailPartnerOneModel(
); } 
@override List<Object?> get props => [];
 }
