// ignore_for_file: must_be_immutable

part of 'email_partner_one_bloc.dart';

class EmailPartnerOneState extends Equatable {
  EmailPartnerOneState({
    this.usernameController,
    this.emailPartnerOneModelObj,
  });

  TextEditingController? usernameController;

  EmailPartnerOneModel? emailPartnerOneModelObj;

  @override
  List<Object?> get props => [
        usernameController,
        emailPartnerOneModelObj,
      ];
  EmailPartnerOneState copyWith({
    TextEditingController? usernameController,
    EmailPartnerOneModel? emailPartnerOneModelObj,
  }) {
    return EmailPartnerOneState(
      usernameController: usernameController ?? this.usernameController,
      emailPartnerOneModelObj:
          emailPartnerOneModelObj ?? this.emailPartnerOneModelObj,
    );
  }
}
