import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application4/presentation/email_partner_one_screen/models/email_partner_one_model.dart';part 'email_partner_one_event.dart';part 'email_partner_one_state.dart';class EmailPartnerOneBloc extends Bloc<EmailPartnerOneEvent, EmailPartnerOneState> {EmailPartnerOneBloc(EmailPartnerOneState initialState) : super(initialState) { on<EmailPartnerOneInitialEvent>(_onInitialize); }

_onInitialize(EmailPartnerOneInitialEvent event, Emitter<EmailPartnerOneState> emit, ) async  { emit(state.copyWith(usernameController: TextEditingController())); } 
 }
