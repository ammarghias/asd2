// ignore_for_file: must_be_immutable

part of 'email_partner_one_bloc.dart';

@immutable
abstract class EmailPartnerOneEvent extends Equatable {}

class EmailPartnerOneInitialEvent extends EmailPartnerOneEvent {
  @override
  List<Object?> get props => [];
}
