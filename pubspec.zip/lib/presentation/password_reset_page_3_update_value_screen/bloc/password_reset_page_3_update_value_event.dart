// ignore_for_file: must_be_immutable

part of 'password_reset_page_3_update_value_bloc.dart';

@immutable
abstract class PasswordResetPage3UpdateValueEvent extends Equatable {}

class PasswordResetPage3UpdateValueInitialEvent
    extends PasswordResetPage3UpdateValueEvent {
  @override
  List<Object?> get props => [];
}
