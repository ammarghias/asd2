import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class PasswordResetPage3UpdateValueModel extends Equatable {PasswordResetPage3UpdateValueModel copyWith() { return PasswordResetPage3UpdateValueModel(
); } 
@override List<Object?> get props => [];
 }
