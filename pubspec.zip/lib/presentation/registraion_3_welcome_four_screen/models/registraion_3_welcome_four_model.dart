import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class Registraion3WelcomeFourModel extends Equatable {Registraion3WelcomeFourModel copyWith() { return Registraion3WelcomeFourModel(
); } 
@override List<Object?> get props => [];
 }
