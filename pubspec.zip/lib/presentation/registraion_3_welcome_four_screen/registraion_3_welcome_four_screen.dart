import 'bloc/registraion_3_welcome_four_bloc.dart';
import 'models/registraion_3_welcome_four_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class Registraion3WelcomeFourScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<Registraion3WelcomeFourBloc>(
      create: (context) =>
          Registraion3WelcomeFourBloc(Registraion3WelcomeFourState(
        registraion3WelcomeFourModelObj: Registraion3WelcomeFourModel(),
      ))
            ..add(Registraion3WelcomeFourInitialEvent()),
      child: Registraion3WelcomeFourScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<Registraion3WelcomeFourBloc,
        Registraion3WelcomeFourState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            appBar: CustomAppBar(
              height: getVerticalSize(
                79,
              ),
              centerTitle: true,
              title: Container(
                height: getVerticalSize(
                  48,
                ),
                width: getHorizontalSize(
                  268,
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    AppbarImage(
                      height: getVerticalSize(
                        47,
                      ),
                      width: getHorizontalSize(
                        268,
                      ),
                      svgPath: ImageConstant.imgGroupWhiteA70047x276,
                    ),
                    AppbarImage(
                      height: getVerticalSize(
                        48,
                      ),
                      width: getHorizontalSize(
                        42,
                      ),
                      svgPath: ImageConstant.imgVectorWhiteA700,
                      margin: getMargin(
                        left: 30,
                        right: 195,
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                AppbarImage(
                  height: getVerticalSize(
                    48,
                  ),
                  width: getHorizontalSize(
                    42,
                  ),
                  svgPath: ImageConstant.imgVectorWhiteA700,
                  margin: getMargin(
                    left: 120,
                    right: 120,
                  ),
                ),
              ],
            ),
            body: SizedBox(
              width: size.width,
              child: SingleChildScrollView(
                child: Container(
                  height: size.height,
                  width: getHorizontalSize(
                    380,
                  ),
                  child: Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      Align(
                        alignment: Alignment.topCenter,
                        child: Text(
                          "lbl_cashback".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtLEMONMILKMedium65,
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Padding(
                          padding: getPadding(
                            left: 13,
                            right: 3,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 264,
                                ),
                                child: Text(
                                  "lbl_cashback".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtLEMONMILKMedium65,
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 260,
                                ),
                                child: Text(
                                  "lbl_cashback".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtLEMONMILKMedium65,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          height: size.height,
                          width: getHorizontalSize(
                            380,
                          ),
                          child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgEllipse1844x380,
                                height: getVerticalSize(
                                  844,
                                ),
                                width: getHorizontalSize(
                                  380,
                                ),
                                alignment: Alignment.center,
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: getPadding(
                                        left: 28,
                                      ),
                                      child: Text(
                                        "lbl_as_easy_as".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtImprimaRegular20,
                                      ),
                                    ),
                                    Container(
                                      width: double.maxFinite,
                                      child: Container(
                                        width: getHorizontalSize(
                                          380,
                                        ),
                                        margin: getMargin(
                                          top: 25,
                                        ),
                                        padding: getPadding(
                                          left: 25,
                                          top: 8,
                                          right: 25,
                                          bottom: 8,
                                        ),
                                        decoration: AppDecoration
                                            .outlineBlack900
                                            .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .customBorderTL30,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Align(
                                              alignment: Alignment.centerRight,
                                              child: Text(
                                                "lbl_skip".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtHindVadodaraRegular20
                                                    .copyWith(
                                                  decoration:
                                                      TextDecoration.underline,
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                left: 2,
                                                top: 45,
                                              ),
                                              child: Text(
                                                "lbl_step_3".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtImprimaRegular40,
                                              ),
                                            ),
                                            Container(
                                              width: getHorizontalSize(
                                                276,
                                              ),
                                              margin: getMargin(
                                                left: 2,
                                                top: 17,
                                                right: 50,
                                              ),
                                              child: Text(
                                                "msg_welcome_screen_about".tr,
                                                maxLines: null,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular25Black900,
                                              ),
                                            ),
                                            Container(
                                              width: getHorizontalSize(
                                                175,
                                              ),
                                              margin: getMargin(
                                                left: 66,
                                                top: 131,
                                              ),
                                              child: Text(
                                                "lbl_graphic_screen".tr,
                                                maxLines: null,
                                                textAlign: TextAlign.center,
                                                style: AppStyle.txtInterBold45,
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                height: getVerticalSize(
                                                  18,
                                                ),
                                                width: getHorizontalSize(
                                                  126,
                                                ),
                                                margin: getMargin(
                                                  top: 184,
                                                  bottom: 26,
                                                ),
                                                child: Stack(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                        height: getSize(
                                                          18,
                                                        ),
                                                        width: getSize(
                                                          18,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .pink700,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                            getHorizontalSize(
                                                              9,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      child: Container(
                                                        height: getVerticalSize(
                                                          14,
                                                        ),
                                                        child: SmoothIndicator(
                                                          offset: 0,
                                                          count: 5,
                                                          size: Size.zero,
                                                          effect:
                                                              ScrollingDotsEffect(
                                                            spacing: 11,
                                                            activeDotColor:
                                                                ColorConstant
                                                                    .pink700,
                                                            dotColor:
                                                                ColorConstant
                                                                    .blueGray100,
                                                            dotHeight:
                                                                getVerticalSize(
                                                              14,
                                                            ),
                                                            dotWidth:
                                                                getHorizontalSize(
                                                              16,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
