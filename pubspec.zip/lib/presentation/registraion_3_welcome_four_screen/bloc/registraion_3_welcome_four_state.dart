// ignore_for_file: must_be_immutable

part of 'registraion_3_welcome_four_bloc.dart';

class Registraion3WelcomeFourState extends Equatable {
  Registraion3WelcomeFourState({this.registraion3WelcomeFourModelObj});

  Registraion3WelcomeFourModel? registraion3WelcomeFourModelObj;

  @override
  List<Object?> get props => [
        registraion3WelcomeFourModelObj,
      ];
  Registraion3WelcomeFourState copyWith(
      {Registraion3WelcomeFourModel? registraion3WelcomeFourModelObj}) {
    return Registraion3WelcomeFourState(
      registraion3WelcomeFourModelObj: registraion3WelcomeFourModelObj ??
          this.registraion3WelcomeFourModelObj,
    );
  }
}
