import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/registraion_3_welcome_four_screen/models/registraion_3_welcome_four_model.dart';
part 'registraion_3_welcome_four_event.dart';
part 'registraion_3_welcome_four_state.dart';

class Registraion3WelcomeFourBloc
    extends Bloc<Registraion3WelcomeFourEvent, Registraion3WelcomeFourState> {
  Registraion3WelcomeFourBloc(Registraion3WelcomeFourState initialState)
      : super(initialState) {
    on<Registraion3WelcomeFourInitialEvent>(_onInitialize);
  }

  _onInitialize(
    Registraion3WelcomeFourInitialEvent event,
    Emitter<Registraion3WelcomeFourState> emit,
  ) async {}
}
