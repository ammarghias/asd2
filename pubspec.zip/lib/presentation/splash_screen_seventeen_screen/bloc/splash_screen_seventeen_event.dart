// ignore_for_file: must_be_immutable

part of 'splash_screen_seventeen_bloc.dart';

@immutable
abstract class SplashScreenSeventeenEvent extends Equatable {}

class SplashScreenSeventeenInitialEvent extends SplashScreenSeventeenEvent {
  @override
  List<Object?> get props => [];
}
