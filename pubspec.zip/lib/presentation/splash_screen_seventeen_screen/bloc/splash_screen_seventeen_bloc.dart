import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_seventeen_screen/models/splash_screen_seventeen_model.dart';
part 'splash_screen_seventeen_event.dart';
part 'splash_screen_seventeen_state.dart';

class SplashScreenSeventeenBloc
    extends Bloc<SplashScreenSeventeenEvent, SplashScreenSeventeenState> {
  SplashScreenSeventeenBloc(SplashScreenSeventeenState initialState)
      : super(initialState) {
    on<SplashScreenSeventeenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenSeventeenInitialEvent event,
    Emitter<SplashScreenSeventeenState> emit,
  ) async {}
}
