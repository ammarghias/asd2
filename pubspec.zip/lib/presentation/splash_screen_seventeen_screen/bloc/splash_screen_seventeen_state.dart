// ignore_for_file: must_be_immutable

part of 'splash_screen_seventeen_bloc.dart';

class SplashScreenSeventeenState extends Equatable {
  SplashScreenSeventeenState({this.splashScreenSeventeenModelObj});

  SplashScreenSeventeenModel? splashScreenSeventeenModelObj;

  @override
  List<Object?> get props => [
        splashScreenSeventeenModelObj,
      ];
  SplashScreenSeventeenState copyWith(
      {SplashScreenSeventeenModel? splashScreenSeventeenModelObj}) {
    return SplashScreenSeventeenState(
      splashScreenSeventeenModelObj:
          splashScreenSeventeenModelObj ?? this.splashScreenSeventeenModelObj,
    );
  }
}
