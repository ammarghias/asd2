import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenSeventeenModel extends Equatable {SplashScreenSeventeenModel copyWith() { return SplashScreenSeventeenModel(
); } 
@override List<Object?> get props => [];
 }
