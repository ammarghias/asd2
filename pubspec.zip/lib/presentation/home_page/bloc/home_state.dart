// ignore_for_file: must_be_immutable

part of 'home_bloc.dart';

class HomeState extends Equatable {
  HomeState({
    this.isSelectedSwitch = false,
    this.homeModelObj,
  });

  HomeModel? homeModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        isSelectedSwitch,
        homeModelObj,
      ];
  HomeState copyWith({
    bool? isSelectedSwitch,
    HomeModel? homeModelObj,
  }) {
    return HomeState(
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      homeModelObj: homeModelObj ?? this.homeModelObj,
    );
  }
}
