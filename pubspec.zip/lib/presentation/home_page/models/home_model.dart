import 'package:equatable/equatable.dart';import 'home_page_item_model.dart';
// ignore: must_be_immutable
class HomeModel extends Equatable {HomeModel({this.homePageItemList = const []});

List<HomePageItemModel> homePageItemList;

HomeModel copyWith({List<HomePageItemModel>? homePageItemList}) { return HomeModel(
homePageItemList : homePageItemList ?? this.homePageItemList,
); } 
@override List<Object?> get props => [homePageItemList];
 }
