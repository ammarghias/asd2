class HomePageItemModel {String loyaltyprogramTxt = "Marriott Bonvoy";

String cashbackrateTxt = "6.3";

String rewardpointsratTxt = "3";

String cardtypeTxt = "American Express";

String cardnameTxt = "Gold Card";

String? id = "";

 }
