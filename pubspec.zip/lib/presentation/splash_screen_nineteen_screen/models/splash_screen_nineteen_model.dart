import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenNineteenModel extends Equatable {SplashScreenNineteenModel copyWith() { return SplashScreenNineteenModel(
); } 
@override List<Object?> get props => [];
 }
