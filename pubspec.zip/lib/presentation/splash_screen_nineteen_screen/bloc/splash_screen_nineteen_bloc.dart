import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application4/presentation/splash_screen_nineteen_screen/models/splash_screen_nineteen_model.dart';
part 'splash_screen_nineteen_event.dart';
part 'splash_screen_nineteen_state.dart';

class SplashScreenNineteenBloc
    extends Bloc<SplashScreenNineteenEvent, SplashScreenNineteenState> {
  SplashScreenNineteenBloc(SplashScreenNineteenState initialState)
      : super(initialState) {
    on<SplashScreenNineteenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenNineteenInitialEvent event,
    Emitter<SplashScreenNineteenState> emit,
  ) async {}
}
