// ignore_for_file: must_be_immutable

part of 'splash_screen_nineteen_bloc.dart';

@immutable
abstract class SplashScreenNineteenEvent extends Equatable {}

class SplashScreenNineteenInitialEvent extends SplashScreenNineteenEvent {
  @override
  List<Object?> get props => [];
}
