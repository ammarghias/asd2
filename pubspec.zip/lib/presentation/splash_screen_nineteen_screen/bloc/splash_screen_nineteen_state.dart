// ignore_for_file: must_be_immutable

part of 'splash_screen_nineteen_bloc.dart';

class SplashScreenNineteenState extends Equatable {
  SplashScreenNineteenState({this.splashScreenNineteenModelObj});

  SplashScreenNineteenModel? splashScreenNineteenModelObj;

  @override
  List<Object?> get props => [
        splashScreenNineteenModelObj,
      ];
  SplashScreenNineteenState copyWith(
      {SplashScreenNineteenModel? splashScreenNineteenModelObj}) {
    return SplashScreenNineteenState(
      splashScreenNineteenModelObj:
          splashScreenNineteenModelObj ?? this.splashScreenNineteenModelObj,
    );
  }
}
