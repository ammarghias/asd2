import 'bloc/splash_screen_nineteen_bloc.dart';
import 'models/splash_screen_nineteen_model.dart';
import 'package:ammar_s_application4/core/app_export.dart';
import 'package:ammar_s_application4/presentation/home_page/home_page.dart';
import 'package:ammar_s_application4/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application4/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class SplashScreenNineteenScreen extends StatelessWidget {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<SplashScreenNineteenBloc>(
      create: (context) => SplashScreenNineteenBloc(SplashScreenNineteenState(
        splashScreenNineteenModelObj: SplashScreenNineteenModel(),
      ))
        ..add(SplashScreenNineteenInitialEvent()),
      child: SplashScreenNineteenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenNineteenBloc, SplashScreenNineteenState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: double.maxFinite,
              padding: getPadding(
                top: 25,
                bottom: 25,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      top: 22,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        CustomAppBar(
                          height: getVerticalSize(
                            48,
                          ),
                          centerTitle: true,
                          title: Container(
                            height: getVerticalSize(
                              48,
                            ),
                            width: getHorizontalSize(
                              276,
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                AppbarImage(
                                  height: getVerticalSize(
                                    47,
                                  ),
                                  width: getHorizontalSize(
                                    276,
                                  ),
                                  svgPath:
                                      ImageConstant.imgGroupWhiteA70047x276,
                                ),
                                AppbarImage(
                                  height: getVerticalSize(
                                    48,
                                  ),
                                  width: getHorizontalSize(
                                    44,
                                  ),
                                  svgPath: ImageConstant.imgFrame,
                                  margin: getMargin(
                                    left: 31,
                                    right: 201,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          actions: [
                            AppbarImage(
                              height: getVerticalSize(
                                48,
                              ),
                              width: getHorizontalSize(
                                44,
                              ),
                              svgPath: ImageConstant.imgFrame,
                              margin: getMargin(
                                left: 123,
                                right: 123,
                              ),
                            ),
                          ],
                        ),
                        Container(
                          width: getHorizontalSize(
                            195,
                          ),
                          margin: getMargin(
                            top: 44,
                          ),
                          child: Text(
                            "msg_thank_you_welcome".tr,
                            maxLines: null,
                            textAlign: TextAlign.center,
                            style: AppStyle.txtStaatlichesRegular50Pink700,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            top: 11,
                          ),
                          child: Text(
                            "msg_where_your_success".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtImprimaRegular20,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            top: 18,
                          ),
                          child: Text(
                            "msg_follow_us_for_all2".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: AppStyle.txtJockeyOneRegular30.copyWith(
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      340,
                    ),
                    width: double.maxFinite,
                    padding: getPadding(
                      left: 6,
                      right: 6,
                    ),
                    child: Stack(
                      alignment: Alignment.topCenter,
                      children: [
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            height: getVerticalSize(
                              172,
                            ),
                            width: getHorizontalSize(
                              323,
                            ),
                            margin: getMargin(
                              top: 43,
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.whiteA700,
                              borderRadius: BorderRadius.circular(
                                getHorizontalSize(
                                  15,
                                ),
                              ),
                              border: Border.all(
                                color: ColorConstant.black900,
                                width: getHorizontalSize(
                                  1,
                                ),
                                strokeAlign: strokeAlignOutside,
                              ),
                            ),
                          ),
                        ),
                        CustomImageView(
                          imagePath: ImageConstant.imgEllipse1561x377,
                          height: getVerticalSize(
                            561,
                          ),
                          width: getHorizontalSize(
                            377,
                          ),
                          alignment: Alignment.topCenter,
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            height: getVerticalSize(
                              173,
                            ),
                            width: getHorizontalSize(
                              377,
                            ),
                            margin: getMargin(
                              bottom: 4,
                            ),
                            child: Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgEllipse2,
                                  height: getVerticalSize(
                                    173,
                                  ),
                                  width: getHorizontalSize(
                                    377,
                                  ),
                                  alignment: Alignment.center,
                                ),
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Container(
                                    width: getHorizontalSize(
                                      298,
                                    ),
                                    margin: getMargin(
                                      bottom: 34,
                                    ),
                                    child: RichText(
                                      text: TextSpan(
                                        children: [
                                          TextSpan(
                                            text: "msg_save_up_to_791_972".tr,
                                            style: TextStyle(
                                              color: ColorConstant.whiteA700,
                                              fontSize: getFontSize(
                                                23,
                                              ),
                                              fontFamily: 'Imprima',
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                          TextSpan(
                                            text: "lbl_referrals".tr,
                                            style: TextStyle(
                                              color: ColorConstant.whiteA700,
                                              fontSize: getFontSize(
                                                23,
                                              ),
                                              fontFamily: 'Imprima',
                                              fontWeight: FontWeight.w400,
                                              decoration:
                                                  TextDecoration.underline,
                                            ),
                                          ),
                                        ],
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            margin: getMargin(
                              left: 30,
                              top: 39,
                              right: 19,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 2,
                              right: 3,
                              bottom: 2,
                            ),
                            decoration: AppDecoration.outlinePink7008.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder15,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                  width: double.maxFinite,
                                  child: Container(
                                    padding: getPadding(
                                      left: 23,
                                      top: 21,
                                      right: 23,
                                      bottom: 21,
                                    ),
                                    decoration:
                                        AppDecoration.outlinePink7006.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder15,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        RatingBar.builder(
                                          initialRating: 5,
                                          minRating: 0,
                                          direction: Axis.horizontal,
                                          allowHalfRating: false,
                                          itemSize: getVerticalSize(
                                            40,
                                          ),
                                          itemCount: 5,
                                          updateOnDrag: true,
                                          onRatingUpdate: (rating) {},
                                          itemBuilder: (context, _) {
                                            return Icon(
                                              Icons.star,
                                            );
                                          },
                                        ),
                                        Container(
                                          width: getHorizontalSize(
                                            225,
                                          ),
                                          margin: getMargin(
                                            left: 23,
                                            top: 10,
                                            right: 28,
                                            bottom: 9,
                                          ),
                                          child: RichText(
                                            text: TextSpan(
                                              children: [
                                                TextSpan(
                                                  text:
                                                      "msg_rate_your_experience"
                                                          .tr,
                                                  style: TextStyle(
                                                    color:
                                                        ColorConstant.gray80004,
                                                    fontSize: getFontSize(
                                                      21,
                                                    ),
                                                    fontFamily: 'Inter',
                                                    fontWeight: FontWeight.w400,
                                                    decoration: TextDecoration
                                                        .underline,
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: "\n".tr,
                                                  style: TextStyle(
                                                    color:
                                                        ColorConstant.gray80004,
                                                    fontSize: getFontSize(
                                                      14,
                                                    ),
                                                    fontFamily: 'Inter',
                                                    fontWeight: FontWeight.w400,
                                                    decoration: TextDecoration
                                                        .underline,
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: "msg_feedback_makes_us"
                                                      .tr,
                                                  style: TextStyle(
                                                    color:
                                                        ColorConstant.gray80004,
                                                    fontSize: getFontSize(
                                                      18,
                                                    ),
                                                    fontFamily: 'Inter',
                                                    fontWeight: FontWeight.w400,
                                                    decoration: TextDecoration
                                                        .underline,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group1:
        return AppRoutes.homePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(BuildContext context, String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
