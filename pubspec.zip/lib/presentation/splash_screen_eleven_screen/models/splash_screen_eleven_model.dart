import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class SplashScreenElevenModel extends Equatable {SplashScreenElevenModel copyWith() { return SplashScreenElevenModel(
); } 
@override List<Object?> get props => [];
 }
