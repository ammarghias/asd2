// ignore_for_file: must_be_immutable

part of 'splash_screen_eleven_bloc.dart';

@immutable
abstract class SplashScreenElevenEvent extends Equatable {}

class SplashScreenElevenInitialEvent extends SplashScreenElevenEvent {
  @override
  List<Object?> get props => [];
}
