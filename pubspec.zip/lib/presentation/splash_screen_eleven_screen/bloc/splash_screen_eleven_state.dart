// ignore_for_file: must_be_immutable

part of 'splash_screen_eleven_bloc.dart';

class SplashScreenElevenState extends Equatable {
  SplashScreenElevenState({this.splashScreenElevenModelObj});

  SplashScreenElevenModel? splashScreenElevenModelObj;

  @override
  List<Object?> get props => [
        splashScreenElevenModelObj,
      ];
  SplashScreenElevenState copyWith(
      {SplashScreenElevenModel? splashScreenElevenModelObj}) {
    return SplashScreenElevenState(
      splashScreenElevenModelObj:
          splashScreenElevenModelObj ?? this.splashScreenElevenModelObj,
    );
  }
}
