import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application4/presentation/splash_screen_eleven_screen/models/splash_screen_eleven_model.dart';
part 'splash_screen_eleven_event.dart';
part 'splash_screen_eleven_state.dart';

class SplashScreenElevenBloc
    extends Bloc<SplashScreenElevenEvent, SplashScreenElevenState> {
  SplashScreenElevenBloc(SplashScreenElevenState initialState)
      : super(initialState) {
    on<SplashScreenElevenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenElevenInitialEvent event,
    Emitter<SplashScreenElevenState> emit,
  ) async {}
}
