import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color black9007e = fromHex('#7e000000');

  static Color gray5001 = fromHex('#fffbfb');

  static Color pink7007e = fromHex('#7ec41f49');

  static Color whiteA700F7 = fromHex('#f7ffffff');

  static Color red800 = fromHex('#be3a2b');

  static Color black90090 = fromHex('#90000000');

  static Color gray80002 = fromHex('#4a4647');

  static Color pink70002 = fromHex('#c22345');

  static Color pink70001 = fromHex('#c41f49');

  static Color gray80001 = fromHex('#66391b');

  static Color black90087 = fromHex('#87000000');

  static Color yellowA400 = fromHex('#fff400');

  static Color blueGray900 = fromHex('#343434');

  static Color gray400 = fromHex('#aeaeae');

  static Color blueGray100 = fromHex('#d9d9d9');

  static Color amber500 = fromHex('#eaba0e');

  static Color gray800 = fromHex('#474747');

  static Color orange200 = fromHex('#ffc670');

  static Color cyan200 = fromHex('#82d4df');

  static Color black90099 = fromHex('#99000000');

  static Color indigoA700 = fromHex('#2f41db');

  static Color black90095 = fromHex('#95000000');

  static Color lime50 = fromHex('#fbffec');

  static Color gray70087 = fromHex('#87595959');

  static Color gray70002 = fromHex('#5f5f5f');

  static Color gray70003 = fromHex('#686868');

  static Color gray70001 = fromHex('#646464');

  static Color blueGray50 = fromHex('#f1f1f1');

  static Color red700 = fromHex('#cd322a');

  static Color blueGray10001 = fromHex('#cfcfcf');

  static Color blueGray10002 = fromHex('#cccccc');

  static Color yellow5001 = fromHex('#fffddf');

  static Color blueGray10003 = fromHex('#d4d4d4');

  static Color blueGray10004 = fromHex('#cfcdcd');

  static Color blueGray10005 = fromHex('#d5d5d5');

  static Color green600 = fromHex('#4fa930');

  static Color gray50 = fromHex('#f8f8f8');

  static Color red50 = fromHex('#ffeff3');

  static Color whiteA700Cc = fromHex('#ccffffff');

  static Color black90066 = fromHex('#66000000');

  static Color lightGreen500 = fromHex('#91c83d');

  static Color gray50001 = fromHex('#a1a1a1');

  static Color purpleA700 = fromHex('#9700de');

  static Color yellow900 = fromHex('#e1712c');

  static Color gray50003 = fromHex('#a7a7a7');

  static Color gray50002 = fromHex('#a6a6a6');

  static Color gray50005 = fromHex('#9c9c9c');

  static Color deepOrange400 = fromHex('#df7f47');

  static Color gray50004 = fromHex('#adadad');

  static Color gray50007 = fromHex('#9a9a9a');

  static Color gray50006 = fromHex('#9b9b9b');

  static Color blueGray40099 = fromHex('#998d8d8d');

  static Color gray50008 = fromHex('#8f8f8f');

  static Color gray500 = fromHex('#9e9e9e');

  static Color gray900 = fromHex('#1b1b1b');

  static Color black900A7 = fromHex('#a7000000');

  static Color pink90033 = fromHex('#33681127');

  static Color gray100 = fromHex('#f7f7f7');

  static Color pink70090 = fromHex('#90c41f49');

  static Color black90075 = fromHex('#75000000');

  static Color lime80019 = fromHex('#19bb6f3b');

  static Color pink7007f = fromHex('#7fc41f49');

  static Color purple6006c = fromHex('#6c93288a');

  static Color whiteA7007e = fromHex('#7effffff');

  static Color green70090 = fromHex('#90189c3d');

  static Color green900 = fromHex('#00800c');

  static Color black9003f = fromHex('#3f000000');

  static Color green500 = fromHex('#4ca655');

  static Color whiteA70099 = fromHex('#99ffffff');

  static Color teal300 = fromHex('#4593c0');

  static Color indigoA70001 = fromHex('#2f40da');

  static Color cyan80001 = fromHex('#1877a1');

  static Color lightGreen800 = fromHex('#676b33');

  static Color pink700 = fromHex('#c41f4a');

  static Color gray20001 = fromHex('#ebebeb');

  static Color deepOrange300 = fromHex('#dd905c');

  static Color gray20002 = fromHex('#ececec');

  static Color blueGray700 = fromHex('#525252');

  static Color green90099 = fromHex('#9900800c');

  static Color gray20000 = fromHex('#00ececec');

  static Color pink300 = fromHex('#f97294');

  static Color redA700 = fromHex('#ff0000');

  static Color gray600 = fromHex('#7e7e7e');

  static Color yellow50 = fromHex('#fff6e8');

  static Color gray4007f = fromHex('#7faeaeae');

  static Color red5001 = fromHex('#fff3f3');

  static Color gray200 = fromHex('#e7e7e7');

  static Color yellowA700 = fromHex('#f2da00');

  static Color gray40009 = fromHex('#c3bebe');

  static Color lime100 = fromHex('#e8ffc3');

  static Color gray40005 = fromHex('#c3c3c3');

  static Color gray40006 = fromHex('#afafaf');

  static Color gray10002 = fromHex('#f2f2f2');

  static Color gray40007 = fromHex('#b4b4b4');

  static Color red80001 = fromHex('#c72c33');

  static Color gray40008 = fromHex('#b9b9b9');

  static Color gray40001 = fromHex('#bdbdbd');

  static Color gray40002 = fromHex('#c9c9c9');

  static Color gray10001 = fromHex('#f3f3f3');

  static Color gray40003 = fromHex('#c3bdbd');

  static Color gray10000 = fromHex('#00f7f7f7');

  static Color gray40004 = fromHex('#c4c4c4');

  static Color gray40087 = fromHex('#87aeaeae');

  static Color cyan80019 = fromHex('#191878a1');

  static Color cyan800 = fromHex('#1878a1');

  static Color blueGray40001 = fromHex('#888888');

  static Color whiteA700 = fromHex('#ffffff');

  static Color gray60099 = fromHex('#997c7c7c');

  static Color gray60010 = fromHex('#747474');

  static Color yellow70019 = fromHex('#19f2b32f');

  static Color pink70066 = fromHex('#66c41f49');

  static Color red100 = fromHex('#f5d0d9');

  static Color black900 = fromHex('#000000');

  static Color yellow700 = fromHex('#f2b32f');

  static Color blueGray800 = fromHex('#384758');

  static Color black90026 = fromHex('#26000000');

  static Color gray90002 = fromHex('#252525');

  static Color gray60087 = fromHex('#877e7e7e');

  static Color gray700 = fromHex('#616161');

  static Color gray90003 = fromHex('#252424');

  static Color gray60002 = fromHex('#7b7b7b');

  static Color lime400 = fromHex('#d2e754');

  static Color gray60001 = fromHex('#838383');

  static Color blueGray400 = fromHex('#8d8d8d');

  static Color pinkA20066 = fromHex('#66ff4e7b');

  static Color lime800 = fromHex('#bb6f3b');

  static Color gray90001 = fromHex('#1e1e1e');

  static Color gray60008 = fromHex('#757474');

  static Color gray60007 = fromHex('#808080');

  static Color gray60009 = fromHex('#6d6d6d');

  static Color gray60004 = fromHex('#6f6f6f');

  static Color gray300 = fromHex('#dbdbdb');

  static Color gray60003 = fromHex('#6e6e6e');

  static Color gray30002 = fromHex('#e2e2e2');

  static Color gray30001 = fromHex('#e6dbd4');

  static Color gray60006 = fromHex('#7c7c7c');

  static Color gray60005 = fromHex('#848484');

  static Color black90033 = fromHex('#33000000');

  static Color whiteA70001 = fromHex('#fffbff');

  static Color indigo500 = fromHex('#3171ad');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
