class ImageConstant {
  static String imgRectangle619 = 'assets/images/img_rectangle619.png';

  static String imgGroup17 = 'assets/images/img_group_17.svg';

  static String imgImage732 = 'assets/images/img_image73_2.png';

  static String imgTelevision = 'assets/images/img_television.svg';

  static String imgGroup1225 = 'assets/images/img_group1225.png';

  static String imgImage6756x68 = 'assets/images/img_image67_56x68.png';

  static String imgStar25 = 'assets/images/img_star2_5.svg';

  static String imgGroupPink70001 = 'assets/images/img_group_pink_700_01.svg';

  static String imgCar = 'assets/images/img_car.svg';

  static String imgEllipse26 = 'assets/images/img_ellipse26.png';

  static String imgPullcreditcard = 'assets/images/img_pullcreditcard.png';

  static String imgGroupWhiteA7009x1 =
      'assets/images/img_group_white_a700_9x1.png';

  static String imgImage72 = 'assets/images/img_image72.png';

  static String imgGroupWhiteA700 = 'assets/images/img_group_white_a700.svg';

  static String imgEllipse27 = 'assets/images/img_ellipse27.png';

  static String imgEllipse25 = 'assets/images/img_ellipse25.png';

  static String imgStar27 = 'assets/images/img_star2_7.svg';

  static String imgRefresh = 'assets/images/img_refresh.svg';

  static String imgOffer = 'assets/images/img_offer.png';

  static String imgBag = 'assets/images/img_bag.svg';

  static String imgImage7263x93 = 'assets/images/img_image72_63x93.png';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgSettingsWhiteA7009x8 =
      'assets/images/img_settings_white_a700_9x8.svg';

  static String imgEllipse12 = 'assets/images/img_ellipse1_2.png';

  static String imgStar21 = 'assets/images/img_star2_1.svg';

  static String imgImage70 = 'assets/images/img_image70.png';

  static String imgImage7757x60 = 'assets/images/img_image77_57x60.png';

  static String imgIconsaxLinearLocation =
      'assets/images/img_iconsax_linear_location.svg';

  static String imgStar28 = 'assets/images/img_star2_8.svg';

  static String imgGroup1 = 'assets/images/img_group_1.svg';

  static String imgImage7053x65 = 'assets/images/img_image70_53x65.png';

  static String imgCutPink10044x42 = 'assets/images/img_cut_pink_100_44x42.png';

  static String imgGroup6 = 'assets/images/img_group6.png';

  static String imgSignalWhiteA700 = 'assets/images/img_signal_white_a700.svg';

  static String imgVector203x243 = 'assets/images/img_vector_203x243.png';

  static String imgImage66 = 'assets/images/img_image66.png';

  static String imgStar2 = 'assets/images/img_star2.svg';

  static String imgImage739 = 'assets/images/img_image73_9.png';

  static String imgImage65 = 'assets/images/img_image65.png';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgGroup581 = 'assets/images/img_group581.png';

  static String imgGroupPink7000147x279 =
      'assets/images/img_group_pink_700_01_47x279.svg';

  static String imgVolumeWhiteA700 = 'assets/images/img_volume_white_a700.svg';

  static String imgPasswordIcon = 'assets/images/img_password_icon.svg';

  static String imgEllipse23 = 'assets/images/img_ellipse23.png';

  static String imgGroup26x27 = 'assets/images/img_group_26x27.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgVectorWhiteA7007x4 =
      'assets/images/img_vector_white_a700_7x4.svg';

  static String imgGroupAmber300 = 'assets/images/img_group_amber_300.svg';

  static String imgGroup19 = 'assets/images/img_group_19.svg';

  static String imgRectangle69463x125 =
      'assets/images/img_rectangle694_63x125.png';

  static String imgEdit = 'assets/images/img_edit.png';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgGroupWhiteA7004x37 =
      'assets/images/img_group_white_a700_4x37.svg';

  static String imgIconcall = 'assets/images/img_iconcall.svg';

  static String imgImage76 = 'assets/images/img_image76.png';

  static String imgAirplane = 'assets/images/img_airplane.svg';

  static String imgMobileBlueGray40001 =
      'assets/images/img_mobile_blue_gray_400_01.svg';

  static String imgGroup56 = 'assets/images/img_group56.png';

  static String imgVectorWhiteA700 = 'assets/images/img_vector_white_a700.svg';

  static String imgImage7357x68 = 'assets/images/img_image73_57x68.png';

  static String imgPullcategorylogo1 =
      'assets/images/img_pullcategorylogo_1.png';

  static String imgGroup10 = 'assets/images/img_group_10.svg';

  static String imgVectorWhiteA7006x4 =
      'assets/images/img_vector_white_a700_6x4.svg';

  static String imgClockPink70001 = 'assets/images/img_clock_pink_700_01.svg';

  static String imgGroup7 = 'assets/images/img_group7.png';

  static String imgPullcategorylogo3 =
      'assets/images/img_pullcategorylogo_3.png';

  static String imgImage7312 = 'assets/images/img_image73_12.png';

  static String imgSignalPink70001 = 'assets/images/img_signal_pink_700_01.svg';

  static String imgPullcreditcard2 = 'assets/images/img_pullcreditcard_2.png';

  static String imgImage7370x93 = 'assets/images/img_image73_70x93.png';

  static String imgFrame38 = 'assets/images/img_frame38.png';

  static String imgButtonProfileStatedefault =
      'assets/images/img_button_profile_statedefault.svg';

  static String imgGroup20 = 'assets/images/img_group20.svg';

  static String imgEllipse13 = 'assets/images/img_ellipse1_3.png';

  static String imgGroupWhiteA7005x12 =
      'assets/images/img_group_white_a700_5x12.svg';

  static String imgGroup11 = 'assets/images/img_group_11.svg';

  static String imgGroup8 = 'assets/images/img_group8.svg';

  static String imgFrame69 = 'assets/images/img_frame69.svg';

  static String imgFileWhiteA700 = 'assets/images/img_file_white_a700.svg';

  static String imgImage7840x43 = 'assets/images/img_image78_40x43.png';

  static String imgImage734 = 'assets/images/img_image73_4.png';

  static String imgGroup15 = 'assets/images/img_group_15.svg';

  static String imgFrame = 'assets/images/img_frame.svg';

  static String imgCutWhiteA700 = 'assets/images/img_cut_white_a700.svg';

  static String imgGroup12 = 'assets/images/img_group_12.svg';

  static String imgStar26 = 'assets/images/img_star2_6.svg';

  static String imgVector19x21 = 'assets/images/img_vector_19x21.png';

  static String imgPullcreditcard34x60 =
      'assets/images/img_pullcreditcard_34x60.png';

  static String imgImage82 = 'assets/images/img_image82.png';

  static String imgImage735 = 'assets/images/img_image73_5.png';

  static String imgImage7575x72 = 'assets/images/img_image75_75x72.png';

  static String imgImage7270x89 = 'assets/images/img_image72_70x89.png';

  static String imgVector232x66 = 'assets/images/img_vector_232x66.png';

  static String imgImage78 = 'assets/images/img_image78.png';

  static String imgPullcategorylogo = 'assets/images/img_pullcategorylogo.png';

  static String imgGroup14 = 'assets/images/img_group_14.svg';

  static String imgRectangle598 = 'assets/images/img_rectangle598.svg';

  static String imgRectangle601 = 'assets/images/img_rectangle601.png';

  static String imgImage7258x93 = 'assets/images/img_image72_58x93.png';

  static String imgGroupWhiteA70029x180 =
      'assets/images/img_group_white_a700_29x180.svg';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgGroupWhiteA7002x17 =
      'assets/images/img_group_white_a700_2x17.svg';

  static String imgGroup63 = 'assets/images/img_group63.svg';

  static String imgVector20x20 = 'assets/images/img_vector_20x20.png';

  static String imgFrame45 = 'assets/images/img_frame45.svg';

  static String imgGroupWhiteA7005x5 =
      'assets/images/img_group_white_a700_5x5.svg';

  static String imgCloseLime800 = 'assets/images/img_close_lime_800.svg';

  static String imgGroup = 'assets/images/img_group.svg';

  static String imgGroupWhiteA70028x22 =
      'assets/images/img_group_white_a700_28x22.svg';

  static String imgLocationPink100 = 'assets/images/img_location_pink_100.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgGroup3 = 'assets/images/img_group_3.svg';

  static String imgVolumeWhiteA7009x7 =
      'assets/images/img_volume_white_a700_9x7.png';

  static String imgTicketAmber300 = 'assets/images/img_ticket_amber_300.svg';

  static String imgVector29x33 = 'assets/images/img_vector_29x33.png';

  static String imgGroup5 = 'assets/images/img_group_5.svg';

  static String imgGroupWhiteA7006x5 =
      'assets/images/img_group_white_a700_6x5.svg';

  static String imgStar29 = 'assets/images/img_star2_9.svg';

  static String imgComputer = 'assets/images/img_computer.png';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgEllipse11 = 'assets/images/img_ellipse1_1.png';

  static String imgGroupPink700 = 'assets/images/img_group_pink_700.svg';

  static String imgRewind = 'assets/images/img_rewind.svg';

  static String imgImage7631x58 = 'assets/images/img_image76_31x58.png';

  static String imgGroupAmber300365x365 =
      'assets/images/img_group_amber_300_365x365.png';

  static String imgImage738 = 'assets/images/img_image73_8.png';

  static String imgGroupWhiteA7002x27 =
      'assets/images/img_group_white_a700_2x27.svg';

  static String imgUpload = 'assets/images/img_upload.svg';

  static String imgEllipse1844x380 = 'assets/images/img_ellipse1_844x380.png';

  static String imgMap = 'assets/images/img_map.svg';

  static String imgRewindWhiteA700 = 'assets/images/img_rewind_white_a700.svg';

  static String imgImage7313 = 'assets/images/img_image73_13.png';

  static String imgPullcategorylogo75x74 =
      'assets/images/img_pullcategorylogo_75x74.png';

  static String imgImage7310 = 'assets/images/img_image73_10.png';

  static String imgGroup13 = 'assets/images/img_group_13.svg';

  static String imgStar225x26 = 'assets/images/img_star2_25x26.svg';

  static String imgSettingsWhiteA700 =
      'assets/images/img_settings_white_a700.svg';

  static String imgVector46x41 = 'assets/images/img_vector_46x41.png';

  static String imgMobile = 'assets/images/img_mobile.svg';

  static String imgGroup4 = 'assets/images/img_group_4.svg';

  static String imgLoginheadercontainer =
      'assets/images/img_loginheadercontainer.png';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgGroupWhiteA7004x13 =
      'assets/images/img_group_white_a700_4x13.svg';

  static String imgCutPink100 = 'assets/images/img_cut_pink_100.svg';

  static String imgSelectButton = 'assets/images/img_select_button.svg';

  static String imgImage7342x45 = 'assets/images/img_image73_42x45.png';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgImage7445x45 = 'assets/images/img_image74_45x45.png';

  static String imgGroupWhiteA70010x8 =
      'assets/images/img_group_white_a700_10x8.png';

  static String imgImage67 = 'assets/images/img_image67.png';

  static String imgStar325x26 = 'assets/images/img_star3_25x26.svg';

  static String imgButtonhomepage = 'assets/images/img_buttonhomepage.svg';

  static String imgButtonnotificationWhiteA700 =
      'assets/images/img_buttonnotification_white_a700.svg';

  static String imgFrame68 = 'assets/images/img_frame68.svg';

  static String imgUploadWhiteA700 = 'assets/images/img_upload_white_a700.png';

  static String imgStar22 = 'assets/images/img_star2_2.svg';

  static String imgCut = 'assets/images/img_cut.svg';

  static String imgPullcreditcard1 = 'assets/images/img_pullcreditcard_1.png';

  static String imgCall = 'assets/images/img_call.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgGroup386x390 = 'assets/images/img_group_386x390.png';

  static String imgImage733 = 'assets/images/img_image73_3.png';

  static String imgPullcategorylogo2 =
      'assets/images/img_pullcategorylogo_2.png';

  static String imgLogo = 'assets/images/img_logo.svg';

  static String imgEllipse1 = 'assets/images/img_ellipse1.png';

  static String imgImage77 = 'assets/images/img_image77.png';

  static String imgPhoneiconGray800 =
      'assets/images/img_phoneicon_gray_800.svg';

  static String imgHeader = 'assets/images/img_header.svg';

  static String imgPullcreditcard3 = 'assets/images/img_pullcreditcard_3.png';

  static String imgGroup16 = 'assets/images/img_group_16.svg';

  static String imgStar210 = 'assets/images/img_star2_10.svg';

  static String imgLocationWhiteA700 =
      'assets/images/img_location_white_a700.svg';

  static String imgGroup18 = 'assets/images/img_group_18.svg';

  static String imgGroup9 = 'assets/images/img_group9.png';

  static String imgFrame212 = 'assets/images/img_frame212.png';

  static String imgVector49x47 = 'assets/images/img_vector_49x47.png';

  static String imgImage64 = 'assets/images/img_image64.png';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgEllipse22 = 'assets/images/img_ellipse22.png';

  static String imgImage736 = 'assets/images/img_image73_6.png';

  static String imgVector203x170 = 'assets/images/img_vector_203x170.png';

  static String imgVolumeWhiteA70034x19 =
      'assets/images/img_volume_white_a700_34x19.png';

  static String imgGroupWhiteA7003x29 =
      'assets/images/img_group_white_a700_3x29.svg';

  static String imgImage73 = 'assets/images/img_image73.png';

  static String imgVolumeWhiteA70035x28 =
      'assets/images/img_volume_white_a700_35x28.svg';

  static String imgRectangle3 = 'assets/images/img_rectangle_3.svg';

  static String imgImage7311 = 'assets/images/img_image73_11.png';

  static String imgStar24 = 'assets/images/img_star2_4.svg';

  static String imgGroupWhiteA70010x5 =
      'assets/images/img_group_white_a700_10x5.png';

  static String imgQuestion = 'assets/images/img_question.svg';

  static String imgFrame70 = 'assets/images/img_frame70.png';

  static String imgVector75x94 = 'assets/images/img_vector_75x94.png';

  static String imgImage87 = 'assets/images/img_image87.png';

  static String imgImage7270x93 = 'assets/images/img_image72_70x93.png';

  static String imgGroup2 = 'assets/images/img_group_2.svg';

  static String imgImage737 = 'assets/images/img_image73_7.png';

  static String imgImage75 = 'assets/images/img_image75.png';

  static String imgRewindBlueGray400 =
      'assets/images/img_rewind_blue_gray_400.svg';

  static String imgVectorWhiteA7009x1 =
      'assets/images/img_vector_white_a700_9x1.png';

  static String imgGroupWhiteA700110x158 =
      'assets/images/img_group_white_a700_110x158.svg';

  static String imgGroup1285 = 'assets/images/img_group1285.png';

  static String imgEllipse24 = 'assets/images/img_ellipse24.png';

  static String imgImage6755x59 = 'assets/images/img_image67_55x59.png';

  static String imgStar23 = 'assets/images/img_star2_3.svg';

  static String imgGroupAmber3005x6 =
      'assets/images/img_group_amber_300_5x6.svg';

  static String imgStar3 = 'assets/images/img_star3.svg';

  static String imgGroupWhiteA700108x164 =
      'assets/images/img_group_white_a700_108x164.svg';

  static String imgPhoneicon = 'assets/images/img_phoneicon.svg';

  static String imgVector337x198 = 'assets/images/img_vector_337x198.png';

  static String imgGroupWhiteA70047x276 =
      'assets/images/img_group_white_a700_47x276.svg';

  static String imgButtonnotification =
      'assets/images/img_buttonnotification.svg';

  static String imgEllipse1844x390 = 'assets/images/img_ellipse1_844x390.png';

  static String imgPullmerchantlogo = 'assets/images/img_pullmerchantlogo.png';

  static String imgImage74 = 'assets/images/img_image74.png';

  static String imgCutPink10021x38 = 'assets/images/img_cut_pink_100_21x38.png';

  static String imgImage731 = 'assets/images/img_image73_1.png';

  static String imgGroup27x27 = 'assets/images/img_group_27x27.svg';

  static String imgLocationAmber300 =
      'assets/images/img_location_amber_300.svg';

  static String imgRectangle694 = 'assets/images/img_rectangle694.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
