/// This class is used in the [featured_one_item_widget] screen.
class FeaturedOneItemModel {String emailaddressTxt = "Net Income";

String emailaddressTxt1 = "Per year, Pre-tax";

String? id = "";

 }
