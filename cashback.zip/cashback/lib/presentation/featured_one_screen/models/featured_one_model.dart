// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';import 'featured_one_item_model.dart';/// This class defines the variables used in the [featured_one_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class FeaturedOneModel extends Equatable {FeaturedOneModel({this.featuredOneItemList = const []});

List<FeaturedOneItemModel> featuredOneItemList;

FeaturedOneModel copyWith({List<FeaturedOneItemModel>? featuredOneItemList}) { return FeaturedOneModel(
featuredOneItemList : featuredOneItemList ?? this.featuredOneItemList,
); } 
@override List<Object?> get props => [featuredOneItemList];
 }
