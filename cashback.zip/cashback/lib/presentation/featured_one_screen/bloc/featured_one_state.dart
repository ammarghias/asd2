// ignore_for_file: must_be_immutable

part of 'featured_one_bloc.dart';

/// Represents the state of FeaturedOne in the application.
class FeaturedOneState extends Equatable {
  FeaturedOneState({
    this.group500Controller,
    this.group502Controller,
    this.emailController,
    this.mobilenoController,
    this.group508Controller,
    this.zipcodeController,
    this.featuredOneModelObj,
  });

  TextEditingController? group500Controller;

  TextEditingController? group502Controller;

  TextEditingController? emailController;

  TextEditingController? mobilenoController;

  TextEditingController? group508Controller;

  TextEditingController? zipcodeController;

  FeaturedOneModel? featuredOneModelObj;

  @override
  List<Object?> get props => [
        group500Controller,
        group502Controller,
        emailController,
        mobilenoController,
        group508Controller,
        zipcodeController,
        featuredOneModelObj,
      ];
  FeaturedOneState copyWith({
    TextEditingController? group500Controller,
    TextEditingController? group502Controller,
    TextEditingController? emailController,
    TextEditingController? mobilenoController,
    TextEditingController? group508Controller,
    TextEditingController? zipcodeController,
    FeaturedOneModel? featuredOneModelObj,
  }) {
    return FeaturedOneState(
      group500Controller: group500Controller ?? this.group500Controller,
      group502Controller: group502Controller ?? this.group502Controller,
      emailController: emailController ?? this.emailController,
      mobilenoController: mobilenoController ?? this.mobilenoController,
      group508Controller: group508Controller ?? this.group508Controller,
      zipcodeController: zipcodeController ?? this.zipcodeController,
      featuredOneModelObj: featuredOneModelObj ?? this.featuredOneModelObj,
    );
  }
}
