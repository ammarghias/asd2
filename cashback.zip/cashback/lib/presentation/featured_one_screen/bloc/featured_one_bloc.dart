import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/featured_one_item_model.dart';
import 'package:ammar_s_application6/presentation/featured_one_screen/models/featured_one_model.dart';
part 'featured_one_event.dart';
part 'featured_one_state.dart';

/// A bloc that manages the state of a FeaturedOne according to the event that is dispatched to it.
class FeaturedOneBloc extends Bloc<FeaturedOneEvent, FeaturedOneState> {
  FeaturedOneBloc(FeaturedOneState initialState) : super(initialState) {
    on<FeaturedOneInitialEvent>(_onInitialize);
  }

  List<FeaturedOneItemModel> fillFeaturedOneItemList() {
    return List.generate(4, (index) => FeaturedOneItemModel());
  }

  _onInitialize(
    FeaturedOneInitialEvent event,
    Emitter<FeaturedOneState> emit,
  ) async {
    emit(state.copyWith(
      group500Controller: TextEditingController(),
      group502Controller: TextEditingController(),
      emailController: TextEditingController(),
      mobilenoController: TextEditingController(),
      group508Controller: TextEditingController(),
      zipcodeController: TextEditingController(),
    ));
    emit(state.copyWith(
        featuredOneModelObj: state.featuredOneModelObj?.copyWith(
      featuredOneItemList: fillFeaturedOneItemList(),
    )));
  }
}
