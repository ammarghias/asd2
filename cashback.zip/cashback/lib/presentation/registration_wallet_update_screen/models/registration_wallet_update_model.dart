// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [registration_wallet_update_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class RegistrationWalletUpdateModel extends Equatable {RegistrationWalletUpdateModel copyWith() { return RegistrationWalletUpdateModel(
); } 
@override List<Object?> get props => [];
 }
