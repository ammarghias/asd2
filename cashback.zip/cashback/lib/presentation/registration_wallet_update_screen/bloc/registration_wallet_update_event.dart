// ignore_for_file: must_be_immutable

part of 'registration_wallet_update_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///RegistrationWalletUpdate widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class RegistrationWalletUpdateEvent extends Equatable {}

/// Event that is dispatched when the RegistrationWalletUpdate widget is first created.
class RegistrationWalletUpdateInitialEvent
    extends RegistrationWalletUpdateEvent {
  @override
  List<Object?> get props => [];
}
