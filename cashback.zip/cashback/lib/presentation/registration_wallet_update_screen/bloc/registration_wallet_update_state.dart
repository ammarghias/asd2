// ignore_for_file: must_be_immutable

part of 'registration_wallet_update_bloc.dart';

/// Represents the state of RegistrationWalletUpdate in the application.
class RegistrationWalletUpdateState extends Equatable {
  RegistrationWalletUpdateState({this.registrationWalletUpdateModelObj});

  RegistrationWalletUpdateModel? registrationWalletUpdateModelObj;

  @override
  List<Object?> get props => [
        registrationWalletUpdateModelObj,
      ];
  RegistrationWalletUpdateState copyWith(
      {RegistrationWalletUpdateModel? registrationWalletUpdateModelObj}) {
    return RegistrationWalletUpdateState(
      registrationWalletUpdateModelObj: registrationWalletUpdateModelObj ??
          this.registrationWalletUpdateModelObj,
    );
  }
}
