// ignore_for_file: must_be_immutable

part of 'registration_one_bloc.dart';

/// Represents the state of RegistrationOne in the application.
class RegistrationOneState extends Equatable {
  RegistrationOneState({
    this.rectangle628Controller,
    this.group116Controller,
    this.group106Controller,
    this.group113Controller,
    this.group114Controller,
    this.registrationOneModelObj,
  });

  TextEditingController? rectangle628Controller;

  TextEditingController? group116Controller;

  TextEditingController? group106Controller;

  TextEditingController? group113Controller;

  TextEditingController? group114Controller;

  RegistrationOneModel? registrationOneModelObj;

  @override
  List<Object?> get props => [
        rectangle628Controller,
        group116Controller,
        group106Controller,
        group113Controller,
        group114Controller,
        registrationOneModelObj,
      ];
  RegistrationOneState copyWith({
    TextEditingController? rectangle628Controller,
    TextEditingController? group116Controller,
    TextEditingController? group106Controller,
    TextEditingController? group113Controller,
    TextEditingController? group114Controller,
    RegistrationOneModel? registrationOneModelObj,
  }) {
    return RegistrationOneState(
      rectangle628Controller:
          rectangle628Controller ?? this.rectangle628Controller,
      group116Controller: group116Controller ?? this.group116Controller,
      group106Controller: group106Controller ?? this.group106Controller,
      group113Controller: group113Controller ?? this.group113Controller,
      group114Controller: group114Controller ?? this.group114Controller,
      registrationOneModelObj:
          registrationOneModelObj ?? this.registrationOneModelObj,
    );
  }
}
