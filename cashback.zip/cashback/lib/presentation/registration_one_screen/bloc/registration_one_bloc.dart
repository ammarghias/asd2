import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application6/presentation/registration_one_screen/models/registration_one_model.dart';part 'registration_one_event.dart';part 'registration_one_state.dart';/// A bloc that manages the state of a RegistrationOne according to the event that is dispatched to it.
class RegistrationOneBloc extends Bloc<RegistrationOneEvent, RegistrationOneState> {RegistrationOneBloc(RegistrationOneState initialState) : super(initialState) { on<RegistrationOneInitialEvent>(_onInitialize); }

_onInitialize(RegistrationOneInitialEvent event, Emitter<RegistrationOneState> emit, ) async  { emit(state.copyWith(rectangle628Controller: TextEditingController(), group116Controller: TextEditingController(), group106Controller: TextEditingController(), group113Controller: TextEditingController(), group114Controller: TextEditingController())); } 
 }
