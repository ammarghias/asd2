// ignore_for_file: must_be_immutable

part of 'registration_terms_and_conditions_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///RegistrationTermsAndConditions widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class RegistrationTermsAndConditionsEvent extends Equatable {}

/// Event that is dispatched when the RegistrationTermsAndConditions widget is first created.
class RegistrationTermsAndConditionsInitialEvent
    extends RegistrationTermsAndConditionsEvent {
  @override
  List<Object?> get props => [];
}
