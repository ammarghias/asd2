import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application6/presentation/registration_terms_and_conditions_screen/models/registration_terms_and_conditions_model.dart';part 'registration_terms_and_conditions_event.dart';part 'registration_terms_and_conditions_state.dart';/// A bloc that manages the state of a RegistrationTermsAndConditions according to the event that is dispatched to it.
class RegistrationTermsAndConditionsBloc extends Bloc<RegistrationTermsAndConditionsEvent, RegistrationTermsAndConditionsState> {RegistrationTermsAndConditionsBloc(RegistrationTermsAndConditionsState initialState) : super(initialState) { on<RegistrationTermsAndConditionsInitialEvent>(_onInitialize); }

_onInitialize(RegistrationTermsAndConditionsInitialEvent event, Emitter<RegistrationTermsAndConditionsState> emit, ) async  {  } 
 }
