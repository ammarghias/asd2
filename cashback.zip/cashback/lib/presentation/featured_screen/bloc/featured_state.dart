// ignore_for_file: must_be_immutable

part of 'featured_bloc.dart';

/// Represents the state of Featured in the application.
class FeaturedState extends Equatable {
  FeaturedState({
    this.isSelectedSwitch = false,
    this.featuredModelObj,
  });

  FeaturedModel? featuredModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        isSelectedSwitch,
        featuredModelObj,
      ];
  FeaturedState copyWith({
    bool? isSelectedSwitch,
    FeaturedModel? featuredModelObj,
  }) {
    return FeaturedState(
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      featuredModelObj: featuredModelObj ?? this.featuredModelObj,
    );
  }
}
