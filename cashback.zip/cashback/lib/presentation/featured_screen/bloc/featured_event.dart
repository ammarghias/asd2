// ignore_for_file: must_be_immutable

part of 'featured_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///Featured widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class FeaturedEvent extends Equatable {}

/// Event that is dispatched when the Featured widget is first created.
class FeaturedInitialEvent extends FeaturedEvent {
  @override
  List<Object?> get props => [];
}

///Event for changing switch
class ChangeSwitchEvent extends FeaturedEvent {
  ChangeSwitchEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
