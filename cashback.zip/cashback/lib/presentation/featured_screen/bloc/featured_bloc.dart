import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/featured_screen/models/featured_model.dart';
part 'featured_event.dart';
part 'featured_state.dart';

/// A bloc that manages the state of a Featured according to the event that is dispatched to it.
class FeaturedBloc extends Bloc<FeaturedEvent, FeaturedState> {
  FeaturedBloc(FeaturedState initialState) : super(initialState) {
    on<FeaturedInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<FeaturedState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  _onInitialize(
    FeaturedInitialEvent event,
    Emitter<FeaturedState> emit,
  ) async {
    emit(state.copyWith(
      isSelectedSwitch: false,
    ));
  }
}
