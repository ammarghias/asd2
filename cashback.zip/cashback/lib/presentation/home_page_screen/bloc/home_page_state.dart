// ignore_for_file: must_be_immutable

part of 'home_page_bloc.dart';

/// Represents the state of HomePage in the application.
class HomePageState extends Equatable {
  HomePageState({
    this.isSelectedSwitch = false,
    this.homePageModelObj,
  });

  HomePageModel? homePageModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        isSelectedSwitch,
        homePageModelObj,
      ];
  HomePageState copyWith({
    bool? isSelectedSwitch,
    HomePageModel? homePageModelObj,
  }) {
    return HomePageState(
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      homePageModelObj: homePageModelObj ?? this.homePageModelObj,
    );
  }
}
