import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/home_page_item_model.dart';
import 'package:ammar_s_application6/presentation/home_page_screen/models/home_page_model.dart';
part 'home_page_event.dart';
part 'home_page_state.dart';

/// A bloc that manages the state of a HomePage according to the event that is dispatched to it.
class HomePageBloc extends Bloc<HomePageEvent, HomePageState> {
  HomePageBloc(HomePageState initialState) : super(initialState) {
    on<HomePageInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<HomePageState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<HomePageItemModel> fillHomePageItemList() {
    return List.generate(3, (index) => HomePageItemModel());
  }

  _onInitialize(
    HomePageInitialEvent event,
    Emitter<HomePageState> emit,
  ) async {
    emit(state.copyWith(
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        homePageModelObj: state.homePageModelObj?.copyWith(
      homePageItemList: fillHomePageItemList(),
    )));
  }
}
