import '../home_page_screen/widgets/home_page_item_widget.dart';
import 'bloc/home_page_bloc.dart';
import 'models/home_page_item_model.dart';
import 'models/home_page_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application6/widgets/custom_switch.dart';
import 'package:flutter/material.dart';

class HomePageScreen extends StatelessWidget {
  HomePageScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<HomePageBloc>(
      create: (context) => HomePageBloc(HomePageState(
        homePageModelObj: HomePageModel(),
      ))
        ..add(HomePageInitialEvent()),
      child: HomePageScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        appBar: CustomAppBar(
          height: getVerticalSize(
            75,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink70001,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: SizedBox(
          width: size.width,
          child: SingleChildScrollView(
            padding: getPadding(
              top: 2,
            ),
            child: Padding(
              padding: getPadding(
                left: 1,
                right: 7,
                bottom: 5,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      left: 7,
                    ),
                    child: Text(
                      "lbl_featured".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtStaatlichesRegular22,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 7,
                      top: 2,
                      right: 4,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "msg_specially_curated".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterRegular14,
                        ),
                        Padding(
                          padding: getPadding(
                            top: 7,
                            bottom: 8,
                          ),
                          child: SizedBox(
                            width: getHorizontalSize(
                              206,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                              indent: getHorizontalSize(
                                6,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: getPadding(
                      left: 7,
                      top: 17,
                      right: 2,
                    ),
                    child: IntrinsicWidth(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            margin: getMargin(
                              top: 13,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 2,
                              right: 3,
                              bottom: 2,
                            ),
                            decoration: AppDecoration.outlineGray300.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgImage67,
                                  height: getVerticalSize(
                                    70,
                                  ),
                                  width: getHorizontalSize(
                                    93,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      7,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: getHorizontalSize(
                                    36,
                                  ),
                                  margin: getMargin(
                                    top: 3,
                                  ),
                                  child: Text(
                                    "msg_walmart_superstores".tr,
                                    maxLines: null,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: getVerticalSize(
                              121,
                            ),
                            width: getHorizontalSize(
                              68,
                            ),
                            child: Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    decoration:
                                        AppDecoration.outlinePink70001.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder4,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: getPadding(
                                            right: 3,
                                          ),
                                          child: Text(
                                            "lbl_cashback2".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular9,
                                          ),
                                        ),
                                        Container(
                                          height: getVerticalSize(
                                            18,
                                          ),
                                          width: getHorizontalSize(
                                            66,
                                          ),
                                          decoration: BoxDecoration(
                                            color: ColorConstant.pink70001,
                                            borderRadius: BorderRadius.circular(
                                              getHorizontalSize(
                                                4,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Padding(
                                    padding: getPadding(
                                      left: 24,
                                      top: 7,
                                    ),
                                    child: Text(
                                      "lbl_5".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold20,
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topRight,
                                  child: Padding(
                                    padding: getPadding(
                                      top: 7,
                                      right: 13,
                                    ),
                                    child: Text(
                                      "lbl".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtInterRegular20WhiteA700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              121,
                            ),
                            width: getHorizontalSize(
                              99,
                            ),
                            margin: getMargin(
                              left: 12,
                            ),
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Container(
                                    padding: getPadding(
                                      all: 3,
                                    ),
                                    decoration:
                                        AppDecoration.outlineGray300.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder10,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Card(
                                          clipBehavior: Clip.antiAlias,
                                          elevation: 0,
                                          margin: EdgeInsets.all(0),
                                          color: ColorConstant.red800,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder7,
                                          ),
                                          child: Container(
                                            height: getVerticalSize(
                                              70,
                                            ),
                                            width: getHorizontalSize(
                                              93,
                                            ),
                                            padding: getPadding(
                                              left: 5,
                                              right: 5,
                                            ),
                                            decoration: AppDecoration.fillRed800
                                                .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .roundedBorder7,
                                            ),
                                            child: Stack(
                                              children: [
                                                CustomImageView(
                                                  imagePath:
                                                      ImageConstant.imgImage73,
                                                  height: getVerticalSize(
                                                    57,
                                                  ),
                                                  width: getHorizontalSize(
                                                    82,
                                                  ),
                                                  alignment:
                                                      Alignment.bottomCenter,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 1,
                                            top: 9,
                                            bottom: 8,
                                          ),
                                          child: Text(
                                            "lbl_mcdonald_s".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular11,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topRight,
                                  child: Container(
                                    height: getVerticalSize(
                                      32,
                                    ),
                                    width: getHorizontalSize(
                                      66,
                                    ),
                                    margin: getMargin(
                                      right: 9,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.bottomRight,
                                      children: [
                                        Align(
                                          alignment: Alignment.topCenter,
                                          child: Container(
                                            decoration: AppDecoration
                                                .outlinePink70001
                                                .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .roundedBorder4,
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding: getPadding(
                                                    right: 3,
                                                  ),
                                                  child: Text(
                                                    "lbl_cashback2".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtInterRegular9,
                                                  ),
                                                ),
                                                Container(
                                                  height: getVerticalSize(
                                                    18,
                                                  ),
                                                  width: getHorizontalSize(
                                                    66,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color:
                                                        ColorConstant.pink70001,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                      getHorizontalSize(
                                                        4,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                            padding: getPadding(
                                              right: 22,
                                            ),
                                            child: Text(
                                              "lbl_2".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle.txtInterBold20,
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                            padding: getPadding(
                                              right: 4,
                                            ),
                                            child: Text(
                                              "lbl".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular20WhiteA700,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              121,
                            ),
                            width: getHorizontalSize(
                              99,
                            ),
                            margin: getMargin(
                              left: 12,
                            ),
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Container(
                                    padding: getPadding(
                                      all: 3,
                                    ),
                                    decoration:
                                        AppDecoration.outlineGray300.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder10,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        CustomImageView(
                                          imagePath: ImageConstant.imgImage70,
                                          height: getVerticalSize(
                                            70,
                                          ),
                                          width: getHorizontalSize(
                                            93,
                                          ),
                                          radius: BorderRadius.circular(
                                            getHorizontalSize(
                                              7,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: getHorizontalSize(
                                            57,
                                          ),
                                          margin: getMargin(
                                            left: 1,
                                            top: 3,
                                            bottom: 2,
                                          ),
                                          child: Text(
                                            "msg_ikea_north_america".tr,
                                            maxLines: null,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular11,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topRight,
                                  child: Container(
                                    height: getVerticalSize(
                                      32,
                                    ),
                                    width: getHorizontalSize(
                                      66,
                                    ),
                                    margin: getMargin(
                                      right: 9,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.bottomRight,
                                      children: [
                                        Align(
                                          alignment: Alignment.topCenter,
                                          child: Container(
                                            decoration: AppDecoration
                                                .outlinePink70001
                                                .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .roundedBorder4,
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding: getPadding(
                                                    right: 3,
                                                  ),
                                                  child: Text(
                                                    "lbl_cashback2".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtInterRegular9,
                                                  ),
                                                ),
                                                Container(
                                                  height: getVerticalSize(
                                                    18,
                                                  ),
                                                  width: getHorizontalSize(
                                                    66,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color:
                                                        ColorConstant.pink70001,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                      getHorizontalSize(
                                                        4,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                            padding: getPadding(
                                              right: 22,
                                            ),
                                            child: Text(
                                              "lbl_5".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle.txtInterBold20,
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                            padding: getPadding(
                                              right: 4,
                                            ),
                                            child: Text(
                                              "lbl".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular20WhiteA700,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              121,
                            ),
                            width: getHorizontalSize(
                              74,
                            ),
                            margin: getMargin(
                              left: 12,
                            ),
                          ),
                          SizedBox(
                            height: getVerticalSize(
                              121,
                            ),
                            width: getHorizontalSize(
                              99,
                            ),
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Container(
                                    padding: getPadding(
                                      all: 3,
                                    ),
                                    decoration:
                                        AppDecoration.outlineGray300.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder10,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        CustomImageView(
                                          imagePath: ImageConstant.imgImage72,
                                          height: getVerticalSize(
                                            70,
                                          ),
                                          width: getHorizontalSize(
                                            93,
                                          ),
                                          radius: BorderRadius.circular(
                                            getHorizontalSize(
                                              7,
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 1,
                                            top: 10,
                                            bottom: 7,
                                          ),
                                          child: Text(
                                            "lbl_best_buy".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular11,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topRight,
                                  child: Container(
                                    height: getVerticalSize(
                                      32,
                                    ),
                                    width: getHorizontalSize(
                                      66,
                                    ),
                                    margin: getMargin(
                                      right: 9,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.bottomRight,
                                      children: [
                                        Align(
                                          alignment: Alignment.topCenter,
                                          child: Container(
                                            decoration: AppDecoration
                                                .outlinePink70001
                                                .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .roundedBorder4,
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding: getPadding(
                                                    right: 15,
                                                  ),
                                                  child: Text(
                                                    "lbl_cashback2".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.right,
                                                    style: AppStyle
                                                        .txtInterRegular9,
                                                  ),
                                                ),
                                                Container(
                                                  height: getVerticalSize(
                                                    18,
                                                  ),
                                                  width: getHorizontalSize(
                                                    66,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color:
                                                        ColorConstant.pink70001,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                      getHorizontalSize(
                                                        4,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                            padding: getPadding(
                                              right: 22,
                                            ),
                                            child: Text(
                                              "lbl_5".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle.txtInterBold20,
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                            padding: getPadding(
                                              right: 14,
                                            ),
                                            child: Text(
                                              "lbl".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular20WhiteA700,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 7,
                      top: 23,
                    ),
                    child: Text(
                      "lbl_categories".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtStaatlichesRegular22,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 7,
                      top: 1,
                      right: 3,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "msg_compare_and_save".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterRegular14,
                        ),
                        Padding(
                          padding: getPadding(
                            top: 7,
                            bottom: 8,
                          ),
                          child: SizedBox(
                            width: getHorizontalSize(
                              210,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                              indent: getHorizontalSize(
                                5,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: getPadding(
                      left: 7,
                      top: 18,
                      right: 3,
                    ),
                    child: IntrinsicWidth(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: getVerticalSize(
                              112,
                            ),
                            width: getHorizontalSize(
                              72,
                            ),
                            margin: getMargin(
                              bottom: 2,
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Align(
                                  alignment: Alignment.topRight,
                                  child: SizedBox(
                                    height: getVerticalSize(
                                      75,
                                    ),
                                    width: getHorizontalSize(
                                      52,
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.center,
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          CustomImageView(
                                            imagePath: ImageConstant.imgImage75,
                                            height: getVerticalSize(
                                              75,
                                            ),
                                            width: getHorizontalSize(
                                              72,
                                            ),
                                            radius: BorderRadius.only(
                                              topLeft: Radius.circular(
                                                getHorizontalSize(
                                                  33,
                                                ),
                                              ),
                                              topRight: Radius.circular(
                                                getHorizontalSize(
                                                  36,
                                                ),
                                              ),
                                              bottomLeft: Radius.circular(
                                                getHorizontalSize(
                                                  36,
                                                ),
                                              ),
                                              bottomRight: Radius.circular(
                                                getHorizontalSize(
                                                  33,
                                                ),
                                              ),
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath: ImageConstant
                                                .imgPullcategorylogo,
                                            height: getVerticalSize(
                                              75,
                                            ),
                                            width: getHorizontalSize(
                                              74,
                                            ),
                                            radius: BorderRadius.circular(
                                              getHorizontalSize(
                                                37,
                                              ),
                                            ),
                                            margin: getMargin(
                                              left: 290,
                                            ),
                                          ),
                                        ],
                                      ),
                                      Container(
                                        width: getHorizontalSize(
                                          47,
                                        ),
                                        margin: getMargin(
                                          top: 10,
                                          right: 5,
                                        ),
                                        child: Text(
                                          "msg_groceries_essential".tr,
                                          maxLines: null,
                                          textAlign: TextAlign.center,
                                          style: AppStyle.txtInterRegular11,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 17,
                              bottom: 2,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomImageView(
                                  imagePath:
                                      ImageConstant.imgPullcategorylogo75x74,
                                  height: getVerticalSize(
                                    75,
                                  ),
                                  width: getHorizontalSize(
                                    74,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      37,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: getHorizontalSize(
                                    62,
                                  ),
                                  margin: getMargin(
                                    top: 10,
                                  ),
                                  child: Text(
                                    "msg_dining_restaurants".tr,
                                    maxLines: null,
                                    textAlign: TextAlign.center,
                                    style: AppStyle.txtInterRegular11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 17,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgPullcategorylogo1,
                                  height: getVerticalSize(
                                    75,
                                  ),
                                  width: getHorizontalSize(
                                    74,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      37,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: getHorizontalSize(
                                    43,
                                  ),
                                  margin: getMargin(
                                    top: 10,
                                  ),
                                  child: Text(
                                    "lbl_retail_therapy".tr,
                                    maxLines: null,
                                    textAlign: TextAlign.center,
                                    style: AppStyle.txtInterRegular11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 17,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgPullcategorylogo2,
                                  height: getVerticalSize(
                                    75,
                                  ),
                                  width: getHorizontalSize(
                                    74,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      37,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: getHorizontalSize(
                                    59,
                                  ),
                                  margin: getMargin(
                                    top: 11,
                                  ),
                                  child: Text(
                                    "lbl_gas_commuting".tr,
                                    maxLines: null,
                                    textAlign: TextAlign.center,
                                    style: AppStyle.txtInterRegular11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: getHorizontalSize(
                              30,
                            ),
                            margin: getMargin(
                              left: 20,
                              top: 85,
                              bottom: 2,
                            ),
                            child: Text(
                              "msg_exploration_adventure".tr,
                              maxLines: null,
                              textAlign: TextAlign.center,
                              style: AppStyle.txtInterRegular11,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 6,
                      top: 19,
                      right: 1,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: getVerticalSize(
                            47,
                          ),
                          width: getHorizontalSize(
                            123,
                          ),
                          child: Stack(
                            alignment: Alignment.topLeft,
                            children: [
                              Align(
                                alignment: Alignment.center,
                                child: Container(
                                  padding: getPadding(
                                    left: 17,
                                    top: 3,
                                    right: 17,
                                    bottom: 3,
                                  ),
                                  decoration:
                                      AppDecoration.fillPink70001.copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder10,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: getPadding(
                                          bottom: 19,
                                        ),
                                        child: Text(
                                          "lbl_brands".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style:
                                              AppStyle.txtStaatlichesRegular15,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                  padding: getPadding(
                                    left: 5,
                                  ),
                                  child: Text(
                                    "lbl_fave".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtStaatlichesRegular35,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            top: 14,
                            bottom: 31,
                          ),
                          child: SizedBox(
                            width: getHorizontalSize(
                              188,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                            ),
                          ),
                        ),
                        Container(
                          height: getVerticalSize(
                            29,
                          ),
                          width: getHorizontalSize(
                            54,
                          ),
                          margin: getMargin(
                            top: 1,
                            bottom: 17,
                          ),
                          child: Stack(
                            alignment: Alignment.centerLeft,
                            children: [
                              BlocSelector<HomePageBloc, HomePageState, bool?>(
                                selector: (state) => state.isSelectedSwitch,
                                builder: (context, isSelectedSwitch) {
                                  return CustomSwitch(
                                    alignment: Alignment.center,
                                    value: isSelectedSwitch,
                                    onChanged: (value) {
                                      context
                                          .read<HomePageBloc>()
                                          .add(ChangeSwitchEvent(value: value));
                                    },
                                  );
                                },
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgLogo,
                                height: getVerticalSize(
                                  6,
                                ),
                                width: getHorizontalSize(
                                  42,
                                ),
                                alignment: Alignment.centerLeft,
                                margin: getMargin(
                                  left: 4,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 9,
                      top: 2,
                    ),
                    child: Text(
                      "lbl_all_year_round".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterRegular14,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 12,
                    ),
                    child: BlocSelector<HomePageBloc, HomePageState,
                        HomePageModel?>(
                      selector: (state) => state.homePageModelObj,
                      builder: (context, homePageModelObj) {
                        return ListView.separated(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          separatorBuilder: (
                            context,
                            index,
                          ) {
                            return SizedBox(
                              height: getVerticalSize(
                                9,
                              ),
                            );
                          },
                          itemCount:
                              homePageModelObj?.homePageItemList.length ?? 0,
                          itemBuilder: (context, index) {
                            HomePageItemModel model =
                                homePageModelObj?.homePageItemList[index] ??
                                    HomePageItemModel();
                            return HomePageItemWidget(
                              model,
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
