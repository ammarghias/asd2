import '../models/listgroup_item_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListgroupItemWidget extends StatelessWidget {
  ListgroupItemWidget(
    this.listgroupItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  ListgroupItemModel listgroupItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomImageView(
          svgPath: ImageConstant.imgGroupPink70001,
          height: getVerticalSize(
            17,
          ),
          width: getHorizontalSize(
            103,
          ),
          margin: getMargin(
            top: 5,
            bottom: 7,
          ),
        ),
        Padding(
          padding: getPadding(
            left: 5,
            bottom: 4,
          ),
          child: Text(
            listgroupItemModelObj.typeTxt,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: AppStyle.txtInterBold21.copyWith(
              decoration: TextDecoration.underline,
            ),
          ),
        ),
        Spacer(),
        Padding(
          padding: getPadding(
            bottom: 1,
          ),
          child: Text(
            "lbl2".tr,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: AppStyle.txtInterRegular23,
          ),
        ),
        Padding(
          padding: getPadding(
            left: 8,
            top: 2,
          ),
          child: Text(
            listgroupItemModelObj.valueTxt,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: AppStyle.txtInterRegular23,
          ),
        ),
      ],
    );
  }
}
