// ignore_for_file: must_be_immutable

part of 'savings_estimator_bloc.dart';

/// Represents the state of SavingsEstimator in the application.
class SavingsEstimatorState extends Equatable {
  SavingsEstimatorState({
    this.isCheckbox = false,
    this.isCheckbox1 = false,
    this.savingsEstimatorModelObj,
  });

  SavingsEstimatorModel? savingsEstimatorModelObj;

  bool isCheckbox;

  bool isCheckbox1;

  @override
  List<Object?> get props => [
        isCheckbox,
        isCheckbox1,
        savingsEstimatorModelObj,
      ];
  SavingsEstimatorState copyWith({
    bool? isCheckbox,
    bool? isCheckbox1,
    SavingsEstimatorModel? savingsEstimatorModelObj,
  }) {
    return SavingsEstimatorState(
      isCheckbox: isCheckbox ?? this.isCheckbox,
      isCheckbox1: isCheckbox1 ?? this.isCheckbox1,
      savingsEstimatorModelObj:
          savingsEstimatorModelObj ?? this.savingsEstimatorModelObj,
    );
  }
}
