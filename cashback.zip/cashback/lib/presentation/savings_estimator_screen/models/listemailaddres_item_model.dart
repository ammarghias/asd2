/// This class is used in the [listemailaddres_item_widget] screen.
class ListemailaddresItemModel {String emailaddressTxt = "Yearly Net Income";

String descriptionTxt = "Your Annual Take home income";

String amountTxt = "87,432";

String? id = "";

 }
