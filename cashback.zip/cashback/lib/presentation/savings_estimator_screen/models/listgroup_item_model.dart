/// This class is used in the [listgroup_item_widget] screen.
class ListgroupItemModel {String typeTxt = "Gold:";

String valueTxt = "1,131.57";

String? id = "";

 }
