// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';import 'listgroup_item_model.dart';import 'listemailaddres_item_model.dart';/// This class defines the variables used in the [savings_estimator_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class SavingsEstimatorModel extends Equatable {SavingsEstimatorModel({this.listgroupItemList = const [], this.listemailaddresItemList = const [], });

List<ListgroupItemModel> listgroupItemList;

List<ListemailaddresItemModel> listemailaddresItemList;

SavingsEstimatorModel copyWith({List<ListgroupItemModel>? listgroupItemList, List<ListemailaddresItemModel>? listemailaddresItemList, }) { return SavingsEstimatorModel(
listgroupItemList : listgroupItemList ?? this.listgroupItemList,
listemailaddresItemList : listemailaddresItemList ?? this.listemailaddresItemList,
); } 
@override List<Object?> get props => [listgroupItemList,listemailaddresItemList];
 }
