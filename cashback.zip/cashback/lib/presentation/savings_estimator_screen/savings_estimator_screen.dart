import '../savings_estimator_screen/widgets/listemailaddres_item_widget.dart';
import '../savings_estimator_screen/widgets/listgroup_item_widget.dart';
import 'bloc/savings_estimator_bloc.dart';
import 'models/listemailaddres_item_model.dart';
import 'models/listgroup_item_model.dart';
import 'models/savings_estimator_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application6/widgets/custom_button.dart';
import 'package:ammar_s_application6/widgets/custom_checkbox.dart';
import 'package:flutter/material.dart';

class SavingsEstimatorScreen extends StatelessWidget {
  SavingsEstimatorScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<SavingsEstimatorBloc>(
      create: (context) => SavingsEstimatorBloc(SavingsEstimatorState(
        savingsEstimatorModelObj: SavingsEstimatorModel(),
      ))
        ..add(SavingsEstimatorInitialEvent()),
      child: SavingsEstimatorScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        appBar: CustomAppBar(
          height: getVerticalSize(
            60,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink70001,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: SizedBox(
          width: size.width,
          child: SingleChildScrollView(
            child: Padding(
              padding: getPadding(
                left: 8,
                bottom: 5,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  CustomButton(
                    width: getHorizontalSize(
                      199,
                    ),
                    text: "msg_savings_estimator".tr,
                    margin: getMargin(
                      left: 83,
                    ),
                    variant: ButtonVariant.OutlineGray50003,
                    shape: ButtonShape.RoundedBorder10,
                    padding: ButtonPadding.PaddingT5,
                    fontStyle: ButtonFontStyle.RobotoRomanRegular18,
                    suffixWidget: Container(
                      margin: getMargin(
                        left: 12,
                      ),
                      child: CustomImageView(
                        svgPath: ImageConstant.imgMobileBlueGray40001,
                      ),
                    ),
                  ),
                  Container(
                    width: getHorizontalSize(
                      230,
                    ),
                    margin: getMargin(
                      left: 70,
                      top: 12,
                    ),
                    child: Text(
                      "msg_default_numbers".tr,
                      maxLines: null,
                      textAlign: TextAlign.center,
                      style: AppStyle.txtInterMedium13,
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      height: getVerticalSize(
                        286,
                      ),
                      width: getHorizontalSize(
                        365,
                      ),
                      margin: getMargin(
                        top: 17,
                      ),
                      child: Stack(
                        alignment: Alignment.topLeft,
                        children: [
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: Container(
                              margin: getMargin(
                                left: 4,
                                bottom: 75,
                              ),
                              padding: getPadding(
                                left: 13,
                                top: 8,
                                right: 13,
                                bottom: 8,
                              ),
                              decoration:
                                  AppDecoration.outlineGray40005.copyWith(
                                borderRadius: BorderRadiusStyle.roundedBorder10,
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    "lbl_732_747".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular31,
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      top: 1,
                                      bottom: 4,
                                    ),
                                    child: Text(
                                      "lbl_good".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold23Lime400,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Padding(
                              padding: getPadding(
                                left: 34,
                                top: 25,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    height: getVerticalSize(
                                      61,
                                    ),
                                    width: getHorizontalSize(
                                      90,
                                    ),
                                    margin: getMargin(
                                      top: 5,
                                      bottom: 12,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.topRight,
                                      children: [
                                        Align(
                                          alignment: Alignment.bottomCenter,
                                          child: Text(
                                            "lbl_scorecard".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtInterRegular18Gray50002,
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Text(
                                            "lbl_fico".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterBold35,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      left: 1,
                                    ),
                                    child: Text(
                                      "lbl_8".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold70,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              "lbl_credit_scoring".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular25Gray50002,
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: SizedBox(
                              height: getVerticalSize(
                                264,
                              ),
                              width: getHorizontalSize(
                                361,
                              ),
                              child: Stack(
                                alignment: Alignment.bottomLeft,
                                children: [
                                  Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Padding(
                                      padding: getPadding(
                                        bottom: 15,
                                      ),
                                      child: Text(
                                        "msg_estimated_savings".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterBold25,
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Padding(
                                      padding: getPadding(
                                        left: 93,
                                      ),
                                      child: Text(
                                        "msg_in_annualized_return".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtInterRegular14Bluegray10004,
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: Padding(
                                      padding: getPadding(
                                        top: 103,
                                        right: 136,
                                      ),
                                      child: Text(
                                        "lbl_good".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular14Lime400,
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: SizedBox(
                                      height: getVerticalSize(
                                        224,
                                      ),
                                      width: getHorizontalSize(
                                        148,
                                      ),
                                      child: Stack(
                                        alignment: Alignment.centerRight,
                                        children: [
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgEllipse22,
                                            height: getVerticalSize(
                                              224,
                                            ),
                                            width: getHorizontalSize(
                                              130,
                                            ),
                                            alignment: Alignment.centerRight,
                                          ),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgEllipse26,
                                            height: getVerticalSize(
                                              224,
                                            ),
                                            width: getHorizontalSize(
                                              130,
                                            ),
                                            alignment: Alignment.centerRight,
                                          ),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgEllipse25,
                                            height: getVerticalSize(
                                              224,
                                            ),
                                            width: getHorizontalSize(
                                              130,
                                            ),
                                            alignment: Alignment.centerRight,
                                          ),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgEllipse24,
                                            height: getVerticalSize(
                                              224,
                                            ),
                                            width: getHorizontalSize(
                                              130,
                                            ),
                                            alignment: Alignment.centerRight,
                                          ),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgEllipse23,
                                            height: getVerticalSize(
                                              224,
                                            ),
                                            width: getHorizontalSize(
                                              130,
                                            ),
                                            alignment: Alignment.centerRight,
                                          ),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgEllipse27,
                                            height: getVerticalSize(
                                              120,
                                            ),
                                            width: getHorizontalSize(
                                              83,
                                            ),
                                            alignment: Alignment.topRight,
                                            margin: getMargin(
                                              top: 48,
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgRewindBlueGray400,
                                            height: getVerticalSize(
                                              20,
                                            ),
                                            width: getHorizontalSize(
                                              27,
                                            ),
                                            alignment: Alignment.topRight,
                                            margin: getMargin(
                                              top: 94,
                                              right: 46,
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.bottomLeft,
                                            child: Padding(
                                              padding: getPadding(
                                                left: 16,
                                                bottom: 27,
                                              ),
                                              child: Text(
                                                "lbl_fair".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular14YellowA700,
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Container(
                                              width: getHorizontalSize(
                                                35,
                                              ),
                                              margin: getMargin(
                                                top: 12,
                                              ),
                                              child: Text(
                                                "lbl_very_good".tr,
                                                maxLines: null,
                                                textAlign: TextAlign.center,
                                                style: AppStyle
                                                    .txtInterRegular14Lightgreen500,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.bottomRight,
                                    child: Padding(
                                      padding: getPadding(
                                        right: 25,
                                        bottom: 21,
                                      ),
                                      child: Text(
                                        "lbl_poor".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular14Red700,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topRight,
                            child: Padding(
                              padding: getPadding(
                                top: 4,
                                right: 26,
                              ),
                              child: Text(
                                "lbl_excellent".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular14Green600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      height: getVerticalSize(
                        333,
                      ),
                      width: getHorizontalSize(
                        356,
                      ),
                      margin: getMargin(
                        top: 13,
                      ),
                      child: Stack(
                        alignment: Alignment.topCenter,
                        children: [
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              margin: getMargin(
                                top: 214,
                              ),
                              padding: getPadding(
                                left: 12,
                                top: 6,
                                right: 12,
                                bottom: 6,
                              ),
                              decoration:
                                  AppDecoration.outlineGray50006.copyWith(
                                borderRadius: BorderRadiusStyle.roundedBorder10,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    width: getHorizontalSize(
                                      146,
                                    ),
                                    margin: getMargin(
                                      top: 63,
                                    ),
                                    child: Text(
                                      "msg_your_personal_pre_approval".tr,
                                      maxLines: null,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold16WhiteA700,
                                    ),
                                  ),
                                  Spacer(),
                                  Padding(
                                    padding: getPadding(
                                      top: 66,
                                      bottom: 5,
                                    ),
                                    child: Text(
                                      "lbl2".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold27,
                                    ),
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      left: 6,
                                      top: 69,
                                      right: 3,
                                      bottom: 3,
                                    ),
                                    child: Text(
                                      "lbl_18_970".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold27,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                              padding: getPadding(
                                left: 12,
                                top: 25,
                                right: 12,
                                bottom: 25,
                              ),
                              decoration:
                                  AppDecoration.outlineGray500061.copyWith(
                                borderRadius: BorderRadiusStyle.roundedBorder10,
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: getPadding(
                                      bottom: 6,
                                    ),
                                    child: BlocSelector<
                                        SavingsEstimatorBloc,
                                        SavingsEstimatorState,
                                        SavingsEstimatorModel?>(
                                      selector: (state) =>
                                          state.savingsEstimatorModelObj,
                                      builder:
                                          (context, savingsEstimatorModelObj) {
                                        return ListView.separated(
                                          physics:
                                              NeverScrollableScrollPhysics(),
                                          shrinkWrap: true,
                                          separatorBuilder: (
                                            context,
                                            index,
                                          ) {
                                            return Padding(
                                              padding: getPadding(
                                                top: 15.0,
                                                bottom: 15.0,
                                              ),
                                              child: SizedBox(
                                                width: getHorizontalSize(
                                                  273,
                                                ),
                                                child: Divider(
                                                  height: getVerticalSize(
                                                    2,
                                                  ),
                                                  thickness: getVerticalSize(
                                                    2,
                                                  ),
                                                  color: ColorConstant
                                                      .blueGray10005,
                                                ),
                                              ),
                                            );
                                          },
                                          itemCount: savingsEstimatorModelObj
                                                  ?.listgroupItemList.length ??
                                              0,
                                          itemBuilder: (context, index) {
                                            ListgroupItemModel model =
                                                savingsEstimatorModelObj
                                                            ?.listgroupItemList[
                                                        index] ??
                                                    ListgroupItemModel();
                                            return ListgroupItemWidget(
                                              model,
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              width: getHorizontalSize(
                                222,
                              ),
                              margin: getMargin(
                                bottom: 59,
                              ),
                              padding: getPadding(
                                left: 30,
                                top: 2,
                                right: 32,
                                bottom: 2,
                              ),
                              decoration:
                                  AppDecoration.txtOutlineWhiteA7001.copyWith(
                                borderRadius:
                                    BorderRadiusStyle.txtRoundedBorder7,
                              ),
                              child: Text(
                                "msg_pre_enroll_today".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular20WhiteA700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: getPadding(
                        top: 22,
                      ),
                      child: Text(
                        "msg_let_s_personalize".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: AppStyle.txtInterRegular19Gray60008.copyWith(
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: getMargin(
                      top: 17,
                      right: 7,
                    ),
                    padding: getPadding(
                      left: 7,
                      top: 15,
                      right: 7,
                      bottom: 15,
                    ),
                    decoration: AppDecoration.outlineGray500062.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder10,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Padding(
                            padding: getPadding(
                              left: 9,
                              right: 11,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    top: 6,
                                    bottom: 3,
                                  ),
                                  child: Text(
                                    "lbl_if_we_may".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterMedium19,
                                  ),
                                ),
                                CustomButton(
                                  width: getHorizontalSize(
                                    144,
                                  ),
                                  text: "lbl_re_calculate".tr,
                                  margin: getMargin(
                                    left: 108,
                                  ),
                                  variant: ButtonVariant.OutlineGray50003_1,
                                  shape: ButtonShape.RoundedBorder10,
                                  padding: ButtonPadding.PaddingAll3,
                                  fontStyle: ButtonFontStyle.RobotoRomanBold20,
                                ),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 3,
                            top: 32,
                            right: 5,
                          ),
                          child: BlocSelector<SavingsEstimatorBloc,
                              SavingsEstimatorState, SavingsEstimatorModel?>(
                            selector: (state) => state.savingsEstimatorModelObj,
                            builder: (context, savingsEstimatorModelObj) {
                              return ListView.separated(
                                physics: NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                separatorBuilder: (
                                  context,
                                  index,
                                ) {
                                  return SizedBox(
                                    height: getVerticalSize(
                                      24,
                                    ),
                                  );
                                },
                                itemCount: savingsEstimatorModelObj
                                        ?.listemailaddresItemList.length ??
                                    0,
                                itemBuilder: (context, index) {
                                  ListemailaddresItemModel model =
                                      savingsEstimatorModelObj
                                                  ?.listemailaddresItemList[
                                              index] ??
                                          ListemailaddresItemModel();
                                  return ListemailaddresItemWidget(
                                    model,
                                  );
                                },
                              );
                            },
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 3,
                            top: 24,
                            right: 15,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: getHorizontalSize(
                                  58,
                                ),
                                child: Text(
                                  "lbl_credit_history".tr,
                                  maxLines: null,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular17Pink70001,
                                ),
                              ),
                              CustomButton(
                                height: getVerticalSize(
                                  38,
                                ),
                                width: getHorizontalSize(
                                  79,
                                ),
                                text: "msg_less_than_2_years".tr,
                                margin: getMargin(
                                  left: 20,
                                  top: 2,
                                  bottom: 4,
                                ),
                                variant: ButtonVariant.OutlineWhiteA700_2,
                                shape: ButtonShape.RoundedBorder5,
                                padding: ButtonPadding.PaddingAll3,
                                fontStyle: ButtonFontStyle.InterMedium12,
                              ),
                              CustomButton(
                                height: getVerticalSize(
                                  38,
                                ),
                                width: getHorizontalSize(
                                  79,
                                ),
                                text: "lbl_2_to_5_years".tr,
                                margin: getMargin(
                                  left: 16,
                                  top: 2,
                                  bottom: 4,
                                ),
                                variant: ButtonVariant.OutlineWhiteA700_3,
                                shape: ButtonShape.RoundedBorder5,
                                padding: ButtonPadding.PaddingAll3,
                                fontStyle: ButtonFontStyle.InterMedium12,
                              ),
                              CustomButton(
                                height: getVerticalSize(
                                  38,
                                ),
                                width: getHorizontalSize(
                                  79,
                                ),
                                text: "lbl_over_5_years".tr,
                                margin: getMargin(
                                  left: 14,
                                  top: 2,
                                  bottom: 4,
                                ),
                                variant: ButtonVariant.OutlinePink70001_2,
                                shape: ButtonShape.RoundedBorder5,
                                padding: ButtonPadding.PaddingAll3,
                                fontStyle: ButtonFontStyle.InterMedium12,
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 3,
                            top: 19,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: getHorizontalSize(
                                  50,
                                ),
                                child: Text(
                                  "lbl_credit_rating".tr,
                                  maxLines: null,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular17Pink70001,
                                ),
                              ),
                              CustomButton(
                                height: getVerticalSize(
                                  38,
                                ),
                                width: getHorizontalSize(
                                  55,
                                ),
                                text: "lbl_excellent".tr,
                                margin: getMargin(
                                  left: 14,
                                  top: 1,
                                  bottom: 5,
                                ),
                                variant: ButtonVariant.OutlineWhiteA700_4,
                                shape: ButtonShape.RoundedBorder5,
                                padding: ButtonPadding.PaddingT12,
                                fontStyle: ButtonFontStyle.InterMedium10,
                              ),
                              CustomButton(
                                height: getVerticalSize(
                                  38,
                                ),
                                width: getHorizontalSize(
                                  55,
                                ),
                                text: "lbl_very_good2".tr,
                                margin: getMargin(
                                  left: 5,
                                  top: 1,
                                  bottom: 5,
                                ),
                                variant: ButtonVariant.OutlineWhiteA700_5,
                                shape: ButtonShape.RoundedBorder5,
                                padding: ButtonPadding.PaddingAll6,
                                fontStyle: ButtonFontStyle.InterMedium10,
                              ),
                              CustomButton(
                                height: getVerticalSize(
                                  38,
                                ),
                                width: getHorizontalSize(
                                  55,
                                ),
                                text: "lbl_good".tr,
                                margin: getMargin(
                                  left: 5,
                                  top: 1,
                                  bottom: 5,
                                ),
                                variant: ButtonVariant.OutlinePink70001_3,
                                shape: ButtonShape.RoundedBorder5,
                                padding: ButtonPadding.PaddingAll11,
                                fontStyle:
                                    ButtonFontStyle.InterMedium10Gray70001,
                              ),
                              CustomButton(
                                height: getVerticalSize(
                                  38,
                                ),
                                width: getHorizontalSize(
                                  55,
                                ),
                                text: "lbl_fair".tr,
                                margin: getMargin(
                                  left: 6,
                                  top: 1,
                                  bottom: 5,
                                ),
                                variant: ButtonVariant.OutlineWhiteA700_6,
                                shape: ButtonShape.RoundedBorder5,
                                padding: ButtonPadding.PaddingAll11,
                                fontStyle:
                                    ButtonFontStyle.InterMedium10Bluegray900,
                              ),
                              CustomButton(
                                height: getVerticalSize(
                                  38,
                                ),
                                width: getHorizontalSize(
                                  55,
                                ),
                                text: "lbl_poor".tr,
                                margin: getMargin(
                                  left: 5,
                                  top: 1,
                                  bottom: 5,
                                ),
                                variant: ButtonVariant.OutlineWhiteA700_7,
                                shape: ButtonShape.RoundedBorder5,
                                padding: ButtonPadding.PaddingAll11,
                                fontStyle: ButtonFontStyle.InterMedium10,
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 3,
                            top: 28,
                          ),
                          child: Text(
                            "msg_missed_payments".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular17Pink70001,
                          ),
                        ),
                        BlocSelector<SavingsEstimatorBloc,
                            SavingsEstimatorState, bool?>(
                          selector: (state) => state.isCheckbox,
                          builder: (context, isCheckbox) {
                            return CustomCheckbox(
                              text: "msg_i_have_not_missed".tr,
                              iconSize: getHorizontalSize(
                                26,
                              ),
                              value: isCheckbox,
                              margin: getMargin(
                                left: 3,
                                top: 9,
                                right: 12,
                              ),
                              fontStyle: CheckboxFontStyle.InterMedium13,
                              onChange: (value) {
                                context
                                    .read<SavingsEstimatorBloc>()
                                    .add(ChangeCheckBoxEvent(value: value));
                              },
                            );
                          },
                        ),
                        CustomButton(
                          text: "msg_i_might_have_missed".tr,
                          margin: getMargin(
                            left: 3,
                            top: 12,
                            right: 85,
                          ),
                          shape: ButtonShape.Square,
                          padding: ButtonPadding.PaddingT3,
                          fontStyle: ButtonFontStyle.InterMedium13,
                          prefixWidget: Container(
                            margin: getMargin(
                              right: 11,
                            ),
                            decoration: BoxDecoration(),
                            child: CustomImageView(
                              svgPath: ImageConstant.imgSelectButton,
                            ),
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 3,
                            top: 34,
                          ),
                          child: Text(
                            "msg_additional_savings".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular17Pink70001,
                          ),
                        ),
                        BlocSelector<SavingsEstimatorBloc,
                            SavingsEstimatorState, bool?>(
                          selector: (state) => state.isCheckbox1,
                          builder: (context, isCheckbox1) {
                            return CustomCheckbox(
                              text: "msg_i_want_to_save_up".tr,
                              iconSize: getHorizontalSize(
                                26,
                              ),
                              value: isCheckbox1,
                              margin: getMargin(
                                left: 3,
                                top: 7,
                                right: 15,
                              ),
                              fontStyle: CheckboxFontStyle.InterMedium15,
                              onChange: (value) {
                                context
                                    .read<SavingsEstimatorBloc>()
                                    .add(ChangeCheckBox1Event(value: value));
                              },
                            );
                          },
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                            padding: getPadding(
                              top: 2,
                              right: 20,
                              bottom: 7,
                            ),
                            child: Text(
                              "msg_requires_a_linked".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium14Gray40006,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      34,
                    ),
                    width: getHorizontalSize(
                      380,
                    ),
                    margin: getMargin(
                      top: 40,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Padding(
                            padding: getPadding(
                              bottom: 15,
                            ),
                            child: SizedBox(
                              width: getHorizontalSize(
                                380,
                              ),
                              child: Divider(
                                height: getVerticalSize(
                                  2,
                                ),
                                thickness: getVerticalSize(
                                  2,
                                ),
                                color: ColorConstant.gray40003,
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            width: getHorizontalSize(
                              222,
                            ),
                            padding: getPadding(
                              left: 30,
                              top: 2,
                              right: 32,
                              bottom: 2,
                            ),
                            decoration:
                                AppDecoration.txtOutlineWhiteA7001.copyWith(
                              borderRadius: BorderRadiusStyle.txtRoundedBorder7,
                            ),
                            child: Text(
                              "msg_pre_enroll_today".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular20WhiteA700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
