import 'bloc/annual_credits_bloc.dart';
import 'models/annual_credits_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

class AnnualCreditsScreen extends StatelessWidget {
  AnnualCreditsScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<AnnualCreditsBloc>(
      create: (context) => AnnualCreditsBloc(AnnualCreditsState(
        annualCreditsModelObj: AnnualCreditsModel(),
      ))
        ..add(AnnualCreditsInitialEvent()),
      child: AnnualCreditsScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AnnualCreditsBloc, AnnualCreditsState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: SizedBox(
              width: size.width,
              child: SingleChildScrollView(
                child: Container(
                  decoration: AppDecoration.fillWhiteA700,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: getVerticalSize(
                          165,
                        ),
                        width: double.maxFinite,
                        child: Stack(
                          alignment: Alignment.topCenter,
                          children: [
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Text(
                                "msg_your_annual_credits".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style:
                                    AppStyle.txtStaatlichesRegular40Gray40008,
                              ),
                            ),
                            CustomImageView(
                              svgPath: ImageConstant.imgHeader,
                              height: getVerticalSize(
                                131,
                              ),
                              width: getHorizontalSize(
                                393,
                              ),
                              alignment: Alignment.topCenter,
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 25,
                          top: 23,
                          right: 36,
                        ),
                        padding: getPadding(
                          left: 5,
                          top: 4,
                          right: 5,
                          bottom: 4,
                        ),
                        decoration: AppDecoration.outlinePink700016.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder21,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding: getPadding(
                                left: 10,
                                top: 9,
                                bottom: 6,
                              ),
                              child: Text(
                                "msg_search_by_credit".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular15Pink70090,
                              ),
                            ),
                            Card(
                              clipBehavior: Clip.antiAlias,
                              elevation: 0,
                              margin: getMargin(
                                left: 5,
                              ),
                              color: ColorConstant.pink70001,
                              shape: RoundedRectangleBorder(
                                side: BorderSide(
                                  color: ColorConstant.whiteA700,
                                  width: getHorizontalSize(
                                    3,
                                  ),
                                ),
                                borderRadius: BorderRadiusStyle.roundedBorder15,
                              ),
                              child: Container(
                                height: getVerticalSize(
                                  35,
                                ),
                                width: getHorizontalSize(
                                  48,
                                ),
                                padding: getPadding(
                                  left: 12,
                                  top: 5,
                                  right: 12,
                                  bottom: 5,
                                ),
                                decoration:
                                    AppDecoration.outlineWhiteA7001.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder15,
                                ),
                                child: Stack(
                                  children: [
                                    CustomImageView(
                                      svgPath: ImageConstant.imgSignal,
                                      height: getSize(
                                        22,
                                      ),
                                      width: getSize(
                                        22,
                                      ),
                                      alignment: Alignment.center,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: getMargin(
                          left: 13,
                          top: 32,
                          right: 24,
                        ),
                        padding: getPadding(
                          left: 13,
                          top: 8,
                          right: 13,
                          bottom: 8,
                        ),
                        decoration: AppDecoration.outlinePink700017.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder10,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: getPadding(
                                left: 1,
                                right: 82,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomImageView(
                                    imagePath: ImageConstant.imgPullcreditcard3,
                                    height: getVerticalSize(
                                      39,
                                    ),
                                    width: getHorizontalSize(
                                      69,
                                    ),
                                    radius: BorderRadius.circular(
                                      getHorizontalSize(
                                        3,
                                      ),
                                    ),
                                    margin: getMargin(
                                      top: 1,
                                      bottom: 6,
                                    ),
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      left: 8,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          "msg_american_express".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style:
                                              AppStyle.txtInterBold18Black90099,
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            top: 2,
                                          ),
                                          child: Text(
                                            "msg_blue_cash_preferred".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtInterRegular18Black90099,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                top: 5,
                              ),
                              child: Divider(
                                height: getVerticalSize(
                                  1,
                                ),
                                thickness: getVerticalSize(
                                  1,
                                ),
                                color: ColorConstant.gray400,
                                indent: getHorizontalSize(
                                  2,
                                ),
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                left: 1,
                                top: 4,
                                right: 1,
                              ),
                              child: Row(
                                children: [
                                  Card(
                                    clipBehavior: Clip.antiAlias,
                                    elevation: 0,
                                    margin: EdgeInsets.all(0),
                                    color: ColorConstant.gray10002,
                                    shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder30,
                                    ),
                                    child: Container(
                                      height: getVerticalSize(
                                        61,
                                      ),
                                      width: getHorizontalSize(
                                        60,
                                      ),
                                      padding: getPadding(
                                        left: 1,
                                        top: 14,
                                        right: 1,
                                        bottom: 14,
                                      ),
                                      decoration:
                                          AppDecoration.fillGray10002.copyWith(
                                        borderRadius:
                                            BorderRadiusStyle.roundedBorder30,
                                      ),
                                      child: Stack(
                                        children: [
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgImage7631x58,
                                            height: getVerticalSize(
                                              31,
                                            ),
                                            width: getHorizontalSize(
                                              58,
                                            ),
                                            radius: BorderRadius.circular(
                                              getHorizontalSize(
                                                10,
                                              ),
                                            ),
                                            alignment: Alignment.bottomCenter,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      left: 17,
                                      top: 18,
                                      bottom: 16,
                                    ),
                                    child: Text(
                                      "lbl_dunkin_donuts".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterRegular21Black900,
                                    ),
                                  ),
                                  Spacer(),
                                  Padding(
                                    padding: getPadding(
                                      top: 21,
                                      bottom: 17,
                                    ),
                                    child: Text(
                                      "lbl_200".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterRegular18Black900,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                left: 1,
                                top: 10,
                                right: 1,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomImageView(
                                    imagePath: ImageConstant.imgImage7757x60,
                                    height: getVerticalSize(
                                      57,
                                    ),
                                    width: getHorizontalSize(
                                      60,
                                    ),
                                    radius: BorderRadius.circular(
                                      getHorizontalSize(
                                        28,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      left: 17,
                                      top: 8,
                                      bottom: 22,
                                    ),
                                    child: Text(
                                      "lbl_kfc".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterRegular21Black900,
                                    ),
                                  ),
                                  Spacer(),
                                  Padding(
                                    padding: getPadding(
                                      top: 10,
                                      bottom: 24,
                                    ),
                                    child: Text(
                                      "lbl_150".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterRegular18Black900,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                top: 10,
                                right: 1,
                                bottom: 2,
                              ),
                              child: Row(
                                children: [
                                  Card(
                                    clipBehavior: Clip.antiAlias,
                                    elevation: 0,
                                    margin: EdgeInsets.all(0),
                                    color: ColorConstant.gray100,
                                    shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder30,
                                    ),
                                    child: Container(
                                      height: getVerticalSize(
                                        61,
                                      ),
                                      width: getHorizontalSize(
                                        60,
                                      ),
                                      padding: getPadding(
                                        left: 8,
                                        top: 10,
                                        right: 8,
                                        bottom: 10,
                                      ),
                                      decoration:
                                          AppDecoration.fillGray100.copyWith(
                                        borderRadius:
                                            BorderRadiusStyle.roundedBorder30,
                                      ),
                                      child: Stack(
                                        children: [
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgImage7840x43,
                                            height: getVerticalSize(
                                              40,
                                            ),
                                            width: getHorizontalSize(
                                              43,
                                            ),
                                            radius: BorderRadius.circular(
                                              getHorizontalSize(
                                                10,
                                              ),
                                            ),
                                            alignment: Alignment.center,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      left: 18,
                                      top: 17,
                                      bottom: 17,
                                    ),
                                    child: Text(
                                      "lbl_el_pollo_loco".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterRegular21Black900,
                                    ),
                                  ),
                                  Spacer(),
                                  Padding(
                                    padding: getPadding(
                                      top: 19,
                                      bottom: 19,
                                    ),
                                    child: Text(
                                      "lbl_50".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterRegular18Black900,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          margin: getMargin(
                            left: 12,
                            top: 37,
                            right: 25,
                            bottom: 164,
                          ),
                          padding: getPadding(
                            left: 12,
                            top: 7,
                            right: 12,
                            bottom: 7,
                          ),
                          decoration: AppDecoration.outlinePink700017.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder10,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: getPadding(
                                  left: 2,
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomImageView(
                                      imagePath:
                                          ImageConstant.imgPullcreditcard3,
                                      height: getVerticalSize(
                                        39,
                                      ),
                                      width: getHorizontalSize(
                                        69,
                                      ),
                                      radius: BorderRadius.circular(
                                        getHorizontalSize(
                                          3,
                                        ),
                                      ),
                                      margin: getMargin(
                                        top: 2,
                                        bottom: 6,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        left: 8,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Align(
                                            alignment: Alignment.center,
                                            child: Text(
                                              "lbl_discover_it".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterBold18Black90099,
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 4,
                                            ),
                                            child: Text(
                                              "lbl_cash_back3".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular18Black90099,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 5,
                                ),
                                child: Divider(
                                  height: getVerticalSize(
                                    1,
                                  ),
                                  thickness: getVerticalSize(
                                    1,
                                  ),
                                  color: ColorConstant.gray400,
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  left: 2,
                                  top: 6,
                                  bottom: 8,
                                ),
                                child: Row(
                                  children: [
                                    Card(
                                      clipBehavior: Clip.antiAlias,
                                      elevation: 0,
                                      margin: EdgeInsets.all(0),
                                      color: ColorConstant.gray10002,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadiusStyle.roundedBorder30,
                                      ),
                                      child: Container(
                                        height: getVerticalSize(
                                          61,
                                        ),
                                        width: getHorizontalSize(
                                          60,
                                        ),
                                        decoration: AppDecoration.fillGray10002
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder30,
                                        ),
                                        child: Stack(
                                          children: [
                                            CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage82,
                                              height: getSize(
                                                60,
                                              ),
                                              width: getSize(
                                                60,
                                              ),
                                              radius: BorderRadius.circular(
                                                getHorizontalSize(
                                                  30,
                                                ),
                                              ),
                                              alignment: Alignment.center,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        left: 17,
                                        top: 18,
                                        bottom: 16,
                                      ),
                                      child: Text(
                                        "lbl_dunkin_donuts".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular21Black900,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        left: 60,
                                        top: 21,
                                        bottom: 17,
                                      ),
                                      child: Text(
                                        "lbl_350".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular18Black900,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
