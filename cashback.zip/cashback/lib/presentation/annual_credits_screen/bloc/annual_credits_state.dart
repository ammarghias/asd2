// ignore_for_file: must_be_immutable

part of 'annual_credits_bloc.dart';

/// Represents the state of AnnualCredits in the application.
class AnnualCreditsState extends Equatable {
  AnnualCreditsState({this.annualCreditsModelObj});

  AnnualCreditsModel? annualCreditsModelObj;

  @override
  List<Object?> get props => [
        annualCreditsModelObj,
      ];
  AnnualCreditsState copyWith({AnnualCreditsModel? annualCreditsModelObj}) {
    return AnnualCreditsState(
      annualCreditsModelObj:
          annualCreditsModelObj ?? this.annualCreditsModelObj,
    );
  }
}
