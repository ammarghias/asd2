import 'package:flutter_svg/flutter_svg.dart';

import 'bloc/login_error_page_bloc.dart';
import 'models/login_error_page_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_button.dart';
import 'package:ammar_s_application6/widgets/custom_icon_button.dart';
import 'package:ammar_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

class LoginErrorPageScreen extends StatefulWidget {
  const LoginErrorPageScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<LoginErrorPageBloc>(
        create: (context) => LoginErrorPageBloc(
            LoginErrorPageState(loginErrorPageModelObj: LoginErrorPageModel()))
          ..add(LoginErrorPageInitialEvent()),
        child: LoginErrorPageScreen());
  }

  @override
  State<LoginErrorPageScreen> createState() => _LoginErrorPageScreenState();
}

class _LoginErrorPageScreenState extends State<LoginErrorPageScreen> {
  @override
  Widget build(BuildContext context) {
    bool nb=false;
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            appBar: CustomAppBar(
                height: getVerticalSize(115),
                centerTitle: true,
                title: SizedBox(
                    height: getVerticalSize(115.24),
                    width: getHorizontalSize(390),
                    child: Stack(alignment: Alignment.bottomCenter, children: [
                      AppbarImage(
                          height: getVerticalSize(106),
                          width: getHorizontalSize(390),
                          imagePath: ImageConstant.imgFrame70,
                          margin: getMargin(bottom: 9)),
                      Align(
                          alignment: Alignment.bottomCenter,
                          child: Padding(
                              padding: getPadding(left: 91, top: 94, right: 92),
                              child: Text("msg_reward_maximization".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: AppStyle.txtInterRegular17)))
                    ]))),
            body: Center(
              child: SizedBox(
                  width: size.width,
                  child: SingleChildScrollView(
                      padding: getPadding(top: 57),
                      child: Padding(
                          padding: getPadding(left: 16, right: 14, bottom: 5),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text("lbl_welcome".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular25),
                                Padding(
                                    padding:
                                        getPadding(left: 3, top: 16, right: 57),
                                    child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                              padding: getPadding(bottom: 1),
                                              child: Text(
                                                  "msg_don_t_have_an_account"
                                                      .tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular17Gray600)),
                                          GestureDetector(
                                              onTap: () {
                                                onTapTxtSignuphyperlink(
                                                    context);
                                              },
                                              child: Padding(
                                                  padding: getPadding(
                                                      left: 10, top: 1),
                                                  child: Text(
                                                      "lbl_sign_up_here".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterRegular17Pink700
                                                          .copyWith(
                                                              decoration:
                                                                  TextDecoration
                                                                      .underline))))
                                        ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 71),
                                    child: Text("lbl_email_address".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterMedium17)),
                                Container(
                                    height: getVerticalSize(51),
                                    width: getHorizontalSize(342),
                                    margin: getMargin(left: 3, top: 10),
                                    child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Align(
                                              alignment: Alignment.center,
                                              child: Stack(
                                                  alignment:
                                                      Alignment.center,
                                                  children: [
                                                    Align(
                                                        alignment: Alignment
                                                            .center,
                                                        child: Container(
                                                            width:
                                                                getHorizontalSize(
                                                                    342),
                                                            padding:
                                                                getPadding(
                                                                    left:
                                                                        15,
                                                                    right:
                                                                        15),
                                                            decoration: BoxDecoration(
                                                                borderRadius: BorderRadiusStyle.roundedBorder15,
                                                                image: DecorationImage(
                                                                    image: fs.Svg(
                                                                      ImageConstant
                                                                          .imgButtonProfileStatedefault,
                                                                    ),
                                                                    fit: BoxFit.cover)),
                                                            child: Row(children: []))),
                                                    Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: TextField(
//    ...,other fields
                                                        decoration:
                                                            InputDecoration(
                                                          enabledBorder:
                                                              OutlineInputBorder(
                                                            borderSide: BorderSide(
                                                                width: 3,
                                                                color: Colors
                                                                    .greenAccent), //<-- SEE HERE
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                          prefixIconConstraints:
                                                              BoxConstraints(
                                                            minHeight: 32,
                                                            minWidth: 32,
                                                          ),
                                                          prefixIcon:
                                                              Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    10,
                                                                    0,
                                                                    0,
                                                                    0),
                                                            child: SvgPicture.asset(
                                                                ImageConstant
                                                                    .imgButtonProfileStatedefault,
                                                                //  ImageConstant
                                                                //                                                                           .imgRectangle3,
                                                                color: Colors
                                                                    .grey,
                                                                height: 3,
                                                                width: 10,
                                                                semanticsLabel:
                                                                    'Label'),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ]))
                                        ])),
                                Padding(
                                    padding: getPadding(left: 4, top: 18),
                                    child: Text("lbl_password".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterMedium17)),
                                Container(
                                    height: getVerticalSize(52),
                                    width: getHorizontalSize(341),
                                    margin: getMargin(left: 4, top: 5),
                                    child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          // Align(
                                          //     alignment: Alignment.centerLeft,
                                          //     child: Padding(
                                          //         padding: getPadding(left: 68),
                                          //         child: Text(
                                          //             "lbl_enter_password".tr,
                                          //             overflow:
                                          //                 TextOverflow.ellipsis,
                                          //             textAlign: TextAlign.left,
                                          //             style: AppStyle
                                          //                 .txtInterMedium15Gray400))),
                                          // Align(
                                          //     alignment: Alignment.center,
                                          //     child: Container(
                                          //         width: getHorizontalSize(341),
                                          //         margin: getMargin(top: 1),
                                          //         padding: getPadding(
                                          //             left: 18, right: 18),
                                          //         decoration: BoxDecoration(
                                          //             borderRadius:
                                          //                 BorderRadiusStyle
                                          //                     .roundedBorder15,
                                          //             image: DecorationImage(
                                          //                 image: fs.Svg(
                                          //                     ImageConstant
                                          //                         .imgRectangle3),
                                          //                 fit: BoxFit.cover)),
                                          //         child: Row(
                                          //             mainAxisAlignment:
                                          //                 MainAxisAlignment
                                          //                     .spaceBetween,
                                          //             children: [
                                          //               Padding(
                                          //                   padding: getPadding(
                                          //                       left: 40),
                                          //                   child: SizedBox(
                                          //                       height:
                                          //                           getVerticalSize(
                                          //                               51),
                                          //                       child: VerticalDivider(
                                          //                           width:
                                          //                               getHorizontalSize(
                                          //                                   1),
                                          //                           thickness:
                                          //                               getVerticalSize(
                                          //                                   1),
                                          //                           color: ColorConstant
                                          //                               .gray200))),
                                          //               Container(
                                          //                   height:
                                          //                       getVerticalSize(
                                          //                           20),
                                          //                   width:
                                          //                       getHorizontalSize(
                                          //                           19),
                                          //                   margin: getMargin(
                                          //                       top: 15,
                                          //                       bottom: 15),
                                          //                   child: Stack(
                                          //                       alignment:
                                          //                           Alignment
                                          //                               .center,
                                          //                       children: [
                                          //                         CustomImageView(
                                          //                             svgPath:
                                                                          // ImageConstant
                                                                          //     .imgVector,
                                          //                             height:
                                          //                                 getSize(
                                          //                                     6),
                                          //                             width:
                                          //                                 getSize(
                                          //                                     6),
                                          //                             alignment:
                                          //                                 Alignment
                                          //                                     .center),
                                          //                         CustomImageView(
                                          //                             svgPath:
                                          //                                 ImageConstant
                                          //                                     .imgRefresh,
                                          //                             height:
                                          //                                 getVerticalSize(
                                          //                                     14),
                                          //                             width:
                                          //                                 getHorizontalSize(
                                          //                                     19),
                                          //                             alignment:
                                          //                                 Alignment
                                          //                                     .center),
                                          //                         Align(
                                          //                             alignment:
                                          //                                 Alignment
                                          //                                     .centerLeft,
                                          //                             child: SizedBox(
                                          //                                 child: Divider(
                                          //                                     height: getVerticalSize(20),
                                          //                                     thickness: getVerticalSize(20),
                                          //                                     color: ColorConstant.gray60001,
                                          //                                     indent: getHorizontalSize(4))))
                                          //                       ]))
                                          //             ]))),
                                          // BlocSelector<
                                          //         LoginErrorPageBloc,
                                          //         LoginErrorPageState,
                                          //         TextEditingController?>(
                                          //     selector: (state) =>
                                          //         state.group120Controller,
                                          //     builder: (context,
                                          //         group120Controller) {
                                          //       return CustomTextFormField(
                                          //           width:
                                          //               getHorizontalSize(58),
                                          //           focusNode: FocusNode(),
                                          //           autofocus: true,
                                          //           controller:
                                          //               group120Controller,
                                          //           variant:
                                          //               TextFormFieldVariant
                                          //                   .FillBluegray50,
                                          //           shape: TextFormFieldShape
                                          //               .CustomBorderTL16,
                                          //           textInputAction:
                                          //               TextInputAction.done,
                                          //           alignment:
                                          //               Alignment.centerLeft,
                                          //           suffix: Container(
                                          //               margin: getMargin(
                                          //                   left: 17,
                                          //                   top: 11,
                                          //                   right: 17,
                                          //                   bottom: 13),
                                          //               child: CustomImageView(
                                          //                   svgPath: ImageConstant
                                          //                       .imgPasswordIcon)),
                                          //           suffixConstraints:
                                          //               BoxConstraints(
                                          //                   maxHeight:
                                          //                       getVerticalSize(
                                          //                           51)));
                                          //     }),
                                         Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: TextField(
//    ...,other fields
                                                        decoration:
                                                            InputDecoration(
                                                          enabledBorder:
                                                              OutlineInputBorder(
                                                            borderSide: BorderSide(
                                                                width: 3,
                                                                color: Colors
                                                                    .greenAccent), //<-- SEE HERE
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                          prefixIconConstraints:
                                                              BoxConstraints(
                                                            minHeight: 32,
                                                            minWidth: 32,
                                                          ),
                                                          prefixIcon:
                                                              Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    10,
                                                                    0,
                                                                    0,
                                                                    0),
                                                            child: SvgPicture.asset(
                                                              ImageConstant
                                                           .imgPasswordIcon,
                                                                //  ImageConstant
                                                                //                                                                           .imgRectangle3,
                                                                color: Colors
                                                                    .grey,
                                                                height: 3,
                                                                width: 10,
                                                                semanticsLabel:
                                                                    'Label'),
                                                          ),
                                                        ),
                                                      ),
                                                    ),])),
                                Align(
                                    alignment: Alignment.center,
                                    child: Padding(
                                        padding: getPadding(
                                            left: 6, top: 24, right: 15),
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                        
                                        CustomButton(
                                                  width: getHorizontalSize(145),
                                                  text: "lbl_remember_me".tr,
                                               
                                                  fontStyle: ButtonFontStyle
                                                      .InterRegular17,
                                                  prefixWidget: Container(
                                                     
                                                        
                                                      decoration:
                                                          BoxDecoration(),
                                                      child:    Checkbox(
                          value: nb, onChanged: (bool? value) {  setState(() {nb=value!; });},
                          
                        ),          )),
                                              GestureDetector(
                                                  onTap: () {
                                                    onTapTxtForgotpassword(
                                                        context);
                                                  },
                                                  child: Padding(
                                                      padding:
                                                          getPadding(top: 1),
                                                      child: Text(
                                                          "msg_forgot_password"
                                                              .tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterMedium15Gray60002
                                                              .copyWith(
                                                                  decoration:
                                                                      TextDecoration
                                                                          .underline))))
                                            ]))),
                                CustomButton(
                                    height: getVerticalSize(51),
                                    width: getHorizontalSize(224),
                                    text: "lbl_sign_in".tr,
                                    margin: getMargin(top: 32),
                                    variant: ButtonVariant.OutlinePink70001_1,
                                    fontStyle:
                                        ButtonFontStyle.InterBold15Pink70001,
                                    onTap: () {
                                      onTapSignin(context);
                                    },
                                    alignment: Alignment.center),
                                Container(
                                    height: getVerticalSize(42),
                                    width: getHorizontalSize(354),
                                    margin: getMargin(left: 6, top: 13),
                                    child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Align(
                                              alignment: Alignment.topCenter,
                                              child: Padding(
                                                  padding: getPadding(top: 20),
                                                  child: SizedBox(
                                                      width: getHorizontalSize(
                                                          354),
                                                      child: Divider(
                                                          height:
                                                              getVerticalSize(
                                                                  1),
                                                          thickness:
                                                              getVerticalSize(
                                                                  1),
                                                          color: ColorConstant
                                                              .blueGray100)))),
                                          CustomButton(
                                              height: getVerticalSize(42),
                                              width: getSize(42),
                                              text: "lbl_or".tr,
                                              variant:
                                                  ButtonVariant.FillWhiteA700,
                                              shape: ButtonShape.Square,
                                              padding:
                                                  ButtonPadding.PaddingAll11,
                                              fontStyle:
                                                  ButtonFontStyle.InterMedium15,
                                              alignment: Alignment.center)
                                        ])),
                                CustomButton(
                                    height: getVerticalSize(51),
                                    width: getHorizontalSize(224),
                                    text: "msg_register_with_us".tr,
                                    margin: getMargin(top: 11),
                                    onTap: () {
                                      onTapRegisterwith(context);
                                    },
                                    alignment: Alignment.center)
                              ])))),
            )));
  }

  /// Navigates to the registrationOneScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the `NavigatorService`
  /// to push the named route for the registrationOneScreen.
  onTapTxtSignuphyperlink(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.registrationOneScreen,
    );
  }

  /// Navigates to the passwordResetPageOneScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the `NavigatorService`
  /// to push the named route for the passwordResetPageOneScreen.
  onTapTxtForgotpassword(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.passwordResetPageOneScreen,
    );
  }

  /// Navigates to the homePageScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the `NavigatorService`
  /// to push the named route for the homePageScreen.
  onTapSignin(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.homePageScreen,
    );
  }

  /// Navigates to the registrationOneScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the `NavigatorService`
  /// to push the named route for the registrationOneScreen.
  onTapRegisterwith(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.registrationOneScreen,
    );
  }
}
