// ignore_for_file: must_be_immutable

part of 'login_error_page_bloc.dart';

/// Represents the state of LoginErrorPage in the application.
class LoginErrorPageState extends Equatable {
  LoginErrorPageState({
    this.group120Controller,
    this.loginErrorPageModelObj,
  });

  TextEditingController? group120Controller;

  LoginErrorPageModel? loginErrorPageModelObj;

  @override
  List<Object?> get props => [
        group120Controller,
        loginErrorPageModelObj,
      ];
  LoginErrorPageState copyWith({
    TextEditingController? group120Controller,
    LoginErrorPageModel? loginErrorPageModelObj,
  }) {
    return LoginErrorPageState(
      group120Controller: group120Controller ?? this.group120Controller,
      loginErrorPageModelObj:
          loginErrorPageModelObj ?? this.loginErrorPageModelObj,
    );
  }
}
