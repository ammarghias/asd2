import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application6/presentation/login_error_page_screen/models/login_error_page_model.dart';part 'login_error_page_event.dart';part 'login_error_page_state.dart';/// A bloc that manages the state of a LoginErrorPage according to the event that is dispatched to it.
class LoginErrorPageBloc extends Bloc<LoginErrorPageEvent, LoginErrorPageState> {LoginErrorPageBloc(LoginErrorPageState initialState) : super(initialState) { on<LoginErrorPageInitialEvent>(_onInitialize); }

_onInitialize(LoginErrorPageInitialEvent event, Emitter<LoginErrorPageState> emit, ) async  { emit(state.copyWith(group120Controller: TextEditingController())); } 
 }
