import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/registraion_3_welcome_six_screen/models/registraion_3_welcome_six_model.dart';
part 'registraion_3_welcome_six_event.dart';
part 'registraion_3_welcome_six_state.dart';

/// A bloc that manages the state of a Registraion3WelcomeSix according to the event that is dispatched to it.
class Registraion3WelcomeSixBloc
    extends Bloc<Registraion3WelcomeSixEvent, Registraion3WelcomeSixState> {
  Registraion3WelcomeSixBloc(Registraion3WelcomeSixState initialState)
      : super(initialState) {
    on<Registraion3WelcomeSixInitialEvent>(_onInitialize);
  }

  _onInitialize(
    Registraion3WelcomeSixInitialEvent event,
    Emitter<Registraion3WelcomeSixState> emit,
  ) async {}
}
