// ignore_for_file: must_be_immutable

part of 'password_reset_page_one_bloc.dart';

/// Represents the state of PasswordResetPageOne in the application.
class PasswordResetPageOneState extends Equatable {
  PasswordResetPageOneState({
    this.rectangle622Controller,
    this.group327Controller,
    this.passwordResetPageOneModelObj,
  });

  TextEditingController? rectangle622Controller;

  TextEditingController? group327Controller;

  PasswordResetPageOneModel? passwordResetPageOneModelObj;

  @override
  List<Object?> get props => [
        rectangle622Controller,
        group327Controller,
        passwordResetPageOneModelObj,
      ];
  PasswordResetPageOneState copyWith({
    TextEditingController? rectangle622Controller,
    TextEditingController? group327Controller,
    PasswordResetPageOneModel? passwordResetPageOneModelObj,
  }) {
    return PasswordResetPageOneState(
      rectangle622Controller:
          rectangle622Controller ?? this.rectangle622Controller,
      group327Controller: group327Controller ?? this.group327Controller,
      passwordResetPageOneModelObj:
          passwordResetPageOneModelObj ?? this.passwordResetPageOneModelObj,
    );
  }
}
