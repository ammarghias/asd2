import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application6/presentation/password_reset_page_one_screen/models/password_reset_page_one_model.dart';part 'password_reset_page_one_event.dart';part 'password_reset_page_one_state.dart';/// A bloc that manages the state of a PasswordResetPageOne according to the event that is dispatched to it.
class PasswordResetPageOneBloc extends Bloc<PasswordResetPageOneEvent, PasswordResetPageOneState> {PasswordResetPageOneBloc(PasswordResetPageOneState initialState) : super(initialState) { on<PasswordResetPageOneInitialEvent>(_onInitialize); }

_onInitialize(PasswordResetPageOneInitialEvent event, Emitter<PasswordResetPageOneState> emit, ) async  { emit(state.copyWith(rectangle622Controller: TextEditingController(), group327Controller: TextEditingController()));Future.delayed(const Duration(milliseconds: 3000), (){
NavigatorService.popAndPushNamed(AppRoutes.loginErrorPageScreen, );}); } 
 }
