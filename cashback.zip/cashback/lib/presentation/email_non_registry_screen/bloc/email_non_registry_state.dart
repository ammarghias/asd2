// ignore_for_file: must_be_immutable

part of 'email_non_registry_bloc.dart';

/// Represents the state of EmailNonRegistry in the application.
class EmailNonRegistryState extends Equatable {
  EmailNonRegistryState({
    this.usernameController,
    this.emailNonRegistryModelObj,
  });

  TextEditingController? usernameController;

  EmailNonRegistryModel? emailNonRegistryModelObj;

  @override
  List<Object?> get props => [
        usernameController,
        emailNonRegistryModelObj,
      ];
  EmailNonRegistryState copyWith({
    TextEditingController? usernameController,
    EmailNonRegistryModel? emailNonRegistryModelObj,
  }) {
    return EmailNonRegistryState(
      usernameController: usernameController ?? this.usernameController,
      emailNonRegistryModelObj:
          emailNonRegistryModelObj ?? this.emailNonRegistryModelObj,
    );
  }
}
