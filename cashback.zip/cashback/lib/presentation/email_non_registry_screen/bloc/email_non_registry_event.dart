// ignore_for_file: must_be_immutable

part of 'email_non_registry_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///EmailNonRegistry widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class EmailNonRegistryEvent extends Equatable {}

/// Event that is dispatched when the EmailNonRegistry widget is first created.
class EmailNonRegistryInitialEvent extends EmailNonRegistryEvent {
  @override
  List<Object?> get props => [];
}
