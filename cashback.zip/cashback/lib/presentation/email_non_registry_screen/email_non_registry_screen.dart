import 'bloc/email_non_registry_bloc.dart';
import 'models/email_non_registry_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/core/utils/validation_functions.dart';
import 'package:ammar_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

class EmailNonRegistryScreen extends StatelessWidget {
  EmailNonRegistryScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<EmailNonRegistryBloc>(
      create: (context) => EmailNonRegistryBloc(EmailNonRegistryState(
        emailNonRegistryModelObj: EmailNonRegistryModel(),
      ))
        ..add(EmailNonRegistryInitialEvent()),
      child: EmailNonRegistryScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: getHorizontalSize(
              390,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        CustomImageView(
                          svgPath: ImageConstant.imgFrame69,
                          height: getVerticalSize(
                            107,
                          ),
                          width: getHorizontalSize(
                            390,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 19,
                            top: 36,
                          ),
                          child: Text(
                            "lbl_contact_us".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular25,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 21,
                            top: 13,
                          ),
                          child: Text(
                            "msg_we_would_love_to".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular17Gray600,
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                            padding: getPadding(
                              left: 57,
                              top: 21,
                              right: 28,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    bottom: 6,
                                  ),
                                  child: Text(
                                    "lbl_from".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterBold17,
                                  ),
                                ),
                                Expanded(
                                  child: BlocSelector<
                                      EmailNonRegistryBloc,
                                      EmailNonRegistryState,
                                      TextEditingController?>(
                                    selector: (state) =>
                                        state.usernameController,
                                    builder: (context, usernameController) {
                                      return CustomTextFormField(
                                        focusNode: FocusNode(),
                                        autofocus: true,
                                        controller: usernameController,
                                        hintText: "lbl_user_name".tr,
                                        margin: getMargin(
                                          left: 9,
                                        ),
                                        variant: TextFormFieldVariant
                                            .UnderLineBlack900,
                                        fontStyle: TextFormFieldFontStyle
                                            .InterMedium17,
                                        textInputAction: TextInputAction.done,
                                        validator: (value) {
                                          if (!isText(value)) {
                                            return "Please enter valid text";
                                          }
                                          return null;
                                        },
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                            padding: getPadding(
                              left: 57,
                              top: 13,
                              right: 24,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    bottom: 6,
                                  ),
                                  child: Text(
                                    "lbl_email".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterBold17,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: getPadding(
                                      left: 10,
                                      top: 1,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          "msg_user_email_address".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterMedium17Gray50001,
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            top: 4,
                                          ),
                                          child: Divider(
                                            height: getVerticalSize(
                                              1,
                                            ),
                                            thickness: getVerticalSize(
                                              1,
                                            ),
                                            color: ColorConstant.black900,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 23,
                            top: 35,
                            right: 92,
                          ),
                          child: Row(
                            children: [
                              Text(
                                "lbl_subject".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterBold17,
                              ),
                              Padding(
                                padding: getPadding(
                                  left: 10,
                                ),
                                child: Text(
                                  "msg_we_re_sorry_to_hear".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterMedium17Black900,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                            width: getHorizontalSize(
                              221,
                            ),
                            margin: getMargin(
                              top: 25,
                              right: 66,
                            ),
                            child: Text(
                              "msg_please_let_us_know".tr,
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular17Black900,
                            ),
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 26,
                            top: 23,
                          ),
                          child: Text(
                            "lbl_message".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterBold17,
                          ),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            height: getVerticalSize(
                              409,
                            ),
                            width: getHorizontalSize(
                              336,
                            ),
                            margin: getMargin(
                              top: 18,
                              bottom: 43,
                            ),
                            child: Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                Align(
                                  alignment: Alignment.topCenter,
                                  child: Container(
                                    height: getVerticalSize(
                                      384,
                                    ),
                                    width: getHorizontalSize(
                                      336,
                                    ),
                                    decoration: BoxDecoration(
                                      color: ColorConstant.whiteA700,
                                      borderRadius: BorderRadius.circular(
                                        getHorizontalSize(
                                          20,
                                        ),
                                      ),
                                      border: Border.all(
                                        color: ColorConstant.pink700,
                                        width: getHorizontalSize(
                                          1,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Container(
                                    margin: getMargin(
                                      left: 56,
                                      right: 56,
                                    ),
                                    padding: getPadding(
                                      left: 85,
                                      top: 15,
                                      right: 85,
                                      bottom: 15,
                                    ),
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder15,
                                      image: DecorationImage(
                                        image: fs.Svg(
                                          ImageConstant.imgGroup20,
                                        ),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          "lbl_submit".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle.txtInterBold15,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
