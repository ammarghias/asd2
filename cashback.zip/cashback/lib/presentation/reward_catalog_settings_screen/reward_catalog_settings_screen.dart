import 'bloc/reward_catalog_settings_bloc.dart';
import 'models/reward_catalog_settings_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

class RewardCatalogSettingsScreen extends StatelessWidget {
  RewardCatalogSettingsScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<RewardCatalogSettingsBloc>(
      create: (context) => RewardCatalogSettingsBloc(RewardCatalogSettingsState(
        rewardCatalogSettingsModelObj: RewardCatalogSettingsModel(),
      ))
        ..add(RewardCatalogSettingsInitialEvent()),
      child: RewardCatalogSettingsScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<RewardCatalogSettingsBloc, RewardCatalogSettingsState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: SizedBox(
              width: double.maxFinite,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  CustomImageView(
                    svgPath: ImageConstant.imgHeader,
                    height: getVerticalSize(
                      131,
                    ),
                    width: getHorizontalSize(
                      393,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 26,
                      top: 57,
                    ),
                    child: Text(
                      "msg_reward_catalog_settings2".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterRegular25Black900,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 7,
                    ),
                    child: Divider(
                      height: getVerticalSize(
                        1,
                      ),
                      thickness: getVerticalSize(
                        1,
                      ),
                      color: ColorConstant.gray80001,
                      indent: getHorizontalSize(
                        26,
                      ),
                      endIndent: getHorizontalSize(
                        75,
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 26,
                      top: 31,
                    ),
                    child: Text(
                      "msg_disable_external".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium21Bluegray400,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 26,
                      top: 4,
                      right: 40,
                    ),
                    child: Row(
                      children: [
                        CustomImageView(
                          svgPath: ImageConstant.imgSelectButton,
                          height: getVerticalSize(
                            20,
                          ),
                          width: getHorizontalSize(
                            22,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 13,
                            bottom: 1,
                          ),
                          child: Text(
                            "msg_links_to_all_external".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterMedium15Bluegray400,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 26,
                      top: 48,
                    ),
                    child: Text(
                      "msg_disable_elite_cards".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium21Bluegray400,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 26,
                      top: 4,
                      right: 47,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomImageView(
                          svgPath: ImageConstant.imgSelectButton,
                          height: getVerticalSize(
                            20,
                          ),
                          width: getHorizontalSize(
                            22,
                          ),
                          margin: getMargin(
                            bottom: 18,
                          ),
                        ),
                        Expanded(
                          child: Container(
                            width: getHorizontalSize(
                              284,
                            ),
                            margin: getMargin(
                              left: 13,
                            ),
                            child: Text(
                              "msg_all_cards_having".tr,
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium15Bluegray400,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 26,
                      top: 43,
                    ),
                    child: Text(
                      "msg_only_show_business".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium21Bluegray400,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 26,
                      top: 2,
                    ),
                    child: Row(
                      children: [
                        CustomImageView(
                          svgPath: ImageConstant.imgSelectButton,
                          height: getVerticalSize(
                            20,
                          ),
                          width: getHorizontalSize(
                            22,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 13,
                            top: 1,
                          ),
                          child: Text(
                            "msg_for_all_your_business".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterMedium15Bluegray400,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: getHorizontalSize(
                      253,
                    ),
                    margin: getMargin(
                      left: 26,
                      top: 39,
                    ),
                    child: Text(
                      "msg_i_ve_applied_for".tr,
                      maxLines: null,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium21Bluegray400,
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: getPadding(
                        left: 27,
                        top: 8,
                        right: 24,
                        bottom: 5,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomImageView(
                            svgPath: ImageConstant.imgSelectButton,
                            height: getVerticalSize(
                              20,
                            ),
                            width: getHorizontalSize(
                              22,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 13,
                              top: 1,
                            ),
                            child: Text(
                              "msg_replaces_cashback".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium15Bluegray400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
