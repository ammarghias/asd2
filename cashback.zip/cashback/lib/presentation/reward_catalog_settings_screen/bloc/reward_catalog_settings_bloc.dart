import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/reward_catalog_settings_screen/models/reward_catalog_settings_model.dart';
part 'reward_catalog_settings_event.dart';
part 'reward_catalog_settings_state.dart';

/// A bloc that manages the state of a RewardCatalogSettings according to the event that is dispatched to it.
class RewardCatalogSettingsBloc
    extends Bloc<RewardCatalogSettingsEvent, RewardCatalogSettingsState> {
  RewardCatalogSettingsBloc(RewardCatalogSettingsState initialState)
      : super(initialState) {
    on<RewardCatalogSettingsInitialEvent>(_onInitialize);
  }

  _onInitialize(
    RewardCatalogSettingsInitialEvent event,
    Emitter<RewardCatalogSettingsState> emit,
  ) async {}
}
