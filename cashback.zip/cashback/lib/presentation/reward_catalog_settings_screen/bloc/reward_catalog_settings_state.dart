// ignore_for_file: must_be_immutable

part of 'reward_catalog_settings_bloc.dart';

/// Represents the state of RewardCatalogSettings in the application.
class RewardCatalogSettingsState extends Equatable {
  RewardCatalogSettingsState({this.rewardCatalogSettingsModelObj});

  RewardCatalogSettingsModel? rewardCatalogSettingsModelObj;

  @override
  List<Object?> get props => [
        rewardCatalogSettingsModelObj,
      ];
  RewardCatalogSettingsState copyWith(
      {RewardCatalogSettingsModel? rewardCatalogSettingsModelObj}) {
    return RewardCatalogSettingsState(
      rewardCatalogSettingsModelObj:
          rewardCatalogSettingsModelObj ?? this.rewardCatalogSettingsModelObj,
    );
  }
}
