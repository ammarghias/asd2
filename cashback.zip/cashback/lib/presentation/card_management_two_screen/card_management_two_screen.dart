import '../card_management_two_screen/widgets/card_management1_item_widget.dart';
import 'bloc/card_management_two_bloc.dart';
import 'models/card_management1_item_model.dart';
import 'models/card_management_two_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/core/utils/validation_functions.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application6/widgets/custom_switch.dart';
import 'package:ammar_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class CardManagementTwoScreen extends StatelessWidget {
  CardManagementTwoScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<CardManagementTwoBloc>(
      create: (context) => CardManagementTwoBloc(CardManagementTwoState(
        cardManagementTwoModelObj: CardManagementTwoModel(),
      ))
        ..add(CardManagementTwoInitialEvent()),
      child: CardManagementTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        appBar: CustomAppBar(
          height: getVerticalSize(
            76,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink70001,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Padding(
              padding: getPadding(
                bottom: 5,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: getVerticalSize(
                      30,
                    ),
                    width: getHorizontalSize(
                      180,
                    ),
                    margin: getMargin(
                      left: 100,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            height: getVerticalSize(
                              27,
                            ),
                            width: getHorizontalSize(
                              180,
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.pink70001,
                              borderRadius: BorderRadius.circular(
                                getHorizontalSize(
                                  10,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            "lbl_card_management".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtHindVadodaraRegular20WhiteA700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    child: Container(
                      margin: getMargin(
                        top: 9,
                      ),
                      padding: getPadding(
                        left: 6,
                        top: 5,
                        right: 6,
                        bottom: 5,
                      ),
                      decoration: AppDecoration.fillWhiteA700,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: getPadding(
                              top: 1,
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    top: 2,
                                  ),
                                  child: Text(
                                    "lbl_welcome_offers2".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtStaatlichesRegular22,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 15,
                                    bottom: 14,
                                  ),
                                  child: SizedBox(
                                    width: getHorizontalSize(
                                      178,
                                    ),
                                    child: Divider(
                                      height: getVerticalSize(
                                        1,
                                      ),
                                      thickness: getVerticalSize(
                                        1,
                                      ),
                                      color: ColorConstant.gray400,
                                      indent: getHorizontalSize(
                                        3,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  height: getVerticalSize(
                                    29,
                                  ),
                                  width: getHorizontalSize(
                                    54,
                                  ),
                                  margin: getMargin(
                                    left: 11,
                                    bottom: 1,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.centerLeft,
                                    children: [
                                      BlocSelector<CardManagementTwoBloc,
                                          CardManagementTwoState, bool?>(
                                        selector: (state) =>
                                            state.isSelectedSwitch,
                                        builder: (context, isSelectedSwitch) {
                                          return CustomSwitch(
                                            alignment: Alignment.center,
                                            value: isSelectedSwitch,
                                            onChanged: (value) {
                                              context
                                                  .read<CardManagementTwoBloc>()
                                                  .add(ChangeSwitchEvent(
                                                      value: value));
                                            },
                                          );
                                        },
                                      ),
                                      CustomImageView(
                                        svgPath: ImageConstant.imgLogo,
                                        height: getVerticalSize(
                                          6,
                                        ),
                                        width: getHorizontalSize(
                                          42,
                                        ),
                                        alignment: Alignment.centerLeft,
                                        margin: getMargin(
                                          left: 4,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Text(
                            "msg_make_the_most_of".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular14,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 7,
                      top: 13,
                      right: 6,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: getPadding(
                            top: 1,
                            bottom: 58,
                          ),
                          child: Text(
                            "lbl_capital_one".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular17Gray60003,
                          ),
                        ),
                        Spacer(),
                        Container(
                          decoration: AppDecoration.outlineBlack9003f.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder7,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                padding: getPadding(
                                  left: 2,
                                ),
                                child: IntrinsicWidth(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding: getPadding(
                                          top: 1,
                                          bottom: 2,
                                        ),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            SizedBox(
                                              height: getVerticalSize(
                                                21,
                                              ),
                                              width: getHorizontalSize(
                                                172,
                                              ),
                                              child: Stack(
                                                alignment: Alignment.centerLeft,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.center,
                                                    child: Container(
                                                      height: getVerticalSize(
                                                        21,
                                                      ),
                                                      width: getHorizontalSize(
                                                        172,
                                                      ),
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(
                                                          getHorizontalSize(
                                                            10,
                                                          ),
                                                        ),
                                                        gradient:
                                                            LinearGradient(
                                                          begin: Alignment(
                                                            0.02,
                                                            0.52,
                                                          ),
                                                          end: Alignment(
                                                            1,
                                                            0.52,
                                                          ),
                                                          colors: [
                                                            ColorConstant
                                                                .gray20002,
                                                            ColorConstant
                                                                .gray20000,
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: Padding(
                                                      padding: getPadding(
                                                        left: 8,
                                                      ),
                                                      child: Text(
                                                        "lbl_capital_one".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular17Gray60003,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                top: 2,
                                              ),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgPullcreditcard2,
                                                    height: getVerticalSize(
                                                      54,
                                                    ),
                                                    width: getHorizontalSize(
                                                      90,
                                                    ),
                                                    radius:
                                                        BorderRadius.circular(
                                                      getHorizontalSize(
                                                        3,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: getVerticalSize(
                                                      53,
                                                    ),
                                                    width: getHorizontalSize(
                                                      82,
                                                    ),
                                                    margin: getMargin(
                                                      left: 2,
                                                      bottom: 1,
                                                    ),
                                                    child: Stack(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment
                                                              .bottomCenter,
                                                          child: Container(
                                                            margin: getMargin(
                                                              top: 3,
                                                            ),
                                                            padding: getPadding(
                                                              left: 2,
                                                              right: 2,
                                                            ),
                                                            decoration:
                                                                AppDecoration
                                                                    .outlineBluegray10001
                                                                    .copyWith(
                                                              borderRadius:
                                                                  BorderRadiusStyle
                                                                      .roundedBorder7,
                                                            ),
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .end,
                                                              children: [
                                                                Padding(
                                                                  padding:
                                                                      getPadding(
                                                                    top: 38,
                                                                  ),
                                                                  child: Text(
                                                                    "lbl_expires"
                                                                        .tr,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtInterRegular9Gray60004,
                                                                  ),
                                                                ),
                                                                Padding(
                                                                  padding:
                                                                      getPadding(
                                                                    left: 1,
                                                                    top: 37,
                                                                    bottom: 1,
                                                                  ),
                                                                  child: Text(
                                                                    "lbl_12_31_23"
                                                                        .tr,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtInterRegular9Gray60004,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Align(
                                                          alignment: Alignment
                                                              .topCenter,
                                                          child: Container(
                                                            height:
                                                                getVerticalSize(
                                                              24,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              82,
                                                            ),
                                                            decoration:
                                                                BoxDecoration(
                                                              color:
                                                                  ColorConstant
                                                                      .pink70001,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                getHorizontalSize(
                                                                  5,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Align(
                                                          alignment: Alignment
                                                              .topCenter,
                                                          child: Container(
                                                            margin: getMargin(
                                                              top: 3,
                                                            ),
                                                            padding: getPadding(
                                                              left: 2,
                                                              top: 1,
                                                              right: 2,
                                                              bottom: 1,
                                                            ),
                                                            decoration:
                                                                AppDecoration
                                                                    .outlinePink700012
                                                                    .copyWith(
                                                              borderRadius:
                                                                  BorderRadiusStyle
                                                                      .roundedBorder7,
                                                            ),
                                                            child: Column(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .min,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .end,
                                                              children: [
                                                                Padding(
                                                                  padding:
                                                                      getPadding(
                                                                    top: 21,
                                                                  ),
                                                                  child: Text(
                                                                    "lbl_reward_points2"
                                                                        .tr,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtInterRegular11Pink70001,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Align(
                                                          alignment: Alignment
                                                              .topRight,
                                                          child: Padding(
                                                            padding: getPadding(
                                                              top: 2,
                                                              right: 2,
                                                            ),
                                                            child: Text(
                                                              "lbl_x".tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterRegular17WhiteA700,
                                                            ),
                                                          ),
                                                        ),
                                                        Align(
                                                          alignment:
                                                              Alignment.topLeft,
                                                          child: Text(
                                                            "lbl_60_000".tr,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtInterRegular21,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          81,
                                        ),
                                        width: getHorizontalSize(
                                          179,
                                        ),
                                        margin: getMargin(
                                          left: 19,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                height: getVerticalSize(
                                                  81,
                                                ),
                                                width: getHorizontalSize(
                                                  179,
                                                ),
                                                decoration: BoxDecoration(
                                                  color:
                                                      ColorConstant.whiteA700,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                    getHorizontalSize(
                                                      5,
                                                    ),
                                                  ),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: ColorConstant
                                                          .black9003f,
                                                      spreadRadius:
                                                          getHorizontalSize(
                                                        2,
                                                      ),
                                                      blurRadius:
                                                          getHorizontalSize(
                                                        2,
                                                      ),
                                                      offset: Offset(
                                                        0,
                                                        4,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.center,
                                              child: Padding(
                                                padding: getPadding(
                                                  left: 2,
                                                  right: 3,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      height: getVerticalSize(
                                                        21,
                                                      ),
                                                      width: getHorizontalSize(
                                                        172,
                                                      ),
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(
                                                          getHorizontalSize(
                                                            10,
                                                          ),
                                                        ),
                                                        gradient:
                                                            LinearGradient(
                                                          begin: Alignment(
                                                            0.02,
                                                            0.52,
                                                          ),
                                                          end: Alignment(
                                                            1,
                                                            0.52,
                                                          ),
                                                          colors: [
                                                            ColorConstant
                                                                .gray20002,
                                                            ColorConstant
                                                                .gray20000,
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 2,
                                                      ),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: [
                                                          CustomImageView(
                                                            imagePath: ImageConstant
                                                                .imgPullcreditcard2,
                                                            height:
                                                                getVerticalSize(
                                                              54,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              90,
                                                            ),
                                                            radius: BorderRadius
                                                                .circular(
                                                              getHorizontalSize(
                                                                3,
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            height:
                                                                getVerticalSize(
                                                              53,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              82,
                                                            ),
                                                            margin: getMargin(
                                                              left: 2,
                                                              bottom: 1,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .topCenter,
                                                              children: [
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .bottomCenter,
                                                                  child:
                                                                      Container(
                                                                    margin:
                                                                        getMargin(
                                                                      top: 3,
                                                                    ),
                                                                    padding:
                                                                        getPadding(
                                                                      left: 2,
                                                                      top: 1,
                                                                      right: 2,
                                                                      bottom: 1,
                                                                    ),
                                                                    decoration: AppDecoration
                                                                        .outlineBluegray10001
                                                                        .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .roundedBorder7,
                                                                    ),
                                                                    child: Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .center,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .end,
                                                                      children: [
                                                                        Padding(
                                                                          padding:
                                                                              getPadding(
                                                                            top:
                                                                                36,
                                                                          ),
                                                                          child:
                                                                              Text(
                                                                            "lbl_expires".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterRegular9Gray60004,
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              getPadding(
                                                                            top:
                                                                                36,
                                                                          ),
                                                                          child:
                                                                              Text(
                                                                            "lbl_12_31_23".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterRegular9Gray60004,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topCenter,
                                                                  child:
                                                                      Container(
                                                                    height:
                                                                        getVerticalSize(
                                                                      24,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      82,
                                                                    ),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: ColorConstant
                                                                          .pink70001,
                                                                      borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                        getHorizontalSize(
                                                                          5,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topCenter,
                                                                  child:
                                                                      Container(
                                                                    margin:
                                                                        getMargin(
                                                                      top: 3,
                                                                    ),
                                                                    padding:
                                                                        getPadding(
                                                                      left: 2,
                                                                      top: 1,
                                                                      right: 2,
                                                                      bottom: 1,
                                                                    ),
                                                                    decoration: AppDecoration
                                                                        .outlinePink700012
                                                                        .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .roundedBorder7,
                                                                    ),
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .end,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .center,
                                                                      children: [
                                                                        Text(
                                                                          "lbl_x"
                                                                              .tr,
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          textAlign:
                                                                              TextAlign.left,
                                                                          style:
                                                                              AppStyle.txtInterRegular17WhiteA700,
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              getPadding(
                                                                            top:
                                                                                5,
                                                                            right:
                                                                                1,
                                                                            bottom:
                                                                                1,
                                                                          ),
                                                                          child:
                                                                              Text(
                                                                            "lbl_reward_points2".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterRegular11Pink70001,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topLeft,
                                                                  child: Text(
                                                                    "lbl_60_000"
                                                                        .tr,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtInterRegular21,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 27,
                            top: 1,
                            bottom: 58,
                          ),
                          child: Text(
                            "lbl_capital_one".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular17Gray60003,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      74,
                    ),
                    width: getHorizontalSize(
                      386,
                    ),
                    margin: getMargin(
                      left: 6,
                      top: 21,
                    ),
                    child: Stack(
                      alignment: Alignment.bottomRight,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Padding(
                            padding: getPadding(
                              right: 7,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Divider(
                                  height: getVerticalSize(
                                    1,
                                  ),
                                  thickness: getVerticalSize(
                                    1,
                                  ),
                                  color: ColorConstant.gray400,
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 2,
                                    top: 15,
                                    right: 20,
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: getPadding(
                                          top: 3,
                                          bottom: 6,
                                        ),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "lbl_quick_add".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtStaatlichesRegular22,
                                                ),
                                                Padding(
                                                  padding: getPadding(
                                                    left: 7,
                                                    top: 4,
                                                    bottom: 4,
                                                  ),
                                                  child: Text(
                                                    "lbl_wallet_manager".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtInterRegular15Gray4007f,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                top: 1,
                                              ),
                                              child: Text(
                                                "msg_your_own_personal".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtInterRegular14,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 72,
                                        ),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage65,
                                              height: getVerticalSize(
                                                35,
                                              ),
                                              width: getHorizontalSize(
                                                45,
                                              ),
                                              radius: BorderRadius.circular(
                                                getHorizontalSize(
                                                  3,
                                                ),
                                              ),
                                            ),
                                            Text(
                                              "lbl_your_wallet2".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtStaatlichesRegular18,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        CustomImageView(
                          imagePath: ImageConstant.imgRectangle69463x125,
                          height: getVerticalSize(
                            63,
                          ),
                          width: getHorizontalSize(
                            125,
                          ),
                          alignment: Alignment.bottomRight,
                        ),
                      ],
                    ),
                  ),
                  BlocSelector<CardManagementTwoBloc, CardManagementTwoState,
                      TextEditingController?>(
                    selector: (state) => state.nameController,
                    builder: (context, nameController) {
                      return CustomTextFormField(
                        focusNode: FocusNode(),
                        autofocus: true,
                        controller: nameController,
                        hintText: "msg_search_by_card_or".tr,
                        margin: getMargin(
                          left: 14,
                          top: 14,
                          right: 31,
                        ),
                        variant: TextFormFieldVariant.OutlinePink70001,
                        fontStyle: TextFormFieldFontStyle.InterRegular12,
                        textInputAction: TextInputAction.done,
                        suffix: Container(
                          padding: getPadding(
                            left: 15,
                            top: 8,
                            right: 15,
                            bottom: 6,
                          ),
                          margin: getMargin(
                            left: 30,
                            top: 4,
                            right: 4,
                            bottom: 4,
                          ),
                          decoration: BoxDecoration(
                            color: ColorConstant.pink70001,
                            borderRadius: BorderRadius.circular(
                              getHorizontalSize(
                                18,
                              ),
                            ),
                            border: Border.all(
                              color: ColorConstant.whiteA700,
                              width: getHorizontalSize(
                                3,
                              ),
                            ),
                          ),
                          child: CustomImageView(
                            svgPath: ImageConstant.imgSettings,
                          ),
                        ),
                        suffixConstraints: BoxConstraints(
                          maxHeight: getVerticalSize(
                            46,
                          ),
                        ),
                        validator: (value) {
                          if (!isText(value)) {
                            return "Please enter valid text";
                          }
                          return null;
                        },
                      );
                    },
                  ),
                  Padding(
                    padding: getPadding(
                      left: 19,
                      top: 8,
                      right: 35,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: getHorizontalSize(
                            67,
                          ),
                          margin: getMargin(
                            bottom: 2,
                          ),
                          child: Text(
                            "msg_no_financial_details".tr,
                            maxLines: null,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular10,
                          ),
                        ),
                        Container(
                          width: getHorizontalSize(
                            65,
                          ),
                          margin: getMargin(
                            left: 24,
                          ),
                          child: Text(
                            "msg_no_account_linking".tr,
                            maxLines: null,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular10,
                          ),
                        ),
                        Container(
                          width: getHorizontalSize(
                            42,
                          ),
                          margin: getMargin(
                            left: 24,
                            bottom: 2,
                          ),
                          child: Text(
                            "lbl_click_save".tr,
                            maxLines: null,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular10,
                          ),
                        ),
                        Container(
                          width: getHorizontalSize(
                            88,
                          ),
                          margin: getMargin(
                            left: 25,
                          ),
                          child: Text(
                            "msg_rewards_simple".tr,
                            maxLines: null,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular10,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 11,
                      top: 14,
                    ),
                    child: Text(
                      "lbl_we_support".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterRegular19,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 11,
                      top: 11,
                      right: 6,
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: getPadding(
                            top: 3,
                            bottom: 3,
                          ),
                          decoration: AppDecoration.outlineGray300.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder10,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgImage7370x93,
                                height: getVerticalSize(
                                  70,
                                ),
                                width: getHorizontalSize(
                                  85,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    7,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  left: 21,
                                  top: 9,
                                  bottom: 8,
                                ),
                                child: Text(
                                  "lbl_chase".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular11,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: getMargin(
                            left: 8,
                          ),
                          padding: getPadding(
                            all: 3,
                          ),
                          decoration: AppDecoration.outlineGray300.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder10,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgImage731,
                                height: getVerticalSize(
                                  70,
                                ),
                                width: getHorizontalSize(
                                  93,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    7,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 8,
                                  bottom: 9,
                                ),
                                child: Text(
                                  "lbl_bank_of_america".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular11,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: getMargin(
                            left: 8,
                          ),
                          decoration: AppDecoration.outlineGray300.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder10,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                padding: getPadding(
                                  left: 3,
                                ),
                                child: IntrinsicWidth(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: getPadding(
                                          top: 3,
                                          bottom: 12,
                                        ),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage732,
                                              height: getVerticalSize(
                                                70,
                                              ),
                                              width: getHorizontalSize(
                                                93,
                                              ),
                                              radius: BorderRadius.circular(
                                                getHorizontalSize(
                                                  7,
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                top: 8,
                                              ),
                                              child: Text(
                                                "lbl_citi".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtInterRegular11,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          108,
                                        ),
                                        width: getHorizontalSize(
                                          99,
                                        ),
                                        margin: getMargin(
                                          left: 11,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.topCenter,
                                          children: [
                                            Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                height: getVerticalSize(
                                                  108,
                                                ),
                                                width: getHorizontalSize(
                                                  99,
                                                ),
                                                decoration: BoxDecoration(
                                                  color:
                                                      ColorConstant.whiteA700,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                    getHorizontalSize(
                                                      10,
                                                    ),
                                                  ),
                                                  border: Border.all(
                                                    color:
                                                        ColorConstant.gray300,
                                                    width: getHorizontalSize(
                                                      1,
                                                    ),
                                                  ),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: ColorConstant
                                                          .black90033,
                                                      spreadRadius:
                                                          getHorizontalSize(
                                                        2,
                                                      ),
                                                      blurRadius:
                                                          getHorizontalSize(
                                                        2,
                                                      ),
                                                      offset: Offset(
                                                        0,
                                                        3,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage736,
                                              height: getVerticalSize(
                                                70,
                                              ),
                                              width: getHorizontalSize(
                                                93,
                                              ),
                                              radius: BorderRadius.circular(
                                                getHorizontalSize(
                                                  7,
                                                ),
                                              ),
                                              alignment: Alignment.topCenter,
                                              margin: getMargin(
                                                top: 3,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 14,
                            top: 83,
                            bottom: 10,
                          ),
                          child: Text(
                            "lbl_synchrony_bank".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: AppStyle.txtInterRegular11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 11,
                      top: 14,
                      right: 27,
                    ),
                    child: Row(
                      children: [
                        Text(
                          "lbl_search_results".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtHindVadodaraBold30.copyWith(
                            letterSpacing: getHorizontalSize(
                              0.3,
                            ),
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            top: 24,
                            bottom: 19,
                          ),
                          child: SizedBox(
                            width: getHorizontalSize(
                              155,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                              indent: getHorizontalSize(
                                11,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 12,
                      top: 11,
                      right: 25,
                    ),
                    child: BlocSelector<CardManagementTwoBloc,
                        CardManagementTwoState, CardManagementTwoModel?>(
                      selector: (state) => state.cardManagementTwoModelObj,
                      builder: (context, cardManagementTwoModelObj) {
                        return ListView.separated(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          separatorBuilder: (
                            context,
                            index,
                          ) {
                            return Padding(
                              padding: getPadding(
                                top: 12.5,
                                bottom: 12.5,
                              ),
                              child: SizedBox(
                                width: getHorizontalSize(
                                  345,
                                ),
                                child: Divider(
                                  height: getVerticalSize(
                                    4,
                                  ),
                                  thickness: getVerticalSize(
                                    4,
                                  ),
                                  color: ColorConstant.purple6006c,
                                ),
                              ),
                            );
                          },
                          itemCount: cardManagementTwoModelObj
                                  ?.cardManagement1ItemList.length ??
                              0,
                          itemBuilder: (context, index) {
                            CardManagement1ItemModel model =
                                cardManagementTwoModelObj
                                        ?.cardManagement1ItemList[index] ??
                                    CardManagement1ItemModel();
                            return CardManagement1ItemWidget(
                              model,
                            );
                          },
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 4,
                    ),
                    child: Divider(
                      height: getVerticalSize(
                        4,
                      ),
                      thickness: getVerticalSize(
                        4,
                      ),
                      color: ColorConstant.purple6006c,
                      indent: getHorizontalSize(
                        15,
                      ),
                      endIndent: getHorizontalSize(
                        33,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
