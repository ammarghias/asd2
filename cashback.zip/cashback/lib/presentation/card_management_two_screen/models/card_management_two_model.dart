// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';import 'card_management1_item_model.dart';/// This class defines the variables used in the [card_management_two_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class CardManagementTwoModel extends Equatable {CardManagementTwoModel({this.cardManagement1ItemList = const []});

List<CardManagement1ItemModel> cardManagement1ItemList;

CardManagementTwoModel copyWith({List<CardManagement1ItemModel>? cardManagement1ItemList}) { return CardManagementTwoModel(
cardManagement1ItemList : cardManagement1ItemList ?? this.cardManagement1ItemList,
); } 
@override List<Object?> get props => [cardManagement1ItemList];
 }
