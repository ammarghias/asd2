/// This class is used in the [card_management1_item_widget] screen.
class CardManagement1ItemModel {String? id = "";

 }
