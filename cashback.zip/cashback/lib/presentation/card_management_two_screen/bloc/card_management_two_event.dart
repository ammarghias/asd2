// ignore_for_file: must_be_immutable

part of 'card_management_two_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///CardManagementTwo widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class CardManagementTwoEvent extends Equatable {}

/// Event that is dispatched when the CardManagementTwo widget is first created.
class CardManagementTwoInitialEvent extends CardManagementTwoEvent {
  @override
  List<Object?> get props => [];
}

///Event for changing switch
class ChangeSwitchEvent extends CardManagementTwoEvent {
  ChangeSwitchEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
