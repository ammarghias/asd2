import 'bloc/profile_page_bloc.dart';
import 'models/profile_page_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

class ProfilePageScreen extends StatelessWidget {
  ProfilePageScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<ProfilePageBloc>(
      create: (context) => ProfilePageBloc(ProfilePageState(
        profilePageModelObj: ProfilePageModel(),
      ))
        ..add(ProfilePageInitialEvent()),
      child: ProfilePageScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ProfilePageBloc, ProfilePageState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: SizedBox(
              width: getHorizontalSize(
                380,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(
                    width: double.maxFinite,
                    child: Container(
                      decoration: AppDecoration.fillWhiteA700,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          CustomAppBar(
                            height: getVerticalSize(
                              102,
                            ),
                            leadingWidth: 50,
                            leading: AppbarImage(
                              height: getSize(
                                25,
                              ),
                              width: getSize(
                                25,
                              ),
                              svgPath: ImageConstant.imgButtonnotification,
                              margin: getMargin(
                                left: 25,
                                top: 9,
                                bottom: 32,
                              ),
                            ),
                            centerTitle: true,
                            title: AppbarImage(
                              height: getVerticalSize(
                                66,
                              ),
                              width: getHorizontalSize(
                                281,
                              ),
                              imagePath: ImageConstant.imgImage64,
                            ),
                            actions: [
                              AppbarImage(
                                height: getVerticalSize(
                                  21,
                                ),
                                width: getHorizontalSize(
                                  29,
                                ),
                                svgPath: ImageConstant.imgMenu,
                                margin: getMargin(
                                  top: 12,
                                  right: 15,
                                  bottom: 33,
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: getPadding(
                              top: 8,
                            ),
                            child: Text(
                              "lbl_user_name2".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLivvicRegular25,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: getPadding(
                        top: 18,
                      ),
                      child: Padding(
                        padding: getPadding(
                          bottom: 5,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: getVerticalSize(
                                526,
                              ),
                              width: getHorizontalSize(
                                380,
                              ),
                              child: Stack(
                                alignment: Alignment.topRight,
                                children: [
                                  Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Container(
                                      padding: getPadding(
                                        left: 10,
                                        top: 23,
                                        right: 10,
                                        bottom: 23,
                                      ),
                                      decoration:
                                          AppDecoration.fillPinkA20066.copyWith(
                                        borderRadius:
                                            BorderRadiusStyle.roundedBorder190,
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Padding(
                                            padding: getPadding(
                                              top: 233,
                                            ),
                                            child: Text(
                                              "lbl_user_profile".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtCastoroRegular19,
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 16,
                                            ),
                                            child: Text(
                                              "msg_media_relations".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtCastoroRegular19,
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 19,
                                            ),
                                            child: Text(
                                              "msg_support_feedback".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtCastoroRegular19,
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 14,
                                            ),
                                            child: Text(
                                              "lbl_cashback_vision".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtCastoroRegular21,
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 18,
                                            ),
                                            child: Text(
                                              "msg_cashback_reward".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtCastoroRegular21,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: Container(
                                      margin: getMargin(
                                        top: 18,
                                      ),
                                      padding: getPadding(
                                        left: 7,
                                        top: 38,
                                        right: 7,
                                        bottom: 38,
                                      ),
                                      decoration:
                                          AppDecoration.fillPink70001.copyWith(
                                        borderRadius:
                                            BorderRadiusStyle.roundedBorder133,
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            width: getHorizontalSize(
                                              133,
                                            ),
                                            child: Text(
                                              "msg_we_re_excited_to".tr,
                                              maxLines: null,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtLivvicRegular18,
                                            ),
                                          ),
                                          Container(
                                            width: getHorizontalSize(
                                              131,
                                            ),
                                            margin: getMargin(
                                              top: 19,
                                            ),
                                            child: Text(
                                              "msg_you_re_feedback".tr,
                                              maxLines: null,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtLivvicRegular18,
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 33,
                                              right: 4,
                                            ),
                                            child: Text(
                                              "msg_let_s_make_saving".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.center,
                                              style:
                                                  AppStyle.txtLivvicRegular18,
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgGroupWhiteA70029x180,
                                            height: getVerticalSize(
                                              29,
                                            ),
                                            width: getHorizontalSize(
                                              180,
                                            ),
                                            margin: getMargin(
                                              top: 1,
                                              right: 3,
                                              bottom: 23,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topLeft,
                                    child: Container(
                                      height: getVerticalSize(
                                        181,
                                      ),
                                      width: getHorizontalSize(
                                        187,
                                      ),
                                      margin: getMargin(
                                        left: 36,
                                      ),
                                      child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Align(
                                            alignment: Alignment.center,
                                            child: Container(
                                              height: getVerticalSize(
                                                181,
                                              ),
                                              width: getHorizontalSize(
                                                187,
                                              ),
                                              decoration: BoxDecoration(
                                                color: ColorConstant.pink70001,
                                                borderRadius:
                                                    BorderRadius.circular(
                                                  getHorizontalSize(
                                                    93,
                                                  ),
                                                ),
                                                border: Border.all(
                                                  color:
                                                      ColorConstant.whiteA700,
                                                  width: getHorizontalSize(
                                                    5,
                                                  ),
                                                  strokeAlign:
                                                      strokeAlignOutside,
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color:
                                                        ColorConstant.pink7007f,
                                                    spreadRadius:
                                                        getHorizontalSize(
                                                      2,
                                                    ),
                                                    blurRadius:
                                                        getHorizontalSize(
                                                      2,
                                                    ),
                                                    offset: Offset(
                                                      2,
                                                      1,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.center,
                                            child: SizedBox(
                                              height: getVerticalSize(
                                                167,
                                              ),
                                              width: getHorizontalSize(
                                                172,
                                              ),
                                              child: Stack(
                                                alignment:
                                                    Alignment.bottomRight,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.center,
                                                    child: Container(
                                                      height: getVerticalSize(
                                                        167,
                                                      ),
                                                      width: getHorizontalSize(
                                                        172,
                                                      ),
                                                      decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .gray50,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(
                                                          getHorizontalSize(
                                                            86,
                                                          ),
                                                        ),
                                                        border: Border.all(
                                                          color: ColorConstant
                                                              .gray40002,
                                                          width:
                                                              getHorizontalSize(
                                                            1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  CustomImageView(
                                                    svgPath: ImageConstant
                                                        .imgSettingsWhiteA700,
                                                    height: getVerticalSize(
                                                      44,
                                                    ),
                                                    width: getHorizontalSize(
                                                      45,
                                                    ),
                                                    alignment:
                                                        Alignment.bottomRight,
                                                    margin: getMargin(
                                                      right: 14,
                                                      bottom: 1,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                left: 10,
                                top: 8,
                              ),
                              child: Text(
                                "msg_cashback_financial".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular15Gray80002,
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                left: 10,
                                top: 13,
                              ),
                              child: Text(
                                "msg_disclosures_and".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular15Gray80002,
                              ),
                            ),
                            Padding(
                              padding: getPadding(
                                left: 10,
                                top: 16,
                              ),
                              child: Text(
                                "msg_app_versioning".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterRegular15Gray80002,
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Padding(
                                padding: getPadding(
                                  left: 10,
                                  top: 10,
                                  right: 16,
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: getHorizontalSize(
                                        114,
                                      ),
                                      margin: getMargin(
                                        top: 22,
                                      ),
                                      child: Text(
                                        "msg_thank_you_team".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular15Gray80002,
                                      ),
                                    ),
                                    Container(
                                      height: getVerticalSize(
                                        56,
                                      ),
                                      width: getHorizontalSize(
                                        123,
                                      ),
                                      margin: getMargin(
                                        bottom: 2,
                                      ),
                                      child: Stack(
                                        alignment: Alignment.topRight,
                                        children: [
                                          Align(
                                            alignment: Alignment.bottomCenter,
                                            child: Text(
                                              "lbl_come_back_soon".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular15Gray80002,
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.topRight,
                                            child: Text(
                                              "lbl_sign_out".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtLivvicRegular30,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
