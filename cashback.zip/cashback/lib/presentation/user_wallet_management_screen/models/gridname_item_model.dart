/// This class is used in the [gridname_item_widget] screen.
class GridnameItemModel {String nameTxt = "Chase";

String? id = "";

 }
