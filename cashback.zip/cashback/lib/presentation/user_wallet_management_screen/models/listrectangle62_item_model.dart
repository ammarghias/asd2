/// This class is used in the [listrectangle62_item_widget] screen.
class Listrectangle62ItemModel {String pullcardnameTxt = "Capital One";

String pullcardnameTxt1 = "Venture";

String? id = "";

 }
