// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';import 'gridname_item_model.dart';import 'listrectangle62_item_model.dart';/// This class defines the variables used in the [user_wallet_management_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class UserWalletManagementModel extends Equatable {UserWalletManagementModel({this.gridnameItemList = const [], this.listrectangle62ItemList = const [], });

List<GridnameItemModel> gridnameItemList;

List<Listrectangle62ItemModel> listrectangle62ItemList;

UserWalletManagementModel copyWith({List<GridnameItemModel>? gridnameItemList, List<Listrectangle62ItemModel>? listrectangle62ItemList, }) { return UserWalletManagementModel(
gridnameItemList : gridnameItemList ?? this.gridnameItemList,
listrectangle62ItemList : listrectangle62ItemList ?? this.listrectangle62ItemList,
); } 
@override List<Object?> get props => [gridnameItemList,listrectangle62ItemList];
 }
