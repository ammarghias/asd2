import '../user_wallet_management_screen/widgets/gridname_item_widget.dart';
import '../user_wallet_management_screen/widgets/listrectangle62_item_widget.dart';
import 'bloc/user_wallet_management_bloc.dart';
import 'models/gridname_item_model.dart';
import 'models/listrectangle62_item_model.dart';
import 'models/user_wallet_management_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/core/utils/validation_functions.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_switch.dart';
import 'package:ammar_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class UserWalletManagementScreen extends StatelessWidget {
  UserWalletManagementScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<UserWalletManagementBloc>(
      create: (context) => UserWalletManagementBloc(UserWalletManagementState(
        userWalletManagementModelObj: UserWalletManagementModel(),
      ))
        ..add(UserWalletManagementInitialEvent()),
      child: UserWalletManagementScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        appBar: CustomAppBar(
          height: getVerticalSize(
            97,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink70001,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: double.maxFinite,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: getVerticalSize(
                    30,
                  ),
                  width: getHorizontalSize(
                    180,
                  ),
                  margin: getMargin(
                    left: 100,
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                          height: getVerticalSize(
                            27,
                          ),
                          width: getHorizontalSize(
                            180,
                          ),
                          decoration: BoxDecoration(
                            color: ColorConstant.pink70001,
                            borderRadius: BorderRadius.circular(
                              getHorizontalSize(
                                10,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Text(
                          "lbl_card_management".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtHindVadodaraRegular20WhiteA700,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: double.maxFinite,
                  child: Container(
                    margin: getMargin(
                      top: 9,
                    ),
                    padding: getPadding(
                      left: 6,
                      top: 5,
                      right: 6,
                      bottom: 5,
                    ),
                    decoration: AppDecoration.fillWhiteA700,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: getPadding(
                            top: 1,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: getPadding(
                                  top: 2,
                                ),
                                child: Text(
                                  "lbl_welcome_offers2".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtStaatlichesRegular22,
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 15,
                                  bottom: 14,
                                ),
                                child: SizedBox(
                                  width: getHorizontalSize(
                                    178,
                                  ),
                                  child: Divider(
                                    height: getVerticalSize(
                                      1,
                                    ),
                                    thickness: getVerticalSize(
                                      1,
                                    ),
                                    color: ColorConstant.gray400,
                                    indent: getHorizontalSize(
                                      3,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  29,
                                ),
                                width: getHorizontalSize(
                                  54,
                                ),
                                margin: getMargin(
                                  left: 11,
                                  bottom: 1,
                                ),
                                child: Stack(
                                  alignment: Alignment.centerLeft,
                                  children: [
                                    BlocSelector<UserWalletManagementBloc,
                                        UserWalletManagementState, bool?>(
                                      selector: (state) =>
                                          state.isSelectedSwitch,
                                      builder: (context, isSelectedSwitch) {
                                        return CustomSwitch(
                                          alignment: Alignment.center,
                                          value: isSelectedSwitch,
                                          onChanged: (value) {
                                            context
                                                .read<
                                                    UserWalletManagementBloc>()
                                                .add(ChangeSwitchEvent(
                                                    value: value));
                                          },
                                        );
                                      },
                                    ),
                                    CustomImageView(
                                      svgPath: ImageConstant.imgLogo,
                                      height: getVerticalSize(
                                        6,
                                      ),
                                      width: getHorizontalSize(
                                        42,
                                      ),
                                      alignment: Alignment.centerLeft,
                                      margin: getMargin(
                                        left: 4,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          "msg_make_the_most_of".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterRegular14,
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: getPadding(
                    left: 7,
                    top: 13,
                    right: 6,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: getPadding(
                          top: 1,
                          bottom: 58,
                        ),
                        child: Text(
                          "lbl_capital_one".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterRegular17Gray60003,
                        ),
                      ),
                      Spacer(),
                      Container(
                        decoration: AppDecoration.outlineBlack9003f.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder7,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              padding: getPadding(
                                left: 2,
                              ),
                              child: IntrinsicWidth(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Padding(
                                      padding: getPadding(
                                        top: 1,
                                        bottom: 2,
                                      ),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            height: getVerticalSize(
                                              21,
                                            ),
                                            width: getHorizontalSize(
                                              172,
                                            ),
                                            child: Stack(
                                              alignment: Alignment.centerLeft,
                                              children: [
                                                Align(
                                                  alignment: Alignment.center,
                                                  child: Container(
                                                    height: getVerticalSize(
                                                      21,
                                                    ),
                                                    width: getHorizontalSize(
                                                      172,
                                                    ),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                        getHorizontalSize(
                                                          10,
                                                        ),
                                                      ),
                                                      gradient: LinearGradient(
                                                        begin: Alignment(
                                                          0.02,
                                                          0.52,
                                                        ),
                                                        end: Alignment(
                                                          1,
                                                          0.52,
                                                        ),
                                                        colors: [
                                                          ColorConstant
                                                              .gray20002,
                                                          ColorConstant
                                                              .gray20000,
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Align(
                                                  alignment:
                                                      Alignment.centerLeft,
                                                  child: Padding(
                                                    padding: getPadding(
                                                      left: 8,
                                                    ),
                                                    child: Text(
                                                      "lbl_capital_one".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterRegular17Gray60003,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 2,
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                CustomImageView(
                                                  imagePath: ImageConstant
                                                      .imgPullcreditcard2,
                                                  height: getVerticalSize(
                                                    54,
                                                  ),
                                                  width: getHorizontalSize(
                                                    90,
                                                  ),
                                                  radius: BorderRadius.circular(
                                                    getHorizontalSize(
                                                      3,
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  height: getVerticalSize(
                                                    53,
                                                  ),
                                                  width: getHorizontalSize(
                                                    82,
                                                  ),
                                                  margin: getMargin(
                                                    left: 2,
                                                    bottom: 1,
                                                  ),
                                                  child: Stack(
                                                    alignment:
                                                        Alignment.topCenter,
                                                    children: [
                                                      Align(
                                                        alignment: Alignment
                                                            .bottomCenter,
                                                        child: Container(
                                                          margin: getMargin(
                                                            top: 3,
                                                          ),
                                                          padding: getPadding(
                                                            left: 2,
                                                            right: 2,
                                                          ),
                                                          decoration: AppDecoration
                                                              .outlineBluegray10001
                                                              .copyWith(
                                                            borderRadius:
                                                                BorderRadiusStyle
                                                                    .roundedBorder7,
                                                          ),
                                                          child: Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                            children: [
                                                              Padding(
                                                                padding:
                                                                    getPadding(
                                                                  top: 38,
                                                                ),
                                                                child: Text(
                                                                  "lbl_expires"
                                                                      .tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtInterRegular9Gray60004,
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    getPadding(
                                                                  left: 1,
                                                                  top: 37,
                                                                  bottom: 1,
                                                                ),
                                                                child: Text(
                                                                  "lbl_12_31_23"
                                                                      .tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtInterRegular9Gray60004,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            Alignment.topCenter,
                                                        child: Container(
                                                          height:
                                                              getVerticalSize(
                                                            24,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            82,
                                                          ),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: ColorConstant
                                                                .pink70001,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                              getHorizontalSize(
                                                                5,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            Alignment.topCenter,
                                                        child: Container(
                                                          margin: getMargin(
                                                            top: 3,
                                                          ),
                                                          padding: getPadding(
                                                            left: 2,
                                                            top: 1,
                                                            right: 2,
                                                            bottom: 1,
                                                          ),
                                                          decoration: AppDecoration
                                                              .outlinePink700012
                                                              .copyWith(
                                                            borderRadius:
                                                                BorderRadiusStyle
                                                                    .roundedBorder7,
                                                          ),
                                                          child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .end,
                                                            children: [
                                                              Padding(
                                                                padding:
                                                                    getPadding(
                                                                  top: 21,
                                                                ),
                                                                child: Text(
                                                                  "lbl_reward_points2"
                                                                      .tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtInterRegular11Pink70001,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            Alignment.topRight,
                                                        child: Padding(
                                                          padding: getPadding(
                                                            top: 2,
                                                            right: 2,
                                                          ),
                                                          child: Text(
                                                            "lbl_x".tr,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtInterRegular17WhiteA700,
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            Alignment.topLeft,
                                                        child: Text(
                                                          "lbl_60_000".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular21,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      height: getVerticalSize(
                                        81,
                                      ),
                                      width: getHorizontalSize(
                                        179,
                                      ),
                                      margin: getMargin(
                                        left: 19,
                                      ),
                                      child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Align(
                                            alignment: Alignment.center,
                                            child: Container(
                                              height: getVerticalSize(
                                                81,
                                              ),
                                              width: getHorizontalSize(
                                                179,
                                              ),
                                              decoration: BoxDecoration(
                                                color: ColorConstant.whiteA700,
                                                borderRadius:
                                                    BorderRadius.circular(
                                                  getHorizontalSize(
                                                    5,
                                                  ),
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: ColorConstant
                                                        .black9003f,
                                                    spreadRadius:
                                                        getHorizontalSize(
                                                      2,
                                                    ),
                                                    blurRadius:
                                                        getHorizontalSize(
                                                      2,
                                                    ),
                                                    offset: Offset(
                                                      0,
                                                      4,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.center,
                                            child: Padding(
                                              padding: getPadding(
                                                left: 2,
                                                right: 3,
                                              ),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    height: getVerticalSize(
                                                      21,
                                                    ),
                                                    width: getHorizontalSize(
                                                      172,
                                                    ),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                        getHorizontalSize(
                                                          10,
                                                        ),
                                                      ),
                                                      gradient: LinearGradient(
                                                        begin: Alignment(
                                                          0.02,
                                                          0.52,
                                                        ),
                                                        end: Alignment(
                                                          1,
                                                          0.52,
                                                        ),
                                                        colors: [
                                                          ColorConstant
                                                              .gray20002,
                                                          ColorConstant
                                                              .gray20000,
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: getPadding(
                                                      top: 2,
                                                    ),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        CustomImageView(
                                                          imagePath: ImageConstant
                                                              .imgPullcreditcard2,
                                                          height:
                                                              getVerticalSize(
                                                            54,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            90,
                                                          ),
                                                          radius: BorderRadius
                                                              .circular(
                                                            getHorizontalSize(
                                                              3,
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          height:
                                                              getVerticalSize(
                                                            53,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            82,
                                                          ),
                                                          margin: getMargin(
                                                            left: 2,
                                                            bottom: 1,
                                                          ),
                                                          child: Stack(
                                                            alignment: Alignment
                                                                .topCenter,
                                                            children: [
                                                              Align(
                                                                alignment: Alignment
                                                                    .bottomCenter,
                                                                child:
                                                                    Container(
                                                                  margin:
                                                                      getMargin(
                                                                    top: 3,
                                                                  ),
                                                                  padding:
                                                                      getPadding(
                                                                    left: 2,
                                                                    top: 1,
                                                                    right: 2,
                                                                    bottom: 1,
                                                                  ),
                                                                  decoration: AppDecoration
                                                                      .outlineBluegray10001
                                                                      .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .roundedBorder7,
                                                                  ),
                                                                  child: Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .end,
                                                                    children: [
                                                                      Padding(
                                                                        padding:
                                                                            getPadding(
                                                                          top:
                                                                              36,
                                                                        ),
                                                                        child:
                                                                            Text(
                                                                          "lbl_expires"
                                                                              .tr,
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          textAlign:
                                                                              TextAlign.left,
                                                                          style:
                                                                              AppStyle.txtInterRegular9Gray60004,
                                                                        ),
                                                                      ),
                                                                      Padding(
                                                                        padding:
                                                                            getPadding(
                                                                          top:
                                                                              36,
                                                                        ),
                                                                        child:
                                                                            Text(
                                                                          "lbl_12_31_23"
                                                                              .tr,
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          textAlign:
                                                                              TextAlign.left,
                                                                          style:
                                                                              AppStyle.txtInterRegular9Gray60004,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                              Align(
                                                                alignment:
                                                                    Alignment
                                                                        .topCenter,
                                                                child:
                                                                    Container(
                                                                  height:
                                                                      getVerticalSize(
                                                                    24,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    82,
                                                                  ),
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: ColorConstant
                                                                        .pink70001,
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(
                                                                      getHorizontalSize(
                                                                        5,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Align(
                                                                alignment:
                                                                    Alignment
                                                                        .topCenter,
                                                                child:
                                                                    Container(
                                                                  margin:
                                                                      getMargin(
                                                                    top: 3,
                                                                  ),
                                                                  padding:
                                                                      getPadding(
                                                                    left: 2,
                                                                    top: 1,
                                                                    right: 2,
                                                                    bottom: 1,
                                                                  ),
                                                                  decoration: AppDecoration
                                                                      .outlinePink700012
                                                                      .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .roundedBorder7,
                                                                  ),
                                                                  child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .end,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    children: [
                                                                      Text(
                                                                        "lbl_x"
                                                                            .tr,
                                                                        overflow:
                                                                            TextOverflow.ellipsis,
                                                                        textAlign:
                                                                            TextAlign.left,
                                                                        style: AppStyle
                                                                            .txtInterRegular17WhiteA700,
                                                                      ),
                                                                      Padding(
                                                                        padding:
                                                                            getPadding(
                                                                          top:
                                                                              5,
                                                                          right:
                                                                              1,
                                                                          bottom:
                                                                              1,
                                                                        ),
                                                                        child:
                                                                            Text(
                                                                          "lbl_reward_points2"
                                                                              .tr,
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          textAlign:
                                                                              TextAlign.left,
                                                                          style:
                                                                              AppStyle.txtInterRegular11Pink70001,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                              Align(
                                                                alignment:
                                                                    Alignment
                                                                        .topLeft,
                                                                child: Text(
                                                                  "lbl_60_000"
                                                                      .tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtInterRegular21,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          left: 27,
                          top: 1,
                          bottom: 58,
                        ),
                        child: Text(
                          "lbl_capital_one".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterRegular17Gray60003,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: getVerticalSize(
                    901,
                  ),
                  width: getHorizontalSize(
                    379,
                  ),
                  margin: getMargin(
                    left: 6,
                    top: 21,
                  ),
                  child: Stack(
                    alignment: Alignment.topLeft,
                    children: [
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Padding(
                          padding: getPadding(
                            left: 7,
                            right: 17,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              BlocSelector<
                                  UserWalletManagementBloc,
                                  UserWalletManagementState,
                                  UserWalletManagementModel?>(
                                selector: (state) =>
                                    state.userWalletManagementModelObj,
                                builder:
                                    (context, userWalletManagementModelObj) {
                                  return GridView.builder(
                                    shrinkWrap: true,
                                    gridDelegate:
                                        SliverGridDelegateWithFixedCrossAxisCount(
                                      mainAxisExtent: getVerticalSize(
                                        109,
                                      ),
                                      crossAxisCount: 3,
                                      mainAxisSpacing: getHorizontalSize(
                                        28,
                                      ),
                                      crossAxisSpacing: getHorizontalSize(
                                        28,
                                      ),
                                    ),
                                    physics: NeverScrollableScrollPhysics(),
                                    itemCount: userWalletManagementModelObj
                                            ?.gridnameItemList.length ??
                                        0,
                                    itemBuilder: (context, index) {
                                      GridnameItemModel model =
                                          userWalletManagementModelObj
                                                  ?.gridnameItemList[index] ??
                                              GridnameItemModel();
                                      return GridnameItemWidget(
                                        model,
                                      );
                                    },
                                  );
                                },
                              ),
                              Container(
                                margin: getMargin(
                                  top: 31,
                                ),
                                padding: getPadding(
                                  all: 3,
                                ),
                                decoration:
                                    AppDecoration.outlineGray300.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder10,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    CustomImageView(
                                      imagePath: ImageConstant.imgImage74,
                                      height: getVerticalSize(
                                        70,
                                      ),
                                      width: getHorizontalSize(
                                        93,
                                      ),
                                      radius: BorderRadius.circular(
                                        getHorizontalSize(
                                          7,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: getHorizontalSize(
                                        89,
                                      ),
                                      margin: getMargin(
                                        top: 3,
                                        bottom: 3,
                                      ),
                                      child: Text(
                                        "lbl_barclays".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtInterRegular11,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Padding(
                          padding: getPadding(
                            left: 4,
                            top: 184,
                          ),
                          child: Text(
                            "lbl_we_support".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular19,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Padding(
                          padding: getPadding(
                            left: 7,
                            top: 88,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              BlocSelector<
                                  UserWalletManagementBloc,
                                  UserWalletManagementState,
                                  TextEditingController?>(
                                selector: (state) => state.nameController,
                                builder: (context, nameController) {
                                  return CustomTextFormField(
                                    focusNode: FocusNode(),
                                    autofocus: true,
                                    controller: nameController,
                                    hintText: "msg_search_by_card_or".tr,
                                    variant:
                                        TextFormFieldVariant.OutlinePink70001,
                                    fontStyle:
                                        TextFormFieldFontStyle.InterRegular12,
                                    textInputAction: TextInputAction.done,
                                    suffix: Container(
                                      padding: getPadding(
                                        left: 15,
                                        top: 8,
                                        right: 15,
                                        bottom: 6,
                                      ),
                                      margin: getMargin(
                                        left: 30,
                                        top: 4,
                                        right: 4,
                                        bottom: 4,
                                      ),
                                      decoration: BoxDecoration(
                                        color: ColorConstant.pink70001,
                                        borderRadius: BorderRadius.circular(
                                          getHorizontalSize(
                                            18,
                                          ),
                                        ),
                                        border: Border.all(
                                          color: ColorConstant.whiteA700,
                                          width: getHorizontalSize(
                                            3,
                                          ),
                                        ),
                                      ),
                                      child: CustomImageView(
                                        svgPath: ImageConstant.imgSettings,
                                      ),
                                    ),
                                    suffixConstraints: BoxConstraints(
                                      maxHeight: getVerticalSize(
                                        46,
                                      ),
                                    ),
                                    validator: (value) {
                                      if (!isText(value)) {
                                        return "Please enter valid text";
                                      }
                                      return null;
                                    },
                                  );
                                },
                              ),
                              Padding(
                                padding: getPadding(
                                  left: 5,
                                  top: 8,
                                  right: 4,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: getHorizontalSize(
                                        67,
                                      ),
                                      margin: getMargin(
                                        bottom: 2,
                                      ),
                                      child: Text(
                                        "msg_no_financial_details".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular10,
                                      ),
                                    ),
                                    Container(
                                      width: getHorizontalSize(
                                        65,
                                      ),
                                      margin: getMargin(
                                        left: 24,
                                      ),
                                      child: Text(
                                        "msg_no_account_linking".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular10,
                                      ),
                                    ),
                                    Container(
                                      width: getHorizontalSize(
                                        42,
                                      ),
                                      margin: getMargin(
                                        left: 24,
                                        bottom: 2,
                                      ),
                                      child: Text(
                                        "lbl_click_save".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular10,
                                      ),
                                    ),
                                    Container(
                                      width: getHorizontalSize(
                                        88,
                                      ),
                                      margin: getMargin(
                                        left: 25,
                                      ),
                                      child: Text(
                                        "msg_rewards_simple".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular10,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                            ),
                            Padding(
                              padding: getPadding(
                                left: 2,
                                top: 15,
                                right: 20,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: getPadding(
                                      top: 3,
                                      bottom: 6,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              "lbl_quick_add".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtStaatlichesRegular22,
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                left: 7,
                                                top: 4,
                                                bottom: 4,
                                              ),
                                              child: Text(
                                                "lbl_wallet_manager".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular15Gray4007f,
                                              ),
                                            ),
                                          ],
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            top: 1,
                                          ),
                                          child: Text(
                                            "msg_your_own_personal".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: getPadding(
                                      left: 72,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        CustomImageView(
                                          imagePath: ImageConstant.imgImage65,
                                          height: getVerticalSize(
                                            35,
                                          ),
                                          width: getHorizontalSize(
                                            45,
                                          ),
                                          radius: BorderRadius.circular(
                                            getHorizontalSize(
                                              3,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          "lbl_your_wallet2".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style:
                                              AppStyle.txtStaatlichesRegular18,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: EdgeInsets.all(0),
                          color: ColorConstant.whiteA700,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadiusStyle.roundedBorder26,
                          ),
                          child: Container(
                            height: getVerticalSize(
                              275,
                            ),
                            width: getHorizontalSize(
                              371,
                            ),
                            padding: getPadding(
                              top: 2,
                              bottom: 2,
                            ),
                            decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder26,
                            ),
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                    margin: getMargin(
                                      top: 7,
                                      right: 11,
                                      bottom: 9,
                                    ),
                                    padding: getPadding(
                                      left: 9,
                                      top: 18,
                                      right: 9,
                                      bottom: 18,
                                    ),
                                    decoration: AppDecoration.outlineGray800012
                                        .copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder15,
                                    ),
                                    child: BlocSelector<
                                        UserWalletManagementBloc,
                                        UserWalletManagementState,
                                        UserWalletManagementModel?>(
                                      selector: (state) =>
                                          state.userWalletManagementModelObj,
                                      builder: (context,
                                          userWalletManagementModelObj) {
                                        return ListView.separated(
                                          physics: BouncingScrollPhysics(),
                                          shrinkWrap: true,
                                          separatorBuilder: (
                                            context,
                                            index,
                                          ) {
                                            return SizedBox(
                                              height: getVerticalSize(
                                                16,
                                              ),
                                            );
                                          },
                                          itemCount:
                                              userWalletManagementModelObj
                                                      ?.listrectangle62ItemList
                                                      .length ??
                                                  0,
                                          itemBuilder: (context, index) {
                                            Listrectangle62ItemModel model =
                                                userWalletManagementModelObj
                                                            ?.listrectangle62ItemList[
                                                        index] ??
                                                    Listrectangle62ItemModel();
                                            return Listrectangle62ItemWidget(
                                              model,
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgCloseLime800,
                                  height: getVerticalSize(
                                    20,
                                  ),
                                  width: getHorizontalSize(
                                    23,
                                  ),
                                  alignment: Alignment.topRight,
                                  margin: getMargin(
                                    right: 2,
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    height: getVerticalSize(
                                      26,
                                    ),
                                    width: getHorizontalSize(
                                      130,
                                    ),
                                    margin: getMargin(
                                      left: 18,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.bottomCenter,
                                      children: [
                                        Align(
                                          alignment: Alignment.center,
                                          child: Container(
                                            height: getVerticalSize(
                                              26,
                                            ),
                                            width: getHorizontalSize(
                                              129,
                                            ),
                                            decoration: BoxDecoration(
                                              color: ColorConstant.gray80001,
                                              borderRadius:
                                                  BorderRadius.circular(
                                                getHorizontalSize(
                                                  13,
                                                ),
                                              ),
                                              border: Border.all(
                                                color: ColorConstant.gray80001,
                                                width: getHorizontalSize(
                                                  1,
                                                ),
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      ColorConstant.black9003f,
                                                  spreadRadius:
                                                      getHorizontalSize(
                                                    2,
                                                  ),
                                                  blurRadius: getHorizontalSize(
                                                    2,
                                                  ),
                                                  offset: Offset(
                                                    0,
                                                    4,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomCenter,
                                          child: Container(
                                            margin: getMargin(
                                              top: 2,
                                              right: 1,
                                            ),
                                            padding: getPadding(
                                              left: 6,
                                              right: 6,
                                            ),
                                            decoration: AppDecoration
                                                .outlineGray80001
                                                .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .roundedBorder10,
                                            ),
                                            child: Row(
                                              children: [
                                                Padding(
                                                  padding: getPadding(
                                                    top: 3,
                                                    bottom: 3,
                                                  ),
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        height: getSize(
                                                          4,
                                                        ),
                                                        width: getSize(
                                                          4,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .gray80001,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                            getHorizontalSize(
                                                              2,
                                                            ),
                                                          ),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: ColorConstant
                                                                  .black90066,
                                                              spreadRadius:
                                                                  getHorizontalSize(
                                                                2,
                                                              ),
                                                              blurRadius:
                                                                  getHorizontalSize(
                                                                2,
                                                              ),
                                                              offset: Offset(
                                                                0,
                                                                2,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        height: getSize(
                                                          4,
                                                        ),
                                                        width: getSize(
                                                          4,
                                                        ),
                                                        margin: getMargin(
                                                          top: 3,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .gray80001,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                            getHorizontalSize(
                                                              2,
                                                            ),
                                                          ),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: ColorConstant
                                                                  .black90066,
                                                              spreadRadius:
                                                                  getHorizontalSize(
                                                                2,
                                                              ),
                                                              blurRadius:
                                                                  getHorizontalSize(
                                                                2,
                                                              ),
                                                              offset: Offset(
                                                                0,
                                                                2,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        height: getSize(
                                                          4,
                                                        ),
                                                        width: getSize(
                                                          4,
                                                        ),
                                                        margin: getMargin(
                                                          top: 3,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .gray80001,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                            getHorizontalSize(
                                                              2,
                                                            ),
                                                          ),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: ColorConstant
                                                                  .black90066,
                                                              spreadRadius:
                                                                  getHorizontalSize(
                                                                2,
                                                              ),
                                                              blurRadius:
                                                                  getHorizontalSize(
                                                                2,
                                                              ),
                                                              offset: Offset(
                                                                0,
                                                                2,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Padding(
                                                  padding: getPadding(
                                                    left: 11,
                                                  ),
                                                  child: Text(
                                                    "lbl_your_wallet3".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtStaatlichesRegular18Gray30001,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Container(
                                            margin: getMargin(
                                              top: 7,
                                            ),
                                            padding: getPadding(
                                              left: 2,
                                              top: 3,
                                              right: 2,
                                              bottom: 3,
                                            ),
                                            decoration: AppDecoration
                                                .outlineGray800011
                                                .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .customBorderTL6,
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Container(
                                                  height: getVerticalSize(
                                                    4,
                                                  ),
                                                  width: getHorizontalSize(
                                                    6,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color:
                                                        ColorConstant.gray80001,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                      getHorizontalSize(
                                                        3,
                                                      ),
                                                    ),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: ColorConstant
                                                            .black90066,
                                                        spreadRadius:
                                                            getHorizontalSize(
                                                          2,
                                                        ),
                                                        blurRadius:
                                                            getHorizontalSize(
                                                          2,
                                                        ),
                                                        offset: Offset(
                                                          0,
                                                          2,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
