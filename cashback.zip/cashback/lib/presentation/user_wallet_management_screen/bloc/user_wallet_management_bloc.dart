import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/gridname_item_model.dart';
import '../models/listrectangle62_item_model.dart';
import 'package:ammar_s_application6/presentation/user_wallet_management_screen/models/user_wallet_management_model.dart';
part 'user_wallet_management_event.dart';
part 'user_wallet_management_state.dart';

/// A bloc that manages the state of a UserWalletManagement according to the event that is dispatched to it.
class UserWalletManagementBloc
    extends Bloc<UserWalletManagementEvent, UserWalletManagementState> {
  UserWalletManagementBloc(UserWalletManagementState initialState)
      : super(initialState) {
    on<UserWalletManagementInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<UserWalletManagementState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<GridnameItemModel> fillGridnameItemList() {
    return List.generate(12, (index) => GridnameItemModel());
  }

  List<Listrectangle62ItemModel> fillListrectangle62ItemList() {
    return List.generate(3, (index) => Listrectangle62ItemModel());
  }

  _onInitialize(
    UserWalletManagementInitialEvent event,
    Emitter<UserWalletManagementState> emit,
  ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        userWalletManagementModelObj:
            state.userWalletManagementModelObj?.copyWith(
      gridnameItemList: fillGridnameItemList(),
      listrectangle62ItemList: fillListrectangle62ItemList(),
    )));
  }
}
