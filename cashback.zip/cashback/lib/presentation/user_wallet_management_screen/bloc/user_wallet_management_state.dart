// ignore_for_file: must_be_immutable

part of 'user_wallet_management_bloc.dart';

/// Represents the state of UserWalletManagement in the application.
class UserWalletManagementState extends Equatable {
  UserWalletManagementState({
    this.nameController,
    this.isSelectedSwitch = false,
    this.userWalletManagementModelObj,
  });

  TextEditingController? nameController;

  UserWalletManagementModel? userWalletManagementModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        nameController,
        isSelectedSwitch,
        userWalletManagementModelObj,
      ];
  UserWalletManagementState copyWith({
    TextEditingController? nameController,
    bool? isSelectedSwitch,
    UserWalletManagementModel? userWalletManagementModelObj,
  }) {
    return UserWalletManagementState(
      nameController: nameController ?? this.nameController,
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      userWalletManagementModelObj:
          userWalletManagementModelObj ?? this.userWalletManagementModelObj,
    );
  }
}
