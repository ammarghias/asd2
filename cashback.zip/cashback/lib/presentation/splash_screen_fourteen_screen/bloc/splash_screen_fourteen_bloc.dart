import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/splash_screen_fourteen_screen/models/splash_screen_fourteen_model.dart';
part 'splash_screen_fourteen_event.dart';
part 'splash_screen_fourteen_state.dart';

/// A bloc that manages the state of a SplashScreenFourteen according to the event that is dispatched to it.
class SplashScreenFourteenBloc
    extends Bloc<SplashScreenFourteenEvent, SplashScreenFourteenState> {
  SplashScreenFourteenBloc(SplashScreenFourteenState initialState)
      : super(initialState) {
    on<SplashScreenFourteenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenFourteenInitialEvent event,
    Emitter<SplashScreenFourteenState> emit,
  ) async {}
}
