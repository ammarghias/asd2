import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application6/presentation/password_reset_page_2_mfa_authentication_screen/models/password_reset_page_2_mfa_authentication_model.dart';part 'password_reset_page_2_mfa_authentication_event.dart';part 'password_reset_page_2_mfa_authentication_state.dart';/// A bloc that manages the state of a PasswordResetPage2MfaAuthentication according to the event that is dispatched to it.
class PasswordResetPage2MfaAuthenticationBloc extends Bloc<PasswordResetPage2MfaAuthenticationEvent, PasswordResetPage2MfaAuthenticationState> {PasswordResetPage2MfaAuthenticationBloc(PasswordResetPage2MfaAuthenticationState initialState) : super(initialState) { on<PasswordResetPage2MfaAuthenticationInitialEvent>(_onInitialize); }

_onInitialize(PasswordResetPage2MfaAuthenticationInitialEvent event, Emitter<PasswordResetPage2MfaAuthenticationState> emit, ) async  {  } 
 }
