// ignore_for_file: must_be_immutable

part of 'password_reset_page_2_mfa_authentication_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///PasswordResetPage2MfaAuthentication widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class PasswordResetPage2MfaAuthenticationEvent extends Equatable {}

/// Event that is dispatched when the PasswordResetPage2MfaAuthentication widget is first created.
class PasswordResetPage2MfaAuthenticationInitialEvent
    extends PasswordResetPage2MfaAuthenticationEvent {
  @override
  List<Object?> get props => [];
}
