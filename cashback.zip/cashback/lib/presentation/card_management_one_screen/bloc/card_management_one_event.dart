// ignore_for_file: must_be_immutable

part of 'card_management_one_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///CardManagementOne widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class CardManagementOneEvent extends Equatable {}

/// Event that is dispatched when the CardManagementOne widget is first created.
class CardManagementOneInitialEvent extends CardManagementOneEvent {
  @override
  List<Object?> get props => [];
}

///Event for changing switch
class ChangeSwitchEvent extends CardManagementOneEvent {
  ChangeSwitchEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
