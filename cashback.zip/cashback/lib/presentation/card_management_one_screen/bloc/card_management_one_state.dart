// ignore_for_file: must_be_immutable

part of 'card_management_one_bloc.dart';

/// Represents the state of CardManagementOne in the application.
class CardManagementOneState extends Equatable {
  CardManagementOneState({
    this.nameController,
    this.isSelectedSwitch = false,
    this.cardManagementOneModelObj,
  });

  TextEditingController? nameController;

  CardManagementOneModel? cardManagementOneModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        nameController,
        isSelectedSwitch,
        cardManagementOneModelObj,
      ];
  CardManagementOneState copyWith({
    TextEditingController? nameController,
    bool? isSelectedSwitch,
    CardManagementOneModel? cardManagementOneModelObj,
  }) {
    return CardManagementOneState(
      nameController: nameController ?? this.nameController,
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      cardManagementOneModelObj:
          cardManagementOneModelObj ?? this.cardManagementOneModelObj,
    );
  }
}
