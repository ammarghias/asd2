import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/card_management_item_model.dart';
import 'package:ammar_s_application6/presentation/card_management_one_screen/models/card_management_one_model.dart';
part 'card_management_one_event.dart';
part 'card_management_one_state.dart';

/// A bloc that manages the state of a CardManagementOne according to the event that is dispatched to it.
class CardManagementOneBloc
    extends Bloc<CardManagementOneEvent, CardManagementOneState> {
  CardManagementOneBloc(CardManagementOneState initialState)
      : super(initialState) {
    on<CardManagementOneInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<CardManagementOneState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<CardManagementItemModel> fillCardManagementItemList() {
    return List.generate(12, (index) => CardManagementItemModel());
  }

  _onInitialize(
    CardManagementOneInitialEvent event,
    Emitter<CardManagementOneState> emit,
  ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        cardManagementOneModelObj: state.cardManagementOneModelObj?.copyWith(
      cardManagementItemList: fillCardManagementItemList(),
    )));
  }
}
