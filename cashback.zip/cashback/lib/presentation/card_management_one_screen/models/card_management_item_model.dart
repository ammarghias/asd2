/// This class is used in the [card_management_item_widget] screen.
class CardManagementItemModel {String nameTxt = "Chase";

String? id = "";

 }
