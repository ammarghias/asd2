// ignore_for_file: must_be_immutable

part of 'terms_and_disclosures_bloc.dart';

/// Represents the state of TermsAndDisclosures in the application.
class TermsAndDisclosuresState extends Equatable {
  TermsAndDisclosuresState({this.termsAndDisclosuresModelObj});

  TermsAndDisclosuresModel? termsAndDisclosuresModelObj;

  @override
  List<Object?> get props => [
        termsAndDisclosuresModelObj,
      ];
  TermsAndDisclosuresState copyWith(
      {TermsAndDisclosuresModel? termsAndDisclosuresModelObj}) {
    return TermsAndDisclosuresState(
      termsAndDisclosuresModelObj:
          termsAndDisclosuresModelObj ?? this.termsAndDisclosuresModelObj,
    );
  }
}
