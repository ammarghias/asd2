import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/terms_and_disclosures_screen/models/terms_and_disclosures_model.dart';
part 'terms_and_disclosures_event.dart';
part 'terms_and_disclosures_state.dart';

/// A bloc that manages the state of a TermsAndDisclosures according to the event that is dispatched to it.
class TermsAndDisclosuresBloc
    extends Bloc<TermsAndDisclosuresEvent, TermsAndDisclosuresState> {
  TermsAndDisclosuresBloc(TermsAndDisclosuresState initialState)
      : super(initialState) {
    on<TermsAndDisclosuresInitialEvent>(_onInitialize);
  }

  _onInitialize(
    TermsAndDisclosuresInitialEvent event,
    Emitter<TermsAndDisclosuresState> emit,
  ) async {}
}
