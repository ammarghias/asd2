// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [splash_screen_fifteen_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class SplashScreenFifteenModel extends Equatable {SplashScreenFifteenModel copyWith() { return SplashScreenFifteenModel(
); } 
@override List<Object?> get props => [];
 }
