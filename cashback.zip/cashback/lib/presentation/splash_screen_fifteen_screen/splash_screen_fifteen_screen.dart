import 'bloc/splash_screen_fifteen_bloc.dart';
import 'models/splash_screen_fifteen_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:flutter/material.dart';

class SplashScreenFifteenScreen extends StatelessWidget {
  const SplashScreenFifteenScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<SplashScreenFifteenBloc>(
      create: (context) => SplashScreenFifteenBloc(SplashScreenFifteenState(
        splashScreenFifteenModelObj: SplashScreenFifteenModel(),
      ))
        ..add(SplashScreenFifteenInitialEvent()),
      child: SplashScreenFifteenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenFifteenBloc, SplashScreenFifteenState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: SizedBox(
              width: getHorizontalSize(
                390,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: SizedBox(
                        height: getVerticalSize(
                          844,
                        ),
                        width: getHorizontalSize(
                          390,
                        ),
                        child: Stack(
                          alignment: Alignment.bottomCenter,
                          children: [
                            Align(
                              alignment: Alignment.topCenter,
                              child: Text(
                                "lbl_cashback".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtLEMONMILKMedium65,
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Padding(
                                padding: getPadding(
                                  left: 13,
                                  right: 13,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 176,
                                      ),
                                      child: Text(
                                        "lbl_cashback".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtLEMONMILKMedium65,
                                      ),
                                    ),
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Text(
                                      "lbl_cashback".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtLEMONMILKMedium65,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 172,
                                      ),
                                      child: Text(
                                        "lbl_cashback".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtLEMONMILKMedium65,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: SizedBox(
                                height: getVerticalSize(
                                  844,
                                ),
                                width: getHorizontalSize(
                                  390,
                                ),
                                child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    CustomImageView(
                                      imagePath:
                                          ImageConstant.imgEllipse1844x390,
                                      height: getVerticalSize(
                                        844,
                                      ),
                                      width: getHorizontalSize(
                                        390,
                                      ),
                                      alignment: Alignment.center,
                                    ),
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Padding(
                                        padding: getPadding(
                                          left: 13,
                                          right: 18,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgGroupWhiteA70047x276,
                                              height: getVerticalSize(
                                                47,
                                              ),
                                              width: getHorizontalSize(
                                                276,
                                              ),
                                            ),
                                            Container(
                                              height: getVerticalSize(
                                                203,
                                              ),
                                              width: getHorizontalSize(
                                                358,
                                              ),
                                              margin: getMargin(
                                                top: 218,
                                              ),
                                              child: Stack(
                                                alignment:
                                                    Alignment.centerRight,
                                                children: [
                                                  CustomImageView(
                                                    svgPath: ImageConstant
                                                        .imgVectorWhiteA700,
                                                    height: getVerticalSize(
                                                      203,
                                                    ),
                                                    width: getHorizontalSize(
                                                      189,
                                                    ),
                                                    alignment:
                                                        Alignment.centerLeft,
                                                  ),
                                                  CustomImageView(
                                                    svgPath: ImageConstant
                                                        .imgVectorWhiteA700,
                                                    height: getVerticalSize(
                                                      203,
                                                    ),
                                                    width: getHorizontalSize(
                                                      189,
                                                    ),
                                                    alignment:
                                                        Alignment.centerRight,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
