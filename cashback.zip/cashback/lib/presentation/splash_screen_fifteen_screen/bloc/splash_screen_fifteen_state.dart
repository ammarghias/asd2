// ignore_for_file: must_be_immutable

part of 'splash_screen_fifteen_bloc.dart';

/// Represents the state of SplashScreenFifteen in the application.
class SplashScreenFifteenState extends Equatable {
  SplashScreenFifteenState({this.splashScreenFifteenModelObj});

  SplashScreenFifteenModel? splashScreenFifteenModelObj;

  @override
  List<Object?> get props => [
        splashScreenFifteenModelObj,
      ];
  SplashScreenFifteenState copyWith(
      {SplashScreenFifteenModel? splashScreenFifteenModelObj}) {
    return SplashScreenFifteenState(
      splashScreenFifteenModelObj:
          splashScreenFifteenModelObj ?? this.splashScreenFifteenModelObj,
    );
  }
}
