import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/splash_screen_fifteen_screen/models/splash_screen_fifteen_model.dart';
part 'splash_screen_fifteen_event.dart';
part 'splash_screen_fifteen_state.dart';

/// A bloc that manages the state of a SplashScreenFifteen according to the event that is dispatched to it.
class SplashScreenFifteenBloc
    extends Bloc<SplashScreenFifteenEvent, SplashScreenFifteenState> {
  SplashScreenFifteenBloc(SplashScreenFifteenState initialState)
      : super(initialState) {
    on<SplashScreenFifteenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SplashScreenFifteenInitialEvent event,
    Emitter<SplashScreenFifteenState> emit,
  ) async {}
}
