// ignore_for_file: must_be_immutable

part of 'splash_screen_fifteen_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///SplashScreenFifteen widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class SplashScreenFifteenEvent extends Equatable {}

/// Event that is dispatched when the SplashScreenFifteen widget is first created.
class SplashScreenFifteenInitialEvent extends SplashScreenFifteenEvent {
  @override
  List<Object?> get props => [];
}
