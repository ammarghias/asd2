import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/reward_catalog_one_screen/models/reward_catalog_one_model.dart';
part 'reward_catalog_one_event.dart';
part 'reward_catalog_one_state.dart';

/// A bloc that manages the state of a RewardCatalogOne according to the event that is dispatched to it.
class RewardCatalogOneBloc
    extends Bloc<RewardCatalogOneEvent, RewardCatalogOneState> {
  RewardCatalogOneBloc(RewardCatalogOneState initialState)
      : super(initialState) {
    on<RewardCatalogOneInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<RewardCatalogOneState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  _onInitialize(
    RewardCatalogOneInitialEvent event,
    Emitter<RewardCatalogOneState> emit,
  ) async {
    emit(state.copyWith(
      searchController: TextEditingController(),
      isSelectedSwitch: false,
    ));
  }
}
