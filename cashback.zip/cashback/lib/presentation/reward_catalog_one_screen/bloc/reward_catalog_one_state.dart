// ignore_for_file: must_be_immutable

part of 'reward_catalog_one_bloc.dart';

/// Represents the state of RewardCatalogOne in the application.
class RewardCatalogOneState extends Equatable {
  RewardCatalogOneState({
    this.searchController,
    this.isSelectedSwitch = false,
    this.rewardCatalogOneModelObj,
  });

  TextEditingController? searchController;

  RewardCatalogOneModel? rewardCatalogOneModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        searchController,
        isSelectedSwitch,
        rewardCatalogOneModelObj,
      ];
  RewardCatalogOneState copyWith({
    TextEditingController? searchController,
    bool? isSelectedSwitch,
    RewardCatalogOneModel? rewardCatalogOneModelObj,
  }) {
    return RewardCatalogOneState(
      searchController: searchController ?? this.searchController,
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      rewardCatalogOneModelObj:
          rewardCatalogOneModelObj ?? this.rewardCatalogOneModelObj,
    );
  }
}
