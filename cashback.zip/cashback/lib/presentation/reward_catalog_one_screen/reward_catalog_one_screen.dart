import 'bloc/reward_catalog_one_bloc.dart';
import 'models/reward_catalog_one_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application6/widgets/custom_switch.dart';
import 'package:ammar_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class RewardCatalogOneScreen extends StatelessWidget {
  RewardCatalogOneScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<RewardCatalogOneBloc>(
      create: (context) => RewardCatalogOneBloc(RewardCatalogOneState(
        rewardCatalogOneModelObj: RewardCatalogOneModel(),
      ))
        ..add(RewardCatalogOneInitialEvent()),
      child: RewardCatalogOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        appBar: CustomAppBar(
          height: getVerticalSize(
            83,
          ),
          leadingWidth: 50,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 25,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink70001,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: SizedBox(
          width: size.width,
          child: SingleChildScrollView(
            child: Padding(
              padding: getPadding(
                left: 3,
                bottom: 8,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      left: 92,
                    ),
                    child: Text(
                      "lbl_reward_catalog".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtHindVadodaraRegular28,
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: getPadding(
                        left: 16,
                        top: 17,
                        right: 14,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: getPadding(
                              all: 3,
                            ),
                            decoration: AppDecoration.outlineGray50002.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder15,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: getHorizontalSize(
                                    130,
                                  ),
                                  padding: getPadding(
                                    left: 25,
                                    top: 1,
                                    right: 25,
                                    bottom: 1,
                                  ),
                                  decoration: AppDecoration.txtOutlinePink70001
                                      .copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.txtRoundedBorder14,
                                  ),
                                  child: Text(
                                    "lbl_detailed".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular20Pink70001,
                                  ),
                                ),
                                Container(
                                  width: getHorizontalSize(
                                    130,
                                  ),
                                  margin: getMargin(
                                    left: 21,
                                  ),
                                  padding: getPadding(
                                    left: 19,
                                    top: 1,
                                    right: 19,
                                    bottom: 1,
                                  ),
                                  decoration: AppDecoration.txtOutlineWhiteA700
                                      .copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.txtRoundedBorder14,
                                  ),
                                  child: Text(
                                    "lbl_summary".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular20WhiteA700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: getVerticalSize(
                              29,
                            ),
                            width: getHorizontalSize(
                              54,
                            ),
                            margin: getMargin(
                              top: 2,
                              bottom: 4,
                            ),
                            child: Stack(
                              alignment: Alignment.centerLeft,
                              children: [
                                BlocSelector<RewardCatalogOneBloc,
                                    RewardCatalogOneState, bool?>(
                                  selector: (state) => state.isSelectedSwitch,
                                  builder: (context, isSelectedSwitch) {
                                    return CustomSwitch(
                                      alignment: Alignment.center,
                                      value: isSelectedSwitch,
                                      onChanged: (value) {
                                        context
                                            .read<RewardCatalogOneBloc>()
                                            .add(ChangeSwitchEvent(
                                                value: value));
                                      },
                                    );
                                  },
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgLogo,
                                  height: getVerticalSize(
                                    6,
                                  ),
                                  width: getHorizontalSize(
                                    42,
                                  ),
                                  alignment: Alignment.centerLeft,
                                  margin: getMargin(
                                    left: 4,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      705,
                    ),
                    width: getHorizontalSize(
                      390,
                    ),
                    margin: getMargin(
                      top: 21,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            height: getVerticalSize(
                              704,
                            ),
                            width: getHorizontalSize(
                              387,
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.pink70001,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(
                                  getHorizontalSize(
                                    44,
                                  ),
                                ),
                                bottomLeft: Radius.circular(
                                  getHorizontalSize(
                                    44,
                                  ),
                                ),
                                bottomRight: Radius.circular(
                                  getHorizontalSize(
                                    44,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            margin: getMargin(
                              left: 3,
                            ),
                            padding: getPadding(
                              left: 10,
                              top: 23,
                              right: 10,
                              bottom: 23,
                            ),
                            decoration: AppDecoration.outlinePink90033.copyWith(
                              borderRadius: BorderRadiusStyle.customBorderTL35,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                BlocSelector<
                                    RewardCatalogOneBloc,
                                    RewardCatalogOneState,
                                    TextEditingController?>(
                                  selector: (state) => state.searchController,
                                  builder: (context, searchController) {
                                    return CustomTextFormField(
                                      focusNode: FocusNode(),
                                      autofocus: true,
                                      controller: searchController,
                                      hintText: "msg_search_reward_catalog".tr,
                                      margin: getMargin(
                                        right: 35,
                                      ),
                                      variant:
                                          TextFormFieldVariant.OutlinePink70001,
                                      padding: TextFormFieldPadding.PaddingT10,
                                      fontStyle:
                                          TextFormFieldFontStyle.InterRegular18,
                                      textInputAction: TextInputAction.done,
                                      suffix: Container(
                                        padding: getPadding(
                                          left: 13,
                                          top: 7,
                                          right: 12,
                                          bottom: 5,
                                        ),
                                        margin: getMargin(
                                          left: 30,
                                          top: 4,
                                          right: 5,
                                          bottom: 4,
                                        ),
                                        decoration: BoxDecoration(
                                          color: ColorConstant.pink70001,
                                          borderRadius: BorderRadius.circular(
                                            getHorizontalSize(
                                              17,
                                            ),
                                          ),
                                          border: Border.all(
                                            color: ColorConstant.whiteA700,
                                            width: getHorizontalSize(
                                              3,
                                            ),
                                          ),
                                        ),
                                        child: CustomImageView(
                                          svgPath: ImageConstant.imgSignal,
                                        ),
                                      ),
                                      suffixConstraints: BoxConstraints(
                                        maxHeight: getVerticalSize(
                                          43,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 3,
                                    top: 11,
                                    bottom: 568,
                                  ),
                                  child: Text(
                                    "lbl_search_results".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular25Black900,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            height: getVerticalSize(
                              285,
                            ),
                            width: getHorizontalSize(
                              371,
                            ),
                            margin: getMargin(
                              left: 2,
                              top: 115,
                            ),
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                    margin: getMargin(
                                      left: 11,
                                      right: 12,
                                    ),
                                    padding: getPadding(
                                      top: 8,
                                      bottom: 8,
                                    ),
                                    decoration:
                                        AppDecoration.outlinePink70001.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder10,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: getPadding(
                                            left: 11,
                                            right: 10,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: getPadding(
                                                  top: 16,
                                                ),
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgPullmerchantlogo,
                                                      height: getVerticalSize(
                                                        61,
                                                      ),
                                                      width: getHorizontalSize(
                                                        60,
                                                      ),
                                                      radius:
                                                          BorderRadius.circular(
                                                        getHorizontalSize(
                                                          30,
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 6,
                                                      ),
                                                      child: Text(
                                                        "lbl_7_eleven".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular13,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                height: getVerticalSize(
                                                  91,
                                                ),
                                                width: getHorizontalSize(
                                                  113,
                                                ),
                                                margin: getMargin(
                                                  bottom: 8,
                                                ),
                                                child: Stack(
                                                  alignment: Alignment.topRight,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                        decoration: AppDecoration
                                                            .outlineBlack9003f1
                                                            .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder10,
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          children: [
                                                            Container(
                                                              margin: getMargin(
                                                                top: 9,
                                                              ),
                                                              padding:
                                                                  getPadding(
                                                                left: 2,
                                                                top: 3,
                                                                right: 2,
                                                                bottom: 3,
                                                              ),
                                                              decoration:
                                                                  AppDecoration
                                                                      .outlineBlack9003f
                                                                      .copyWith(
                                                                borderRadius:
                                                                    BorderRadiusStyle
                                                                        .roundedBorder10,
                                                              ),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Container(
                                                                    width:
                                                                        getHorizontalSize(
                                                                      107,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      left: 2,
                                                                      top: 3,
                                                                    ),
                                                                    child: Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      children: [
                                                                        Container(
                                                                          height:
                                                                              getVerticalSize(
                                                                            35,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            60,
                                                                          ),
                                                                          margin:
                                                                              getMargin(
                                                                            top:
                                                                                1,
                                                                          ),
                                                                          child:
                                                                              Stack(
                                                                            alignment:
                                                                                Alignment.center,
                                                                            children: [
                                                                              CustomImageView(
                                                                                imagePath: ImageConstant.imgPullcreditcard,
                                                                                height: getVerticalSize(
                                                                                  34,
                                                                                ),
                                                                                width: getHorizontalSize(
                                                                                  60,
                                                                                ),
                                                                                radius: BorderRadius.circular(
                                                                                  getHorizontalSize(
                                                                                    3,
                                                                                  ),
                                                                                ),
                                                                                alignment: Alignment.center,
                                                                              ),
                                                                              CustomImageView(
                                                                                svgPath: ImageConstant.imgTicketAmber300,
                                                                                height: getVerticalSize(
                                                                                  35,
                                                                                ),
                                                                                width: getHorizontalSize(
                                                                                  60,
                                                                                ),
                                                                                alignment: Alignment.center,
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Column(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.end,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: [
                                                                            SizedBox(
                                                                              height: getVerticalSize(
                                                                                26,
                                                                              ),
                                                                              width: getHorizontalSize(
                                                                                44,
                                                                              ),
                                                                              child: Stack(
                                                                                alignment: Alignment.topRight,
                                                                                children: [
                                                                                  Align(
                                                                                    alignment: Alignment.bottomCenter,
                                                                                    child: Container(
                                                                                      decoration: AppDecoration.outlinePink70001.copyWith(
                                                                                        borderRadius: BorderRadiusStyle.roundedBorder4,
                                                                                      ),
                                                                                      child: Column(
                                                                                        mainAxisSize: MainAxisSize.min,
                                                                                        crossAxisAlignment: CrossAxisAlignment.end,
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: [
                                                                                          Container(
                                                                                            height: getVerticalSize(
                                                                                              16,
                                                                                            ),
                                                                                            width: getHorizontalSize(
                                                                                              44,
                                                                                            ),
                                                                                            decoration: BoxDecoration(
                                                                                              color: ColorConstant.pink70001,
                                                                                              borderRadius: BorderRadius.circular(
                                                                                                getHorizontalSize(
                                                                                                  4,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          Padding(
                                                                                            padding: getPadding(
                                                                                              right: 2,
                                                                                            ),
                                                                                            child: Text(
                                                                                              "lbl_cashback2".tr,
                                                                                              overflow: TextOverflow.ellipsis,
                                                                                              textAlign: TextAlign.left,
                                                                                              style: AppStyle.txtInterRegular6,
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: Alignment.topRight,
                                                                                    child: Padding(
                                                                                      padding: getPadding(
                                                                                        right: 14,
                                                                                      ),
                                                                                      child: Text(
                                                                                        "lbl_5".tr,
                                                                                        overflow: TextOverflow.ellipsis,
                                                                                        textAlign: TextAlign.left,
                                                                                        style: AppStyle.txtInterRegular17WhiteA700,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: Alignment.topRight,
                                                                                    child: Text(
                                                                                      "lbl".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtInterRegular17WhiteA700,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            Padding(
                                                                              padding: getPadding(
                                                                                right: 2,
                                                                              ),
                                                                              child: Text(
                                                                                "lbl_stacked".tr,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                textAlign: TextAlign.left,
                                                                                style: AppStyle.txtInterBold8,
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      top: 3,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_cashback2"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterBold11,
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      top: 1,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_blaze"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular11Black90099,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Padding(
                                                        padding: getPadding(
                                                          right: 9,
                                                        ),
                                                        child: Text(
                                                          "lbl_cashback2".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtStaatlichesRegular9,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                height: getVerticalSize(
                                                  89,
                                                ),
                                                width: getHorizontalSize(
                                                  113,
                                                ),
                                                margin: getMargin(
                                                  top: 1,
                                                  bottom: 8,
                                                ),
                                                child: Stack(
                                                  alignment: Alignment.topRight,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                        decoration:
                                                            AppDecoration
                                                                .fillIndigoA700
                                                                .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder10,
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          children: [
                                                            Container(
                                                              margin: getMargin(
                                                                top: 8,
                                                              ),
                                                              padding:
                                                                  getPadding(
                                                                left: 2,
                                                                top: 4,
                                                                right: 2,
                                                                bottom: 4,
                                                              ),
                                                              decoration:
                                                                  AppDecoration
                                                                      .outlineBlack9003f
                                                                      .copyWith(
                                                                borderRadius:
                                                                    BorderRadiusStyle
                                                                        .roundedBorder10,
                                                              ),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Container(
                                                                    width:
                                                                        getHorizontalSize(
                                                                      107,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      left: 2,
                                                                      top: 3,
                                                                    ),
                                                                    child: Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        CustomImageView(
                                                                          imagePath:
                                                                              ImageConstant.imgPullcreditcard3,
                                                                          height:
                                                                              getVerticalSize(
                                                                            34,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            60,
                                                                          ),
                                                                          radius:
                                                                              BorderRadius.circular(
                                                                            getHorizontalSize(
                                                                              3,
                                                                            ),
                                                                          ),
                                                                          margin:
                                                                              getMargin(
                                                                            top:
                                                                                2,
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          height:
                                                                              getVerticalSize(
                                                                            26,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            44,
                                                                          ),
                                                                          margin:
                                                                              getMargin(
                                                                            bottom:
                                                                                10,
                                                                          ),
                                                                          child:
                                                                              Stack(
                                                                            alignment:
                                                                                Alignment.topRight,
                                                                            children: [
                                                                              Align(
                                                                                alignment: Alignment.bottomCenter,
                                                                                child: Container(
                                                                                  decoration: AppDecoration.outlineIndigoA700.copyWith(
                                                                                    borderRadius: BorderRadiusStyle.roundedBorder4,
                                                                                  ),
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.min,
                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                    children: [
                                                                                      Container(
                                                                                        height: getVerticalSize(
                                                                                          16,
                                                                                        ),
                                                                                        width: getHorizontalSize(
                                                                                          44,
                                                                                        ),
                                                                                        decoration: BoxDecoration(
                                                                                          color: ColorConstant.indigoA70001,
                                                                                          borderRadius: BorderRadius.circular(
                                                                                            getHorizontalSize(
                                                                                              4,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      Text(
                                                                                        "lbl_reward_points".tr,
                                                                                        overflow: TextOverflow.ellipsis,
                                                                                        textAlign: TextAlign.left,
                                                                                        style: AppStyle.txtInterRegular6IndigoA700,
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Align(
                                                                                alignment: Alignment.topRight,
                                                                                child: Padding(
                                                                                  padding: getPadding(
                                                                                    right: 13,
                                                                                  ),
                                                                                  child: Text(
                                                                                    "lbl_6".tr,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                    textAlign: TextAlign.left,
                                                                                    style: AppStyle.txtInterRegular17WhiteA700,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Align(
                                                                                alignment: Alignment.bottomRight,
                                                                                child: Padding(
                                                                                  padding: getPadding(
                                                                                    right: 4,
                                                                                    bottom: 4,
                                                                                  ),
                                                                                  child: Text(
                                                                                    "lbl_x".tr,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                    textAlign: TextAlign.left,
                                                                                    style: AppStyle.txtInterRegular17WhiteA700,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    height:
                                                                        getVerticalSize(
                                                                      27,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      103,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 4,
                                                                    ),
                                                                    child:
                                                                        Stack(
                                                                      alignment:
                                                                          Alignment
                                                                              .bottomCenter,
                                                                      children: [
                                                                        Align(
                                                                          alignment:
                                                                              Alignment.topCenter,
                                                                          child:
                                                                              Text(
                                                                            "msg_american_express".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterBold11,
                                                                          ),
                                                                        ),
                                                                        Align(
                                                                          alignment:
                                                                              Alignment.bottomCenter,
                                                                          child:
                                                                              Text(
                                                                            "msg_blue_cash_preferred".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterRegular11Black90099,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Padding(
                                                        padding: getPadding(
                                                          right: 9,
                                                        ),
                                                        child: Text(
                                                          "msg_servicer_highest"
                                                              .tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular6WhiteA700,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.centerRight,
                                          child: Padding(
                                            padding: getPadding(
                                              top: 1,
                                              right: 24,
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding: getPadding(
                                                    top: 6,
                                                    bottom: 7,
                                                  ),
                                                  child: Text(
                                                    "msg_register_with_us".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtInterBold10
                                                        .copyWith(
                                                      decoration: TextDecoration
                                                          .underline,
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  width: getHorizontalSize(
                                                    83,
                                                  ),
                                                  margin: getMargin(
                                                    left: 48,
                                                  ),
                                                  child: RichText(
                                                    text: TextSpan(
                                                      children: [
                                                        TextSpan(
                                                          text:
                                                              "msg_pre_approval_offers"
                                                                  .tr,
                                                          style: TextStyle(
                                                            color: ColorConstant
                                                                .gray50002,
                                                            fontSize:
                                                                getFontSize(
                                                              9,
                                                            ),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            decoration:
                                                                TextDecoration
                                                                    .underline,
                                                          ),
                                                        ),
                                                        TextSpan(
                                                          text:
                                                              "lbl_coming_soon"
                                                                  .tr,
                                                          style: TextStyle(
                                                            color: ColorConstant
                                                                .gray50002,
                                                            fontSize:
                                                                getFontSize(
                                                              10,
                                                            ),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            decoration:
                                                                TextDecoration
                                                                    .underline,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: getVerticalSize(
                                            26,
                                          ),
                                          width: getHorizontalSize(
                                            347,
                                          ),
                                          margin: getMargin(
                                            top: 8,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              Align(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                child: Padding(
                                                  padding: getPadding(
                                                    bottom: 10,
                                                  ),
                                                  child: SizedBox(
                                                    width: getHorizontalSize(
                                                      347,
                                                    ),
                                                    child: Divider(
                                                      height: getVerticalSize(
                                                        1,
                                                      ),
                                                      thickness:
                                                          getVerticalSize(
                                                        1,
                                                      ),
                                                      color: ColorConstant
                                                          .gray80001,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.center,
                                                child: SizedBox(
                                                  height: getVerticalSize(
                                                    26,
                                                  ),
                                                  width: getHorizontalSize(
                                                    102,
                                                  ),
                                                  child: Stack(
                                                    alignment:
                                                        Alignment.bottomCenter,
                                                    children: [
                                                      Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Container(
                                                          height:
                                                              getVerticalSize(
                                                            26,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            101,
                                                          ),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: ColorConstant
                                                                .gray80001,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                              getHorizontalSize(
                                                                13,
                                                              ),
                                                            ),
                                                            border: Border.all(
                                                              color:
                                                                  ColorConstant
                                                                      .gray80001,
                                                              width:
                                                                  getHorizontalSize(
                                                                1,
                                                              ),
                                                            ),
                                                            boxShadow: [
                                                              BoxShadow(
                                                                color: ColorConstant
                                                                    .black9003f,
                                                                spreadRadius:
                                                                    getHorizontalSize(
                                                                  2,
                                                                ),
                                                                blurRadius:
                                                                    getHorizontalSize(
                                                                  2,
                                                                ),
                                                                offset: Offset(
                                                                  0,
                                                                  4,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment: Alignment
                                                            .bottomCenter,
                                                        child: Container(
                                                          margin: getMargin(
                                                            top: 2,
                                                            right: 1,
                                                          ),
                                                          padding: getPadding(
                                                            top: 2,
                                                            bottom: 2,
                                                          ),
                                                          decoration: AppDecoration
                                                              .outlineGray80001
                                                              .copyWith(
                                                            borderRadius:
                                                                BorderRadiusStyle
                                                                    .roundedBorder10,
                                                          ),
                                                          child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceEvenly,
                                                            children: [
                                                              Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Container(
                                                                    height:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    width:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: ColorConstant
                                                                          .gray80001,
                                                                      borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                        getHorizontalSize(
                                                                          2,
                                                                        ),
                                                                      ),
                                                                      boxShadow: [
                                                                        BoxShadow(
                                                                          color:
                                                                              ColorConstant.black90066,
                                                                          spreadRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          blurRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          offset:
                                                                              Offset(
                                                                            0,
                                                                            2,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    height:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    width:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 3,
                                                                    ),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: ColorConstant
                                                                          .gray80001,
                                                                      borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                        getHorizontalSize(
                                                                          2,
                                                                        ),
                                                                      ),
                                                                      boxShadow: [
                                                                        BoxShadow(
                                                                          color:
                                                                              ColorConstant.black90066,
                                                                          spreadRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          blurRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          offset:
                                                                              Offset(
                                                                            0,
                                                                            2,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    height:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    width:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 3,
                                                                    ),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: ColorConstant
                                                                          .gray80001,
                                                                      borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                        getHorizontalSize(
                                                                          2,
                                                                        ),
                                                                      ),
                                                                      boxShadow: [
                                                                        BoxShadow(
                                                                          color:
                                                                              ColorConstant.black90066,
                                                                          spreadRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          blurRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          offset:
                                                                              Offset(
                                                                            0,
                                                                            2,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              Text(
                                                                "lbl_your_wallet3"
                                                                    .tr,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtStaatlichesRegular15Gray30001,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            Alignment.topRight,
                                                        child: Container(
                                                          margin: getMargin(
                                                            top: 7,
                                                          ),
                                                          padding: getPadding(
                                                            left: 2,
                                                            top: 3,
                                                            right: 2,
                                                            bottom: 3,
                                                          ),
                                                          decoration: AppDecoration
                                                              .outlineGray800011
                                                              .copyWith(
                                                            borderRadius:
                                                                BorderRadiusStyle
                                                                    .customBorderTL6,
                                                          ),
                                                          child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Container(
                                                                height: getSize(
                                                                  4,
                                                                ),
                                                                width: getSize(
                                                                  4,
                                                                ),
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: ColorConstant
                                                                      .gray80001,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                    getHorizontalSize(
                                                                      2,
                                                                    ),
                                                                  ),
                                                                  boxShadow: [
                                                                    BoxShadow(
                                                                      color: ColorConstant
                                                                          .black90066,
                                                                      spreadRadius:
                                                                          getHorizontalSize(
                                                                        2,
                                                                      ),
                                                                      blurRadius:
                                                                          getHorizontalSize(
                                                                        2,
                                                                      ),
                                                                      offset:
                                                                          Offset(
                                                                        0,
                                                                        2,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 12,
                                            top: 10,
                                            right: 1,
                                            bottom: 3,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                margin: getMargin(
                                                  bottom: 2,
                                                ),
                                                padding: getPadding(
                                                  all: 2,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineBlack90026
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder10,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 4,
                                                      ),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Container(
                                                            height:
                                                                getVerticalSize(
                                                              34,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              60,
                                                            ),
                                                            margin: getMargin(
                                                              top: 2,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard34x60,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            height:
                                                                getVerticalSize(
                                                              26,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              44,
                                                            ),
                                                            margin: getMargin(
                                                              left: 2,
                                                              bottom: 10,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .topRight,
                                                              children: [
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .bottomCenter,
                                                                  child:
                                                                      Container(
                                                                    decoration: AppDecoration
                                                                        .outlineLime800
                                                                        .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .roundedBorder4,
                                                                    ),
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Container(
                                                                          height:
                                                                              getVerticalSize(
                                                                            16,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            44,
                                                                          ),
                                                                          decoration:
                                                                              BoxDecoration(
                                                                            color:
                                                                                ColorConstant.lime800,
                                                                            borderRadius:
                                                                                BorderRadius.circular(
                                                                              getHorizontalSize(
                                                                                4,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          "lbl_reward_points"
                                                                              .tr,
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          textAlign:
                                                                              TextAlign.left,
                                                                          style:
                                                                              AppStyle.txtInterRegular6Lime800,
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topRight,
                                                                  child:
                                                                      Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      right: 14,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_4"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular17WhiteA700,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .bottomRight,
                                                                  child:
                                                                      Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      right: 4,
                                                                      bottom: 4,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_x"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular17WhiteA700,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 5,
                                                      ),
                                                      child: Text(
                                                        "msg_american_express"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterBold11,
                                                      ),
                                                    ),
                                                    Text(
                                                      "lbl_gold_card".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterRegular11Black90099,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: getMargin(
                                                  top: 1,
                                                  bottom: 1,
                                                ),
                                                padding: getPadding(
                                                  all: 2,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineBlack90026
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder10,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 4,
                                                      ),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Container(
                                                            height:
                                                                getVerticalSize(
                                                              35,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              60,
                                                            ),
                                                            margin: getMargin(
                                                              top: 1,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard1,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            height:
                                                                getVerticalSize(
                                                              26,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              44,
                                                            ),
                                                            margin: getMargin(
                                                              left: 2,
                                                              bottom: 10,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .topRight,
                                                              children: [
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .bottomCenter,
                                                                  child:
                                                                      Container(
                                                                    decoration: AppDecoration
                                                                        .outlineLime800
                                                                        .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .roundedBorder4,
                                                                    ),
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .end,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Container(
                                                                          height:
                                                                              getVerticalSize(
                                                                            16,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            44,
                                                                          ),
                                                                          decoration:
                                                                              BoxDecoration(
                                                                            color:
                                                                                ColorConstant.lime800,
                                                                            borderRadius:
                                                                                BorderRadius.circular(
                                                                              getHorizontalSize(
                                                                                4,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              getPadding(
                                                                            right:
                                                                                2,
                                                                          ),
                                                                          child:
                                                                              Text(
                                                                            "lbl_cashback2".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterRegular6Lime800,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topRight,
                                                                  child:
                                                                      Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      right: 15,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_1"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular17WhiteA700,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topRight,
                                                                  child: Text(
                                                                    "lbl".tr,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtInterRegular17WhiteA700,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 4,
                                                      ),
                                                      child: Text(
                                                        "lbl_discover_it".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterBold11,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 1,
                                                      ),
                                                      child: Text(
                                                        "lbl_cash_back3".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular11Black90099,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: getMargin(
                                                  top: 2,
                                                ),
                                                padding: getPadding(
                                                  top: 2,
                                                  bottom: 2,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineBlack90026
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder10,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 6,
                                                      ),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          SizedBox(
                                                            height:
                                                                getVerticalSize(
                                                              35,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              60,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard2,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding: getPadding(
                                                              left: 2,
                                                            ),
                                                            child: SizedBox(
                                                              height:
                                                                  getVerticalSize(
                                                                35,
                                                              ),
                                                              child:
                                                                  VerticalDivider(
                                                                width:
                                                                    getHorizontalSize(
                                                                  1,
                                                                ),
                                                                thickness:
                                                                    getVerticalSize(
                                                                  1,
                                                                ),
                                                                color: ColorConstant
                                                                    .whiteA700,
                                                                indent:
                                                                    getHorizontalSize(
                                                                  1,
                                                                ),
                                                                endIndent:
                                                                    getHorizontalSize(
                                                                  10,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height:
                                                                getVerticalSize(
                                                              35,
                                                            ),
                                                            child:
                                                                VerticalDivider(
                                                              width:
                                                                  getHorizontalSize(
                                                                1,
                                                              ),
                                                              thickness:
                                                                  getVerticalSize(
                                                                1,
                                                              ),
                                                              color:
                                                                  ColorConstant
                                                                      .lime800,
                                                              indent:
                                                                  getHorizontalSize(
                                                                1,
                                                              ),
                                                              endIndent:
                                                                  getHorizontalSize(
                                                                18,
                                                              ),
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding: getPadding(
                                                              top: 17,
                                                              bottom: 11,
                                                            ),
                                                            child: Text(
                                                              "lbl_cashback2"
                                                                  .tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .right,
                                                              style: AppStyle
                                                                  .txtInterRegular6Lime800,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 5,
                                                      ),
                                                      child: Text(
                                                        "lbl_capital_one".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: AppStyle
                                                            .txtInterBold11,
                                                      ),
                                                    ),
                                                    Text(
                                                      "lbl_venture".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: AppStyle
                                                          .txtInterRegular11Black90099,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgStar3,
                                  height: getVerticalSize(
                                    25,
                                  ),
                                  width: getHorizontalSize(
                                    26,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      1,
                                    ),
                                  ),
                                  alignment: Alignment.topRight,
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgClose,
                                  height: getVerticalSize(
                                    20,
                                  ),
                                  width: getHorizontalSize(
                                    23,
                                  ),
                                  alignment: Alignment.topLeft,
                                  margin: getMargin(
                                    top: 2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Container(
                            height: getVerticalSize(
                              288,
                            ),
                            width: getHorizontalSize(
                              373,
                            ),
                            margin: getMargin(
                              bottom: 6,
                            ),
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                    margin: getMargin(
                                      left: 13,
                                      right: 12,
                                    ),
                                    padding: getPadding(
                                      top: 8,
                                      bottom: 8,
                                    ),
                                    decoration:
                                        AppDecoration.outlinePink70001.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder10,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: getPadding(
                                            left: 11,
                                            right: 10,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: getPadding(
                                                  top: 16,
                                                ),
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgPullmerchantlogo,
                                                      height: getVerticalSize(
                                                        61,
                                                      ),
                                                      width: getHorizontalSize(
                                                        60,
                                                      ),
                                                      radius:
                                                          BorderRadius.circular(
                                                        getHorizontalSize(
                                                          30,
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 6,
                                                      ),
                                                      child: Text(
                                                        "lbl_7_eleven".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular13,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                height: getVerticalSize(
                                                  91,
                                                ),
                                                width: getHorizontalSize(
                                                  113,
                                                ),
                                                margin: getMargin(
                                                  bottom: 8,
                                                ),
                                                child: Stack(
                                                  alignment: Alignment.topRight,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                        decoration: AppDecoration
                                                            .outlineBlack9003f1
                                                            .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder10,
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          children: [
                                                            Container(
                                                              margin: getMargin(
                                                                top: 9,
                                                              ),
                                                              padding:
                                                                  getPadding(
                                                                left: 2,
                                                                top: 3,
                                                                right: 2,
                                                                bottom: 3,
                                                              ),
                                                              decoration:
                                                                  AppDecoration
                                                                      .outlineBlack9003f
                                                                      .copyWith(
                                                                borderRadius:
                                                                    BorderRadiusStyle
                                                                        .roundedBorder10,
                                                              ),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Container(
                                                                    width:
                                                                        getHorizontalSize(
                                                                      107,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      left: 2,
                                                                      top: 3,
                                                                    ),
                                                                    child: Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      children: [
                                                                        Container(
                                                                          height:
                                                                              getVerticalSize(
                                                                            35,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            60,
                                                                          ),
                                                                          margin:
                                                                              getMargin(
                                                                            top:
                                                                                1,
                                                                          ),
                                                                          child:
                                                                              Stack(
                                                                            alignment:
                                                                                Alignment.center,
                                                                            children: [
                                                                              CustomImageView(
                                                                                imagePath: ImageConstant.imgPullcreditcard,
                                                                                height: getVerticalSize(
                                                                                  34,
                                                                                ),
                                                                                width: getHorizontalSize(
                                                                                  60,
                                                                                ),
                                                                                radius: BorderRadius.circular(
                                                                                  getHorizontalSize(
                                                                                    3,
                                                                                  ),
                                                                                ),
                                                                                alignment: Alignment.center,
                                                                              ),
                                                                              CustomImageView(
                                                                                svgPath: ImageConstant.imgTicketAmber300,
                                                                                height: getVerticalSize(
                                                                                  35,
                                                                                ),
                                                                                width: getHorizontalSize(
                                                                                  60,
                                                                                ),
                                                                                alignment: Alignment.center,
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Column(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.end,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: [
                                                                            SizedBox(
                                                                              height: getVerticalSize(
                                                                                26,
                                                                              ),
                                                                              width: getHorizontalSize(
                                                                                44,
                                                                              ),
                                                                              child: Stack(
                                                                                alignment: Alignment.topRight,
                                                                                children: [
                                                                                  Align(
                                                                                    alignment: Alignment.bottomCenter,
                                                                                    child: Container(
                                                                                      decoration: AppDecoration.outlinePink70001.copyWith(
                                                                                        borderRadius: BorderRadiusStyle.roundedBorder4,
                                                                                      ),
                                                                                      child: Column(
                                                                                        mainAxisSize: MainAxisSize.min,
                                                                                        crossAxisAlignment: CrossAxisAlignment.end,
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: [
                                                                                          Container(
                                                                                            height: getVerticalSize(
                                                                                              16,
                                                                                            ),
                                                                                            width: getHorizontalSize(
                                                                                              44,
                                                                                            ),
                                                                                            decoration: BoxDecoration(
                                                                                              color: ColorConstant.pink70001,
                                                                                              borderRadius: BorderRadius.circular(
                                                                                                getHorizontalSize(
                                                                                                  4,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          Padding(
                                                                                            padding: getPadding(
                                                                                              right: 2,
                                                                                            ),
                                                                                            child: Text(
                                                                                              "lbl_cashback2".tr,
                                                                                              overflow: TextOverflow.ellipsis,
                                                                                              textAlign: TextAlign.left,
                                                                                              style: AppStyle.txtInterRegular6,
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: Alignment.topRight,
                                                                                    child: Padding(
                                                                                      padding: getPadding(
                                                                                        right: 14,
                                                                                      ),
                                                                                      child: Text(
                                                                                        "lbl_5".tr,
                                                                                        overflow: TextOverflow.ellipsis,
                                                                                        textAlign: TextAlign.left,
                                                                                        style: AppStyle.txtInterRegular17WhiteA700,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: Alignment.topRight,
                                                                                    child: Text(
                                                                                      "lbl".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtInterRegular17WhiteA700,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            Padding(
                                                                              padding: getPadding(
                                                                                right: 2,
                                                                              ),
                                                                              child: Text(
                                                                                "lbl_stacked".tr,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                textAlign: TextAlign.left,
                                                                                style: AppStyle.txtInterBold8,
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      top: 3,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_cashback2"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterBold11,
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      top: 1,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_blaze"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular11Black90099,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Padding(
                                                        padding: getPadding(
                                                          right: 9,
                                                        ),
                                                        child: Text(
                                                          "lbl_cashback2".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtStaatlichesRegular9,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                height: getVerticalSize(
                                                  89,
                                                ),
                                                width: getHorizontalSize(
                                                  113,
                                                ),
                                                margin: getMargin(
                                                  top: 1,
                                                  bottom: 8,
                                                ),
                                                child: Stack(
                                                  alignment: Alignment.topRight,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                        decoration:
                                                            AppDecoration
                                                                .fillIndigoA700
                                                                .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder10,
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          children: [
                                                            Container(
                                                              margin: getMargin(
                                                                top: 8,
                                                              ),
                                                              padding:
                                                                  getPadding(
                                                                left: 2,
                                                                top: 4,
                                                                right: 2,
                                                                bottom: 4,
                                                              ),
                                                              decoration:
                                                                  AppDecoration
                                                                      .outlineBlack9003f
                                                                      .copyWith(
                                                                borderRadius:
                                                                    BorderRadiusStyle
                                                                        .roundedBorder10,
                                                              ),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Container(
                                                                    width:
                                                                        getHorizontalSize(
                                                                      107,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      left: 2,
                                                                      top: 3,
                                                                    ),
                                                                    child: Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        CustomImageView(
                                                                          imagePath:
                                                                              ImageConstant.imgPullcreditcard3,
                                                                          height:
                                                                              getVerticalSize(
                                                                            34,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            60,
                                                                          ),
                                                                          radius:
                                                                              BorderRadius.circular(
                                                                            getHorizontalSize(
                                                                              3,
                                                                            ),
                                                                          ),
                                                                          margin:
                                                                              getMargin(
                                                                            top:
                                                                                2,
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          height:
                                                                              getVerticalSize(
                                                                            26,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            44,
                                                                          ),
                                                                          margin:
                                                                              getMargin(
                                                                            bottom:
                                                                                10,
                                                                          ),
                                                                          child:
                                                                              Stack(
                                                                            alignment:
                                                                                Alignment.topRight,
                                                                            children: [
                                                                              Align(
                                                                                alignment: Alignment.bottomCenter,
                                                                                child: Container(
                                                                                  decoration: AppDecoration.outlineIndigoA700.copyWith(
                                                                                    borderRadius: BorderRadiusStyle.roundedBorder4,
                                                                                  ),
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.min,
                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                    children: [
                                                                                      Container(
                                                                                        height: getVerticalSize(
                                                                                          16,
                                                                                        ),
                                                                                        width: getHorizontalSize(
                                                                                          44,
                                                                                        ),
                                                                                        decoration: BoxDecoration(
                                                                                          color: ColorConstant.indigoA70001,
                                                                                          borderRadius: BorderRadius.circular(
                                                                                            getHorizontalSize(
                                                                                              4,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      Text(
                                                                                        "lbl_reward_points".tr,
                                                                                        overflow: TextOverflow.ellipsis,
                                                                                        textAlign: TextAlign.left,
                                                                                        style: AppStyle.txtInterRegular6IndigoA700,
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Align(
                                                                                alignment: Alignment.topRight,
                                                                                child: Padding(
                                                                                  padding: getPadding(
                                                                                    right: 13,
                                                                                  ),
                                                                                  child: Text(
                                                                                    "lbl_6".tr,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                    textAlign: TextAlign.left,
                                                                                    style: AppStyle.txtInterRegular17WhiteA700,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Align(
                                                                                alignment: Alignment.bottomRight,
                                                                                child: Padding(
                                                                                  padding: getPadding(
                                                                                    right: 4,
                                                                                    bottom: 4,
                                                                                  ),
                                                                                  child: Text(
                                                                                    "lbl_x".tr,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                    textAlign: TextAlign.left,
                                                                                    style: AppStyle.txtInterRegular17WhiteA700,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    height:
                                                                        getVerticalSize(
                                                                      27,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      103,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 4,
                                                                    ),
                                                                    child:
                                                                        Stack(
                                                                      alignment:
                                                                          Alignment
                                                                              .bottomCenter,
                                                                      children: [
                                                                        Align(
                                                                          alignment:
                                                                              Alignment.topCenter,
                                                                          child:
                                                                              Text(
                                                                            "msg_american_express".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterBold11,
                                                                          ),
                                                                        ),
                                                                        Align(
                                                                          alignment:
                                                                              Alignment.bottomCenter,
                                                                          child:
                                                                              Text(
                                                                            "msg_blue_cash_preferred".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterRegular11Black90099,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Padding(
                                                        padding: getPadding(
                                                          right: 9,
                                                        ),
                                                        child: Text(
                                                          "msg_servicer_highest"
                                                              .tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular6WhiteA700,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.centerRight,
                                          child: Padding(
                                            padding: getPadding(
                                              top: 1,
                                              right: 24,
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding: getPadding(
                                                    top: 6,
                                                    bottom: 7,
                                                  ),
                                                  child: Text(
                                                    "msg_register_with_us".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtInterBold10
                                                        .copyWith(
                                                      decoration: TextDecoration
                                                          .underline,
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  width: getHorizontalSize(
                                                    83,
                                                  ),
                                                  margin: getMargin(
                                                    left: 48,
                                                  ),
                                                  child: RichText(
                                                    text: TextSpan(
                                                      children: [
                                                        TextSpan(
                                                          text:
                                                              "msg_pre_approval_offers"
                                                                  .tr,
                                                          style: TextStyle(
                                                            color: ColorConstant
                                                                .gray50002,
                                                            fontSize:
                                                                getFontSize(
                                                              9,
                                                            ),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            decoration:
                                                                TextDecoration
                                                                    .underline,
                                                          ),
                                                        ),
                                                        TextSpan(
                                                          text:
                                                              "lbl_coming_soon"
                                                                  .tr,
                                                          style: TextStyle(
                                                            color: ColorConstant
                                                                .gray50002,
                                                            fontSize:
                                                                getFontSize(
                                                              10,
                                                            ),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            decoration:
                                                                TextDecoration
                                                                    .underline,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: getVerticalSize(
                                            26,
                                          ),
                                          width: getHorizontalSize(
                                            347,
                                          ),
                                          margin: getMargin(
                                            top: 8,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              Align(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                child: Padding(
                                                  padding: getPadding(
                                                    bottom: 10,
                                                  ),
                                                  child: SizedBox(
                                                    width: getHorizontalSize(
                                                      347,
                                                    ),
                                                    child: Divider(
                                                      height: getVerticalSize(
                                                        1,
                                                      ),
                                                      thickness:
                                                          getVerticalSize(
                                                        1,
                                                      ),
                                                      color: ColorConstant
                                                          .gray80001,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.center,
                                                child: SizedBox(
                                                  height: getVerticalSize(
                                                    26,
                                                  ),
                                                  width: getHorizontalSize(
                                                    102,
                                                  ),
                                                  child: Stack(
                                                    alignment:
                                                        Alignment.bottomCenter,
                                                    children: [
                                                      Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Container(
                                                          height:
                                                              getVerticalSize(
                                                            26,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            101,
                                                          ),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: ColorConstant
                                                                .gray80001,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                              getHorizontalSize(
                                                                13,
                                                              ),
                                                            ),
                                                            border: Border.all(
                                                              color:
                                                                  ColorConstant
                                                                      .gray80001,
                                                              width:
                                                                  getHorizontalSize(
                                                                1,
                                                              ),
                                                            ),
                                                            boxShadow: [
                                                              BoxShadow(
                                                                color: ColorConstant
                                                                    .black9003f,
                                                                spreadRadius:
                                                                    getHorizontalSize(
                                                                  2,
                                                                ),
                                                                blurRadius:
                                                                    getHorizontalSize(
                                                                  2,
                                                                ),
                                                                offset: Offset(
                                                                  0,
                                                                  4,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment: Alignment
                                                            .bottomCenter,
                                                        child: Container(
                                                          margin: getMargin(
                                                            top: 2,
                                                            right: 1,
                                                          ),
                                                          padding: getPadding(
                                                            top: 2,
                                                            bottom: 2,
                                                          ),
                                                          decoration: AppDecoration
                                                              .outlineGray80001
                                                              .copyWith(
                                                            borderRadius:
                                                                BorderRadiusStyle
                                                                    .roundedBorder10,
                                                          ),
                                                          child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceEvenly,
                                                            children: [
                                                              Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Container(
                                                                    height:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    width:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: ColorConstant
                                                                          .gray80001,
                                                                      borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                        getHorizontalSize(
                                                                          2,
                                                                        ),
                                                                      ),
                                                                      boxShadow: [
                                                                        BoxShadow(
                                                                          color:
                                                                              ColorConstant.black90066,
                                                                          spreadRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          blurRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          offset:
                                                                              Offset(
                                                                            0,
                                                                            2,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    height:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    width:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 3,
                                                                    ),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: ColorConstant
                                                                          .gray80001,
                                                                      borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                        getHorizontalSize(
                                                                          2,
                                                                        ),
                                                                      ),
                                                                      boxShadow: [
                                                                        BoxShadow(
                                                                          color:
                                                                              ColorConstant.black90066,
                                                                          spreadRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          blurRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          offset:
                                                                              Offset(
                                                                            0,
                                                                            2,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    height:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    width:
                                                                        getSize(
                                                                      4,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 3,
                                                                    ),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: ColorConstant
                                                                          .gray80001,
                                                                      borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                        getHorizontalSize(
                                                                          2,
                                                                        ),
                                                                      ),
                                                                      boxShadow: [
                                                                        BoxShadow(
                                                                          color:
                                                                              ColorConstant.black90066,
                                                                          spreadRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          blurRadius:
                                                                              getHorizontalSize(
                                                                            2,
                                                                          ),
                                                                          offset:
                                                                              Offset(
                                                                            0,
                                                                            2,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              Text(
                                                                "lbl_your_wallet3"
                                                                    .tr,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtStaatlichesRegular15Gray30001,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            Alignment.topRight,
                                                        child: Container(
                                                          margin: getMargin(
                                                            top: 7,
                                                          ),
                                                          padding: getPadding(
                                                            left: 2,
                                                            top: 3,
                                                            right: 2,
                                                            bottom: 3,
                                                          ),
                                                          decoration: AppDecoration
                                                              .outlineGray800011
                                                              .copyWith(
                                                            borderRadius:
                                                                BorderRadiusStyle
                                                                    .customBorderTL6,
                                                          ),
                                                          child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Container(
                                                                height: getSize(
                                                                  4,
                                                                ),
                                                                width: getSize(
                                                                  4,
                                                                ),
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: ColorConstant
                                                                      .gray80001,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                    getHorizontalSize(
                                                                      2,
                                                                    ),
                                                                  ),
                                                                  boxShadow: [
                                                                    BoxShadow(
                                                                      color: ColorConstant
                                                                          .black90066,
                                                                      spreadRadius:
                                                                          getHorizontalSize(
                                                                        2,
                                                                      ),
                                                                      blurRadius:
                                                                          getHorizontalSize(
                                                                        2,
                                                                      ),
                                                                      offset:
                                                                          Offset(
                                                                        0,
                                                                        2,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 12,
                                            top: 10,
                                            right: 1,
                                            bottom: 3,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                margin: getMargin(
                                                  bottom: 2,
                                                ),
                                                padding: getPadding(
                                                  all: 2,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineBlack90026
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder10,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 4,
                                                      ),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Container(
                                                            height:
                                                                getVerticalSize(
                                                              34,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              60,
                                                            ),
                                                            margin: getMargin(
                                                              top: 2,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard34x60,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            height:
                                                                getVerticalSize(
                                                              26,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              44,
                                                            ),
                                                            margin: getMargin(
                                                              left: 2,
                                                              bottom: 10,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .topRight,
                                                              children: [
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .bottomCenter,
                                                                  child:
                                                                      Container(
                                                                    decoration: AppDecoration
                                                                        .outlineLime800
                                                                        .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .roundedBorder4,
                                                                    ),
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Container(
                                                                          height:
                                                                              getVerticalSize(
                                                                            16,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            44,
                                                                          ),
                                                                          decoration:
                                                                              BoxDecoration(
                                                                            color:
                                                                                ColorConstant.lime800,
                                                                            borderRadius:
                                                                                BorderRadius.circular(
                                                                              getHorizontalSize(
                                                                                4,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          "lbl_reward_points"
                                                                              .tr,
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          textAlign:
                                                                              TextAlign.left,
                                                                          style:
                                                                              AppStyle.txtInterRegular6Lime800,
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topRight,
                                                                  child:
                                                                      Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      right: 14,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_4"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular17WhiteA700,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .bottomRight,
                                                                  child:
                                                                      Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      right: 4,
                                                                      bottom: 4,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_x"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular17WhiteA700,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 5,
                                                      ),
                                                      child: Text(
                                                        "msg_american_express"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterBold11,
                                                      ),
                                                    ),
                                                    Text(
                                                      "lbl_gold_card".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterRegular11Black90099,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: getMargin(
                                                  top: 1,
                                                  bottom: 1,
                                                ),
                                                padding: getPadding(
                                                  all: 2,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineBlack90026
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder10,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 4,
                                                      ),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Container(
                                                            height:
                                                                getVerticalSize(
                                                              35,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              60,
                                                            ),
                                                            margin: getMargin(
                                                              top: 1,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard1,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            height:
                                                                getVerticalSize(
                                                              26,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              44,
                                                            ),
                                                            margin: getMargin(
                                                              left: 2,
                                                              bottom: 10,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .topRight,
                                                              children: [
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .bottomCenter,
                                                                  child:
                                                                      Container(
                                                                    decoration: AppDecoration
                                                                        .outlineLime800
                                                                        .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .roundedBorder4,
                                                                    ),
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .end,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Container(
                                                                          height:
                                                                              getVerticalSize(
                                                                            16,
                                                                          ),
                                                                          width:
                                                                              getHorizontalSize(
                                                                            44,
                                                                          ),
                                                                          decoration:
                                                                              BoxDecoration(
                                                                            color:
                                                                                ColorConstant.lime800,
                                                                            borderRadius:
                                                                                BorderRadius.circular(
                                                                              getHorizontalSize(
                                                                                4,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              getPadding(
                                                                            right:
                                                                                2,
                                                                          ),
                                                                          child:
                                                                              Text(
                                                                            "lbl_cashback2".tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign:
                                                                                TextAlign.left,
                                                                            style:
                                                                                AppStyle.txtInterRegular6Lime800,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topRight,
                                                                  child:
                                                                      Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      right: 15,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_1"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular17WhiteA700,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topRight,
                                                                  child: Text(
                                                                    "lbl".tr,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtInterRegular17WhiteA700,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 4,
                                                      ),
                                                      child: Text(
                                                        "lbl_discover_it".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterBold11,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 1,
                                                      ),
                                                      child: Text(
                                                        "lbl_cash_back3".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular11Black90099,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: getMargin(
                                                  top: 2,
                                                ),
                                                padding: getPadding(
                                                  top: 2,
                                                  bottom: 2,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineBlack90026
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder10,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 6,
                                                      ),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          SizedBox(
                                                            height:
                                                                getVerticalSize(
                                                              35,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              60,
                                                            ),
                                                            child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                                CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgPullcreditcard2,
                                                                  height:
                                                                      getVerticalSize(
                                                                    34,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    60,
                                                                  ),
                                                                  radius: BorderRadius
                                                                      .circular(
                                                                    getHorizontalSize(
                                                                      3,
                                                                    ),
                                                                  ),
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding: getPadding(
                                                              left: 2,
                                                            ),
                                                            child: SizedBox(
                                                              height:
                                                                  getVerticalSize(
                                                                35,
                                                              ),
                                                              child:
                                                                  VerticalDivider(
                                                                width:
                                                                    getHorizontalSize(
                                                                  1,
                                                                ),
                                                                thickness:
                                                                    getVerticalSize(
                                                                  1,
                                                                ),
                                                                color: ColorConstant
                                                                    .whiteA700,
                                                                indent:
                                                                    getHorizontalSize(
                                                                  1,
                                                                ),
                                                                endIndent:
                                                                    getHorizontalSize(
                                                                  10,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height:
                                                                getVerticalSize(
                                                              35,
                                                            ),
                                                            child:
                                                                VerticalDivider(
                                                              width:
                                                                  getHorizontalSize(
                                                                1,
                                                              ),
                                                              thickness:
                                                                  getVerticalSize(
                                                                1,
                                                              ),
                                                              color:
                                                                  ColorConstant
                                                                      .lime800,
                                                              indent:
                                                                  getHorizontalSize(
                                                                1,
                                                              ),
                                                              endIndent:
                                                                  getHorizontalSize(
                                                                18,
                                                              ),
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding: getPadding(
                                                              top: 17,
                                                              bottom: 11,
                                                            ),
                                                            child: Text(
                                                              "lbl_cashback2"
                                                                  .tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .right,
                                                              style: AppStyle
                                                                  .txtInterRegular6Lime800,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 5,
                                                      ),
                                                      child: Text(
                                                        "lbl_capital_one".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: AppStyle
                                                            .txtInterBold11,
                                                      ),
                                                    ),
                                                    Text(
                                                      "lbl_venture".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: AppStyle
                                                          .txtInterRegular11Black90099,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgStar325x26,
                                  height: getVerticalSize(
                                    25,
                                  ),
                                  width: getHorizontalSize(
                                    26,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      1,
                                    ),
                                  ),
                                  alignment: Alignment.topRight,
                                  margin: getMargin(
                                    top: 3,
                                  ),
                                ),
                                CustomImageView(
                                  svgPath: ImageConstant.imgClose,
                                  height: getVerticalSize(
                                    20,
                                  ),
                                  width: getHorizontalSize(
                                    23,
                                  ),
                                  alignment: Alignment.topLeft,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
