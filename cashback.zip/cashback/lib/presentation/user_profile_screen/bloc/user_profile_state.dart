// ignore_for_file: must_be_immutable

part of 'user_profile_bloc.dart';

/// Represents the state of UserProfile in the application.
class UserProfileState extends Equatable {
  UserProfileState({
    this.group432Controller,
    this.emailController,
    this.mobilenoController,
    this.group438Controller,
    this.zipcodeController,
    this.userProfileModelObj,
  });

  TextEditingController? group432Controller;

  TextEditingController? emailController;

  TextEditingController? mobilenoController;

  TextEditingController? group438Controller;

  TextEditingController? zipcodeController;

  UserProfileModel? userProfileModelObj;

  @override
  List<Object?> get props => [
        group432Controller,
        emailController,
        mobilenoController,
        group438Controller,
        zipcodeController,
        userProfileModelObj,
      ];
  UserProfileState copyWith({
    TextEditingController? group432Controller,
    TextEditingController? emailController,
    TextEditingController? mobilenoController,
    TextEditingController? group438Controller,
    TextEditingController? zipcodeController,
    UserProfileModel? userProfileModelObj,
  }) {
    return UserProfileState(
      group432Controller: group432Controller ?? this.group432Controller,
      emailController: emailController ?? this.emailController,
      mobilenoController: mobilenoController ?? this.mobilenoController,
      group438Controller: group438Controller ?? this.group438Controller,
      zipcodeController: zipcodeController ?? this.zipcodeController,
      userProfileModelObj: userProfileModelObj ?? this.userProfileModelObj,
    );
  }
}
