import 'bloc/user_profile_bloc.dart';
import 'models/user_profile_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/core/utils/validation_functions.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class UserProfileScreen extends StatelessWidget {
  UserProfileScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<UserProfileBloc>(
      create: (context) => UserProfileBloc(UserProfileState(
        userProfileModelObj: UserProfileModel(),
      ))
        ..add(UserProfileInitialEvent()),
      child: UserProfileScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        appBar: CustomAppBar(
          height: getVerticalSize(
            56,
          ),
          leadingWidth: 53,
          leading: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              29,
            ),
            svgPath: ImageConstant.imgClock,
            margin: getMargin(
              left: 24,
              top: 12,
              bottom: 12,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink70001,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 42,
                top: 18,
                right: 42,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: getPadding(
              top: 25,
            ),
            child: Padding(
              padding: getPadding(
                left: 13,
                right: 14,
                bottom: 5,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      left: 19,
                    ),
                    child: Text(
                      "lbl_user_profile".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterRegular30,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 4,
                    ),
                    child: Divider(
                      height: getVerticalSize(
                        1,
                      ),
                      thickness: getVerticalSize(
                        1,
                      ),
                      color: ColorConstant.gray80001,
                      endIndent: getHorizontalSize(
                        19,
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 13,
                      top: 36,
                    ),
                    child: Text(
                      "msg_first_and_last_name".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium17Bluegray400,
                    ),
                  ),
                  BlocSelector<UserProfileBloc, UserProfileState,
                      TextEditingController?>(
                    selector: (state) => state.group432Controller,
                    builder: (context, group432Controller) {
                      return CustomTextFormField(
                        focusNode: FocusNode(),
                        autofocus: true,
                        controller: group432Controller,
                        hintText: "lbl_jane_doe".tr,
                        margin: getMargin(
                          left: 13,
                          top: 5,
                        ),
                      );
                    },
                  ),
                  Padding(
                    padding: getPadding(
                      left: 13,
                      top: 30,
                    ),
                    child: Text(
                      "lbl_email_address".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium17Bluegray400,
                    ),
                  ),
                  BlocSelector<UserProfileBloc, UserProfileState,
                      TextEditingController?>(
                    selector: (state) => state.emailController,
                    builder: (context, emailController) {
                      return CustomTextFormField(
                        focusNode: FocusNode(),
                        autofocus: true,
                        controller: emailController,
                        hintText: "msg_janedoe_cashback_financial".tr,
                        margin: getMargin(
                          left: 13,
                          top: 6,
                        ),
                        textInputType: TextInputType.emailAddress,
                        validator: (value) {
                          if (value == null ||
                              (!isValidEmail(value, isRequired: true))) {
                            return "Please enter valid email";
                          }
                          return null;
                        },
                      );
                    },
                  ),
                  Padding(
                    padding: getPadding(
                      left: 13,
                      top: 30,
                    ),
                    child: Text(
                      "lbl_phone_number2".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterMedium17Bluegray400,
                    ),
                  ),
                  BlocSelector<UserProfileBloc, UserProfileState,
                      TextEditingController?>(
                    selector: (state) => state.mobilenoController,
                    builder: (context, mobilenoController) {
                      return CustomTextFormField(
                        focusNode: FocusNode(),
                        autofocus: true,
                        controller: mobilenoController,
                        hintText: "lbl_1_3456542993".tr,
                        margin: getMargin(
                          left: 13,
                          top: 4,
                        ),
                      );
                    },
                  ),
                  Container(
                    height: getVerticalSize(
                      103,
                    ),
                    width: getHorizontalSize(
                      353,
                    ),
                    margin: getMargin(
                      left: 13,
                      top: 30,
                    ),
                    child: Stack(
                      alignment: Alignment.topLeft,
                      children: [
                        Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                            padding: getPadding(
                              right: 2,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  "lbl_optional".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterMedium15Bluegray40099,
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 60,
                                  ),
                                  child: Text(
                                    "lbl_optional".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style:
                                        AppStyle.txtInterMedium15Bluegray40099,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "msg_street_address_line".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterMedium17Bluegray400,
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 6,
                                ),
                                child: Text(
                                  "msg_3678_montgomery".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterMedium17,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: SizedBox(
                            width: getHorizontalSize(
                              353,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray200,
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Text(
                            "msg_street_address_line3".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterMedium17Bluegray400,
                          ),
                        ),
                      ],
                    ),
                  ),
                  BlocSelector<UserProfileBloc, UserProfileState,
                      TextEditingController?>(
                    selector: (state) => state.group438Controller,
                    builder: (context, group438Controller) {
                      return CustomTextFormField(
                        focusNode: FocusNode(),
                        autofocus: true,
                        controller: group438Controller,
                        hintText: "lbl_house_36".tr,
                        margin: getMargin(
                          left: 13,
                          top: 4,
                        ),
                      );
                    },
                  ),
                  Padding(
                    padding: getPadding(
                      left: 13,
                      top: 30,
                    ),
                    child: Row(
                      children: [
                        Padding(
                          padding: getPadding(
                            top: 2,
                          ),
                          child: Text(
                            "lbl_zip_code".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterMedium17Bluegray400,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 103,
                            bottom: 2,
                          ),
                          child: Text(
                            "lbl_state".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterMedium17Bluegray400,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 13,
                      top: 2,
                      right: 34,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: BlocSelector<UserProfileBloc, UserProfileState,
                              TextEditingController?>(
                            selector: (state) => state.zipcodeController,
                            builder: (context, zipcodeController) {
                              return CustomTextFormField(
                                focusNode: FocusNode(),
                                autofocus: true,
                                controller: zipcodeController,
                                hintText: "lbl_84832".tr,
                                margin: getMargin(
                                  top: 1,
                                  right: 17,
                                ),
                                textInputAction: TextInputAction.done,
                              );
                            },
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: getPadding(
                              left: 17,
                              bottom: 1,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  "lbl_va".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterMedium17,
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 4,
                                  ),
                                  child: SizedBox(
                                    width: getHorizontalSize(
                                      142,
                                    ),
                                    child: Divider(
                                      height: getVerticalSize(
                                        1,
                                      ),
                                      thickness: getVerticalSize(
                                        1,
                                      ),
                                      color: ColorConstant.gray200,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: getPadding(
                        top: 66,
                        right: 2,
                      ),
                      child: Text(
                        "lbl_reset_password".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtInterMedium21Black90087.copyWith(
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
