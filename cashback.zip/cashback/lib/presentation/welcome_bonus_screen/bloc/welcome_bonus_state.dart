// ignore_for_file: must_be_immutable

part of 'welcome_bonus_bloc.dart';

/// Represents the state of WelcomeBonus in the application.
class WelcomeBonusState extends Equatable {
  WelcomeBonusState({this.welcomeBonusModelObj});

  WelcomeBonusModel? welcomeBonusModelObj;

  @override
  List<Object?> get props => [
        welcomeBonusModelObj,
      ];
  WelcomeBonusState copyWith({WelcomeBonusModel? welcomeBonusModelObj}) {
    return WelcomeBonusState(
      welcomeBonusModelObj: welcomeBonusModelObj ?? this.welcomeBonusModelObj,
    );
  }
}
