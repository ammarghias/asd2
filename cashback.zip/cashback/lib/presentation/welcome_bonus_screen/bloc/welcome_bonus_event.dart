// ignore_for_file: must_be_immutable

part of 'welcome_bonus_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///WelcomeBonus widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class WelcomeBonusEvent extends Equatable {}

/// Event that is dispatched when the WelcomeBonus widget is first created.
class WelcomeBonusInitialEvent extends WelcomeBonusEvent {
  @override
  List<Object?> get props => [];
}
