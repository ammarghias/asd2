import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/welcome_bonus_screen/models/welcome_bonus_model.dart';
part 'welcome_bonus_event.dart';
part 'welcome_bonus_state.dart';

/// A bloc that manages the state of a WelcomeBonus according to the event that is dispatched to it.
class WelcomeBonusBloc extends Bloc<WelcomeBonusEvent, WelcomeBonusState> {
  WelcomeBonusBloc(WelcomeBonusState initialState) : super(initialState) {
    on<WelcomeBonusInitialEvent>(_onInitialize);
  }

  _onInitialize(
    WelcomeBonusInitialEvent event,
    Emitter<WelcomeBonusState> emit,
  ) async {}
}
