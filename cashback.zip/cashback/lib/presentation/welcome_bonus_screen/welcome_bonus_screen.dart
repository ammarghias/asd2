import 'bloc/welcome_bonus_bloc.dart';
import 'models/welcome_bonus_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:flutter/material.dart';

class WelcomeBonusScreen extends StatelessWidget {
  const WelcomeBonusScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<WelcomeBonusBloc>(
      create: (context) => WelcomeBonusBloc(WelcomeBonusState(
        welcomeBonusModelObj: WelcomeBonusModel(),
      ))
        ..add(WelcomeBonusInitialEvent()),
      child: WelcomeBonusScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<WelcomeBonusBloc, WelcomeBonusState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: SizedBox(
              width: double.maxFinite,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(
                    height: getVerticalSize(
                      165,
                    ),
                    width: double.maxFinite,
                    child: Stack(
                      alignment: Alignment.topCenter,
                      children: [
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Text(
                            "lbl_welcome_bonus2".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtStaatlichesRegular40Gray40008,
                          ),
                        ),
                        CustomImageView(
                          svgPath: ImageConstant.imgHeader,
                          height: getVerticalSize(
                            131,
                          ),
                          width: getHorizontalSize(
                            393,
                          ),
                          alignment: Alignment.topCenter,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 14,
                      top: 17,
                      right: 40,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: getHorizontalSize(
                            179,
                          ),
                          padding: getPadding(
                            left: 2,
                            top: 4,
                            right: 2,
                            bottom: 4,
                          ),
                          decoration: AppDecoration.outlineBlack9003f.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder7,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgPullcreditcard2,
                                height: getVerticalSize(
                                  54,
                                ),
                                width: getHorizontalSize(
                                  90,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    3,
                                  ),
                                ),
                                margin: getMargin(
                                  bottom: 1,
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  53,
                                ),
                                width: getHorizontalSize(
                                  82,
                                ),
                                margin: getMargin(
                                  left: 2,
                                  bottom: 2,
                                ),
                                child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Container(
                                        margin: getMargin(
                                          top: 3,
                                        ),
                                        padding: getPadding(
                                          left: 2,
                                          right: 2,
                                        ),
                                        decoration: AppDecoration
                                            .outlineBluegray10001
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder7,
                                        ),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                top: 38,
                                              ),
                                              child: Text(
                                                "lbl_expires".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular9Gray60004,
                                              ),
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                left: 1,
                                                top: 37,
                                                bottom: 1,
                                              ),
                                              child: Text(
                                                "lbl_12_31_23".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular9Gray60004,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        height: getVerticalSize(
                                          24,
                                        ),
                                        width: getHorizontalSize(
                                          82,
                                        ),
                                        decoration: BoxDecoration(
                                          color: ColorConstant.pink70001,
                                          borderRadius: BorderRadius.circular(
                                            getHorizontalSize(
                                              5,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        margin: getMargin(
                                          top: 3,
                                        ),
                                        padding: getPadding(
                                          left: 2,
                                          top: 1,
                                          right: 2,
                                          bottom: 1,
                                        ),
                                        decoration: AppDecoration
                                            .outlinePink700012
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder7,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                top: 21,
                                              ),
                                              child: Text(
                                                "lbl_reward_points2".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular11Pink70001,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Padding(
                                        padding: getPadding(
                                          top: 2,
                                          right: 2,
                                        ),
                                        child: Text(
                                          "lbl_x".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular17WhiteA700,
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "lbl_60_000".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular21,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 7,
                            top: 8,
                            bottom: 8,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "msg_american_express".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterBold17Gray70003,
                              ),
                              Padding(
                                padding: getPadding(
                                  left: 3,
                                  top: 1,
                                ),
                                child: Text(
                                  "lbl_venture".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular19Black900,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 18,
                    ),
                    child: Divider(
                      height: getVerticalSize(
                        1,
                      ),
                      thickness: getVerticalSize(
                        1,
                      ),
                      color: ColorConstant.gray400,
                      indent: getHorizontalSize(
                        16,
                      ),
                      endIndent: getHorizontalSize(
                        28,
                      ),
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 14,
                      top: 15,
                      right: 40,
                    ),
                    child: Row(
                      children: [
                        Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: EdgeInsets.all(0),
                          color: ColorConstant.whiteA700,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadiusStyle.roundedBorder7,
                          ),
                          child: Container(
                            height: getVerticalSize(
                              63,
                            ),
                            width: getHorizontalSize(
                              179,
                            ),
                            decoration:
                                AppDecoration.outlineBlack9003f.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder7,
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CustomImageView(
                                        imagePath:
                                            ImageConstant.imgPullcreditcard2,
                                        height: getVerticalSize(
                                          54,
                                        ),
                                        width: getHorizontalSize(
                                          90,
                                        ),
                                        radius: BorderRadius.circular(
                                          getHorizontalSize(
                                            3,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          53,
                                        ),
                                        width: getHorizontalSize(
                                          82,
                                        ),
                                        margin: getMargin(
                                          left: 2,
                                          bottom: 1,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.topCenter,
                                          children: [
                                            Align(
                                              alignment: Alignment.bottomCenter,
                                              child: Container(
                                                margin: getMargin(
                                                  top: 3,
                                                ),
                                                padding: getPadding(
                                                  left: 2,
                                                  right: 2,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineBluegray10001
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder7,
                                                ),
                                                child: Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 38,
                                                      ),
                                                      child: Text(
                                                        "lbl_expires".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular9Gray60004,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        left: 1,
                                                        top: 37,
                                                        bottom: 1,
                                                      ),
                                                      child: Text(
                                                        "lbl_12_31_23".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular9Gray60004,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                height: getVerticalSize(
                                                  24,
                                                ),
                                                width: getHorizontalSize(
                                                  82,
                                                ),
                                                decoration: BoxDecoration(
                                                  color:
                                                      ColorConstant.pink70001,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                    getHorizontalSize(
                                                      5,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                margin: getMargin(
                                                  top: 3,
                                                ),
                                                padding: getPadding(
                                                  left: 2,
                                                  top: 1,
                                                  right: 2,
                                                  bottom: 1,
                                                ),
                                                decoration: AppDecoration
                                                    .outlinePink700012
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder7,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 21,
                                                      ),
                                                      child: Text(
                                                        "lbl_reward_points2".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular11Pink70001,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Padding(
                                                padding: getPadding(
                                                  top: 2,
                                                  right: 2,
                                                ),
                                                child: Text(
                                                  "lbl_x".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular17WhiteA700,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Text(
                                                "lbl_60_000".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtInterRegular21,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                    width: getHorizontalSize(
                                      179,
                                    ),
                                    padding: getPadding(
                                      top: 4,
                                      bottom: 4,
                                    ),
                                    decoration: AppDecoration.outlineBlack9003f
                                        .copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder7,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: [
                                        CustomImageView(
                                          imagePath:
                                              ImageConstant.imgPullcreditcard2,
                                          height: getVerticalSize(
                                            54,
                                          ),
                                          width: getHorizontalSize(
                                            90,
                                          ),
                                          radius: BorderRadius.circular(
                                            getHorizontalSize(
                                              3,
                                            ),
                                          ),
                                          margin: getMargin(
                                            bottom: 1,
                                          ),
                                        ),
                                        Container(
                                          height: getVerticalSize(
                                            53,
                                          ),
                                          width: getHorizontalSize(
                                            82,
                                          ),
                                          margin: getMargin(
                                            bottom: 2,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.topCenter,
                                            children: [
                                              Align(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                child: Container(
                                                  margin: getMargin(
                                                    top: 3,
                                                  ),
                                                  padding: getPadding(
                                                    left: 2,
                                                    right: 2,
                                                  ),
                                                  decoration: AppDecoration
                                                      .outlineBluegray10001
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder7,
                                                  ),
                                                  child: Row(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    children: [
                                                      Padding(
                                                        padding: getPadding(
                                                          top: 38,
                                                        ),
                                                        child: Text(
                                                          "lbl_expires".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular9Gray60004,
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding: getPadding(
                                                          left: 1,
                                                          top: 37,
                                                          bottom: 1,
                                                        ),
                                                        child: Text(
                                                          "lbl_12_31_23".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular9Gray60004,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  height: getVerticalSize(
                                                    24,
                                                  ),
                                                  width: getHorizontalSize(
                                                    82,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color:
                                                        ColorConstant.pink70001,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                      getHorizontalSize(
                                                        5,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  margin: getMargin(
                                                    top: 3,
                                                  ),
                                                  padding: getPadding(
                                                    left: 2,
                                                    top: 1,
                                                    right: 2,
                                                    bottom: 1,
                                                  ),
                                                  decoration: AppDecoration
                                                      .outlinePink700012
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder7,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    children: [
                                                      Padding(
                                                        padding: getPadding(
                                                          top: 21,
                                                        ),
                                                        child: Text(
                                                          "lbl_reward_points2"
                                                              .tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular11Pink70001,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                  padding: getPadding(
                                                    top: 2,
                                                    right: 2,
                                                  ),
                                                  child: Text(
                                                    "lbl_x".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtInterRegular17WhiteA700,
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Text(
                                                  "lbl_60_000".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular21,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 7,
                            top: 8,
                            bottom: 8,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: getVerticalSize(
                                  21,
                                ),
                                width: getHorizontalSize(
                                  153,
                                ),
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "msg_american_express".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterBold17Gray70003,
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "msg_american_express".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterBold17Gray70003,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  23,
                                ),
                                width: getHorizontalSize(
                                  70,
                                ),
                                margin: getMargin(
                                  left: 3,
                                  top: 1,
                                ),
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "lbl_venture".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular19Black900,
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "lbl_venture".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular19Black900,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      1,
                    ),
                    width: getHorizontalSize(
                      349,
                    ),
                    margin: getMargin(
                      left: 16,
                      top: 18,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: SizedBox(
                            width: getHorizontalSize(
                              349,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: SizedBox(
                            width: getHorizontalSize(
                              349,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 14,
                      top: 15,
                      right: 40,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: getHorizontalSize(
                            179,
                          ),
                          padding: getPadding(
                            left: 2,
                            top: 4,
                            right: 2,
                            bottom: 4,
                          ),
                          decoration: AppDecoration.outlineBlack9003f.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder7,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgPullcreditcard2,
                                height: getVerticalSize(
                                  54,
                                ),
                                width: getHorizontalSize(
                                  90,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    3,
                                  ),
                                ),
                                margin: getMargin(
                                  bottom: 1,
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  53,
                                ),
                                width: getHorizontalSize(
                                  82,
                                ),
                                margin: getMargin(
                                  left: 2,
                                  bottom: 2,
                                ),
                                child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Container(
                                        margin: getMargin(
                                          top: 3,
                                        ),
                                        padding: getPadding(
                                          left: 2,
                                          right: 2,
                                        ),
                                        decoration: AppDecoration
                                            .outlineBluegray10001
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder7,
                                        ),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                top: 38,
                                              ),
                                              child: Text(
                                                "lbl_expires".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular9Gray60004,
                                              ),
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                left: 1,
                                                top: 37,
                                                bottom: 1,
                                              ),
                                              child: Text(
                                                "lbl_12_31_23".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular9Gray60004,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        height: getVerticalSize(
                                          24,
                                        ),
                                        width: getHorizontalSize(
                                          82,
                                        ),
                                        decoration: BoxDecoration(
                                          color: ColorConstant.pink70001,
                                          borderRadius: BorderRadius.circular(
                                            getHorizontalSize(
                                              5,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        margin: getMargin(
                                          top: 3,
                                        ),
                                        padding: getPadding(
                                          left: 2,
                                          top: 1,
                                          right: 2,
                                          bottom: 1,
                                        ),
                                        decoration: AppDecoration
                                            .outlinePink700012
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder7,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                top: 21,
                                              ),
                                              child: Text(
                                                "lbl_reward_points2".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular11Pink70001,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Padding(
                                        padding: getPadding(
                                          top: 2,
                                          right: 2,
                                        ),
                                        child: Text(
                                          "lbl_x".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular17WhiteA700,
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "lbl_60_000".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular21,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 7,
                            top: 8,
                            bottom: 8,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: getVerticalSize(
                                  21,
                                ),
                                width: getHorizontalSize(
                                  153,
                                ),
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "msg_american_express".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterBold17Gray70003,
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "msg_american_express".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterBold17Gray70003,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  23,
                                ),
                                width: getHorizontalSize(
                                  70,
                                ),
                                margin: getMargin(
                                  left: 3,
                                  top: 1,
                                ),
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "lbl_venture".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular19Black900,
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "lbl_venture".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular19Black900,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      1,
                    ),
                    width: getHorizontalSize(
                      349,
                    ),
                    margin: getMargin(
                      left: 16,
                      top: 18,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: SizedBox(
                            width: getHorizontalSize(
                              349,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: SizedBox(
                            width: getHorizontalSize(
                              349,
                            ),
                            child: Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 14,
                      top: 15,
                      right: 40,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: getHorizontalSize(
                            179,
                          ),
                          padding: getPadding(
                            left: 2,
                            top: 4,
                            right: 2,
                            bottom: 4,
                          ),
                          decoration: AppDecoration.outlineBlack9003f.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder7,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgPullcreditcard2,
                                height: getVerticalSize(
                                  54,
                                ),
                                width: getHorizontalSize(
                                  90,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    3,
                                  ),
                                ),
                                margin: getMargin(
                                  bottom: 1,
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  53,
                                ),
                                width: getHorizontalSize(
                                  82,
                                ),
                                margin: getMargin(
                                  left: 2,
                                  bottom: 2,
                                ),
                                child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Container(
                                        margin: getMargin(
                                          top: 3,
                                        ),
                                        padding: getPadding(
                                          left: 2,
                                          right: 2,
                                        ),
                                        decoration: AppDecoration
                                            .outlineBluegray10001
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder7,
                                        ),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                top: 38,
                                              ),
                                              child: Text(
                                                "lbl_expires".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular9Gray60004,
                                              ),
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                left: 1,
                                                top: 37,
                                                bottom: 1,
                                              ),
                                              child: Text(
                                                "lbl_12_31_23".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular9Gray60004,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        height: getVerticalSize(
                                          24,
                                        ),
                                        width: getHorizontalSize(
                                          82,
                                        ),
                                        decoration: BoxDecoration(
                                          color: ColorConstant.pink70001,
                                          borderRadius: BorderRadius.circular(
                                            getHorizontalSize(
                                              5,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        margin: getMargin(
                                          top: 3,
                                        ),
                                        padding: getPadding(
                                          left: 2,
                                          top: 1,
                                          right: 2,
                                          bottom: 1,
                                        ),
                                        decoration: AppDecoration
                                            .outlinePink700012
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder7,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                top: 21,
                                              ),
                                              child: Text(
                                                "lbl_reward_points2".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular11Pink70001,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Padding(
                                        padding: getPadding(
                                          top: 2,
                                          right: 2,
                                        ),
                                        child: Text(
                                          "lbl_x".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular17WhiteA700,
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "lbl_60_000".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular21,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 7,
                            top: 8,
                            bottom: 8,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "msg_american_express".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterBold17Gray70003,
                              ),
                              Padding(
                                padding: getPadding(
                                  left: 3,
                                  top: 1,
                                ),
                                child: Text(
                                  "lbl_venture".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular19Black900,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 11,
                      top: 34,
                      right: 43,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: getHorizontalSize(
                            179,
                          ),
                          padding: getPadding(
                            left: 2,
                            top: 4,
                            right: 2,
                            bottom: 4,
                          ),
                          decoration: AppDecoration.outlineBlack9003f.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder7,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgPullcreditcard2,
                                height: getVerticalSize(
                                  54,
                                ),
                                width: getHorizontalSize(
                                  90,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    3,
                                  ),
                                ),
                                margin: getMargin(
                                  bottom: 1,
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  53,
                                ),
                                width: getHorizontalSize(
                                  82,
                                ),
                                margin: getMargin(
                                  left: 2,
                                  bottom: 2,
                                ),
                                child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Container(
                                        margin: getMargin(
                                          top: 3,
                                        ),
                                        padding: getPadding(
                                          left: 2,
                                          right: 2,
                                        ),
                                        decoration: AppDecoration
                                            .outlineBluegray10001
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder7,
                                        ),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                top: 38,
                                              ),
                                              child: Text(
                                                "lbl_expires".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular9Gray60004,
                                              ),
                                            ),
                                            Padding(
                                              padding: getPadding(
                                                left: 1,
                                                top: 37,
                                                bottom: 1,
                                              ),
                                              child: Text(
                                                "lbl_12_31_23".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular9Gray60004,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        height: getVerticalSize(
                                          24,
                                        ),
                                        width: getHorizontalSize(
                                          82,
                                        ),
                                        decoration: BoxDecoration(
                                          color: ColorConstant.pink70001,
                                          borderRadius: BorderRadius.circular(
                                            getHorizontalSize(
                                              5,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        margin: getMargin(
                                          top: 3,
                                        ),
                                        padding: getPadding(
                                          left: 2,
                                          top: 1,
                                          right: 2,
                                          bottom: 1,
                                        ),
                                        decoration: AppDecoration
                                            .outlinePink700012
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder7,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                top: 21,
                                              ),
                                              child: Text(
                                                "lbl_reward_points2".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular11Pink70001,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Padding(
                                        padding: getPadding(
                                          top: 2,
                                          right: 2,
                                        ),
                                        child: Text(
                                          "lbl_x".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular17WhiteA700,
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "lbl_60_000".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular21,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 7,
                            top: 8,
                            bottom: 8,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "msg_american_express".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtInterBold17Gray70003,
                              ),
                              Padding(
                                padding: getPadding(
                                  left: 3,
                                  top: 1,
                                ),
                                child: Text(
                                  "lbl_venture".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular19Black900,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 18,
                      bottom: 5,
                    ),
                    child: Divider(
                      height: getVerticalSize(
                        1,
                      ),
                      thickness: getVerticalSize(
                        1,
                      ),
                      color: ColorConstant.gray400,
                      indent: getHorizontalSize(
                        13,
                      ),
                      endIndent: getHorizontalSize(
                        31,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
