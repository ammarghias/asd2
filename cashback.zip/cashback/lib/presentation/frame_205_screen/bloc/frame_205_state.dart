// ignore_for_file: must_be_immutable

part of 'frame_205_bloc.dart';

/// Represents the state of Frame205 in the application.
class Frame205State extends Equatable {
  Frame205State({
    this.zipcodeController,
    this.frame205ModelObj,
  });

  TextEditingController? zipcodeController;

  Frame205Model? frame205ModelObj;

  @override
  List<Object?> get props => [
        zipcodeController,
        frame205ModelObj,
      ];
  Frame205State copyWith({
    TextEditingController? zipcodeController,
    Frame205Model? frame205ModelObj,
  }) {
    return Frame205State(
      zipcodeController: zipcodeController ?? this.zipcodeController,
      frame205ModelObj: frame205ModelObj ?? this.frame205ModelObj,
    );
  }
}
