import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/frame_205_screen/models/frame_205_model.dart';
part 'frame_205_event.dart';
part 'frame_205_state.dart';

/// A bloc that manages the state of a Frame205 according to the event that is dispatched to it.
class Frame205Bloc extends Bloc<Frame205Event, Frame205State> {
  Frame205Bloc(Frame205State initialState) : super(initialState) {
    on<Frame205InitialEvent>(_onInitialize);
  }

  _onInitialize(
    Frame205InitialEvent event,
    Emitter<Frame205State> emit,
  ) async {
    emit(state.copyWith(
      zipcodeController: TextEditingController(),
    ));
  }
}
