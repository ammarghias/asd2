/// This class is used in the [listpullcardnam_item_widget] screen.
class ListpullcardnamItemModel {String pullcardnameTxt = "Small households";

String pullcardnameTxt1 = "AI Debt Manager";

String pullcardnameTxt12 = "Every day purchases";

String pullcardnameTxt123 = "Groceries Utilities";

String pullcardnameTxt1234 = "Credit building";

String? id = "";

 }
