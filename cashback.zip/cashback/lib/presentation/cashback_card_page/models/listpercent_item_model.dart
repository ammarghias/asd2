/// This class is used in the [listpercent_item_widget] screen.
class ListpercentItemModel {String monthTxt = "apr";

String? id = "";

 }
