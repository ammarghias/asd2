/// This class is used in the [listautomatical_item_widget] screen.
class ListautomaticalItemModel {String automaticallyauTxt = "Automatically authorize transactions";

String whereyougettheTxt = "Where You get the Maximum reward";

String consolidatedcreTxt = "Consolidated Credit limits";

String? id = "";

 }
