// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';import 'listpercent_item_model.dart';import 'listautomatical_item_model.dart';import 'listpullcardnam_item_model.dart';/// This class defines the variables used in the [cashback_card_page],
/// and is typically used to hold data that is passed between different parts of the application.
class CashbackCardModel extends Equatable {CashbackCardModel({this.listpercentItemList = const [], this.listautomaticalItemList = const [], this.listpullcardnamItemList = const [], });

List<ListpercentItemModel> listpercentItemList;

List<ListautomaticalItemModel> listautomaticalItemList;

List<ListpullcardnamItemModel> listpullcardnamItemList;

CashbackCardModel copyWith({List<ListpercentItemModel>? listpercentItemList, List<ListautomaticalItemModel>? listautomaticalItemList, List<ListpullcardnamItemModel>? listpullcardnamItemList, }) { return CashbackCardModel(
listpercentItemList : listpercentItemList ?? this.listpercentItemList,
listautomaticalItemList : listautomaticalItemList ?? this.listautomaticalItemList,
listpullcardnamItemList : listpullcardnamItemList ?? this.listpullcardnamItemList,
); } 
@override List<Object?> get props => [listpercentItemList,listautomaticalItemList,listpullcardnamItemList];
 }
