// ignore_for_file: must_be_immutable

part of 'cashback_card_bloc.dart';

/// Represents the state of CashbackCard in the application.
class CashbackCardState extends Equatable {
  CashbackCardState({
    this.groupfortysixController,
    this.isCheckbox = false,
    this.cashbackCardModelObj,
  });

  TextEditingController? groupfortysixController;

  CashbackCardModel? cashbackCardModelObj;

  bool isCheckbox;

  @override
  List<Object?> get props => [
        groupfortysixController,
        isCheckbox,
        cashbackCardModelObj,
      ];
  CashbackCardState copyWith({
    TextEditingController? groupfortysixController,
    bool? isCheckbox,
    CashbackCardModel? cashbackCardModelObj,
  }) {
    return CashbackCardState(
      groupfortysixController:
          groupfortysixController ?? this.groupfortysixController,
      isCheckbox: isCheckbox ?? this.isCheckbox,
      cashbackCardModelObj: cashbackCardModelObj ?? this.cashbackCardModelObj,
    );
  }
}
