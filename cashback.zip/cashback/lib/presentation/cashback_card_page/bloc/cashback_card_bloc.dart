import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/listpercent_item_model.dart';
import '../models/listautomatical_item_model.dart';
import '../models/listpullcardnam_item_model.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/models/cashback_card_model.dart';
part 'cashback_card_event.dart';
part 'cashback_card_state.dart';

/// A bloc that manages the state of a CashbackCard according to the event that is dispatched to it.
class CashbackCardBloc extends Bloc<CashbackCardEvent, CashbackCardState> {
  CashbackCardBloc(CashbackCardState initialState) : super(initialState) {
    on<CashbackCardInitialEvent>(_onInitialize);
    on<ChangeCheckBoxEvent>(_changeCheckBox);
  }

  _changeCheckBox(
    ChangeCheckBoxEvent event,
    Emitter<CashbackCardState> emit,
  ) {
    emit(state.copyWith(
      isCheckbox: event.value,
    ));
  }

  List<ListpercentItemModel> fillListpercentItemList() {
    return List.generate(3, (index) => ListpercentItemModel());
  }

  List<ListautomaticalItemModel> fillListautomaticalItemList() {
    return List.generate(3, (index) => ListautomaticalItemModel());
  }

  List<ListpullcardnamItemModel> fillListpullcardnamItemList() {
    return List.generate(3, (index) => ListpullcardnamItemModel());
  }

  _onInitialize(
    CashbackCardInitialEvent event,
    Emitter<CashbackCardState> emit,
  ) async {
    emit(state.copyWith(
      groupfortysixController: TextEditingController(),
      isCheckbox: false,
    ));
    emit(state.copyWith(
        cashbackCardModelObj: state.cashbackCardModelObj?.copyWith(
      listpercentItemList: fillListpercentItemList(),
      listautomaticalItemList: fillListautomaticalItemList(),
      listpullcardnamItemList: fillListpullcardnamItemList(),
    )));
  }
}
