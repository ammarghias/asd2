// ignore_for_file: must_be_immutable

part of 'cashback_card_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///CashbackCard widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class CashbackCardEvent extends Equatable {}

/// Event that is dispatched when the CashbackCard widget is first created.
class CashbackCardInitialEvent extends CashbackCardEvent {
  @override
  List<Object?> get props => [];
}

///Event for changing checkbox
class ChangeCheckBoxEvent extends CashbackCardEvent {
  ChangeCheckBoxEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
