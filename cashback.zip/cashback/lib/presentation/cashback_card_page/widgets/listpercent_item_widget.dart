import '../models/listpercent_item_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListpercentItemWidget extends StatelessWidget {
  ListpercentItemWidget(
    this.listpercentItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  ListpercentItemModel listpercentItemModelObj;

  @override
  Widget build(BuildContext context) {
    return IntrinsicWidth(
      child: Padding(
        padding: getPadding(
          right: 41,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Padding(
              padding: getPadding(
                top: 14,
              ),
              child: Text(
                "lbl".tr.toUpperCase(),
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtChalkboard20,
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: SizedBox(
                height: getVerticalSize(
                  54,
                ),
                width: getHorizontalSize(
                  40,
                ),
                child: Stack(
                  alignment: Alignment.bottomLeft,
                  children: [
                    Align(
                      alignment: Alignment.topRight,
                      child: Text(
                        "lbl_0".tr.toUpperCase(),
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtChalkboard50,
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Text(
                        listpercentItemModelObj.monthTxt,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtChalkboard20,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
