import '../models/listpullcardnam_item_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListpullcardnamItemWidget extends StatelessWidget {
  ListpullcardnamItemWidget(
    this.listpullcardnamItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  ListpullcardnamItemModel listpullcardnamItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: getHorizontalSize(
        320,
      ),
      padding: getPadding(
        top: 4,
        bottom: 4,
      ),
      decoration: AppDecoration.outlineYellow700.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder10,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          SizedBox(
            height: getVerticalSize(
              60,
            ),
            width: getHorizontalSize(
              90,
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    decoration: AppDecoration.outlineYellow7001.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder7,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: getHorizontalSize(
                            80,
                          ),
                          child: Text(
                            listpullcardnamItemModelObj.pullcardnameTxt,
                            maxLines: null,
                            textAlign: TextAlign.center,
                            style: AppStyle.txtJockeyOneRegular18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    decoration: AppDecoration.outlineYellow7001.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder7,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: getHorizontalSize(
                            86,
                          ),
                          child: Text(
                            listpullcardnamItemModelObj.pullcardnameTxt1,
                            maxLines: null,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtJockeyOneRegular18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: getPadding(
              left: 7,
              top: 3,
              right: 7,
              bottom: 3,
            ),
            decoration: AppDecoration.outlineYellow7001.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder7,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: getHorizontalSize(
                    43,
                  ),
                  margin: getMargin(
                    top: 3,
                  ),
                  child: Text(
                    listpullcardnamItemModelObj.pullcardnameTxt12,
                    maxLines: null,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtJockeyOneRegular18,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: getPadding(
              left: 3,
              top: 5,
              right: 3,
              bottom: 5,
            ),
            decoration: AppDecoration.outlineYellow7001.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder7,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                  width: getHorizontalSize(
                    62,
                  ),
                  child: Text(
                    listpullcardnamItemModelObj.pullcardnameTxt123,
                    maxLines: null,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtJockeyOneRegular18,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: getPadding(
              left: 1,
              top: 3,
              right: 1,
              bottom: 3,
            ),
            decoration: AppDecoration.outlineYellow7001.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder7,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: getHorizontalSize(
                    55,
                  ),
                  margin: getMargin(
                    top: 3,
                  ),
                  child: Text(
                    listpullcardnamItemModelObj.pullcardnameTxt1234,
                    maxLines: null,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtJockeyOneRegular18,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
