import '../cashback_card_page/widgets/listautomatical_item_widget.dart';
import '../cashback_card_page/widgets/listpercent_item_widget.dart';
import '../cashback_card_page/widgets/listpullcardnam_item_widget.dart';
import 'bloc/cashback_card_bloc.dart';
import 'models/cashback_card_model.dart';
import 'models/listautomatical_item_model.dart';
import 'models/listpercent_item_model.dart';
import 'models/listpullcardnam_item_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/widgets/custom_checkbox.dart';
import 'package:ammar_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

// ignore_for_file: must_be_immutable
class CashbackCardPage extends StatelessWidget {
  const CashbackCardPage({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<CashbackCardBloc>(
      create: (context) => CashbackCardBloc(CashbackCardState(
        cashbackCardModelObj: CashbackCardModel(),
      ))
        ..add(CashbackCardInitialEvent()),
      child: CashbackCardPage(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        body: Container(
          width: getHorizontalSize(
            380,
          ),
          decoration: AppDecoration.fillWhiteA700,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: getPadding(
                      bottom: 5,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: getVerticalSize(
                            1016,
                          ),
                          width: getHorizontalSize(
                            380,
                          ),
                          child: Stack(
                            alignment: Alignment.topRight,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgFrame38,
                                height: getVerticalSize(
                                  44,
                                ),
                                width: getHorizontalSize(
                                  11,
                                ),
                                alignment: Alignment.topRight,
                                margin: getMargin(
                                  top: 239,
                                ),
                              ),
                              CustomImageView(
                                imagePath: ImageConstant.imgGroup6,
                                height: getVerticalSize(
                                  377,
                                ),
                                width: getHorizontalSize(
                                  275,
                                ),
                                radius: BorderRadius.circular(
                                  getHorizontalSize(
                                    40,
                                  ),
                                ),
                                alignment: Alignment.topRight,
                                margin: getMargin(
                                  top: 210,
                                ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: getVerticalSize(
                                        632,
                                      ),
                                      width: getHorizontalSize(
                                        380,
                                      ),
                                      child: Stack(
                                        alignment: Alignment.topCenter,
                                        children: [
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgLocationPink100,
                                            height: getVerticalSize(
                                              45,
                                            ),
                                            width: getHorizontalSize(
                                              19,
                                            ),
                                            alignment: Alignment.topRight,
                                            margin: getMargin(
                                              top: 123,
                                              right: 55,
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.topCenter,
                                            child: SizedBox(
                                              height: getVerticalSize(
                                                510,
                                              ),
                                              width: getHorizontalSize(
                                                380,
                                              ),
                                              child: Stack(
                                                alignment: Alignment.topCenter,
                                                children: [
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgImage66,
                                                    height: getVerticalSize(
                                                      510,
                                                    ),
                                                    width: getHorizontalSize(
                                                      380,
                                                    ),
                                                    alignment: Alignment.center,
                                                  ),
                                                  Align(
                                                    alignment:
                                                        Alignment.topCenter,
                                                    child: Container(
                                                      height: getVerticalSize(
                                                        326,
                                                      ),
                                                      width: getHorizontalSize(
                                                        380,
                                                      ),
                                                      margin: getMargin(
                                                        top: 21,
                                                      ),
                                                      child: Stack(
                                                        alignment: Alignment
                                                            .bottomRight,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            child: Padding(
                                                              padding:
                                                                  getPadding(
                                                                left: 7,
                                                              ),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  CustomImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgCut,
                                                                    height:
                                                                        getVerticalSize(
                                                                      44,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      42,
                                                                    ),
                                                                    alignment:
                                                                        Alignment
                                                                            .centerRight,
                                                                  ),
                                                                  CustomImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgCutPink100,
                                                                    height:
                                                                        getVerticalSize(
                                                                      44,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      42,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 89,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment
                                                                .bottomRight,
                                                            child: Padding(
                                                              padding:
                                                                  getPadding(
                                                                left: 73,
                                                                top: 158,
                                                                right: 17,
                                                                bottom: 73,
                                                              ),
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  CustomImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgVolume,
                                                                    height:
                                                                        getVerticalSize(
                                                                      45,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      17,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 49,
                                                                    ),
                                                                  ),
                                                                  Spacer(),
                                                                  Container(
                                                                    width:
                                                                        getHorizontalSize(
                                                                      111,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 14,
                                                                      bottom:
                                                                          40,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_scratch_that"
                                                                          .tr
                                                                          .toUpperCase(),
                                                                      maxLines:
                                                                          null,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .right,
                                                                      style: AppStyle
                                                                          .txtCaveatBrushRegular20,
                                                                    ),
                                                                  ),
                                                                  CustomImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgSignalPink70001,
                                                                    height:
                                                                        getVerticalSize(
                                                                      44,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      42,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      left: 44,
                                                                      bottom:
                                                                          49,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment
                                                                .topRight,
                                                            child: SizedBox(
                                                              height:
                                                                  getVerticalSize(
                                                                152,
                                                              ),
                                                              width:
                                                                  getHorizontalSize(
                                                                156,
                                                              ),
                                                              child: Stack(
                                                                alignment: Alignment
                                                                    .bottomCenter,
                                                                children: [
                                                                  CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgCutPink10044x42,
                                                                    height:
                                                                        getVerticalSize(
                                                                      44,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      42,
                                                                    ),
                                                                    alignment:
                                                                        Alignment
                                                                            .topRight,
                                                                    margin:
                                                                        getMargin(
                                                                      top: 22,
                                                                    ),
                                                                  ),
                                                                  CustomImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgLightbulb,
                                                                    height:
                                                                        getVerticalSize(
                                                                      45,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      17,
                                                                    ),
                                                                    alignment:
                                                                        Alignment
                                                                            .bottomCenter,
                                                                    margin:
                                                                        getMargin(
                                                                      bottom: 8,
                                                                    ),
                                                                  ),
                                                                  CustomImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgFrame45,
                                                                    height:
                                                                        getVerticalSize(
                                                                      45,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      31,
                                                                    ),
                                                                    alignment:
                                                                        Alignment
                                                                            .bottomRight,
                                                                    margin:
                                                                        getMargin(
                                                                      right: 55,
                                                                      bottom: 5,
                                                                    ),
                                                                  ),
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .topLeft,
                                                                    child: Text(
                                                                      "lbl_21"
                                                                          .tr
                                                                          .toUpperCase(),
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtChalkboardBold100,
                                                                    ),
                                                                  ),
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .centerRight,
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          getPadding(
                                                                        right:
                                                                            8,
                                                                      ),
                                                                      child:
                                                                          Text(
                                                                        "lbl"
                                                                            .tr
                                                                            .toUpperCase(),
                                                                        overflow:
                                                                            TextOverflow.ellipsis,
                                                                        textAlign:
                                                                            TextAlign.left,
                                                                        style: AppStyle
                                                                            .txtChalkboard60,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .topRight,
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          getPadding(
                                                                        top: 23,
                                                                        right:
                                                                            12,
                                                                      ),
                                                                      child:
                                                                          Text(
                                                                        "lbl_up_to"
                                                                            .tr
                                                                            .toUpperCase(),
                                                                        overflow:
                                                                            TextOverflow.ellipsis,
                                                                        textAlign:
                                                                            TextAlign.left,
                                                                        style: AppStyle
                                                                            .txtCaveatBrushRegular20,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .bottomRight,
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          getPadding(
                                                                        right:
                                                                            3,
                                                                      ),
                                                                      child:
                                                                          Text(
                                                                        "lbl_back2"
                                                                            .tr
                                                                            .toUpperCase(),
                                                                        overflow:
                                                                            TextOverflow.ellipsis,
                                                                        textAlign:
                                                                            TextAlign.left,
                                                                        style: AppStyle
                                                                            .txtChalkboard40,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment
                                                                .topLeft,
                                                            child: Padding(
                                                              padding:
                                                                  getPadding(
                                                                top: 12,
                                                              ),
                                                              child: Row(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgComputer,
                                                                    height:
                                                                        getVerticalSize(
                                                                      32,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      31,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 15,
                                                                    ),
                                                                  ),
                                                                  CustomImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgCutPink100,
                                                                    height:
                                                                        getVerticalSize(
                                                                      44,
                                                                    ),
                                                                    width:
                                                                        getHorizontalSize(
                                                                      42,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      left: 13,
                                                                      bottom: 2,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgRectangle601,
                                            height: getVerticalSize(
                                              182,
                                            ),
                                            width: getHorizontalSize(
                                              155,
                                            ),
                                            alignment: Alignment.bottomLeft,
                                            margin: getMargin(
                                              bottom: 80,
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath: ImageConstant
                                                .imgCutPink10044x42,
                                            height: getVerticalSize(
                                              44,
                                            ),
                                            width: getHorizontalSize(
                                              19,
                                            ),
                                            alignment: Alignment.topLeft,
                                            margin: getMargin(
                                              top: 109,
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath: ImageConstant
                                                .imgCutPink10021x38,
                                            height: getVerticalSize(
                                              21,
                                            ),
                                            width: getHorizontalSize(
                                              38,
                                            ),
                                            alignment: Alignment.topLeft,
                                          ),
                                          Align(
                                            alignment: Alignment.topRight,
                                            child: Container(
                                              height: getVerticalSize(
                                                44,
                                              ),
                                              width: getHorizontalSize(
                                                12,
                                              ),
                                              margin: getMargin(
                                                top: 237,
                                              ),
                                              child: Stack(
                                                alignment:
                                                    Alignment.bottomRight,
                                                children: [
                                                  CustomImageView(
                                                    imagePath:
                                                        ImageConstant.imgEdit,
                                                    height: getVerticalSize(
                                                      44,
                                                    ),
                                                    width: getHorizontalSize(
                                                      12,
                                                    ),
                                                    radius:
                                                        BorderRadius.circular(
                                                      getHorizontalSize(
                                                        6,
                                                      ),
                                                    ),
                                                    alignment: Alignment.center,
                                                  ),
                                                  Align(
                                                    alignment:
                                                        Alignment.bottomRight,
                                                    child: Container(
                                                      height: getVerticalSize(
                                                        16,
                                                      ),
                                                      width: getHorizontalSize(
                                                        8,
                                                      ),
                                                      margin: getMargin(
                                                        bottom: 4,
                                                      ),
                                                      child: Stack(
                                                        alignment:
                                                            Alignment.topRight,
                                                        children: [
                                                          CustomImageView(
                                                            imagePath: ImageConstant
                                                                .imgGroupWhiteA70010x8,
                                                            height:
                                                                getVerticalSize(
                                                              10,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              8,
                                                            ),
                                                            alignment: Alignment
                                                                .bottomCenter,
                                                          ),
                                                          CustomImageView(
                                                            imagePath: ImageConstant
                                                                .imgGroupWhiteA7009x1,
                                                            height:
                                                                getVerticalSize(
                                                              9,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              1,
                                                            ),
                                                            alignment: Alignment
                                                                .topRight,
                                                          ),
                                                          CustomImageView(
                                                            imagePath: ImageConstant
                                                                .imgGroupWhiteA70010x5,
                                                            height:
                                                                getVerticalSize(
                                                              10,
                                                            ),
                                                            width:
                                                                getHorizontalSize(
                                                              5,
                                                            ),
                                                            alignment: Alignment
                                                                .topRight,
                                                            margin: getMargin(
                                                              top: 2,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.bottomRight,
                                            child: Container(
                                              width: getHorizontalSize(
                                                178,
                                              ),
                                              margin: getMargin(
                                                right: 12,
                                              ),
                                              child: Text(
                                                "msg_on_all_of_your_everyday"
                                                    .tr,
                                                maxLines: null,
                                                textAlign: TextAlign.right,
                                                style: AppStyle
                                                    .txtInterRegular17Black9007e,
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.bottomLeft,
                                            child: Padding(
                                              padding: getPadding(
                                                left: 3,
                                                bottom: 55,
                                              ),
                                              child: Text(
                                                "lbl_no_login".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular14Black9007e,
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.bottomLeft,
                                            child: Padding(
                                              padding: getPadding(
                                                left: 12,
                                                bottom: 30,
                                              ),
                                              child: Text(
                                                "lbl_no_signup".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular15Black90087,
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.bottomLeft,
                                            child: Padding(
                                              padding: getPadding(
                                                left: 28,
                                                bottom: 2,
                                              ),
                                              child: Text(
                                                "lbl_no_expirations".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtInterRegular16,
                                              ),
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath: ImageConstant.imgOffer,
                                            height: getVerticalSize(
                                              29,
                                            ),
                                            width: getHorizontalSize(
                                              34,
                                            ),
                                            alignment: Alignment.topLeft,
                                            margin: getMargin(
                                              top: 46,
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath: ImageConstant
                                                .imgUploadWhiteA700,
                                            height: getVerticalSize(
                                              40,
                                            ),
                                            width: getHorizontalSize(
                                              49,
                                            ),
                                            alignment: Alignment.topLeft,
                                            margin: getMargin(
                                              top: 64,
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath: ImageConstant.imgImage87,
                                            height: getVerticalSize(
                                              619,
                                            ),
                                            width: getHorizontalSize(
                                              215,
                                            ),
                                            radius: BorderRadius.circular(
                                              getHorizontalSize(
                                                54,
                                              ),
                                            ),
                                            alignment: Alignment.centerLeft,
                                          ),
                                          CustomImageView(
                                            imagePath: ImageConstant.imgGroup7,
                                            height: getVerticalSize(
                                              372,
                                            ),
                                            width: getHorizontalSize(
                                              380,
                                            ),
                                            alignment: Alignment.bottomCenter,
                                            margin: getMargin(
                                              bottom: 62,
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath: ImageConstant
                                                .imgGroupAmber300365x365,
                                            height: getSize(
                                              365,
                                            ),
                                            width: getSize(
                                              365,
                                            ),
                                            alignment: Alignment.bottomCenter,
                                            margin: getMargin(
                                              bottom: 62,
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.bottomRight,
                                            child: Container(
                                              height: getVerticalSize(
                                                364,
                                              ),
                                              width: getHorizontalSize(
                                                319,
                                              ),
                                              margin: getMargin(
                                                bottom: 53,
                                              ),
                                              padding: getPadding(
                                                top: 7,
                                                bottom: 7,
                                              ),
                                              decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  image: AssetImage(
                                                    ImageConstant.imgGroup581,
                                                  ),
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                              child: Stack(
                                                alignment: Alignment.bottomLeft,
                                                children: [
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgVector203x243,
                                                    height: getVerticalSize(
                                                      203,
                                                    ),
                                                    width: getHorizontalSize(
                                                      243,
                                                    ),
                                                    alignment:
                                                        Alignment.bottomRight,
                                                    margin: getMargin(
                                                      right: 6,
                                                    ),
                                                  ),
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgVector203x170,
                                                    height: getVerticalSize(
                                                      203,
                                                    ),
                                                    width: getHorizontalSize(
                                                      170,
                                                    ),
                                                    alignment:
                                                        Alignment.bottomLeft,
                                                    margin: getMargin(
                                                      bottom: 32,
                                                    ),
                                                  ),
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgVector75x94,
                                                    height: getVerticalSize(
                                                      75,
                                                    ),
                                                    width: getHorizontalSize(
                                                      94,
                                                    ),
                                                    alignment:
                                                        Alignment.topLeft,
                                                    margin: getMargin(
                                                      left: 77,
                                                      top: 74,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.centerRight,
                                            child: Container(
                                              padding: getPadding(
                                                top: 21,
                                                bottom: 21,
                                              ),
                                              decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  image: AssetImage(
                                                    ImageConstant.imgGroup56,
                                                  ),
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                children: [
                                                  CustomImageView(
                                                    svgPath:
                                                        ImageConstant.imgRewind,
                                                    height: getVerticalSize(
                                                      41,
                                                    ),
                                                    width: getHorizontalSize(
                                                      55,
                                                    ),
                                                    margin: getMargin(
                                                      top: 26,
                                                      right: 29,
                                                    ),
                                                  ),
                                                  Container(
                                                    height: getVerticalSize(
                                                      46,
                                                    ),
                                                    width: getHorizontalSize(
                                                      27,
                                                    ),
                                                    margin: getMargin(
                                                      top: 74,
                                                    ),
                                                    child: Stack(
                                                      alignment:
                                                          Alignment.topLeft,
                                                      children: [
                                                        CustomImageView(
                                                          svgPath: ImageConstant
                                                              .imgRewindWhiteA700,
                                                          height:
                                                              getVerticalSize(
                                                            8,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            7,
                                                          ),
                                                          alignment:
                                                              Alignment.topLeft,
                                                          margin: getMargin(
                                                            top: 16,
                                                          ),
                                                        ),
                                                        CustomImageView(
                                                          svgPath: ImageConstant
                                                              .imgRewindWhiteA700,
                                                          height:
                                                              getVerticalSize(
                                                            7,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            6,
                                                          ),
                                                          alignment:
                                                              Alignment.topLeft,
                                                          margin: getMargin(
                                                            left: 5,
                                                            top: 15,
                                                          ),
                                                        ),
                                                        CustomImageView(
                                                          svgPath: ImageConstant
                                                              .imgSettingsWhiteA7009x8,
                                                          height:
                                                              getVerticalSize(
                                                            9,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            8,
                                                          ),
                                                          alignment: Alignment
                                                              .topCenter,
                                                          margin: getMargin(
                                                            top: 12,
                                                          ),
                                                        ),
                                                        CustomImageView(
                                                          svgPath: ImageConstant
                                                              .imgVectorWhiteA7007x4,
                                                          height:
                                                              getVerticalSize(
                                                            7,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            4,
                                                          ),
                                                          alignment: Alignment
                                                              .topRight,
                                                          margin: getMargin(
                                                            top: 9,
                                                            right: 8,
                                                          ),
                                                        ),
                                                        CustomImageView(
                                                          svgPath: ImageConstant
                                                              .imgVectorWhiteA7006x4,
                                                          height:
                                                              getVerticalSize(
                                                            6,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            4,
                                                          ),
                                                          alignment: Alignment
                                                              .topRight,
                                                          margin: getMargin(
                                                            top: 9,
                                                            right: 4,
                                                          ),
                                                        ),
                                                        CustomImageView(
                                                          imagePath: ImageConstant
                                                              .imgVolumeWhiteA7009x7,
                                                          height:
                                                              getVerticalSize(
                                                            9,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            7,
                                                          ),
                                                          alignment: Alignment
                                                              .topRight,
                                                          margin: getMargin(
                                                            top: 6,
                                                          ),
                                                        ),
                                                        CustomImageView(
                                                          imagePath: ImageConstant
                                                              .imgVectorWhiteA7009x1,
                                                          height:
                                                              getVerticalSize(
                                                            9,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            1,
                                                          ),
                                                          alignment: Alignment
                                                              .topRight,
                                                        ),
                                                        CustomImageView(
                                                          imagePath: ImageConstant
                                                              .imgVolumeWhiteA70034x19,
                                                          height:
                                                              getVerticalSize(
                                                            34,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            19,
                                                          ),
                                                          alignment: Alignment
                                                              .bottomRight,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgGroupWhiteA700110x158,
                                            height: getVerticalSize(
                                              110,
                                            ),
                                            width: getHorizontalSize(
                                              158,
                                            ),
                                            alignment: Alignment.bottomLeft,
                                            margin: getMargin(
                                              left: 92,
                                              bottom: 209,
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgGroupWhiteA700108x164,
                                            height: getVerticalSize(
                                              108,
                                            ),
                                            width: getHorizontalSize(
                                              164,
                                            ),
                                            alignment: Alignment.bottomRight,
                                            margin: getMargin(
                                              right: 40,
                                              bottom: 169,
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant.imgGroup,
                                            height: getVerticalSize(
                                              52,
                                            ),
                                            width: getHorizontalSize(
                                              82,
                                            ),
                                            alignment: Alignment.bottomRight,
                                            margin: getMargin(
                                              right: 102,
                                              bottom: 140,
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath:
                                                ImageConstant.imgGroupWhiteA700,
                                            height: getVerticalSize(
                                              59,
                                            ),
                                            width: getHorizontalSize(
                                              89,
                                            ),
                                            alignment: Alignment.bottomRight,
                                            margin: getMargin(
                                              right: 84,
                                              bottom: 121,
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath:
                                                ImageConstant.imgCutWhiteA700,
                                            height: getVerticalSize(
                                              36,
                                            ),
                                            width: getHorizontalSize(
                                              53,
                                            ),
                                            alignment: Alignment.bottomRight,
                                            margin: getMargin(
                                              right: 104,
                                              bottom: 96,
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgVolumeWhiteA700,
                                            height: getVerticalSize(
                                              35,
                                            ),
                                            width: getHorizontalSize(
                                              46,
                                            ),
                                            alignment: Alignment.bottomRight,
                                            margin: getMargin(
                                              right: 104,
                                              bottom: 79,
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath: ImageConstant.imgGroup9,
                                            height: getVerticalSize(
                                              366,
                                            ),
                                            width: getHorizontalSize(
                                              266,
                                            ),
                                            radius: BorderRadius.circular(
                                              getHorizontalSize(
                                                40,
                                              ),
                                            ),
                                            alignment: Alignment.bottomRight,
                                            margin: getMargin(
                                              bottom: 35,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 7,
                                      ),
                                      child: Text(
                                        "msg_automatically_applied".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style: AppStyle
                                            .txtInterRegular17Black900a7,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        left: 15,
                                        top: 7,
                                        right: 19,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          SizedBox(
                                            height: getVerticalSize(
                                              75,
                                            ),
                                            child: BlocSelector<
                                                CashbackCardBloc,
                                                CashbackCardState,
                                                CashbackCardModel?>(
                                              selector: (state) =>
                                                  state.cashbackCardModelObj,
                                              builder: (context,
                                                  cashbackCardModelObj) {
                                                return ListView.separated(
                                                  scrollDirection:
                                                      Axis.horizontal,
                                                  separatorBuilder: (
                                                    context,
                                                    index,
                                                  ) {
                                                    return SizedBox(
                                                      height: getVerticalSize(
                                                        41,
                                                      ),
                                                    );
                                                  },
                                                  itemCount: cashbackCardModelObj
                                                          ?.listpercentItemList
                                                          .length ??
                                                      0,
                                                  itemBuilder:
                                                      (context, index) {
                                                    ListpercentItemModel model =
                                                        cashbackCardModelObj
                                                                    ?.listpercentItemList[
                                                                index] ??
                                                            ListpercentItemModel();
                                                    return ListpercentItemWidget(
                                                      model,
                                                    );
                                                  },
                                                );
                                              },
                                            ),
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 12,
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding: getPadding(
                                                    left: 1,
                                                  ),
                                                  child: Text(
                                                    "lbl".tr.toUpperCase(),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtChalkboard20,
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: getVerticalSize(
                                                    55,
                                                  ),
                                                  width: getHorizontalSize(
                                                    92,
                                                  ),
                                                  child: Stack(
                                                    alignment:
                                                        Alignment.bottomCenter,
                                                    children: [
                                                      Align(
                                                        alignment:
                                                            Alignment.topRight,
                                                        child: Text(
                                                          "lbl_100"
                                                              .tr
                                                              .toUpperCase(),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtChalkboard50,
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment: Alignment
                                                            .bottomCenter,
                                                        child: Text(
                                                          "lbl_rewards"
                                                              .tr
                                                              .toUpperCase(),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtChalkboard20,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 12,
                                      ),
                                      child: Text(
                                        "msg_because_saving_shouldn_t".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style:
                                            AppStyle.txtInterRegular16Pink70001,
                                      ),
                                    ),
                                    CustomImageView(
                                      svgPath:
                                          ImageConstant.imgGroupPink7000147x279,
                                      height: getVerticalSize(
                                        47,
                                      ),
                                      width: getHorizontalSize(
                                        279,
                                      ),
                                      alignment: Alignment.centerLeft,
                                      margin: getMargin(
                                        left: 44,
                                        top: 27,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 3,
                                      ),
                                      child: Text(
                                        "msg_aiwd_reward_maximization".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style: AppStyle
                                            .txtRobotoRomanRegular16Pink70001,
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                        padding: getPadding(
                                          left: 67,
                                          top: 5,
                                        ),
                                        child: Text(
                                          "lbl_reward_lines".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.center,
                                          style: AppStyle.txtKulimParkItalic40,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: getVerticalSize(
                                        34,
                                      ),
                                      width: getHorizontalSize(
                                        380,
                                      ),
                                      margin: getMargin(
                                        top: 17,
                                      ),
                                      child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Align(
                                            alignment: Alignment.center,
                                            child: SizedBox(
                                              width: getHorizontalSize(
                                                380,
                                              ),
                                              child: Divider(
                                                height: getVerticalSize(
                                                  2,
                                                ),
                                                thickness: getVerticalSize(
                                                  2,
                                                ),
                                                color: ColorConstant.gray40003,
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.center,
                                            child: SizedBox(
                                              height: getVerticalSize(
                                                34,
                                              ),
                                              width: getHorizontalSize(
                                                222,
                                              ),
                                              child: Stack(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                children: [
                                                  CustomImageView(
                                                    svgPath: ImageConstant
                                                        .imgRectangle598,
                                                    height: getVerticalSize(
                                                      34,
                                                    ),
                                                    width: getHorizontalSize(
                                                      222,
                                                    ),
                                                    radius:
                                                        BorderRadius.circular(
                                                      getHorizontalSize(
                                                        7,
                                                      ),
                                                    ),
                                                    alignment: Alignment.center,
                                                  ),
                                                  Align(
                                                    alignment:
                                                        Alignment.bottomCenter,
                                                    child: Padding(
                                                      padding: getPadding(
                                                        bottom: 2,
                                                      ),
                                                      child: Text(
                                                        "msg_pre_enroll_today"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular20WhiteA700,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 22,
                                      ),
                                      child: Text(
                                        "msg_no_fees_no_financial".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style: AppStyle
                                            .txtRobotoRomanRegular16Gray60007,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 11,
                            top: 14,
                            right: 13,
                          ),
                          child: BlocSelector<CashbackCardBloc,
                              CashbackCardState, CashbackCardModel?>(
                            selector: (state) => state.cashbackCardModelObj,
                            builder: (context, cashbackCardModelObj) {
                              return ListView.separated(
                                physics: NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                separatorBuilder: (
                                  context,
                                  index,
                                ) {
                                  return SizedBox(
                                    height: getVerticalSize(
                                      20,
                                    ),
                                  );
                                },
                                itemCount: cashbackCardModelObj
                                        ?.listautomaticalItemList.length ??
                                    0,
                                itemBuilder: (context, index) {
                                  ListautomaticalItemModel model =
                                      cashbackCardModelObj
                                                  ?.listautomaticalItemList[
                                              index] ??
                                          ListautomaticalItemModel();
                                  return ListautomaticalItemWidget(
                                    model,
                                  );
                                },
                              );
                            },
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            top: 19,
                          ),
                          child: Text(
                            "lbl_our_offerings".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtStaatlichesRegular45,
                          ),
                        ),
                        Container(
                          margin: getMargin(
                            left: 29,
                            top: 18,
                            right: 23,
                          ),
                          padding: getPadding(
                            left: 13,
                            top: 3,
                            right: 13,
                            bottom: 3,
                          ),
                          decoration: AppDecoration.outlineGray500031.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder10,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: getPadding(
                                    top: 2,
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Text(
                                        "msg_see_how_you_could".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtRobotoRomanRegular23,
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          top: 1,
                                          right: 2,
                                        ),
                                        child: Text(
                                          "msg_cashback_savings".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style:
                                              AppStyle.txtRobotoRomanRegular15,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              CustomImageView(
                                svgPath: ImageConstant.imgMobile,
                                height: getVerticalSize(
                                  41,
                                ),
                                width: getHorizontalSize(
                                  38,
                                ),
                                margin: getMargin(
                                  left: 10,
                                  top: 2,
                                  right: 8,
                                  bottom: 4,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 3,
                            top: 36,
                            right: 5,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SizedBox(
                                height: getVerticalSize(
                                  526,
                                ),
                                width: getHorizontalSize(
                                  198,
                                ),
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        height: getVerticalSize(
                                          120,
                                        ),
                                        width: getHorizontalSize(
                                          66,
                                        ),
                                        margin: getMargin(
                                          top: 33,
                                          right: 33,
                                        ),
                                        padding: getPadding(
                                          left: 18,
                                          top: 26,
                                          right: 18,
                                          bottom: 26,
                                        ),
                                        decoration: BoxDecoration(
                                          image: DecorationImage(
                                            image: fs.Svg(
                                              ImageConstant.imgGroup63,
                                            ),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                        child: Stack(
                                          alignment: Alignment.bottomLeft,
                                          children: [
                                            CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgGroupWhiteA7005x12,
                                              height: getVerticalSize(
                                                5,
                                              ),
                                              width: getHorizontalSize(
                                                12,
                                              ),
                                              alignment: Alignment.bottomLeft,
                                            ),
                                            CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgGroupWhiteA7005x12,
                                              height: getVerticalSize(
                                                5,
                                              ),
                                              width: getHorizontalSize(
                                                12,
                                              ),
                                              alignment: Alignment.bottomLeft,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.center,
                                      child: SizedBox(
                                        height: getVerticalSize(
                                          526,
                                        ),
                                        width: getHorizontalSize(
                                          198,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.topLeft,
                                          children: [
                                            Align(
                                              alignment: Alignment.center,
                                              child: SizedBox(
                                                width: getHorizontalSize(
                                                  198,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    SizedBox(
                                                      height: getVerticalSize(
                                                        526,
                                                      ),
                                                      width: getHorizontalSize(
                                                        331,
                                                      ),
                                                      child: Stack(
                                                        alignment:
                                                            Alignment.center,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Container(
                                                              height:
                                                                  getVerticalSize(
                                                                526,
                                                              ),
                                                              width:
                                                                  getHorizontalSize(
                                                                331,
                                                              ),
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: ColorConstant
                                                                    .whiteA700,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                  getHorizontalSize(
                                                                    15,
                                                                  ),
                                                                ),
                                                                border:
                                                                    Border.all(
                                                                  color: ColorConstant
                                                                      .pink70001,
                                                                  width:
                                                                      getHorizontalSize(
                                                                    2,
                                                                  ),
                                                                  strokeAlign:
                                                                      strokeAlignOutside,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Padding(
                                                              padding:
                                                                  getPadding(
                                                                left: 4,
                                                                right: 6,
                                                              ),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .end,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      right: 18,
                                                                    ),
                                                                    child: Text(
                                                                      "msg_set_this_card_as"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular11Black9007e,
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      top: 13,
                                                                      right: 63,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_cashback2"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterBold15Black90075,
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      right: 61,
                                                                    ),
                                                                    child: Text(
                                                                      "lbl_gold"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular35Yellow700,
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width:
                                                                        getHorizontalSize(
                                                                      124,
                                                                    ),
                                                                    margin:
                                                                        getMargin(
                                                                      top: 4,
                                                                      right: 13,
                                                                    ),
                                                                    child: Text(
                                                                      "msg_free_now_free"
                                                                          .tr,
                                                                      maxLines:
                                                                          null,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtInterRegular20Black90099,
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin:
                                                                        getMargin(
                                                                      top: 15,
                                                                      right: 1,
                                                                    ),
                                                                    padding:
                                                                        getPadding(
                                                                      top: 1,
                                                                      bottom: 1,
                                                                    ),
                                                                    decoration: AppDecoration
                                                                        .outlinePink7007e
                                                                        .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .roundedBorder10,
                                                                    ),
                                                                    child: Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceEvenly,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .end,
                                                                      children: [
                                                                        Padding(
                                                                          padding:
                                                                              getPadding(
                                                                            top:
                                                                                5,
                                                                            bottom:
                                                                                1,
                                                                          ),
                                                                          child:
                                                                              Column(
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              Padding(
                                                                                padding: getPadding(
                                                                                  left: 1,
                                                                                ),
                                                                                child: Text(
                                                                                  "lbl_estimated".tr,
                                                                                  overflow: TextOverflow.ellipsis,
                                                                                  textAlign: TextAlign.left,
                                                                                  style: AppStyle.txtInterRegular8,
                                                                                ),
                                                                              ),
                                                                              Align(
                                                                                alignment: Alignment.centerRight,
                                                                                child: Padding(
                                                                                  padding: getPadding(
                                                                                    top: 1,
                                                                                    right: 3,
                                                                                  ),
                                                                                  child: Text(
                                                                                    "lbl_annual_savings".tr,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                    textAlign: TextAlign.left,
                                                                                    style: AppStyle.txtInterRegular18Black90087,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                width: getHorizontalSize(
                                                                                  137,
                                                                                ),
                                                                                margin: getMargin(
                                                                                  top: 1,
                                                                                ),
                                                                                child: Text(
                                                                                  "msg_0_introductory".tr,
                                                                                  maxLines: null,
                                                                                  textAlign: TextAlign.left,
                                                                                  style: AppStyle.txtInterRegular8,
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              getPadding(
                                                                            top:
                                                                                7,
                                                                          ),
                                                                          child:
                                                                              Column(
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.end,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              Row(
                                                                                mainAxisAlignment: MainAxisAlignment.end,
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                children: [
                                                                                  Padding(
                                                                                    padding: getPadding(
                                                                                      bottom: 21,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "lbl2".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtInterRegular20Green90099,
                                                                                    ),
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: getPadding(
                                                                                      top: 12,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "lbl_2_643_57".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtInterBold28,
                                                                                    ),
                                                                                  ),
                                                                                  CustomImageView(
                                                                                    svgPath: ImageConstant.imgMobileBlueGray40001,
                                                                                    height: getVerticalSize(
                                                                                      24,
                                                                                    ),
                                                                                    width: getHorizontalSize(
                                                                                      21,
                                                                                    ),
                                                                                    margin: getMargin(
                                                                                      left: 6,
                                                                                      top: 1,
                                                                                      bottom: 8,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              Padding(
                                                                                padding: getPadding(
                                                                                  top: 2,
                                                                                  right: 1,
                                                                                ),
                                                                                child: Row(
                                                                                  mainAxisAlignment: MainAxisAlignment.end,
                                                                                  children: [
                                                                                    SizedBox(
                                                                                      width: getHorizontalSize(
                                                                                        64,
                                                                                      ),
                                                                                      child: Text(
                                                                                        "msg_est_more_than_national".tr,
                                                                                        maxLines: null,
                                                                                        textAlign: TextAlign.left,
                                                                                        style: AppStyle.txtInterRegular8,
                                                                                      ),
                                                                                    ),
                                                                                    Padding(
                                                                                      padding: getPadding(
                                                                                        left: 8,
                                                                                        bottom: 6,
                                                                                      ),
                                                                                      child: Text(
                                                                                        "lbl2".tr,
                                                                                        overflow: TextOverflow.ellipsis,
                                                                                        textAlign: TextAlign.left,
                                                                                        style: AppStyle.txtInterRegular12Green90099,
                                                                                      ),
                                                                                    ),
                                                                                    Padding(
                                                                                      padding: getPadding(
                                                                                        left: 2,
                                                                                      ),
                                                                                      child: Text(
                                                                                        "lbl_1_136_75".tr,
                                                                                        overflow: TextOverflow.ellipsis,
                                                                                        textAlign: TextAlign.left,
                                                                                        style: AppStyle.txtInterRegular18Green90099,
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding:
                                                                        getPadding(
                                                                      left: 1,
                                                                      top: 8,
                                                                    ),
                                                                    child: BlocSelector<
                                                                        CashbackCardBloc,
                                                                        CashbackCardState,
                                                                        CashbackCardModel?>(
                                                                      selector:
                                                                          (state) =>
                                                                              state.cashbackCardModelObj,
                                                                      builder:
                                                                          (context,
                                                                              cashbackCardModelObj) {
                                                                        return ListView
                                                                            .separated(
                                                                          physics:
                                                                              NeverScrollableScrollPhysics(),
                                                                          shrinkWrap:
                                                                              true,
                                                                          separatorBuilder:
                                                                              (
                                                                            context,
                                                                            index,
                                                                          ) {
                                                                            return SizedBox(
                                                                              height: getVerticalSize(
                                                                                11,
                                                                              ),
                                                                            );
                                                                          },
                                                                          itemCount:
                                                                              cashbackCardModelObj?.listpullcardnamItemList.length ?? 0,
                                                                          itemBuilder:
                                                                              (context, index) {
                                                                            ListpullcardnamItemModel
                                                                                model =
                                                                                cashbackCardModelObj?.listpullcardnamItemList[index] ?? ListpullcardnamItemModel();
                                                                            return ListpullcardnamItemWidget(
                                                                              model,
                                                                            );
                                                                          },
                                                                        );
                                                                      },
                                                                    ),
                                                                  ),
                                                                  BlocSelector<
                                                                      CashbackCardBloc,
                                                                      CashbackCardState,
                                                                      TextEditingController?>(
                                                                    selector:
                                                                        (state) =>
                                                                            state.groupfortysixController,
                                                                    builder:
                                                                        (context,
                                                                            groupfortysixController) {
                                                                      return CustomTextFormField(
                                                                        width:
                                                                            getHorizontalSize(
                                                                          191,
                                                                        ),
                                                                        focusNode:
                                                                            FocusNode(),
                                                                        autofocus:
                                                                            true,
                                                                        controller:
                                                                            groupfortysixController,
                                                                        hintText:
                                                                            "msg_everything_else".tr,
                                                                        margin:
                                                                            getMargin(
                                                                          top:
                                                                              9,
                                                                          right:
                                                                              4,
                                                                        ),
                                                                        variant:
                                                                            TextFormFieldVariant.OutlineYellow700,
                                                                        shape: TextFormFieldShape
                                                                            .RoundedBorder6,
                                                                        padding:
                                                                            TextFormFieldPadding.PaddingT16,
                                                                        fontStyle:
                                                                            TextFormFieldFontStyle.InterRegular15,
                                                                        textInputAction:
                                                                            TextInputAction.done,
                                                                      );
                                                                    },
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SingleChildScrollView(
                                                      scrollDirection:
                                                          Axis.horizontal,
                                                      child: IntrinsicWidth(
                                                        child: SizedBox(
                                                          height:
                                                              getVerticalSize(
                                                            526,
                                                          ),
                                                          width:
                                                              getHorizontalSize(
                                                            331,
                                                          ),
                                                          child: Stack(
                                                            alignment: Alignment
                                                                .bottomCenter,
                                                            children: [
                                                              Align(
                                                                alignment:
                                                                    Alignment
                                                                        .center,
                                                                child:
                                                                    Container(
                                                                  height:
                                                                      getVerticalSize(
                                                                    526,
                                                                  ),
                                                                  width:
                                                                      getHorizontalSize(
                                                                    331,
                                                                  ),
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: ColorConstant
                                                                        .whiteA700,
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(
                                                                      getHorizontalSize(
                                                                        15,
                                                                      ),
                                                                    ),
                                                                    border:
                                                                        Border
                                                                            .all(
                                                                      color: ColorConstant
                                                                          .pink70001,
                                                                      width:
                                                                          getHorizontalSize(
                                                                        2,
                                                                      ),
                                                                      strokeAlign:
                                                                          strokeAlignOutside,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Align(
                                                                alignment: Alignment
                                                                    .bottomCenter,
                                                                child: Padding(
                                                                  padding:
                                                                      getPadding(
                                                                    left: 4,
                                                                    right: 6,
                                                                    bottom: 72,
                                                                  ),
                                                                  child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Container(
                                                                        margin:
                                                                            getMargin(
                                                                          right:
                                                                              1,
                                                                        ),
                                                                        padding:
                                                                            getPadding(
                                                                          left:
                                                                              6,
                                                                          top:
                                                                              2,
                                                                          right:
                                                                              6,
                                                                          bottom:
                                                                              2,
                                                                        ),
                                                                        decoration: AppDecoration
                                                                            .outlinePink7007e
                                                                            .copyWith(
                                                                          borderRadius:
                                                                              BorderRadiusStyle.roundedBorder10,
                                                                        ),
                                                                        child:
                                                                            Column(
                                                                          mainAxisSize:
                                                                              MainAxisSize.min,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.end,
                                                                          children: [
                                                                            Padding(
                                                                              padding: getPadding(
                                                                                top: 5,
                                                                                right: 30,
                                                                              ),
                                                                              child: Row(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                children: [
                                                                                  Container(
                                                                                    height: getVerticalSize(
                                                                                      31,
                                                                                    ),
                                                                                    width: getHorizontalSize(
                                                                                      107,
                                                                                    ),
                                                                                    margin: getMargin(
                                                                                      bottom: 1,
                                                                                    ),
                                                                                    child: Stack(
                                                                                      alignment: Alignment.topLeft,
                                                                                      children: [
                                                                                        Align(
                                                                                          alignment: Alignment.bottomCenter,
                                                                                          child: Text(
                                                                                            "lbl_annual_savings".tr,
                                                                                            overflow: TextOverflow.ellipsis,
                                                                                            textAlign: TextAlign.left,
                                                                                            style: AppStyle.txtInterRegular18Black90087,
                                                                                          ),
                                                                                        ),
                                                                                        Align(
                                                                                          alignment: Alignment.topLeft,
                                                                                          child: Padding(
                                                                                            padding: getPadding(
                                                                                              left: 2,
                                                                                            ),
                                                                                            child: Text(
                                                                                              "lbl_estimated".tr,
                                                                                              overflow: TextOverflow.ellipsis,
                                                                                              textAlign: TextAlign.left,
                                                                                              style: AppStyle.txtInterRegular8,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: getPadding(
                                                                                      left: 33,
                                                                                      top: 1,
                                                                                      bottom: 22,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "lbl2".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtInterRegular20Green90099,
                                                                                    ),
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: getPadding(
                                                                                      top: 10,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "lbl_2_643_57".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.right,
                                                                                      style: AppStyle.txtInterBold28,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            Padding(
                                                                              padding: getPadding(
                                                                                left: 1,
                                                                                top: 2,
                                                                                right: 4,
                                                                              ),
                                                                              child: Row(
                                                                                children: [
                                                                                  Container(
                                                                                    width: getHorizontalSize(
                                                                                      94,
                                                                                    ),
                                                                                    margin: getMargin(
                                                                                      bottom: 3,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "msg_0_introductory2".tr,
                                                                                      maxLines: null,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtInterRegular8,
                                                                                    ),
                                                                                  ),
                                                                                  Spacer(),
                                                                                  SizedBox(
                                                                                    width: getHorizontalSize(
                                                                                      72,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "msg_est_more_than_national".tr,
                                                                                      maxLines: null,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtInterRegular8,
                                                                                    ),
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: getPadding(
                                                                                      left: 2,
                                                                                      bottom: 3,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "lbl2".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.right,
                                                                                      style: AppStyle.txtInterRegular12Green90099,
                                                                                    ),
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: getPadding(
                                                                                      left: 1,
                                                                                      bottom: 3,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "lbl_1_136_75".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.right,
                                                                                      style: AppStyle.txtInterRegular15Green90099,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin:
                                                                            getMargin(
                                                                          left:
                                                                              1,
                                                                          top:
                                                                              7,
                                                                        ),
                                                                        padding:
                                                                            getPadding(
                                                                          top:
                                                                              4,
                                                                          bottom:
                                                                              4,
                                                                        ),
                                                                        decoration: AppDecoration
                                                                            .outlineCyan800
                                                                            .copyWith(
                                                                          borderRadius:
                                                                              BorderRadiusStyle.roundedBorder10,
                                                                        ),
                                                                        child:
                                                                            Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceEvenly,
                                                                          children: [
                                                                            SizedBox(
                                                                              height: getVerticalSize(
                                                                                60,
                                                                              ),
                                                                              width: getHorizontalSize(
                                                                                90,
                                                                              ),
                                                                              child: Stack(
                                                                                alignment: Alignment.center,
                                                                                children: [
                                                                                  Align(
                                                                                    alignment: Alignment.centerLeft,
                                                                                    child: Container(
                                                                                      padding: getPadding(
                                                                                        top: 5,
                                                                                        bottom: 5,
                                                                                      ),
                                                                                      decoration: AppDecoration.outlineYellow7001.copyWith(
                                                                                        borderRadius: BorderRadiusStyle.roundedBorder7,
                                                                                      ),
                                                                                      child: Column(
                                                                                        mainAxisSize: MainAxisSize.min,
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: [
                                                                                          SizedBox(
                                                                                            width: getHorizontalSize(
                                                                                              78,
                                                                                            ),
                                                                                            child: Text(
                                                                                              "msg_small_households".tr,
                                                                                              maxLines: null,
                                                                                              textAlign: TextAlign.center,
                                                                                              style: AppStyle.txtJockeyOneRegular18,
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: Alignment.center,
                                                                                    child: Container(
                                                                                      padding: getPadding(
                                                                                        left: 4,
                                                                                        top: 3,
                                                                                        right: 4,
                                                                                        bottom: 3,
                                                                                      ),
                                                                                      decoration: AppDecoration.outlineCyan8001.copyWith(
                                                                                        borderRadius: BorderRadiusStyle.roundedBorder7,
                                                                                      ),
                                                                                      child: Column(
                                                                                        mainAxisSize: MainAxisSize.min,
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                                                        children: [
                                                                                          Container(
                                                                                            width: getHorizontalSize(
                                                                                              69,
                                                                                            ),
                                                                                            margin: getMargin(
                                                                                              top: 3,
                                                                                            ),
                                                                                            child: Text(
                                                                                              "msg_analytical_budgeting".tr,
                                                                                              maxLines: null,
                                                                                              textAlign: TextAlign.left,
                                                                                              style: AppStyle.txtJockeyOneRegular18,
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              padding: getPadding(
                                                                                all: 5,
                                                                              ),
                                                                              decoration: AppDecoration.outlineCyan8001.copyWith(
                                                                                borderRadius: BorderRadiusStyle.roundedBorder7,
                                                                              ),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.min,
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: [
                                                                                  SizedBox(
                                                                                    width: getHorizontalSize(
                                                                                      9,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "msg_travel_adventure".tr,
                                                                                      maxLines: null,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtJockeyOneRegular18,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              decoration: AppDecoration.outlineCyan8001.copyWith(
                                                                                borderRadius: BorderRadiusStyle.roundedBorder7,
                                                                              ),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.min,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: [
                                                                                  SizedBox(
                                                                                    width: getHorizontalSize(
                                                                                      67,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "msg_chilling_dining".tr,
                                                                                      maxLines: null,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtJockeyOneRegular18,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              decoration: AppDecoration.outlineCyan8001.copyWith(
                                                                                borderRadius: BorderRadiusStyle.roundedBorder7,
                                                                              ),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.min,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: [
                                                                                  SizedBox(
                                                                                    width: getHorizontalSize(
                                                                                      57,
                                                                                    ),
                                                                                    child: Text(
                                                                                      "lbl_finance_hub".tr,
                                                                                      maxLines: null,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtJockeyOneRegular18,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin:
                                                                            getMargin(
                                                                          left:
                                                                              6,
                                                                          top:
                                                                              12,
                                                                          right:
                                                                              4,
                                                                        ),
                                                                        padding:
                                                                            getPadding(
                                                                          left:
                                                                              7,
                                                                          top:
                                                                              3,
                                                                          right:
                                                                              7,
                                                                          bottom:
                                                                              3,
                                                                        ),
                                                                        decoration: AppDecoration
                                                                            .outlineCyan8002
                                                                            .copyWith(
                                                                          borderRadius:
                                                                              BorderRadiusStyle.roundedBorder7,
                                                                        ),
                                                                        child:
                                                                            Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.end,
                                                                          mainAxisSize:
                                                                              MainAxisSize.min,
                                                                          children: [
                                                                            Container(
                                                                              height: getVerticalSize(
                                                                                47,
                                                                              ),
                                                                              width: getHorizontalSize(
                                                                                54,
                                                                              ),
                                                                              margin: getMargin(
                                                                                left: 47,
                                                                                top: 6,
                                                                              ),
                                                                              child: Stack(
                                                                                alignment: Alignment.topLeft,
                                                                                children: [
                                                                                  Align(
                                                                                    alignment: Alignment.bottomCenter,
                                                                                    child: Text(
                                                                                      "lbl_32".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtInterRegular35Pink70001,
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: Alignment.topLeft,
                                                                                    child: Padding(
                                                                                      padding: getPadding(
                                                                                        left: 3,
                                                                                      ),
                                                                                      child: Text(
                                                                                        "lbl_upto2".tr,
                                                                                        overflow: TextOverflow.ellipsis,
                                                                                        textAlign: TextAlign.left,
                                                                                        style: AppStyle.txtInterRegular9,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              width: getHorizontalSize(
                                                                                83,
                                                                              ),
                                                                              margin: getMargin(
                                                                                left: 20,
                                                                                top: 12,
                                                                                bottom: 12,
                                                                              ),
                                                                              child: Text(
                                                                                "msg_groceries_utilities2".tr,
                                                                                maxLines: null,
                                                                                textAlign: TextAlign.left,
                                                                                style: AppStyle.txtInterRegular8Black90090,
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              width: getHorizontalSize(
                                                                                89,
                                                                              ),
                                                                              margin: getMargin(
                                                                                left: 4,
                                                                                top: 12,
                                                                                bottom: 12,
                                                                              ),
                                                                              child: Text(
                                                                                "msg_outlets_shopping_home".tr,
                                                                                maxLines: null,
                                                                                textAlign: TextAlign.left,
                                                                                style: AppStyle.txtInterRegular8Black90090,
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin:
                                                                            getMargin(
                                                                          left:
                                                                              6,
                                                                          top:
                                                                              9,
                                                                          right:
                                                                              4,
                                                                        ),
                                                                        padding:
                                                                            getPadding(
                                                                          left:
                                                                              7,
                                                                          top:
                                                                              3,
                                                                          right:
                                                                              7,
                                                                          bottom:
                                                                              3,
                                                                        ),
                                                                        decoration: AppDecoration
                                                                            .outlineCyan8002
                                                                            .copyWith(
                                                                          borderRadius:
                                                                              BorderRadiusStyle.roundedBorder7,
                                                                        ),
                                                                        child:
                                                                            Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.end,
                                                                          mainAxisSize:
                                                                              MainAxisSize.min,
                                                                          children: [
                                                                            Container(
                                                                              height: getVerticalSize(
                                                                                47,
                                                                              ),
                                                                              width: getHorizontalSize(
                                                                                53,
                                                                              ),
                                                                              margin: getMargin(
                                                                                left: 46,
                                                                                top: 6,
                                                                              ),
                                                                              child: Stack(
                                                                                alignment: Alignment.topLeft,
                                                                                children: [
                                                                                  Align(
                                                                                    alignment: Alignment.bottomCenter,
                                                                                    child: Text(
                                                                                      "lbl_42".tr,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      textAlign: TextAlign.left,
                                                                                      style: AppStyle.txtInterRegular35Pink70001,
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: Alignment.topLeft,
                                                                                    child: Padding(
                                                                                      padding: getPadding(
                                                                                        left: 4,
                                                                                      ),
                                                                                      child: Text(
                                                                                        "lbl_upto2".tr,
                                                                                        overflow: TextOverflow.ellipsis,
                                                                                        textAlign: TextAlign.left,
                                                                                        style: AppStyle.txtInterRegular9,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              width: getHorizontalSize(
                                                                                83,
                                                                              ),
                                                                              margin: getMargin(
                                                                                left: 21,
                                                                                top: 12,
                                                                                bottom: 12,
                                                                              ),
                                                                              child: Text(
                                                                                "msg_travelling_flights".tr,
                                                                                maxLines: null,
                                                                                textAlign: TextAlign.left,
                                                                                style: AppStyle.txtInterRegular8Black90090,
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              width: getHorizontalSize(
                                                                                89,
                                                                              ),
                                                                              margin: getMargin(
                                                                                left: 4,
                                                                                top: 12,
                                                                                bottom: 12,
                                                                              ),
                                                                              child: Text(
                                                                                "msg_hoteling_lodging_tourism".tr,
                                                                                maxLines: null,
                                                                                textAlign: TextAlign.left,
                                                                                style: AppStyle.txtInterRegular8Black90090,
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: getHorizontalSize(
                                                  192,
                                                ),
                                                margin: getMargin(
                                                  top: 34,
                                                  right: 158,
                                                  bottom: 372,
                                                ),
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: fs.Svg(
                                                      ImageConstant.imgGroup63,
                                                    ),
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgGroup8,
                                                      height: getVerticalSize(
                                                        120,
                                                      ),
                                                      width: getHorizontalSize(
                                                        192,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: IntrinsicWidth(
                                  child: Container(
                                    padding: getPadding(
                                      top: 9,
                                      bottom: 9,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgTelevision,
                                              height: getSize(
                                                20,
                                              ),
                                              width: getSize(
                                                20,
                                              ),
                                            ),
                                            BlocSelector<CashbackCardBloc,
                                                CashbackCardState, bool?>(
                                              selector: (state) =>
                                                  state.isCheckbox,
                                              builder: (context, isCheckbox) {
                                                return CustomCheckbox(
                                                  text:
                                                      "msg_set_this_card_as".tr,
                                                  value: isCheckbox,
                                                  margin: getMargin(
                                                    left: 369,
                                                  ),
                                                  fontStyle: CheckboxFontStyle
                                                      .InterRegular11,
                                                  onChange: (value) {
                                                    context
                                                        .read<
                                                            CashbackCardBloc>()
                                                        .add(
                                                            ChangeCheckBoxEvent(
                                                                value: value));
                                                  },
                                                );
                                              },
                                            ),
                                          ],
                                        ),
                                        Align(
                                          alignment: Alignment.center,
                                          child: Container(
                                            height: getVerticalSize(
                                              4,
                                            ),
                                            width: getHorizontalSize(
                                              37,
                                            ),
                                            margin: getMargin(
                                              top: 80,
                                            ),
                                            child: Stack(
                                              alignment: Alignment.centerLeft,
                                              children: [
                                                CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgGroupWhiteA7004x37,
                                                  height: getVerticalSize(
                                                    4,
                                                  ),
                                                  width: getHorizontalSize(
                                                    37,
                                                  ),
                                                  alignment: Alignment.center,
                                                ),
                                                Align(
                                                  alignment:
                                                      Alignment.centerLeft,
                                                  child: Row(
                                                    children: [
                                                      SizedBox(
                                                        height: getVerticalSize(
                                                          4,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          37,
                                                        ),
                                                        child: Stack(
                                                          alignment:
                                                              Alignment.center,
                                                          children: [
                                                            CustomImageView(
                                                              svgPath: ImageConstant
                                                                  .imgGroupWhiteA7004x37,
                                                              height:
                                                                  getVerticalSize(
                                                                4,
                                                              ),
                                                              width:
                                                                  getHorizontalSize(
                                                                37,
                                                              ),
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                            ),
                                                            CustomImageView(
                                                              svgPath: ImageConstant
                                                                  .imgGroupWhiteA7004x37,
                                                              height:
                                                                  getVerticalSize(
                                                                4,
                                                              ),
                                                              width:
                                                                  getHorizontalSize(
                                                                37,
                                                              ),
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgGroupWhiteA7004x37,
                                                        height: getVerticalSize(
                                                          4,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          37,
                                                        ),
                                                        margin: getMargin(
                                                          left: 351,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 32,
                                            top: 210,
                                          ),
                                          child: Text(
                                            "lbl_22".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtInterRegular35Pink70001,
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            left: 33,
                                            top: 26,
                                          ),
                                          child: Text(
                                            "lbl_22".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtInterRegular35Pink70001,
                                          ),
                                        ),
                                        Padding(
                                          padding: getPadding(
                                            top: 26,
                                            bottom: 1,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Container(
                                                height: getVerticalSize(
                                                  40,
                                                ),
                                                width: getHorizontalSize(
                                                  46,
                                                ),
                                                margin: getMargin(
                                                  top: 4,
                                                  bottom: 8,
                                                ),
                                                child: Stack(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  children: [
                                                    Align(
                                                      alignment: Alignment
                                                          .bottomCenter,
                                                      child: Text(
                                                        "lbl_12".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: AppStyle
                                                            .txtInterRegular35Pink70001,
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      child: Text(
                                                        "lbl_unlimited".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.right,
                                                        style: AppStyle
                                                            .txtInterBold9,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                height: getVerticalSize(
                                                  52,
                                                ),
                                                width: getHorizontalSize(
                                                  106,
                                                ),
                                                margin: getMargin(
                                                  left: 285,
                                                ),
                                                child: Stack(
                                                  alignment:
                                                      Alignment.bottomRight,
                                                  children: [
                                                    CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgRectangle619,
                                                      height: getVerticalSize(
                                                        52,
                                                      ),
                                                      width: getHorizontalSize(
                                                        106,
                                                      ),
                                                      alignment:
                                                          Alignment.center,
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.bottomRight,
                                                      child: Padding(
                                                        padding: getPadding(
                                                          right: 3,
                                                        ),
                                                        child: Text(
                                                          "lbl_12".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular35Pink70001,
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Padding(
                                                        padding: getPadding(
                                                          top: 4,
                                                          right: 10,
                                                        ),
                                                        child: Text(
                                                          "lbl_unlimited".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterBold9,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: getVerticalSize(
                            34,
                          ),
                          width: getHorizontalSize(
                            380,
                          ),
                          margin: getMargin(
                            top: 28,
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Padding(
                                  padding: getPadding(
                                    bottom: 14,
                                  ),
                                  child: SizedBox(
                                    width: getHorizontalSize(
                                      380,
                                    ),
                                    child: Divider(
                                      height: getVerticalSize(
                                        2,
                                      ),
                                      thickness: getVerticalSize(
                                        2,
                                      ),
                                      color: ColorConstant.gray40003,
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Container(
                                  width: getHorizontalSize(
                                    222,
                                  ),
                                  padding: getPadding(
                                    left: 30,
                                    top: 2,
                                    right: 31,
                                    bottom: 2,
                                  ),
                                  decoration: AppDecoration.txtOutlineWhiteA7001
                                      .copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.txtRoundedBorder7,
                                  ),
                                  child: Text(
                                    "msg_pre_enroll_today".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular20WhiteA700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: getHorizontalSize(
                            354,
                          ),
                          margin: getMargin(
                            left: 12,
                            top: 15,
                            right: 13,
                          ),
                          child: Text(
                            "msg_all_eligible_rewards".tr,
                            maxLines: null,
                            textAlign: TextAlign.center,
                            style: AppStyle.txtRobotoRomanRegular10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
