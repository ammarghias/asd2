// ignore_for_file: must_be_immutable

part of 'pay_from_points_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///PayFromPoints widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class PayFromPointsEvent extends Equatable {}

/// Event that is dispatched when the PayFromPoints widget is first created.
class PayFromPointsInitialEvent extends PayFromPointsEvent {
  @override
  List<Object?> get props => [];
}

///Event for changing checkbox
class ChangeCheckBoxEvent extends PayFromPointsEvent {
  ChangeCheckBoxEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}

///Event for changing checkbox
class ChangeCheckBox1Event extends PayFromPointsEvent {
  ChangeCheckBox1Event({required this.value});

  bool value;

  @override
  List<Object?> get props => [
        value,
      ];
}
