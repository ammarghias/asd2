// ignore_for_file: must_be_immutable

part of 'pay_from_points_bloc.dart';

/// Represents the state of PayFromPoints in the application.
class PayFromPointsState extends Equatable {
  PayFromPointsState({
    this.nameController,
    this.everythingelseController,
    this.isCheckbox = false,
    this.isCheckbox1 = false,
    this.payFromPointsModelObj,
  });

  TextEditingController? nameController;

  TextEditingController? everythingelseController;

  PayFromPointsModel? payFromPointsModelObj;

  bool isCheckbox;

  bool isCheckbox1;

  @override
  List<Object?> get props => [
        nameController,
        everythingelseController,
        isCheckbox,
        isCheckbox1,
        payFromPointsModelObj,
      ];
  PayFromPointsState copyWith({
    TextEditingController? nameController,
    TextEditingController? everythingelseController,
    bool? isCheckbox,
    bool? isCheckbox1,
    PayFromPointsModel? payFromPointsModelObj,
  }) {
    return PayFromPointsState(
      nameController: nameController ?? this.nameController,
      everythingelseController:
          everythingelseController ?? this.everythingelseController,
      isCheckbox: isCheckbox ?? this.isCheckbox,
      isCheckbox1: isCheckbox1 ?? this.isCheckbox1,
      payFromPointsModelObj:
          payFromPointsModelObj ?? this.payFromPointsModelObj,
    );
  }
}
