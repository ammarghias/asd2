import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/pay_from_points_screen/models/pay_from_points_model.dart';
part 'pay_from_points_event.dart';
part 'pay_from_points_state.dart';

/// A bloc that manages the state of a PayFromPoints according to the event that is dispatched to it.
class PayFromPointsBloc extends Bloc<PayFromPointsEvent, PayFromPointsState> {
  PayFromPointsBloc(PayFromPointsState initialState) : super(initialState) {
    on<PayFromPointsInitialEvent>(_onInitialize);
    on<ChangeCheckBoxEvent>(_changeCheckBox);
    on<ChangeCheckBox1Event>(_changeCheckBox1);
  }

  _changeCheckBox(
    ChangeCheckBoxEvent event,
    Emitter<PayFromPointsState> emit,
  ) {
    emit(state.copyWith(
      isCheckbox: event.value,
    ));
  }

  _changeCheckBox1(
    ChangeCheckBox1Event event,
    Emitter<PayFromPointsState> emit,
  ) {
    emit(state.copyWith(
      isCheckbox1: event.value,
    ));
  }

  _onInitialize(
    PayFromPointsInitialEvent event,
    Emitter<PayFromPointsState> emit,
  ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      everythingelseController: TextEditingController(),
      isCheckbox: false,
      isCheckbox1: false,
    ));
  }
}
