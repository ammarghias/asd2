import 'bloc/pay_from_points_bloc.dart';
import 'models/pay_from_points_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/core/utils/validation_functions.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application6/widgets/custom_checkbox.dart';
import 'package:ammar_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class PayFromPointsScreen extends StatelessWidget {
  PayFromPointsScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<PayFromPointsBloc>(
      create: (context) => PayFromPointsBloc(PayFromPointsState(
        payFromPointsModelObj: PayFromPointsModel(),
      ))
        ..add(PayFromPointsInitialEvent()),
      child: PayFromPointsScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        appBar: CustomAppBar(
          height: getVerticalSize(
            82,
          ),
          leadingWidth: 46,
          leading: AppbarImage(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),
            svgPath: ImageConstant.imgButtonnotification,
            margin: getMargin(
              left: 21,
              top: 15,
              bottom: 15,
            ),
          ),
          centerTitle: true,
          title: AppbarImage(
            height: getVerticalSize(
              31,
            ),
            width: getHorizontalSize(
              180,
            ),
            svgPath: ImageConstant.imgGroupPink70001,
          ),
          actions: [
            AppbarImage(
              height: getVerticalSize(
                21,
              ),
              width: getHorizontalSize(
                29,
              ),
              svgPath: ImageConstant.imgMenu,
              margin: getMargin(
                left: 30,
                top: 18,
                right: 30,
                bottom: 16,
              ),
            ),
          ],
        ),
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Padding(
              padding: getPadding(
                left: 14,
                right: 15,
                bottom: 5,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      left: 82,
                    ),
                    child: Text(
                      "lbl_pay_with_points".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtStickNoBillsRegular32,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 4,
                    ),
                    child: Divider(
                      height: getVerticalSize(
                        1,
                      ),
                      thickness: getVerticalSize(
                        1,
                      ),
                      color: ColorConstant.gray50003,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 16,
                      right: 5,
                    ),
                    child: Row(
                      children: [
                        Text(
                          "lbl_reward_balances".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtRobotoRomanBold25,
                        ),
                        Padding(
                          padding: getPadding(
                            left: 4,
                            top: 7,
                            bottom: 6,
                          ),
                          child: Text(
                            "msg_make_your_points".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtJuraBold13,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      157,
                    ),
                    width: getHorizontalSize(
                      364,
                    ),
                    margin: getMargin(
                      top: 11,
                    ),
                    child: Stack(
                      alignment: Alignment.bottomRight,
                      children: [
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            margin: getMargin(
                              right: 1,
                            ),
                            padding: getPadding(
                              left: 4,
                              top: 17,
                              right: 4,
                              bottom: 17,
                            ),
                            decoration:
                                AppDecoration.outlineBluegray10002.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    right: 7,
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomImageView(
                                        svgPath: ImageConstant.imgClose,
                                        height: getSize(
                                          29,
                                        ),
                                        width: getSize(
                                          29,
                                        ),
                                        radius: BorderRadius.circular(
                                          getHorizontalSize(
                                            3,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          27,
                                        ),
                                        width: getHorizontalSize(
                                          305,
                                        ),
                                        margin: getMargin(
                                          bottom: 2,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.centerRight,
                                          children: [
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                padding: getPadding(
                                                  left: 6,
                                                  top: 1,
                                                  right: 6,
                                                  bottom: 1,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineGray50003
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder7,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 2,
                                                      ),
                                                      child: Text(
                                                        "msg_american_express"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtRobotoRomanRegular16,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.centerRight,
                                              child: BlocSelector<
                                                  PayFromPointsBloc,
                                                  PayFromPointsState,
                                                  bool?>(
                                                selector: (state) =>
                                                    state.isCheckbox,
                                                builder: (context, isCheckbox) {
                                                  return CustomCheckbox(
                                                    alignment:
                                                        Alignment.centerRight,
                                                    text: "lbl_999_000".tr,
                                                    value: isCheckbox,
                                                    fontStyle: CheckboxFontStyle
                                                        .RobotoRomanRegular16,
                                                    onChange: (value) {
                                                      context
                                                          .read<
                                                              PayFromPointsBloc>()
                                                          .add(
                                                              ChangeCheckBoxEvent(
                                                                  value:
                                                                      value));
                                                    },
                                                  );
                                                },
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 25,
                                    right: 7,
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomImageView(
                                        svgPath: ImageConstant.imgClose,
                                        height: getSize(
                                          29,
                                        ),
                                        width: getSize(
                                          29,
                                        ),
                                        radius: BorderRadius.circular(
                                          getHorizontalSize(
                                            3,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          27,
                                        ),
                                        width: getHorizontalSize(
                                          305,
                                        ),
                                        margin: getMargin(
                                          bottom: 2,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.centerLeft,
                                          children: [
                                            Align(
                                              alignment: Alignment.centerRight,
                                              child: BlocSelector<
                                                  PayFromPointsBloc,
                                                  PayFromPointsState,
                                                  bool?>(
                                                selector: (state) =>
                                                    state.isCheckbox1,
                                                builder:
                                                    (context, isCheckbox1) {
                                                  return CustomCheckbox(
                                                    alignment:
                                                        Alignment.centerRight,
                                                    text: "lbl_999_000".tr,
                                                    value: isCheckbox1,
                                                    fontStyle: CheckboxFontStyle
                                                        .RobotoRomanRegular16,
                                                    onChange: (value) {
                                                      context
                                                          .read<
                                                              PayFromPointsBloc>()
                                                          .add(
                                                              ChangeCheckBox1Event(
                                                                  value:
                                                                      value));
                                                    },
                                                  );
                                                },
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                padding: getPadding(
                                                  left: 6,
                                                  top: 1,
                                                  right: 6,
                                                  bottom: 1,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineGray50003
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder7,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Padding(
                                                      padding: getPadding(
                                                        top: 2,
                                                      ),
                                                      child: Text(
                                                        "msg_j_p_morgan_chase"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtRobotoRomanRegular16,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    bottom: 30,
                                  ),
                                  child: SizedBox(
                                    width: getHorizontalSize(
                                      93,
                                    ),
                                    child: Divider(
                                      height: getVerticalSize(
                                        1,
                                      ),
                                      thickness: getVerticalSize(
                                        1,
                                      ),
                                      color: ColorConstant.gray50003,
                                      endIndent: getHorizontalSize(
                                        2,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomRight,
                          child: Container(
                            margin: getMargin(
                              left: 41,
                              top: 127,
                              bottom: 3,
                            ),
                            padding: getPadding(
                              left: 9,
                              right: 9,
                            ),
                            decoration:
                                AppDecoration.outlinePink700013.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder7,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    top: 2,
                                    bottom: 2,
                                  ),
                                  child: Text(
                                    "msg_statement_credits".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtJuraBold18,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 27,
                                    top: 3,
                                    bottom: 1,
                                  ),
                                  child: Text(
                                    "lbl2".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtJuraBold18,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 2,
                                    top: 4,
                                  ),
                                  child: Text(
                                    "lbl_1_238_99".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtJuraBold18,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Padding(
                            padding: getPadding(
                              left: 7,
                            ),
                            child: Text(
                              "lbl3".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtCaladeaBold40,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 22,
                    ),
                    child: Text(
                      "msg_partner_programs".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtRobotoRomanBold25,
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      43,
                    ),
                    width: getHorizontalSize(
                      364,
                    ),
                    margin: getMargin(
                      top: 6,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Padding(
                            padding: getPadding(
                              bottom: 1,
                            ),
                            child: Text(
                              "msg_american_express".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterBold23,
                            ),
                          ),
                        ),
                        BlocSelector<PayFromPointsBloc, PayFromPointsState,
                            TextEditingController?>(
                          selector: (state) => state.nameController,
                          builder: (context, nameController) {
                            return CustomTextFormField(
                              width: getHorizontalSize(
                                364,
                              ),
                              focusNode: FocusNode(),
                              autofocus: true,
                              controller: nameController,
                              hintText: "msg_search_store_name".tr,
                              variant: TextFormFieldVariant.OutlinePink70001,
                              padding: TextFormFieldPadding.PaddingT10,
                              fontStyle: TextFormFieldFontStyle.InterRegular16,
                              alignment: Alignment.center,
                              suffix: Container(
                                padding: getPadding(
                                  left: 13,
                                  top: 6,
                                  right: 12,
                                  bottom: 4,
                                ),
                                margin: getMargin(
                                  left: 30,
                                  top: 4,
                                  right: 5,
                                  bottom: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: ColorConstant.pink70001,
                                  borderRadius: BorderRadius.circular(
                                    getHorizontalSize(
                                      17,
                                    ),
                                  ),
                                  border: Border.all(
                                    color: ColorConstant.whiteA700,
                                    width: getHorizontalSize(
                                      3,
                                    ),
                                  ),
                                ),
                                child: CustomImageView(
                                  svgPath: ImageConstant.imgLocation,
                                ),
                              ),
                              suffixConstraints: BoxConstraints(
                                maxHeight: getVerticalSize(
                                  43,
                                ),
                              ),
                              validator: (value) {
                                if (!isText(value)) {
                                  return "Please enter valid text";
                                }
                                return null;
                              },
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 5,
                      top: 24,
                      right: 6,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "lbl_adventures".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtRobotoRomanRegular13,
                                ),
                                Padding(
                                  padding: getPadding(
                                    left: 62,
                                  ),
                                  child: Text(
                                    "lbl_restaurnts".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtRobotoRomanRegular13,
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: getPadding(
                                top: 5,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: getHorizontalSize(
                                      99,
                                    ),
                                    child: Divider(
                                      height: getVerticalSize(
                                        1,
                                      ),
                                      thickness: getVerticalSize(
                                        1,
                                      ),
                                      color: ColorConstant.gray50004,
                                    ),
                                  ),
                                  SizedBox(
                                    width: getHorizontalSize(
                                      127,
                                    ),
                                    child: Divider(
                                      height: getVerticalSize(
                                        1,
                                      ),
                                      thickness: getVerticalSize(
                                        1,
                                      ),
                                      color: ColorConstant.gray50004,
                                      indent: getHorizontalSize(
                                        28,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        BlocSelector<PayFromPointsBloc, PayFromPointsState,
                            TextEditingController?>(
                          selector: (state) => state.everythingelseController,
                          builder: (context, everythingelseController) {
                            return CustomTextFormField(
                              width: getHorizontalSize(
                                99,
                              ),
                              focusNode: FocusNode(),
                              autofocus: true,
                              controller: everythingelseController,
                              hintText: "lbl_everything_else".tr,
                              margin: getMargin(
                                top: 1,
                              ),
                              variant: TextFormFieldVariant.UnderLineGray50004,
                              fontStyle:
                                  TextFormFieldFontStyle.RobotoRomanRegular13,
                              textInputAction: TextInputAction.done,
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 5,
                      top: 22,
                      right: 6,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Container(
                            margin: getMargin(
                              right: 14,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 1,
                              right: 3,
                              bottom: 1,
                            ),
                            decoration: AppDecoration.outlineGray300.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: getVerticalSize(
                                    71,
                                  ),
                                  width: getHorizontalSize(
                                    93,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.bottomCenter,
                                    children: [
                                      Align(
                                        alignment: Alignment.topCenter,
                                        child: Container(
                                          margin: getMargin(
                                            top: 1,
                                          ),
                                          decoration: AppDecoration
                                              .fillBluegray800
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .customBorderTL7,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                height: getVerticalSize(
                                                  12,
                                                ),
                                                width: getHorizontalSize(
                                                  93,
                                                ),
                                                margin: getMargin(
                                                  bottom: 19,
                                                ),
                                                decoration: BoxDecoration(
                                                  color:
                                                      ColorConstant.pink70001,
                                                  borderRadius:
                                                      BorderRadius.only(
                                                    topLeft: Radius.circular(
                                                      getHorizontalSize(
                                                        7,
                                                      ),
                                                    ),
                                                    topRight: Radius.circular(
                                                      getHorizontalSize(
                                                        7,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      CustomImageView(
                                        imagePath:
                                            ImageConstant.imgImage7258x93,
                                        height: getVerticalSize(
                                          58,
                                        ),
                                        width: getHorizontalSize(
                                          93,
                                        ),
                                        radius: BorderRadius.circular(
                                          getHorizontalSize(
                                            7,
                                          ),
                                        ),
                                        alignment: Alignment.bottomCenter,
                                      ),
                                      Align(
                                        alignment: Alignment.topCenter,
                                        child: Text(
                                          "lbl_on_gift_cards".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular11WhiteA700,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 1,
                                    right: 2,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Text(
                                        "lbl2".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular18Gray90002,
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 4,
                                        ),
                                        child: Text(
                                          "lbl_69_72".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular18Gray90003,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            margin: getMargin(
                              left: 14,
                              right: 14,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 1,
                              right: 3,
                              bottom: 1,
                            ),
                            decoration: AppDecoration.outlineGray300.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: getVerticalSize(
                                    71,
                                  ),
                                  width: getHorizontalSize(
                                    93,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      CustomImageView(
                                        imagePath: ImageConstant.imgImage70,
                                        height: getVerticalSize(
                                          70,
                                        ),
                                        width: getHorizontalSize(
                                          93,
                                        ),
                                        radius: BorderRadius.circular(
                                          getHorizontalSize(
                                            7,
                                          ),
                                        ),
                                        alignment: Alignment.center,
                                      ),
                                      Align(
                                        alignment: Alignment.center,
                                        child: SizedBox(
                                          height: getVerticalSize(
                                            71,
                                          ),
                                          width: getHorizontalSize(
                                            93,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.topCenter,
                                            children: [
                                              Align(
                                                alignment: Alignment.center,
                                                child: Container(
                                                  decoration: AppDecoration
                                                      .fillRed800
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder7,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        height: getVerticalSize(
                                                          12,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          93,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .pink70001,
                                                          borderRadius:
                                                              BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                7,
                                                              ),
                                                            ),
                                                            topRight:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                7,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgImage73,
                                                        height: getVerticalSize(
                                                          57,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          82,
                                                        ),
                                                        margin: getMargin(
                                                          top: 1,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Text(
                                                  "lbl_on_gift_cards".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular11WhiteA700,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 1,
                                    right: 3,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Text(
                                        "lbl2".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular18Gray90002,
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 5,
                                        ),
                                        child: Text(
                                          "lbl_413_21".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular18Gray90003,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            margin: getMargin(
                              left: 14,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 1,
                              right: 3,
                              bottom: 1,
                            ),
                            decoration: AppDecoration.outlineGray300.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgImage67,
                                  height: getVerticalSize(
                                    70,
                                  ),
                                  width: getHorizontalSize(
                                    93,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      7,
                                    ),
                                  ),
                                  margin: getMargin(
                                    top: 1,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 1,
                                    right: 3,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Text(
                                        "lbl2".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular18Gray90002,
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 3,
                                        ),
                                        child: Text(
                                          "lbl_732_71".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular18Gray90003,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 3,
                      top: 8,
                      right: 17,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: getPadding(
                            bottom: 17,
                          ),
                          child: Text(
                            "msg_american_airlines".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoRomanRegular13Gray60006,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 42,
                            bottom: 17,
                          ),
                          child: Text(
                            "lbl_mcdonald_s".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoRomanRegular13Gray60006,
                          ),
                        ),
                        Spacer(),
                        SizedBox(
                          width: getHorizontalSize(
                            70,
                          ),
                          child: Text(
                            "msg_walmart_superstores".tr,
                            maxLines: null,
                            textAlign: TextAlign.center,
                            style: AppStyle.txtRobotoRomanRegular13Gray60006,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 3,
                      top: 16,
                      right: 8,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: getPadding(
                            left: 3,
                            top: 1,
                            right: 3,
                            bottom: 1,
                          ),
                          decoration: AppDecoration.outlineGray300.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder10,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: getVerticalSize(
                                  71,
                                ),
                                width: getHorizontalSize(
                                  93,
                                ),
                                child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    CustomImageView(
                                      imagePath: ImageConstant.imgImage7263x93,
                                      height: getVerticalSize(
                                        63,
                                      ),
                                      width: getHorizontalSize(
                                        93,
                                      ),
                                      radius: BorderRadius.circular(
                                        getHorizontalSize(
                                          7,
                                        ),
                                      ),
                                      alignment: Alignment.bottomCenter,
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        height: getVerticalSize(
                                          12,
                                        ),
                                        width: getHorizontalSize(
                                          93,
                                        ),
                                        margin: getMargin(
                                          top: 1,
                                        ),
                                        decoration: BoxDecoration(
                                          color: ColorConstant.pink70001,
                                          borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(
                                              getHorizontalSize(
                                                7,
                                              ),
                                            ),
                                            topRight: Radius.circular(
                                              getHorizontalSize(
                                                7,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Text(
                                        "lbl_on_gift_cards".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular11WhiteA700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 1,
                                  right: 2,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      "lbl2".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtInterRegular18Gray90002,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        left: 4,
                                      ),
                                      child: Text(
                                        "lbl_69_72".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular18Gray90003,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: getPadding(
                            left: 3,
                            top: 1,
                            right: 3,
                            bottom: 1,
                          ),
                          decoration: AppDecoration.outlineGray300.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder10,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: getVerticalSize(
                                  71,
                                ),
                                width: getHorizontalSize(
                                  93,
                                ),
                                child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: SizedBox(
                                        height: getVerticalSize(
                                          70,
                                        ),
                                        width: getHorizontalSize(
                                          93,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.topCenter,
                                          children: [
                                            CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage7312,
                                              height: getVerticalSize(
                                                70,
                                              ),
                                              width: getHorizontalSize(
                                                93,
                                              ),
                                              radius: BorderRadius.circular(
                                                getHorizontalSize(
                                                  7,
                                                ),
                                              ),
                                              alignment: Alignment.center,
                                            ),
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                height: getVerticalSize(
                                                  12,
                                                ),
                                                width: getHorizontalSize(
                                                  93,
                                                ),
                                                decoration: BoxDecoration(
                                                  color:
                                                      ColorConstant.pink70001,
                                                  borderRadius:
                                                      BorderRadius.only(
                                                    topLeft: Radius.circular(
                                                      getHorizontalSize(
                                                        7,
                                                      ),
                                                    ),
                                                    topRight: Radius.circular(
                                                      getHorizontalSize(
                                                        7,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Text(
                                        "lbl_on_gift_cards".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular11WhiteA700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 1,
                                  right: 3,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      "lbl2".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtInterRegular18Gray90002,
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        left: 5,
                                      ),
                                      child: Text(
                                        "lbl_413_21".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular18Gray90003,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: EdgeInsets.all(0),
                          color: ColorConstant.whiteA700,
                          shape: RoundedRectangleBorder(
                            side: BorderSide(
                              color: ColorConstant.gray300,
                              width: getHorizontalSize(
                                1,
                              ),
                            ),
                            borderRadius: BorderRadiusStyle.roundedBorder10,
                          ),
                          child: Container(
                            height: getVerticalSize(
                              98,
                            ),
                            width: getHorizontalSize(
                              99,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 1,
                              right: 3,
                              bottom: 1,
                            ),
                            decoration: AppDecoration.outlineGray300.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Stack(
                              alignment: Alignment.bottomLeft,
                              children: [
                                Align(
                                  alignment: Alignment.bottomRight,
                                  child: Padding(
                                    padding: getPadding(
                                      right: 3,
                                    ),
                                    child: Text(
                                      "lbl_732_71".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtInterRegular18Gray90003,
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Padding(
                                    padding: getPadding(
                                      left: 22,
                                    ),
                                    child: Text(
                                      "lbl2".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtInterRegular18Gray90002,
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topCenter,
                                  child: Container(
                                    margin: getMargin(
                                      top: 1,
                                    ),
                                    decoration:
                                        AppDecoration.fillBlack900.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder7,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Container(
                                          height: getVerticalSize(
                                            12,
                                          ),
                                          width: getHorizontalSize(
                                            93,
                                          ),
                                          decoration: BoxDecoration(
                                            color: ColorConstant.pink70001,
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(
                                                getHorizontalSize(
                                                  7,
                                                ),
                                              ),
                                              topRight: Radius.circular(
                                                getHorizontalSize(
                                                  7,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        CustomImageView(
                                          imagePath:
                                              ImageConstant.imgImage6755x59,
                                          height: getVerticalSize(
                                            55,
                                          ),
                                          width: getHorizontalSize(
                                            59,
                                          ),
                                          radius: BorderRadius.circular(
                                            getHorizontalSize(
                                              7,
                                            ),
                                          ),
                                          margin: getMargin(
                                            top: 5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topCenter,
                                  child: Text(
                                    "lbl_on_gift_cards".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular11WhiteA700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 14,
                      top: 8,
                      right: 38,
                    ),
                    child: Row(
                      children: [
                        Padding(
                          padding: getPadding(
                            bottom: 1,
                          ),
                          child: Text(
                            "lbl_delta_airlines".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoRomanRegular13Gray60006,
                          ),
                        ),
                        Spacer(
                          flex: 40,
                        ),
                        Padding(
                          padding: getPadding(
                            bottom: 1,
                          ),
                          child: Text(
                            "lbl_olive_garden".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoRomanRegular13Gray60006,
                          ),
                        ),
                        Spacer(
                          flex: 59,
                        ),
                        Padding(
                          padding: getPadding(
                            top: 1,
                          ),
                          child: Text(
                            "lbl_apple".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoRomanRegular13Gray60006,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 5,
                      top: 17,
                      right: 6,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Container(
                            margin: getMargin(
                              right: 14,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 1,
                              right: 3,
                              bottom: 1,
                            ),
                            decoration: AppDecoration.outlineGray300.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: getVerticalSize(
                                    71,
                                  ),
                                  width: getHorizontalSize(
                                    93,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Align(
                                        alignment: Alignment.center,
                                        child: SizedBox(
                                          height: getVerticalSize(
                                            70,
                                          ),
                                          width: getHorizontalSize(
                                            93,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.topCenter,
                                            children: [
                                              CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgImage7270x93,
                                                height: getVerticalSize(
                                                  70,
                                                ),
                                                width: getHorizontalSize(
                                                  93,
                                                ),
                                                radius: BorderRadius.circular(
                                                  getHorizontalSize(
                                                    7,
                                                  ),
                                                ),
                                                alignment: Alignment.center,
                                              ),
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  height: getVerticalSize(
                                                    12,
                                                  ),
                                                  width: getHorizontalSize(
                                                    93,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color:
                                                        ColorConstant.pink70001,
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topLeft: Radius.circular(
                                                        getHorizontalSize(
                                                          7,
                                                        ),
                                                      ),
                                                      topRight: Radius.circular(
                                                        getHorizontalSize(
                                                          7,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topCenter,
                                        child: Text(
                                          "lbl_on_gift_cards".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular11WhiteA700,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 1,
                                    right: 2,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Text(
                                        "lbl2".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular18Gray90002,
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 4,
                                        ),
                                        child: Text(
                                          "lbl_69_72".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular18Gray90003,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            margin: getMargin(
                              left: 14,
                              right: 14,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 1,
                              right: 3,
                              bottom: 1,
                            ),
                            decoration: AppDecoration.outlineGray300.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: getVerticalSize(
                                    71,
                                  ),
                                  width: getHorizontalSize(
                                    93,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      CustomImageView(
                                        imagePath: ImageConstant.imgImage70,
                                        height: getVerticalSize(
                                          70,
                                        ),
                                        width: getHorizontalSize(
                                          93,
                                        ),
                                        radius: BorderRadius.circular(
                                          getHorizontalSize(
                                            7,
                                          ),
                                        ),
                                        alignment: Alignment.center,
                                      ),
                                      Align(
                                        alignment: Alignment.center,
                                        child: SizedBox(
                                          height: getVerticalSize(
                                            71,
                                          ),
                                          width: getHorizontalSize(
                                            93,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.topCenter,
                                            children: [
                                              Align(
                                                alignment: Alignment.center,
                                                child: Container(
                                                  decoration: AppDecoration
                                                      .fillGray100
                                                      .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder7,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        height: getVerticalSize(
                                                          12,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          93,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .pink70001,
                                                          borderRadius:
                                                              BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                7,
                                                              ),
                                                            ),
                                                            topRight:
                                                                Radius.circular(
                                                              getHorizontalSize(
                                                                7,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgImage7357x68,
                                                        height: getVerticalSize(
                                                          57,
                                                        ),
                                                        width:
                                                            getHorizontalSize(
                                                          68,
                                                        ),
                                                        margin: getMargin(
                                                          top: 1,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Text(
                                                  "lbl_on_gift_cards".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular11WhiteA700,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 1,
                                    right: 3,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Text(
                                        "lbl2".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular18Gray90002,
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 5,
                                        ),
                                        child: Text(
                                          "lbl_413_21".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular18Gray90003,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            margin: getMargin(
                              left: 14,
                            ),
                            padding: getPadding(
                              left: 3,
                              top: 1,
                              right: 3,
                              bottom: 1,
                            ),
                            decoration: AppDecoration.outlineGray300.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgImage67,
                                  height: getVerticalSize(
                                    70,
                                  ),
                                  width: getHorizontalSize(
                                    93,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      7,
                                    ),
                                  ),
                                  margin: getMargin(
                                    top: 1,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 1,
                                    right: 3,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Text(
                                        "lbl2".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular18Gray90002,
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 3,
                                        ),
                                        child: Text(
                                          "lbl_732_71".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtInterRegular18Gray90003,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      left: 7,
                      top: 10,
                      right: 19,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: getPadding(
                            top: 1,
                            bottom: 16,
                          ),
                          child: Text(
                            "lbl_marriott_bonvoy".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoRomanRegular13Gray60006,
                          ),
                        ),
                        Spacer(
                          flex: 44,
                        ),
                        Padding(
                          padding: getPadding(
                            top: 1,
                            bottom: 16,
                          ),
                          child: Text(
                            "lbl_arby_s".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtRobotoRomanRegular13Gray60006,
                          ),
                        ),
                        Spacer(
                          flex: 55,
                        ),
                        SizedBox(
                          width: getHorizontalSize(
                            70,
                          ),
                          child: Text(
                            "msg_walmart_superstores".tr,
                            maxLines: null,
                            textAlign: TextAlign.center,
                            style: AppStyle.txtRobotoRomanRegular13Gray60006,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
