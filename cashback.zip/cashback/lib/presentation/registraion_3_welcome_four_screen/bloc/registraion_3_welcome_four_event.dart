// ignore_for_file: must_be_immutable

part of 'registraion_3_welcome_four_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///Registraion3WelcomeFour widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class Registraion3WelcomeFourEvent extends Equatable {}

/// Event that is dispatched when the Registraion3WelcomeFour widget is first created.
class Registraion3WelcomeFourInitialEvent extends Registraion3WelcomeFourEvent {
  @override
  List<Object?> get props => [];
}
