import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/liststorename_item_model.dart';
import '../models/listpullmerchan_item_model.dart';
import 'package:ammar_s_application6/presentation/categories_screen/models/categories_model.dart';
part 'categories_event.dart';
part 'categories_state.dart';

/// A bloc that manages the state of a Categories according to the event that is dispatched to it.
class CategoriesBloc extends Bloc<CategoriesEvent, CategoriesState> {
  CategoriesBloc(CategoriesState initialState) : super(initialState) {
    on<CategoriesInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<CategoriesState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<ListstorenameItemModel> fillListstorenameItemList() {
    return List.generate(4, (index) => ListstorenameItemModel());
  }

  List<ListpullmerchanItemModel> fillListpullmerchanItemList() {
    return List.generate(3, (index) => ListpullmerchanItemModel());
  }

  _onInitialize(
    CategoriesInitialEvent event,
    Emitter<CategoriesState> emit,
  ) async {
    emit(state.copyWith(
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        categoriesModelObj: state.categoriesModelObj?.copyWith(
      liststorenameItemList: fillListstorenameItemList(),
      listpullmerchanItemList: fillListpullmerchanItemList(),
    )));
  }
}
