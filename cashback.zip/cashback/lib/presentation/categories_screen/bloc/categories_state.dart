// ignore_for_file: must_be_immutable

part of 'categories_bloc.dart';

/// Represents the state of Categories in the application.
class CategoriesState extends Equatable {
  CategoriesState({
    this.isSelectedSwitch = false,
    this.categoriesModelObj,
  });

  CategoriesModel? categoriesModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        isSelectedSwitch,
        categoriesModelObj,
      ];
  CategoriesState copyWith({
    bool? isSelectedSwitch,
    CategoriesModel? categoriesModelObj,
  }) {
    return CategoriesState(
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      categoriesModelObj: categoriesModelObj ?? this.categoriesModelObj,
    );
  }
}
