/// This class is used in the [liststorename_item_widget] screen.
class ListstorenameItemModel {String storenameTxt = "Panera Bread";

String? id = "";

 }
