// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';import 'liststorename_item_model.dart';import 'listpullmerchan_item_model.dart';/// This class defines the variables used in the [categories_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class CategoriesModel extends Equatable {CategoriesModel({this.liststorenameItemList = const [], this.listpullmerchanItemList = const [], });

List<ListstorenameItemModel> liststorenameItemList;

List<ListpullmerchanItemModel> listpullmerchanItemList;

CategoriesModel copyWith({List<ListstorenameItemModel>? liststorenameItemList, List<ListpullmerchanItemModel>? listpullmerchanItemList, }) { return CategoriesModel(
liststorenameItemList : liststorenameItemList ?? this.liststorenameItemList,
listpullmerchanItemList : listpullmerchanItemList ?? this.listpullmerchanItemList,
); } 
@override List<Object?> get props => [liststorenameItemList,listpullmerchanItemList];
 }
