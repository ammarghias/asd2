// ignore_for_file: must_be_immutable

part of 'registration_2_mfa_authentication_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///Registration2MfaAuthentication widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class Registration2MfaAuthenticationEvent extends Equatable {}

/// Event that is dispatched when the Registration2MfaAuthentication widget is first created.
class Registration2MfaAuthenticationInitialEvent
    extends Registration2MfaAuthenticationEvent {
  @override
  List<Object?> get props => [];
}
