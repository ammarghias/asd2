// ignore_for_file: must_be_immutable

part of 'registration_2_mfa_authentication_bloc.dart';

/// Represents the state of Registration2MfaAuthentication in the application.
class Registration2MfaAuthenticationState extends Equatable {
  Registration2MfaAuthenticationState(
      {this.registration2MfaAuthenticationModelObj});

  Registration2MfaAuthenticationModel? registration2MfaAuthenticationModelObj;

  @override
  List<Object?> get props => [
        registration2MfaAuthenticationModelObj,
      ];
  Registration2MfaAuthenticationState copyWith(
      {Registration2MfaAuthenticationModel?
          registration2MfaAuthenticationModelObj}) {
    return Registration2MfaAuthenticationState(
      registration2MfaAuthenticationModelObj:
          registration2MfaAuthenticationModelObj ??
              this.registration2MfaAuthenticationModelObj,
    );
  }
}
