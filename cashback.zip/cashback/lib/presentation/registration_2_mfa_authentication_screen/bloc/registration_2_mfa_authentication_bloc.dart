import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application6/presentation/registration_2_mfa_authentication_screen/models/registration_2_mfa_authentication_model.dart';part 'registration_2_mfa_authentication_event.dart';part 'registration_2_mfa_authentication_state.dart';/// A bloc that manages the state of a Registration2MfaAuthentication according to the event that is dispatched to it.
class Registration2MfaAuthenticationBloc extends Bloc<Registration2MfaAuthenticationEvent, Registration2MfaAuthenticationState> {Registration2MfaAuthenticationBloc(Registration2MfaAuthenticationState initialState) : super(initialState) { on<Registration2MfaAuthenticationInitialEvent>(_onInitialize); }

_onInitialize(Registration2MfaAuthenticationInitialEvent event, Emitter<Registration2MfaAuthenticationState> emit, ) async  {  } 
 }
