import '../models/listpullcreditc_item_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListpullcreditcItemWidget extends StatelessWidget {
  ListpullcreditcItemWidget(
    this.listpullcreditcItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  ListpullcreditcItemModel listpullcreditcItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomImageView(
          svgPath: ImageConstant.imgSelectButton,
          height: getSize(
            20,
          ),
          width: getSize(
            20,
          ),
          margin: getMargin(
            top: 9,
            bottom: 24,
          ),
        ),
        Padding(
          padding: getPadding(
            left: 17,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: getPadding(
                  right: 5,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgPullcreditcard2,
                      height: getVerticalSize(
                        42,
                      ),
                      width: getHorizontalSize(
                        69,
                      ),
                      radius: BorderRadius.circular(
                        getHorizontalSize(
                          3,
                        ),
                      ),
                    ),
                    Padding(
                      padding: getPadding(
                        left: 6,
                        bottom: 19,
                      ),
                      child: Text(
                        "lbl_venture".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtInterRegular18Black90099,
                      ),
                    ),
                    Padding(
                      padding: getPadding(
                        left: 77,
                        bottom: 1,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            "lbl_annual_fee_0".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular9Black90099,
                          ),
                          Container(
                            width: getHorizontalSize(
                              44,
                            ),
                            margin: getMargin(
                              top: 6,
                              right: 6,
                            ),
                            child: Text(
                              "msg_cashback_1".tr,
                              maxLines: null,
                              textAlign: TextAlign.center,
                              style: AppStyle.txtInterRegular9Black90099,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 9,
                ),
                child: Divider(
                  height: getVerticalSize(
                    2,
                  ),
                  thickness: getVerticalSize(
                    2,
                  ),
                  color: ColorConstant.gray40003,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
