import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/gridname1_item_model.dart';
import '../models/listpullcreditc_item_model.dart';
import 'package:ammar_s_application6/presentation/bank_card_management_four_screen/models/bank_card_management_four_model.dart';
part 'bank_card_management_four_event.dart';
part 'bank_card_management_four_state.dart';

/// A bloc that manages the state of a BankCardManagementFour according to the event that is dispatched to it.
class BankCardManagementFourBloc
    extends Bloc<BankCardManagementFourEvent, BankCardManagementFourState> {
  BankCardManagementFourBloc(BankCardManagementFourState initialState)
      : super(initialState) {
    on<BankCardManagementFourInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
  }

  _changeSwitch(
    ChangeSwitchEvent event,
    Emitter<BankCardManagementFourState> emit,
  ) {
    emit(state.copyWith(
      isSelectedSwitch: event.value,
    ));
  }

  List<Gridname1ItemModel> fillGridname1ItemList() {
    return List.generate(12, (index) => Gridname1ItemModel());
  }

  List<ListpullcreditcItemModel> fillListpullcreditcItemList() {
    return List.generate(4, (index) => ListpullcreditcItemModel());
  }

  _onInitialize(
    BankCardManagementFourInitialEvent event,
    Emitter<BankCardManagementFourState> emit,
  ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      isSelectedSwitch: false,
    ));
    emit(state.copyWith(
        bankCardManagementFourModelObj:
            state.bankCardManagementFourModelObj?.copyWith(
      gridname1ItemList: fillGridname1ItemList(),
      listpullcreditcItemList: fillListpullcreditcItemList(),
    )));
  }
}
