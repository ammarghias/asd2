/// This class is used in the [gridname1_item_widget] screen.
class Gridname1ItemModel {String nameTxt = "Chase";

String? id = "";

 }
