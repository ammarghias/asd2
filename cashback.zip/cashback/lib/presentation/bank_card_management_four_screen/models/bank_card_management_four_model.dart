// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';import 'gridname1_item_model.dart';import 'listpullcreditc_item_model.dart';/// This class defines the variables used in the [bank_card_management_four_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class BankCardManagementFourModel extends Equatable {BankCardManagementFourModel({this.gridname1ItemList = const [], this.listpullcreditcItemList = const [], });

List<Gridname1ItemModel> gridname1ItemList;

List<ListpullcreditcItemModel> listpullcreditcItemList;

BankCardManagementFourModel copyWith({List<Gridname1ItemModel>? gridname1ItemList, List<ListpullcreditcItemModel>? listpullcreditcItemList, }) { return BankCardManagementFourModel(
gridname1ItemList : gridname1ItemList ?? this.gridname1ItemList,
listpullcreditcItemList : listpullcreditcItemList ?? this.listpullcreditcItemList,
); } 
@override List<Object?> get props => [gridname1ItemList,listpullcreditcItemList];
 }
