/// This class is used in the [listpullcreditc_item_widget] screen.
class ListpullcreditcItemModel {String? id = "";

 }
