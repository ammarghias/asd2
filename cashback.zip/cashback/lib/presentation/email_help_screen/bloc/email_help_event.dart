// ignore_for_file: must_be_immutable

part of 'email_help_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///EmailHelp widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class EmailHelpEvent extends Equatable {}

/// Event that is dispatched when the EmailHelp widget is first created.
class EmailHelpInitialEvent extends EmailHelpEvent {
  @override
  List<Object?> get props => [];
}
