// ignore_for_file: must_be_immutable

part of 'vastwo_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///Vastwo widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class VastwoEvent extends Equatable {}

/// Event that is dispatched when the Vastwo widget is first created.
class VastwoInitialEvent extends VastwoEvent {
  @override
  List<Object?> get props => [];
}
