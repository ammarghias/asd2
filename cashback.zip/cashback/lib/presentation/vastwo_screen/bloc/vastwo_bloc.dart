import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:ammar_s_application6/presentation/vastwo_screen/models/vastwo_model.dart';
part 'vastwo_event.dart';
part 'vastwo_state.dart';

/// A bloc that manages the state of a Vastwo according to the event that is dispatched to it.
class VastwoBloc extends Bloc<VastwoEvent, VastwoState> {
  VastwoBloc(VastwoState initialState) : super(initialState) {
    on<VastwoInitialEvent>(_onInitialize);
  }

  _onInitialize(
    VastwoInitialEvent event,
    Emitter<VastwoState> emit,
  ) async {}
}
