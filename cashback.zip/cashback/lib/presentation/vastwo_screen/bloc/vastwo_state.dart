// ignore_for_file: must_be_immutable

part of 'vastwo_bloc.dart';

/// Represents the state of Vastwo in the application.
class VastwoState extends Equatable {
  VastwoState({this.vastwoModelObj});

  VastwoModel? vastwoModelObj;

  @override
  List<Object?> get props => [
        vastwoModelObj,
      ];
  VastwoState copyWith({VastwoModel? vastwoModelObj}) {
    return VastwoState(
      vastwoModelObj: vastwoModelObj ?? this.vastwoModelObj,
    );
  }
}
