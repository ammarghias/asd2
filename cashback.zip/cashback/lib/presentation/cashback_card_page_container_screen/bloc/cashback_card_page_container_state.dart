// ignore_for_file: must_be_immutable

part of 'cashback_card_page_container_bloc.dart';

/// Represents the state of CashbackCardPageContainer in the application.
class CashbackCardPageContainerState extends Equatable {
  CashbackCardPageContainerState({this.cashbackCardPageContainerModelObj});

  CashbackCardPageContainerModel? cashbackCardPageContainerModelObj;

  @override
  List<Object?> get props => [
        cashbackCardPageContainerModelObj,
      ];
  CashbackCardPageContainerState copyWith(
      {CashbackCardPageContainerModel? cashbackCardPageContainerModelObj}) {
    return CashbackCardPageContainerState(
      cashbackCardPageContainerModelObj: cashbackCardPageContainerModelObj ??
          this.cashbackCardPageContainerModelObj,
    );
  }
}
