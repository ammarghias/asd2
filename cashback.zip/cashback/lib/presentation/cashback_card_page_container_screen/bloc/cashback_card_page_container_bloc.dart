import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application6/presentation/cashback_card_page_container_screen/models/cashback_card_page_container_model.dart';part 'cashback_card_page_container_event.dart';part 'cashback_card_page_container_state.dart';/// A bloc that manages the state of a CashbackCardPageContainer according to the event that is dispatched to it.
class CashbackCardPageContainerBloc extends Bloc<CashbackCardPageContainerEvent, CashbackCardPageContainerState> {CashbackCardPageContainerBloc(CashbackCardPageContainerState initialState) : super(initialState) { on<CashbackCardPageContainerInitialEvent>(_onInitialize); }

_onInitialize(CashbackCardPageContainerInitialEvent event, Emitter<CashbackCardPageContainerState> emit, ) async  {  } 
 }
