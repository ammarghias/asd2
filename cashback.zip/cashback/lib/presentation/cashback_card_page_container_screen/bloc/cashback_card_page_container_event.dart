// ignore_for_file: must_be_immutable

part of 'cashback_card_page_container_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///CashbackCardPageContainer widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class CashbackCardPageContainerEvent extends Equatable {}

/// Event that is dispatched when the CashbackCardPageContainer widget is first created.
class CashbackCardPageContainerInitialEvent
    extends CashbackCardPageContainerEvent {
  @override
  List<Object?> get props => [];
}
