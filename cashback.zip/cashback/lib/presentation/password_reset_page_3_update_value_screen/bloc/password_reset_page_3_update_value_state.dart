// ignore_for_file: must_be_immutable

part of 'password_reset_page_3_update_value_bloc.dart';

/// Represents the state of PasswordResetPage3UpdateValue in the application.
class PasswordResetPage3UpdateValueState extends Equatable {
  PasswordResetPage3UpdateValueState(
      {this.passwordResetPage3UpdateValueModelObj});

  PasswordResetPage3UpdateValueModel? passwordResetPage3UpdateValueModelObj;

  @override
  List<Object?> get props => [
        passwordResetPage3UpdateValueModelObj,
      ];
  PasswordResetPage3UpdateValueState copyWith(
      {PasswordResetPage3UpdateValueModel?
          passwordResetPage3UpdateValueModelObj}) {
    return PasswordResetPage3UpdateValueState(
      passwordResetPage3UpdateValueModelObj:
          passwordResetPage3UpdateValueModelObj ??
              this.passwordResetPage3UpdateValueModelObj,
    );
  }
}
