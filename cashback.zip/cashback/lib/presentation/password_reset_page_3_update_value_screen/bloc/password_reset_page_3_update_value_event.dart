// ignore_for_file: must_be_immutable

part of 'password_reset_page_3_update_value_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///PasswordResetPage3UpdateValue widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class PasswordResetPage3UpdateValueEvent extends Equatable {}

/// Event that is dispatched when the PasswordResetPage3UpdateValue widget is first created.
class PasswordResetPage3UpdateValueInitialEvent
    extends PasswordResetPage3UpdateValueEvent {
  @override
  List<Object?> get props => [];
}
