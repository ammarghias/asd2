import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:ammar_s_application6/presentation/password_reset_page_3_update_value_screen/models/password_reset_page_3_update_value_model.dart';part 'password_reset_page_3_update_value_event.dart';part 'password_reset_page_3_update_value_state.dart';/// A bloc that manages the state of a PasswordResetPage3UpdateValue according to the event that is dispatched to it.
class PasswordResetPage3UpdateValueBloc extends Bloc<PasswordResetPage3UpdateValueEvent, PasswordResetPage3UpdateValueState> {PasswordResetPage3UpdateValueBloc(PasswordResetPage3UpdateValueState initialState) : super(initialState) { on<PasswordResetPage3UpdateValueInitialEvent>(_onInitialize); }

_onInitialize(PasswordResetPage3UpdateValueInitialEvent event, Emitter<PasswordResetPage3UpdateValueState> emit, ) async  {  } 
 }
