import '../models/reward_catalog_item_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class RewardCatalogItemWidget extends StatelessWidget {
  RewardCatalogItemWidget(
    this.rewardCatalogItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  RewardCatalogItemModel rewardCatalogItemModelObj;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: getVerticalSize(
        124,
      ),
      width: getHorizontalSize(
        380,
      ),
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              margin: getMargin(
                left: 6,
                top: 11,
                right: 12,
              ),
              padding: getPadding(
                left: 12,
                top: 7,
                right: 12,
                bottom: 7,
              ),
              decoration: AppDecoration.outlinePink70001.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder10,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      top: 1,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: EdgeInsets.all(0),
                          color: ColorConstant.gray900,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadiusStyle.roundedBorder30,
                          ),
                          child: Container(
                            height: getVerticalSize(
                              61,
                            ),
                            width: getHorizontalSize(
                              60,
                            ),
                            padding: getPadding(
                              top: 9,
                              bottom: 9,
                            ),
                            decoration: AppDecoration.fillGray900.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder30,
                            ),
                            child: Stack(
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgImage76,
                                  height: getVerticalSize(
                                    43,
                                  ),
                                  width: getHorizontalSize(
                                    60,
                                  ),
                                  radius: BorderRadius.circular(
                                    getHorizontalSize(
                                      21,
                                    ),
                                  ),
                                  alignment: Alignment.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: getHorizontalSize(
                            48,
                          ),
                          margin: getMargin(
                            top: 1,
                          ),
                          child: Text(
                            rewardCatalogItemModelObj.loyaltyprogramTxt,
                            maxLines: null,
                            textAlign: TextAlign.center,
                            style: AppStyle.txtInterRegular13,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      91,
                    ),
                    width: getHorizontalSize(
                      113,
                    ),
                    margin: getMargin(
                      left: 33,
                      bottom: 6,
                    ),
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            height: getVerticalSize(
                              25,
                            ),
                            width: getHorizontalSize(
                              113,
                            ),
                            margin: getMargin(
                              top: 1,
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.pink70001,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(
                                  getHorizontalSize(
                                    15,
                                  ),
                                ),
                                topRight: Radius.circular(
                                  getHorizontalSize(
                                    15,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            padding: getPadding(
                              left: 2,
                              top: 3,
                              right: 2,
                              bottom: 3,
                            ),
                            decoration:
                                AppDecoration.outlineBlack9003f.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    top: 3,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: getVerticalSize(
                                          35,
                                        ),
                                        width: getHorizontalSize(
                                          61,
                                        ),
                                        margin: getMargin(
                                          top: 2,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgPullcreditcard,
                                              height: getVerticalSize(
                                                34,
                                              ),
                                              width: getHorizontalSize(
                                                60,
                                              ),
                                              radius: BorderRadius.circular(
                                                getHorizontalSize(
                                                  3,
                                                ),
                                              ),
                                              alignment: Alignment.centerLeft,
                                            ),
                                            CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgTicketAmber300,
                                              height: getVerticalSize(
                                                35,
                                              ),
                                              width: getHorizontalSize(
                                                61,
                                              ),
                                              alignment: Alignment.center,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          35,
                                        ),
                                        width: getHorizontalSize(
                                          44,
                                        ),
                                        margin: getMargin(
                                          left: 1,
                                          bottom: 1,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.topCenter,
                                          children: [
                                            Align(
                                              alignment: Alignment.bottomRight,
                                              child: Padding(
                                                padding: getPadding(
                                                  right: 1,
                                                ),
                                                child: Text(
                                                  "lbl_stacked".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle.txtInterBold8,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                margin: getMargin(
                                                  top: 2,
                                                ),
                                                decoration: AppDecoration
                                                    .outlinePink70001
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder4,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      height: getVerticalSize(
                                                        16,
                                                      ),
                                                      width: getHorizontalSize(
                                                        44,
                                                      ),
                                                      decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .pink70001,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(
                                                          getHorizontalSize(
                                                            4,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: getPadding(
                                                        right: 2,
                                                      ),
                                                      child: Text(
                                                        "lbl_cashback2".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterRegular6,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Padding(
                                                padding: getPadding(
                                                  left: 4,
                                                ),
                                                child: Text(
                                                  rewardCatalogItemModelObj
                                                      .cashbackrateTxt,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular17WhiteA700,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Text(
                                                "lbl".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterRegular17WhiteA700,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 3,
                                  ),
                                  child: Text(
                                    "lbl_cashback2".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterBold11,
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 1,
                                  ),
                                  child: Text(
                                    "lbl_blaze".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular11Black90099,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topRight,
                          child: Padding(
                            padding: getPadding(
                              right: 10,
                            ),
                            child: Text(
                              "lbl_cashback2".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtStaatlichesRegular10,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: getVerticalSize(
                      91,
                    ),
                    width: getHorizontalSize(
                      113,
                    ),
                    margin: getMargin(
                      left: 17,
                      bottom: 6,
                    ),
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            height: getVerticalSize(
                              25,
                            ),
                            width: getHorizontalSize(
                              113,
                            ),
                            margin: getMargin(
                              top: 1,
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.lime800,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(
                                  getHorizontalSize(
                                    15,
                                  ),
                                ),
                                topRight: Radius.circular(
                                  getHorizontalSize(
                                    15,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            padding: getPadding(
                              left: 2,
                              top: 3,
                              right: 2,
                              bottom: 3,
                            ),
                            decoration:
                                AppDecoration.outlineBlack9003f.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: getPadding(
                                    top: 3,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      CustomImageView(
                                        imagePath: ImageConstant
                                            .imgPullcreditcard34x60,
                                        height: getVerticalSize(
                                          34,
                                        ),
                                        width: getHorizontalSize(
                                          60,
                                        ),
                                        radius: BorderRadius.circular(
                                          getHorizontalSize(
                                            3,
                                          ),
                                        ),
                                        margin: getMargin(
                                          top: 2,
                                        ),
                                      ),
                                      Container(
                                        height: getVerticalSize(
                                          26,
                                        ),
                                        width: getHorizontalSize(
                                          44,
                                        ),
                                        margin: getMargin(
                                          left: 3,
                                          bottom: 10,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.topRight,
                                          children: [
                                            Align(
                                              alignment: Alignment.bottomCenter,
                                              child: Container(
                                                decoration: AppDecoration
                                                    .outlineLime800
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder4,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      height: getVerticalSize(
                                                        16,
                                                      ),
                                                      width: getHorizontalSize(
                                                        44,
                                                      ),
                                                      decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .lime800,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(
                                                          getHorizontalSize(
                                                            4,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      "lbl_reward_points".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterRegular6Lime800,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Padding(
                                                padding: getPadding(
                                                  right: 14,
                                                ),
                                                child: Text(
                                                  rewardCatalogItemModelObj
                                                      .rewardmultiplieTxt,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular17WhiteA700,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.bottomRight,
                                              child: Padding(
                                                padding: getPadding(
                                                  right: 4,
                                                  bottom: 4,
                                                ),
                                                child: Text(
                                                  "lbl_x".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular17WhiteA700,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: getPadding(
                                    top: 4,
                                  ),
                                  child: Text(
                                    rewardCatalogItemModelObj.cardproviderTxt,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterBold11,
                                  ),
                                ),
                                Text(
                                  rewardCatalogItemModelObj.cardtypeTxt,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular11Black90099,
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topRight,
                          child: Padding(
                            padding: getPadding(
                              right: 13,
                            ),
                            child: Text(
                              "lbl_your_wallet".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtStaatlichesRegular10Yellow50,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          CustomImageView(
            svgPath: ImageConstant.imgStar24,
            height: getVerticalSize(
              25,
            ),
            width: getHorizontalSize(
              26,
            ),
            radius: BorderRadius.circular(
              getHorizontalSize(
                1,
              ),
            ),
            alignment: Alignment.topRight,
          ),
          CustomImageView(
            svgPath: ImageConstant.imgClose,
            height: getVerticalSize(
              20,
            ),
            width: getHorizontalSize(
              23,
            ),
            alignment: Alignment.topLeft,
            margin: getMargin(
              top: 1,
            ),
          ),
        ],
      ),
    );
  }
}
