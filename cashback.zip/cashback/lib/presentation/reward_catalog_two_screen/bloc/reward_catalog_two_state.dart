// ignore_for_file: must_be_immutable

part of 'reward_catalog_two_bloc.dart';

/// Represents the state of RewardCatalogTwo in the application.
class RewardCatalogTwoState extends Equatable {
  RewardCatalogTwoState({
    this.searchController,
    this.isSelectedSwitch = false,
    this.rewardCatalogTwoModelObj,
  });

  TextEditingController? searchController;

  RewardCatalogTwoModel? rewardCatalogTwoModelObj;

  bool isSelectedSwitch;

  @override
  List<Object?> get props => [
        searchController,
        isSelectedSwitch,
        rewardCatalogTwoModelObj,
      ];
  RewardCatalogTwoState copyWith({
    TextEditingController? searchController,
    bool? isSelectedSwitch,
    RewardCatalogTwoModel? rewardCatalogTwoModelObj,
  }) {
    return RewardCatalogTwoState(
      searchController: searchController ?? this.searchController,
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      rewardCatalogTwoModelObj:
          rewardCatalogTwoModelObj ?? this.rewardCatalogTwoModelObj,
    );
  }
}
