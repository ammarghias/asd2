/// This class is used in the [reward_catalog_item_widget] screen.
class RewardCatalogItemModel {String loyaltyprogramTxt = "Marriott Bonvoy";

String cashbackrateTxt = "6.3";

String rewardmultiplieTxt = "3";

String cardproviderTxt = "American Express";

String cardtypeTxt = "Gold Card";

String? id = "";

 }
