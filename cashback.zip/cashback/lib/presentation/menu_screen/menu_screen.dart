import 'bloc/menu_bloc.dart';
import 'models/menu_model.dart';
import 'package:ammar_s_application6/core/app_export.dart';
import 'package:ammar_s_application6/presentation/cashback_card_page/cashback_card_page.dart';
import 'package:ammar_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ammar_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ammar_s_application6/widgets/custom_bottom_bar.dart';
import 'package:ammar_s_application6/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class MenuScreen extends StatelessWidget {
  MenuScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<MenuBloc>(
      create: (context) => MenuBloc(MenuState(
        menuModelObj: MenuModel(),
      ))
        ..add(MenuInitialEvent()),
      child: MenuScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MenuBloc, MenuState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            appBar: CustomAppBar(
              height: getVerticalSize(
                68,
              ),
              leadingWidth: 51,
              leading: AppbarImage(
                height: getSize(
                  25,
                ),
                width: getSize(
                  25,
                ),
                svgPath: ImageConstant.imgButtonnotificationWhiteA700,
                margin: getMargin(
                  left: 26,
                  top: 22,
                  bottom: 21,
                ),
              ),
              centerTitle: true,
              title: CustomButton(
                height: getVerticalSize(
                  68,
                ),
                width: getHorizontalSize(
                  252,
                ),
                text: "lbl_menu".tr,
                variant: ButtonVariant.FillWhiteA700,
                padding: ButtonPadding.PaddingAll11,
                fontStyle: ButtonFontStyle.StaatlichesRegular40,
              ),
              actions: [
                Padding(
                  padding: getPadding(
                    left: 23,
                    top: 9,
                    right: 23,
                    bottom: 8,
                  ),
                  child: Text(
                    "lbl4".tr,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtStaatlichesRegular40,
                  ),
                ),
              ],
            ),
            body: SizedBox(
              width: size.width,
              child: SingleChildScrollView(
                padding: getPadding(
                  top: 23,
                ),
                child: SizedBox(
                  height: getVerticalSize(
                    801,
                  ),
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      Align(
                        alignment: Alignment.topCenter,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: double.maxFinite,
                              child: Container(
                                padding: getPadding(
                                  left: 9,
                                  top: 11,
                                  right: 9,
                                  bottom: 11,
                                ),
                                decoration: AppDecoration.fillWhiteA700,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "msg_reward_catalog_settings".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style:
                                          AppStyle.txtCastoroRegular19.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 17,
                                        right: 11,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Padding(
                                            padding: getPadding(
                                              top: 1,
                                            ),
                                            child: Text(
                                              "lbl_welcome_offers".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtCastoroRegular19
                                                  .copyWith(
                                                decoration:
                                                    TextDecoration.underline,
                                              ),
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgButtonnotification,
                                            height: getSize(
                                              25,
                                            ),
                                            width: getSize(
                                              25,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 19,
                                        right: 11,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Padding(
                                            padding: getPadding(
                                              top: 4,
                                            ),
                                            child: Text(
                                              "msg_track_your_annual".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtCastoroRegular19
                                                  .copyWith(
                                                decoration:
                                                    TextDecoration.underline,
                                              ),
                                            ),
                                          ),
                                          CustomImageView(
                                            svgPath: ImageConstant
                                                .imgButtonnotification,
                                            height: getSize(
                                              25,
                                            ),
                                            width: getSize(
                                              25,
                                            ),
                                            margin: getMargin(
                                              bottom: 3,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 20,
                                        bottom: 22,
                                      ),
                                      child: Text(
                                        "msg_referral_rewards".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtCastoroRegular19
                                            .copyWith(
                                          decoration: TextDecoration.underline,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Divider(
                              height: getVerticalSize(
                                1,
                              ),
                              thickness: getVerticalSize(
                                1,
                              ),
                              color: ColorConstant.gray400,
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          height: getVerticalSize(
                            535,
                          ),
                          width: double.maxFinite,
                          margin: getMargin(
                            bottom: 92,
                          ),
                          child: Stack(
                            alignment: Alignment.topRight,
                            children: [
                              CustomImageView(
                                imagePath: ImageConstant.imgFrame212,
                                height: getVerticalSize(
                                  465,
                                ),
                                width: getHorizontalSize(
                                  393,
                                ),
                                alignment: Alignment.topCenter,
                              ),
                              Align(
                                alignment: Alignment.topRight,
                                child: Padding(
                                  padding: getPadding(
                                    top: 34,
                                    right: 10,
                                  ),
                                  child: Text(
                                    "msg_open_pre_enrollment".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtKulimParkBold15,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector337x198,
                        height: getVerticalSize(
                          337,
                        ),
                        width: getHorizontalSize(
                          198,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            40,
                          ),
                        ),
                        alignment: Alignment.bottomRight,
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                          margin: getMargin(
                            left: 4,
                            top: 241,
                            right: 8,
                          ),
                          decoration:
                              AppDecoration.outlineBluegray10003.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder15,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: double.maxFinite,
                                child: Container(
                                  width: getHorizontalSize(
                                    381,
                                  ),
                                  padding: getPadding(
                                    left: 9,
                                    top: 5,
                                    right: 9,
                                    bottom: 5,
                                  ),
                                  decoration:
                                      AppDecoration.outlinePink700014.copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder15,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CustomImageView(
                                        svgPath: ImageConstant
                                            .imgGroupWhiteA70029x180,
                                        height: getVerticalSize(
                                          36,
                                        ),
                                        width: getHorizontalSize(
                                          205,
                                        ),
                                        margin: getMargin(
                                          left: 1,
                                          top: 3,
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          top: 3,
                                        ),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: getPadding(
                                                bottom: 8,
                                              ),
                                              child: Text(
                                                "lbl_reward_lines".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtKulimParkItalic25,
                                              ),
                                            ),
                                            Container(
                                              width: getHorizontalSize(
                                                104,
                                              ),
                                              margin: getMargin(
                                                left: 4,
                                                top: 7,
                                              ),
                                              child: Text(
                                                "msg_maximize_savings_minimize"
                                                    .tr,
                                                maxLines: null,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtInterRegular12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  left: 10,
                                  top: 13,
                                  right: 6,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: getPadding(
                                        bottom: 16,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Padding(
                                                padding: getPadding(
                                                  top: 3,
                                                ),
                                                child: Text(
                                                  "lbl_save_more_than".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterBold20Black9007e,
                                                ),
                                              ),
                                              Padding(
                                                padding: getPadding(
                                                  left: 3,
                                                  bottom: 1,
                                                ),
                                                child: Text(
                                                  "lbl2".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style:
                                                      AppStyle.txtInterBold40,
                                                ),
                                              ),
                                            ],
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              top: 1,
                                            ),
                                            child: Text(
                                              "msg_on_literally_everything".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular14Black9007e,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: getPadding(
                                        top: 26,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            "lbl_5_643_57".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterBold40,
                                          ),
                                          Padding(
                                            padding: getPadding(
                                              right: 3,
                                            ),
                                            child: Text(
                                              "msg_in_annualized_savings".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular13Black90087,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 14,
                                  bottom: 33,
                                ),
                                child: Text(
                                  "msg_estimate_how_much".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular21Black90075
                                      .copyWith(
                                    decoration: TextDecoration.underline,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgFileWhiteA700,
                        height: getVerticalSize(
                          68,
                        ),
                        width: getHorizontalSize(
                          55,
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 232,
                          right: 4,
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgBag,
                        height: getVerticalSize(
                          67,
                        ),
                        width: getHorizontalSize(
                          60,
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 236,
                          right: 30,
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgAirplane,
                        height: getVerticalSize(
                          64,
                        ),
                        width: getHorizontalSize(
                          57,
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 236,
                          right: 61,
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgAirplane,
                        height: getVerticalSize(
                          67,
                        ),
                        width: getHorizontalSize(
                          60,
                        ),
                        radius: BorderRadius.circular(
                          getHorizontalSize(
                            30,
                          ),
                        ),
                        alignment: Alignment.topRight,
                        margin: getMargin(
                          top: 236,
                          right: 84,
                        ),
                      ),
                      CustomButton(
                        height: getVerticalSize(
                          32,
                        ),
                        width: getHorizontalSize(
                          224,
                        ),
                        text: "lbl_details".tr,
                        margin: getMargin(
                          bottom: 302,
                        ),
                        variant: ButtonVariant.OutlineWhiteA700,
                        shape: ButtonShape.RoundedBorder10,
                        padding: ButtonPadding.PaddingT5,
                        fontStyle: ButtonFontStyle.InterRegular18,
                        suffixWidget: Container(
                          margin: getMargin(
                            left: 13,
                          ),
                          decoration: BoxDecoration(
                            color: ColorConstant.whiteA700,
                          ),
                          child: CustomImageView(
                            svgPath: ImageConstant.imgLocationWhiteA700,
                          ),
                        ),
                        alignment: Alignment.bottomCenter,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Buttonhomepage:
        return "/";
      case BottomBarEnum.Group26x27:
        return AppRoutes.cashbackCardPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.cashbackCardPage:
        return CashbackCardPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
