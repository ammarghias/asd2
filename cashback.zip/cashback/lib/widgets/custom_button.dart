import 'package:ammar_s_application6/core/app_export.dart';
import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  CustomButton(
      {this.shape,
      this.padding,
      this.variant,
      this.fontStyle,
      this.alignment,
      this.margin,
      this.onTap,
      this.width,
      this.height,
      this.text,
      this.prefixWidget,
      this.suffixWidget});

  ButtonShape? shape;

  ButtonPadding? padding;

  ButtonVariant? variant;

  ButtonFontStyle? fontStyle;

  Alignment? alignment;

  EdgeInsetsGeometry? margin;

  VoidCallback? onTap;

  double? width;

  double? height;

  String? text;

  Widget? prefixWidget;

  Widget? suffixWidget;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
            alignment: alignment!,
            child: _buildButtonWidget(),
          )
        : _buildButtonWidget();
  }

  _buildButtonWidget() {
    return Padding(
      padding: margin ?? EdgeInsets.zero,
      child: TextButton(
        onPressed: onTap,
        style: _buildTextButtonStyle(),
        child: _buildButtonChildWidget(),
      ),
    );
  }

  _buildButtonChildWidget() {
    if (checkGradient()) {
      return Container(
        width: width ?? double.maxFinite,
        padding: _setPadding(),
        decoration: _buildDecoration(),
        child: _buildButtonWithOrWithoutIcon(),
      );
    } else {
      return _buildButtonWithOrWithoutIcon();
    }
  }

  _buildButtonWithOrWithoutIcon() {
    if (prefixWidget != null || suffixWidget != null) {
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          prefixWidget ?? SizedBox(),
          Text(
            text ?? "",
            textAlign: TextAlign.center,
            style: _setFontStyle(),
          ),
          suffixWidget ?? SizedBox(),
        ],
      );
    } else {
      return Text(
        text ?? "",
        textAlign: TextAlign.center,
        style: _setFontStyle(),
      );
    }
  }

  _buildDecoration() {
    return BoxDecoration(
      border: _setBorder(),
      borderRadius: _setBorderRadius(),
      gradient: _setGradient(),
      boxShadow: _setBoxShadow(),
    );
  }

  _buildTextButtonStyle() {
    if (checkGradient()) {
      return TextButton.styleFrom(
        padding: EdgeInsets.zero,
      );
    } else {
      return TextButton.styleFrom(
        fixedSize: Size(
          width ?? double.maxFinite,
          height ?? getVerticalSize(40),
        ),
        padding: _setPadding(),
        backgroundColor: _setColor(),
        side: _setTextButtonBorder(),
        shadowColor: _setTextButtonShadowColor(),
        shape: RoundedRectangleBorder(
          borderRadius: _setBorderRadius(),
        ),
      );
    }
  }

  _setPadding() {
    switch (padding) {
      case ButtonPadding.PaddingAll3:
        return getPadding(
          all: 3,
        );
      case ButtonPadding.PaddingAll11:
        return getPadding(
          all: 11,
        );
      case ButtonPadding.PaddingT5:
        return getPadding(
          left: 5,
          top: 5,
          bottom: 5,
        );
      case ButtonPadding.PaddingT12:
        return getPadding(
          left: 5,
          top: 12,
          right: 5,
          bottom: 12,
        );
      case ButtonPadding.PaddingAll6:
        return getPadding(
          all: 6,
        );
      case ButtonPadding.PaddingT3:
        return getPadding(
          top: 3,
          bottom: 3,
        );
      default:
        return getPadding(
          all: 15,
        );
    }
  }

  _setColor() {
    switch (variant) {
      case ButtonVariant.OutlinePink70001_1:
        return ColorConstant.whiteA700;
      case ButtonVariant.FillWhiteA700:
        return ColorConstant.whiteA700;
      case ButtonVariant.OutlineWhiteA700:
        return ColorConstant.pink70001;
      case ButtonVariant.OutlinePink300:
        return ColorConstant.whiteA700;
      case ButtonVariant.OutlineWhiteA700_1:
        return ColorConstant.pink70001;
      case ButtonVariant.OutlineWhiteA700_2:
        return ColorConstant.red5001;
      case ButtonVariant.OutlineWhiteA700_3:
        return ColorConstant.lime50;
      case ButtonVariant.OutlinePink70001_2:
        return ColorConstant.lime100;
      case ButtonVariant.OutlineWhiteA700_4:
        return ColorConstant.green600;
      case ButtonVariant.OutlineWhiteA700_5:
        return ColorConstant.lightGreen500;
      case ButtonVariant.OutlinePink70001_3:
        return ColorConstant.lime400;
      case ButtonVariant.OutlineWhiteA700_6:
        return ColorConstant.yellowA700;
      case ButtonVariant.OutlineWhiteA700_7:
        return ColorConstant.yellow900;
      case ButtonVariant.OutlineWhiteA700_8:
        return ColorConstant.pink70001;
      case ButtonVariant.OutlineGray50003:
      case ButtonVariant.OutlineGray50003_1:
        return null;
      default:
        return ColorConstant.pink70001;
    }
  }

  _setTextButtonBorder() {
    switch (variant) {
      case ButtonVariant.OutlinePink70001_1:
        return BorderSide(
          color: ColorConstant.pink70001,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700:
        return BorderSide(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            3.00,
          ),
        );
      case ButtonVariant.OutlineGray50003:
        return BorderSide(
          color: ColorConstant.gray50003,
          width: getHorizontalSize(
            2.00,
          ),
        );
      case ButtonVariant.OutlineGray50003_1:
        return BorderSide(
          color: ColorConstant.gray50003,
          width: getHorizontalSize(
            2.00,
          ),
        );
      case ButtonVariant.OutlinePink300:
        return BorderSide(
          color: ColorConstant.pink300,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_1:
        return BorderSide(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_2:
        return BorderSide(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_3:
        return BorderSide(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlinePink70001_2:
        return BorderSide(
          color: ColorConstant.pink70001,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_4:
        return BorderSide(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_5:
        return BorderSide(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlinePink70001_3:
        return BorderSide(
          color: ColorConstant.pink70001,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_6:
        return BorderSide(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_7:
        return BorderSide(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_8:
        return BorderSide(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            4.00,
          ),
        );
      case ButtonVariant.FillWhiteA700:
        return null;
      default:
        return BorderSide(
          color: ColorConstant.pink70001,
          width: getHorizontalSize(
            1.00,
          ),
        );
    }
  }

  _setTextButtonShadowColor() {
    switch (variant) {
      case ButtonVariant.OutlinePink70001_1:
        return ColorConstant.black90033;
      case ButtonVariant.OutlineWhiteA700:
        return ColorConstant.black9003f;
      case ButtonVariant.OutlineGray50003_1:
        return ColorConstant.black9003f;
      case ButtonVariant.OutlineWhiteA700_8:
        return ColorConstant.black9003f;
      case ButtonVariant.OutlinePink70001:
      case ButtonVariant.FillWhiteA700:
      case ButtonVariant.OutlineGray50003:
      case ButtonVariant.OutlinePink300:
      case ButtonVariant.OutlineWhiteA700_1:
      case ButtonVariant.OutlineWhiteA700_2:
      case ButtonVariant.OutlineWhiteA700_3:
      case ButtonVariant.OutlinePink70001_2:
      case ButtonVariant.OutlineWhiteA700_4:
      case ButtonVariant.OutlineWhiteA700_5:
      case ButtonVariant.OutlinePink70001_3:
      case ButtonVariant.OutlineWhiteA700_6:
      case ButtonVariant.OutlineWhiteA700_7:
        return null;
      default:
        return null;
    }
  }

  _setBorderRadius() {
    switch (shape) {
      case ButtonShape.RoundedBorder10:
        return BorderRadius.circular(
          getHorizontalSize(
            10.00,
          ),
        );
      case ButtonShape.RoundedBorder5:
        return BorderRadius.circular(
          getHorizontalSize(
            5.00,
          ),
        );
      case ButtonShape.Square:
        return BorderRadius.circular(0);
      default:
        return BorderRadius.circular(
          getHorizontalSize(
            15.00,
          ),
        );
    }
  }

  _setFontStyle() {
    switch (fontStyle) {
      case ButtonFontStyle.InterRegular17:
        return TextStyle(
          color: ColorConstant.black9007e,
          fontSize: getFontSize(
            17,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w400,
        );
      case ButtonFontStyle.InterBold15Pink70001:
        return TextStyle(
          color: ColorConstant.pink70001,
          fontSize: getFontSize(
            15,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w700,
        );
      case ButtonFontStyle.InterMedium15:
        return TextStyle(
          color: ColorConstant.gray40001,
          fontSize: getFontSize(
            15,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w500,
        );
      case ButtonFontStyle.StaatlichesRegular40:
        return TextStyle(
          color: ColorConstant.blueGray700,
          fontSize: getFontSize(
            40,
          ),
          fontFamily: 'Staatliches',
          fontWeight: FontWeight.w400,
        );
      case ButtonFontStyle.InterRegular18:
        return TextStyle(
          color: ColorConstant.whiteA700,
          fontSize: getFontSize(
            18,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w400,
        );
      case ButtonFontStyle.RobotoRomanRegular18:
        return TextStyle(
          color: ColorConstant.gray60007,
          fontSize: getFontSize(
            18,
          ),
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
        );
      case ButtonFontStyle.RobotoRomanBold20:
        return TextStyle(
          color: ColorConstant.gray70087,
          fontSize: getFontSize(
            20,
          ),
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w700,
        );
      case ButtonFontStyle.InterMedium15Bluegray400:
        return TextStyle(
          color: ColorConstant.blueGray400,
          fontSize: getFontSize(
            15,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w500,
        );
      case ButtonFontStyle.InterMedium15WhiteA700:
        return TextStyle(
          color: ColorConstant.whiteA700,
          fontSize: getFontSize(
            15,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w500,
        );
      case ButtonFontStyle.InterMedium12:
        return TextStyle(
          color: ColorConstant.gray60010,
          fontSize: getFontSize(
            12,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w500,
        );
      case ButtonFontStyle.InterMedium10:
        return TextStyle(
          color: ColorConstant.whiteA700,
          fontSize: getFontSize(
            10,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w500,
        );
      case ButtonFontStyle.InterMedium10Gray70001:
        return TextStyle(
          color: ColorConstant.gray70001,
          fontSize: getFontSize(
            10,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w500,
        );
      case ButtonFontStyle.InterMedium10Bluegray900:
        return TextStyle(
          color: ColorConstant.blueGray900,
          fontSize: getFontSize(
            10,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w500,
        );
      case ButtonFontStyle.InterMedium13:
        return TextStyle(
          color: ColorConstant.blueGray400,
          fontSize: getFontSize(
            13,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w500,
        );
      case ButtonFontStyle.HindVadodaraBold21:
        return TextStyle(
          color: ColorConstant.whiteA700,
          fontSize: getFontSize(
            21,
          ),
          fontFamily: 'Hind Vadodara',
          fontWeight: FontWeight.w700,
        );
      default:
        return TextStyle(
          color: ColorConstant.whiteA700,
          fontSize: getFontSize(
            15,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w700,
        );
    }
  }

  _setBorder() {
    switch (variant) {
      case ButtonVariant.OutlinePink70001_1:
        return Border.all(
          color: ColorConstant.pink70001,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700:
        return Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            3.00,
          ),
        );
      case ButtonVariant.OutlineGray50003:
        return Border.all(
          color: ColorConstant.gray50003,
          width: getHorizontalSize(
            2.00,
          ),
        );
      case ButtonVariant.OutlineGray50003_1:
        return Border.all(
          color: ColorConstant.gray50003,
          width: getHorizontalSize(
            2.00,
          ),
        );
      case ButtonVariant.OutlinePink300:
        return Border.all(
          color: ColorConstant.pink300,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_1:
        return Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_2:
        return Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_3:
        return Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlinePink70001_2:
        return Border.all(
          color: ColorConstant.pink70001,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_4:
        return Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_5:
        return Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlinePink70001_3:
        return Border.all(
          color: ColorConstant.pink70001,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_6:
        return Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_7:
        return Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            1.00,
          ),
        );
      case ButtonVariant.OutlineWhiteA700_8:
        return Border.all(
          color: ColorConstant.whiteA700,
          width: getHorizontalSize(
            4.00,
          ),
        );
      case ButtonVariant.FillWhiteA700:
        return null;
      default:
        return Border.all(
          color: ColorConstant.pink70001,
          width: getHorizontalSize(
            1.00,
          ),
        );
    }
  }

  checkGradient() {
    switch (variant) {
      case ButtonVariant.OutlineGray50003:
      case ButtonVariant.OutlineGray50003_1:
        return true;
      default:
        return false;
    }
  }

  _setGradient() {
    switch (variant) {
      case ButtonVariant.OutlineGray50003:
        return LinearGradient(
          begin: Alignment(
            0.5,
            0,
          ),
          end: Alignment(
            0.5,
            1,
          ),
          colors: [
            ColorConstant.gray30002,
            ColorConstant.gray100,
          ],
        );
      case ButtonVariant.OutlineGray50003_1:
        return LinearGradient(
          begin: Alignment(
            0.5,
            0,
          ),
          end: Alignment(
            0.5,
            1,
          ),
          colors: [
            ColorConstant.gray30002,
            ColorConstant.gray100,
          ],
        );
      case ButtonVariant.OutlinePink70001:
      case ButtonVariant.OutlinePink70001_1:
      case ButtonVariant.FillWhiteA700:
      case ButtonVariant.OutlineWhiteA700:
      case ButtonVariant.OutlinePink300:
      case ButtonVariant.OutlineWhiteA700_1:
      case ButtonVariant.OutlineWhiteA700_2:
      case ButtonVariant.OutlineWhiteA700_3:
      case ButtonVariant.OutlinePink70001_2:
      case ButtonVariant.OutlineWhiteA700_4:
      case ButtonVariant.OutlineWhiteA700_5:
      case ButtonVariant.OutlinePink70001_3:
      case ButtonVariant.OutlineWhiteA700_6:
      case ButtonVariant.OutlineWhiteA700_7:
      case ButtonVariant.OutlineWhiteA700_8:
        return null;
      default:
        return null;
    }
  }

  _setBoxShadow() {
    switch (variant) {
      case ButtonVariant.OutlinePink70001_1:
        return [
          BoxShadow(
            color: ColorConstant.black90033,
            spreadRadius: getHorizontalSize(
              2.00,
            ),
            blurRadius: getHorizontalSize(
              2.00,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ];
      case ButtonVariant.OutlineWhiteA700:
        return [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2.00,
            ),
            blurRadius: getHorizontalSize(
              2.00,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ];
      case ButtonVariant.OutlineGray50003_1:
        return [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2.00,
            ),
            blurRadius: getHorizontalSize(
              2.00,
            ),
            offset: Offset(
              0,
              2,
            ),
          ),
        ];
      case ButtonVariant.OutlineWhiteA700_8:
        return [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2.00,
            ),
            blurRadius: getHorizontalSize(
              2.00,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ];
      case ButtonVariant.OutlinePink70001:
      case ButtonVariant.FillWhiteA700:
      case ButtonVariant.OutlineGray50003:
      case ButtonVariant.OutlinePink300:
      case ButtonVariant.OutlineWhiteA700_1:
      case ButtonVariant.OutlineWhiteA700_2:
      case ButtonVariant.OutlineWhiteA700_3:
      case ButtonVariant.OutlinePink70001_2:
      case ButtonVariant.OutlineWhiteA700_4:
      case ButtonVariant.OutlineWhiteA700_5:
      case ButtonVariant.OutlinePink70001_3:
      case ButtonVariant.OutlineWhiteA700_6:
      case ButtonVariant.OutlineWhiteA700_7:
        return null;
      default:
        return null;
    }
  }
}

enum ButtonShape {
  Square,
  RoundedBorder15,
  RoundedBorder10,
  RoundedBorder5,
}
enum ButtonPadding {
  PaddingAll15,
  PaddingAll3,
  PaddingAll11,
  PaddingT5,
  PaddingT12,
  PaddingAll6,
  PaddingT3,
}
enum ButtonVariant {
  OutlinePink70001,
  OutlinePink70001_1,
  FillWhiteA700,
  OutlineWhiteA700,
  OutlineGray50003,
  OutlineGray50003_1,
  OutlinePink300,
  OutlineWhiteA700_1,
  OutlineWhiteA700_2,
  OutlineWhiteA700_3,
  OutlinePink70001_2,
  OutlineWhiteA700_4,
  OutlineWhiteA700_5,
  OutlinePink70001_3,
  OutlineWhiteA700_6,
  OutlineWhiteA700_7,
  OutlineWhiteA700_8,
}
enum ButtonFontStyle {
  InterBold15,
  InterRegular17,
  InterBold15Pink70001,
  InterMedium15,
  StaatlichesRegular40,
  InterRegular18,
  RobotoRomanRegular18,
  RobotoRomanBold20,
  InterMedium15Bluegray400,
  InterMedium15WhiteA700,
  InterMedium12,
  InterMedium10,
  InterMedium10Gray70001,
  InterMedium10Bluegray900,
  InterMedium13,
  HindVadodaraBold21,
}
