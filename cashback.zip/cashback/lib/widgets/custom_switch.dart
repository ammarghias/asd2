import 'package:ammar_s_application6/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';

class CustomSwitch extends StatelessWidget {
  CustomSwitch({this.alignment, this.margin, this.value, this.onChanged});

  Alignment? alignment;

  EdgeInsetsGeometry? margin;

  bool? value;

  Function(bool)? onChanged;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
            alignment: alignment ?? Alignment.center,
            child: _buildSwitchWidget(),
          )
        : _buildSwitchWidget();
  }

  _buildSwitchWidget() {
    return Padding(
      padding: margin ?? EdgeInsets.zero,
      child: FlutterSwitch(
        value: value ?? false,
        height: getHorizontalSize(24),
        width: getHorizontalSize(50),
        toggleSize: 29,
        borderRadius: getHorizontalSize(
          12.00,
        ),
        switchBorder: Border.all(
          color: ColorConstant.gray20001,
          width: getHorizontalSize(
            1.00,
          ),
        ),
        activeColor: ColorConstant.pink70001,
        activeToggleColor: ColorConstant.whiteA70001,
        inactiveColor: ColorConstant.pink70001,
        inactiveToggleColor: ColorConstant.whiteA70001,
        onToggle: (value) {
          onChanged!(value);
        },
      ),
    );
  }
}
