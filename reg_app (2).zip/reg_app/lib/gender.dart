// To parse this JSON data, do
//
//     final docce = docceFromJson(jsonString);

import 'dart:convert';

List<Docce> docceFromJson(String str) => List<Docce>.from(json.decode(str).map((x) => Docce.fromJson(x)));

String docceToJson(List<Docce> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Docce {
    int id;
    String name;

    Docce({
        required this.id,
        required this.name,
    });

    factory Docce.fromJson(Map<String, dynamic> json) => Docce(
        id: json["id"],
        name: json["name"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
    };
}

class Gender {
  int id;
  String gender;

  Gender({required this.id, required this.gender});

  factory Gender.fromJson(Map<String, dynamic> json) {
    return Gender(
      id: json['id'],
      gender: json['gender'],
    );
  }
}

class ethnicxity {
  int id;
  String ethni;

  ethnicxity({required this.id, required this.ethni});

  factory ethnicxity.fromJson(Map<String, dynamic> json) {
    return ethnicxity(
      id: json['id'],
      ethni: json['name'],
    );
  }

  // Map<String, dynamic> toJson() => {
  //   'gender': gender,
  //   'id': id,
  // };
  //
  // @override
  // String toString() => gender;
}

class racemodle {
  int id;
  String racen;

  racemodle({required this.id, required this.racen});

  factory racemodle.fromJson(Map<String, dynamic> json) {
    return racemodle(
      id: json['id'],
      racen: json['conceptName'],
    );
  }

  // Map<String, dynamic> toJson() => {
  //   'gender': gender,
  //   'id': id,
  // };
  //
  // @override
  // String toString() => gender;
}

class relationd {
  int id;
  String name;

  relationd({required this.id, required this.name});

  factory relationd.fromJson(Map<String, dynamic> json) {
    return relationd(
      id: json['id'],
      name: json['name'],
    );
  }
}

class doc {
  int? id;
  String? doctorsFirstName;
  String? doctorsLastName;
  String? status;
  String? npi;
  String? taxonomySpecialty;
  String? ssn;
  String? etin;
  String? phoneNumber;
  String? createdOn;
  Null? updatedOn;
  Null? createdBy;
  Null? updatedBy;
  bool? isDeleted;

  doc(
      {this.id,
      this.doctorsFirstName,
      this.doctorsLastName,
      this.status,
      this.npi,
      this.taxonomySpecialty,
      this.ssn,
      this.etin,
      this.phoneNumber,
      this.createdOn,
      this.updatedOn,
      this.createdBy,
      this.updatedBy,
      this.isDeleted});

  doc.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    doctorsFirstName = json['doctorsFirstName'];
    doctorsLastName = json['doctorsLastName'];
    status = json['status'];
    npi = json['npi'];
    taxonomySpecialty = json['taxonomySpecialty'];
    ssn = json['ssn'];
    etin = json['etin'];
    phoneNumber = json['phoneNumber'];
    createdOn = json['createdOn'];
    updatedOn = json['updatedOn'];
    createdBy = json['createdBy'];
    updatedBy = json['updatedBy'];
    isDeleted = json['isDeleted'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['doctorsFirstName'] = this.doctorsFirstName;
    data['doctorsLastName'] = this.doctorsLastName;
    data['status'] = this.status;
    data['npi'] = this.npi;
    data['taxonomySpecialty'] = this.taxonomySpecialty;
    data['ssn'] = this.ssn;
    data['etin'] = this.etin;
    data['phoneNumber'] = this.phoneNumber;
    data['createdOn'] = this.createdOn;
    data['updatedOn'] = this.updatedOn;
    data['createdBy'] = this.createdBy;
    data['updatedBy'] = this.updatedBy;
    data['isDeleted'] = this.isDeleted;
    return data;
  }
}
