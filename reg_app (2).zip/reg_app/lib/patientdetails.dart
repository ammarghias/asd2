import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/pspdfkit_form_example.dart';
import 'package:reg_app/utils/file_utils.dart';
import 'package:reg_app/regph2.dart';
import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph6.dart';
import 'package:reg_app/regph7.dart';
import 'package:reg_app/regph8.dart';
import 'package:reg_app/vetest.dart';
import 'modle.dart';
const String _formPath = 'PDFs/Form_example.pdf';
class patientdetails extends StatefulWidget {
  const patientdetails({super.key});
  static const String route = '/patientdetails';
  @override
  _patientdetailsState createState() => _patientdetailsState();
}

class _patientdetailsState extends State<patientdetails> {
  String ser="";
  Image img = const Image(
    image: AssetImage("assets/illustration.png"),
    fit: BoxFit.fill,
  );
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController dobcontroller = TextEditingController();

//exsisting

  Future<List<listdart>> fetchData() async {
    var url = Uri.parse(
        'https://qa.rovermd.com:7685/patientExternal/bundle/patientsForSignature');
    final response = await http.get(url, headers: {
      'accept': '*/*',
      'X-TenantID': '${context.read<UserData>().terenid}',
    });
     print('teryyy${context.read<UserData>().terenid}');

    if (response.statusCode == 200) {
    
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((data) => listdart.fromJson(data)).toList();
    } else {
     
      throw Exception('Unexpected error occured!');
    }
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          backgroundColor: Color.fromRGBO(119, 94, 158, 100),
          // title: const Text(
          //   'Patients',
          //   style: TextStyle(color: Colors.white),
          // ),
          title:
           TextFormField(  
            onChanged: (valuie){setState(() {
              ser=valuie;
            });},
            decoration: InputDecoration(
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                  borderSide: BorderSide(
                                    color: context.read<UserData>().rs == null
                                        ? Color.fromARGB(122, 255, 255, 255)
                                        : context.read<UserData>().rs!
                                            ? const Color.fromARGB(255, 255, 255, 255)
                                            : Color.fromARGB(122, 255, 255, 255),
                                    width: 2.0,
                                  ),
                                ),
                                hintText: "Serach",
                                labelText: "Serach",
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                              ),),
           
          
        ),
        drawer: Drawer(
        width: 200,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(51, 62, 101, 5),
                Color.fromRGBO(107, 80, 135, 5)
              ],
            ),
          ),
          child: ListView(
            children: <Widget>[
              ListTile(
                title: Text(
                  'Patient',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg1()));

                  // TODO: Navigate to patient info page
                },
              ),
              ListTile(
                autofocus: true,
                selected: true,
                focusColor: Colors.white,
                selectedColor: Colors.white,
                enabled: true,
                title: Text(
                  'Physician',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg2()));
                },
              ),
              ListTile(
                title: Text(
                  'COVID-19',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg8()));
                  // TODO: Navigate to COVID-19 info page
                },
              ),
              ListTile(
                title: Text(
                  'Guarantor',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg3()));
                  // TODO: Navigate to guarantor info page
                },
              ),
              ListTile(
                title: Text(
                  'Insurance',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg7()));
                  // TODO: Navigate to insurance info page
                },
              ),
              ListTile(
                title: Text(
                  'Emergency Contact',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg4()));
                  // TODO: Navigate to emergency info page
                },
              ),
              ListTile(
                title: Text(
                  'Marketing',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg5()));
                  // TODO: Navigate to marketing info page
                },
              ),
              ListTile(
                title: Text(
                  'ID Upload',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg6()));
                  // TODO: Navigate to ID upload page
                },
              ),
                 ListTile(
                title: Text(
                  'Patient bundle',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => patientdetails()));
                  // TODO: Navigate to ID upload page
                },
              ),
            ],
          ),
        ),
      ),

        body: Container(
          child: FutureBuilder<List<listdart>>(
            future: fetchData(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListView.builder(
                    itemCount: snapshot.data!.length,
                    itemBuilder: (BuildContext context, int index) {
                      print(snapshot.data![index].patientName!.toString());
                      if(ser==""||snapshot.data![index].dob!.contains(ser)||snapshot.data![index].patientName!.toString().contains(ser)||snapshot.data![index].mrn!.toString().contains(ser))
                      {return Padding(
                        padding: const EdgeInsets.fromLTRB(8, 3, 8, 3),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.5),
                                blurRadius: 4,
                                offset: Offset(4, 8), // Shadow position
                              ),
                            ],
                          ),
                          height: 85,
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(20, 10, 8, 8),
                            child: SingleChildScrollView(
                              child: GestureDetector(
                                onTap: () {
                                  showFormDocumentExample(snapshot.data![index].patientRegId
                                            .toString());
                                 
                                },
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      snapshot.data![index].patientName
                                          .toString(),
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Row(
                                      children: [
                                        Text("DOB : "),
                                        Text(snapshot.data![index].dob
                                            .toString()),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Text("MRN : "),
                                        Text(snapshot.data![index].mrn
                                            .toString()),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      );}else{return SizedBox.shrink();}
                    });
              } else if (snapshot.hasError) {
                return Text(snapshot.error.toString());
              }
              // By default show a loading spinner.
              return const CircularProgressIndicator();
            },
          ),
        ));
  }
   void showFormDocumentExample(String jk) async {
   print("iddddd"+jk);
    await Navigator.of(context).push<dynamic>(MaterialPageRoute<dynamic>(
        builder: (_) => PspdfkitFormExampleWidget(
            documentPath: 'PDFs/Form_example.pdf',regid: jk,)));
  }
}
