import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/regph2.dart';
import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph7.dart';
import 'package:toggle_switch/toggle_switch.dart';

class pereg8 extends StatefulWidget {
  @override
  _pereg8State createState() => _pereg8State();
  static const String route = '/Covid19';
}

class _pereg8State extends State<pereg8> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  TextEditingController covisydateController = TextEditingController();
  TextEditingController covidateController = TextEditingController();
  TextEditingController directController = TextEditingController();
  TextEditingController outsideController = TextEditingController();
  TextEditingController outsideController1 = TextEditingController();
  TextEditingController outsideController2 = TextEditingController();
  TextEditingController covisydateControllerg = TextEditingController();

  Color fi = Color.fromRGBO(51, 62, 101, 100),
      sec = Colors.white,
      th = Colors.white;
  int ifh = 2, ch1 = 0, ch2 = 0, ch3 = 0, ch4 = 0, ch5 = 0, ch6 = 0, ch7 = 0;
  String selectedText = "";
  List<String> listOFSelectedItemc = [];
  List<String> listOFStrings = [
    "Fever",
    "Cough",
    "Short Breath",
    "Fatigue",
    "Body Aches",
    "Headache",
    "Loss Taste",
    "Sore Throat",
    "Congestion Runny Nose",
    "Nausea Vomit",
    "Diarrhea",
    "Pain in Chest",
    "New Confusion",
    "stay awake",
    "Others",
  ];
  void initState() {
    super.initState();
    if (context.read<UserData>().dateSympOnset != null)
      covisydateController.text = context
          .read<UserData>()
          .dateSympOnset!
          .replaceAll("T14:21:25.017Z", "");
    ;

    if (context.read<UserData>().covidPositiveBeforeDate != null)
      covidateController.text = context
          .read<UserData>()
          .covidPositiveBeforeDate!
          .replaceAll("T14:21:25.017Z", "");
    ;

    if (context.read<UserData>().exposedDirectContactCovidDate != null)
      directController.text = context
          .read<UserData>()
          .exposedDirectContactCovidDate!
          .replaceAll("T14:21:25.017Z", "");
    ;

    if (context.read<UserData>().outsideCountryTravelDate != null)
      outsideController.text = context
          .read<UserData>()
          .outsideCountryTravelDate!
          .replaceAll("T14:21:25.017Z", "");
    ;

    if (context.read<UserData>().sympOthersTxt != null)
      covisydateControllerg.text = context.read<UserData>().sympOthersTxt!;

    if (context.read<UserData>().listOFSelectedItemc != null)
      listOFSelectedItemc = context.read<UserData>().listOFSelectedItemc!;
    if (context.read<UserData>().outsideCountryTravelDuration != null)
      outsideController.text =
          context.read<UserData>().outsideCountryTravelDuration!;

    if (context.read<UserData>().outsideCountryTravelDestination != null)
      outsideController.text =
          context.read<UserData>().outsideCountryTravelDestination!;

    if (context.read<UserData>().outsideCountryTravelDuration != null)
      outsideController2.text =
          context.read<UserData>().outsideCountryTravelDuration!;

    if ( context.read<UserData>().outsideCountryTravelDestination  != null)
      outsideController1.text =
         context.read<UserData>().outsideCountryTravelDestination !;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(119, 94, 158, 100),
        title: const Text(
          ' COVID-19',
          style: TextStyle(color: Colors.white),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              '',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            onPressed: () {
              if (_formKey.currentState!.validate()) {}
            },
          ),
        ],
      ),
      drawer: Drawer(
        width: 200,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(51, 62, 101, 5),
                Color.fromRGBO(107, 80, 135, 5)
              ],
            ),
          ),
          child: ListView(
            children: <Widget>[
              ListTile(
                title: const Text(
                  'Patient',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg1()));

                  // TODO: Navigate to patient info page
                },
              ),
              ListTile(
                autofocus: true,
                selected: true,
                focusColor: Colors.white,
                selectedColor: Colors.white,
                enabled: true,
                title: const Text(
                  'Physician',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg2()));
                },
              ),
              ListTile(
                title: const Text(
                  'COVID-19',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  // TODO: Navigate to COVID-19 info page
                },
              ),
              ListTile(
                title: const Text(
                  'Guarantor',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg3()));
                },
              ),
              ListTile(
                title: const Text(
                  'Insurance',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {},
              ),
              ListTile(
                title: const Text(
                  'Emergency Contact',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg4()));
                  // TODO: Navigate to emergency info page
                },
              ),
              ListTile(
                title: const Text(
                  'Marketing',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg5()));
                  // TODO: Navigate to marketing info page
                },
              ),
              ListTile(
                title: const Text(
                  'ID Upload',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg7()));
                  // TODO: Navigate to ID upload page
                },
              ),
              const Divider(
                color: Colors.white,
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(

          // color: Color(0xFFC0C0C0),
          child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.grey,
            ],
          ),
        ),
        child: Row(
          children: <Widget>[
            Padding(
                padding: const EdgeInsets.only(
                    left: 10.0, top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          Navigator.of(context).pop();
                        },
                        child: const Text("BACK"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
            const Spacer(),
            const Expanded(
              child: Padding(
                padding: EdgeInsets.all(18.0),
                child: Text(
                  "",
                  style: TextStyle(fontSize: 16.0),
                ),
              ),
            ),
            Padding(
                padding: EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          context.read<UserData>().sympFever =
                              listOFSelectedItemc.contains(listOFStrings[0]);
                          print("context.read<UserData>().sympFever" +
                              context.read<UserData>().sympFever.toString());
                          context.read<UserData>().sympCough =
                              listOFSelectedItemc.contains(listOFStrings[1]);
                          context.read<UserData>().sympShortBreath =
                              listOFSelectedItemc.contains(listOFStrings[2]);
                          context.read<UserData>().sympFatigue =
                              listOFSelectedItemc.contains(listOFStrings[3]);
                          context.read<UserData>().sympMuscBodyAches =
                              listOFSelectedItemc.contains(listOFStrings[4]);
                          context.read<UserData>().sympHeadache =
                              listOFSelectedItemc.contains(listOFStrings[5]);
                          context.read<UserData>().sympLossTaste =
                              listOFSelectedItemc.contains(listOFStrings[6]);
                          context.read<UserData>().sympSoreThroat =
                              listOFSelectedItemc.contains(listOFStrings[7]);
                          context.read<UserData>().sympCongestionRunNos =
                              listOFSelectedItemc.contains(listOFStrings[8]);
                          context.read<UserData>().sympNauseaVomit =
                              listOFSelectedItemc.contains(listOFStrings[9]);
                          context.read<UserData>().sympDiarrhea =
                              listOFSelectedItemc.contains(listOFStrings[10]);
                          context.read<UserData>().sympPerPainChest =
                              listOFSelectedItemc.contains(listOFStrings[11]);
                          context.read<UserData>().sympNewConfusion =
                              listOFSelectedItemc.contains(listOFStrings[12]);
                          context.read<UserData>().sympInabWake =
                              listOFSelectedItemc.contains(listOFStrings[13]);
                          context.read<UserData>().sympOthers =
                              listOFSelectedItemc.contains(listOFStrings[14]);
                          context.read<UserData>().listOFSelectedItemc =
                              listOFSelectedItemc;
                          if (ch1 == 1) {
                            if (listOFSelectedItemc.length == 0) {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(SnackBar(
                                content: const Text('Select Symptoms'),
                                action: SnackBarAction(
                                  label: 'Undo',
                                  onPressed: () {
                                    // Some code to undo the change.
                                  },
                                ),
                              ));
                            } else {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => pereg3()));
                            }
                          } else {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => pereg3()));
                          }
                        },
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        child: const Text("Next")))),
          ],
        ),
      )),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Do you have any symptoms?',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(width: 15.0),
                  ToggleSwitch(
                    minWidth: 42.0,
                    minHeight: 20.0,
                    customTextStyles: [TextStyle(fontSize: 10)],
                    activeFgColor: Colors.black,
                    inactiveBgColor: Colors.white,
                    dividerColor: Colors.white,
                    inactiveFgColor: Colors.black,
                    activeBgColors: const [
                      [Colors.grey],
                      [Colors.grey]
                    ],
                    initialLabelIndex: context.read<UserData>().sympCheckCovid,
                    totalSwitches: 2,
                    labels: const [
                      'No',
                      'Yes',
                    ],
                    onToggle: (index) {
                      context.read<UserData>().sympCheckCovid = index;
                      setState(() {
                        ch1 = index!;
                      });

                      print('switched to: $index');
                    },
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Visibility(
                visible: context.read<UserData>().sympCheckCovid == 1,
                child: Column(
                  children: [
                    const SizedBox(height: 10.0),
                    Visibility(
                      visible: context.read<UserData>().sympCheckCovid == 1,
                      child: SizedBox(
                        height: 30,
                        child: TextFormField(
                          controller: covisydateController,
                          onChanged: (String? value) {
                            setState(() {
                              _formKey.currentState!.validate();
                            });
                          },
                          decoration: InputDecoration(
                            labelText: 'Date of Symptoms started',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                            ),
                          ),
                          onTap: () async {
                            DateTime? dob = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1900),
                                lastDate: DateTime.now());
                            if (dob != null) {
                              context.read<UserData>().dateSympOnset =
                                  "${dob.year}-${dob.month < 10 ? "0${dob.month}" : dob.month}-${dob.day < 10 ? "0${dob.day}" : dob.day}T14:21:25.017Z";
                              covisydateController.text =
                                  "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                              // Do something with the selected date
                            }
                          },
                        ),
                      ),
                    ),
                    Visibility(
                      visible: context.read<UserData>().sympCheckCovid == 1,
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Text(
                                  "Check All Symptoms That You Have: ",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            Text(
                              "Please Select At least one option*",
                              style: TextStyle(
                                color: const Color.fromARGB(255, 255, 0, 0),
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                            Container(
                              // height: 42,
                              margin: EdgeInsets.only(top: 10.0),
                              decoration: BoxDecoration(
                                border: Border.all(
                                    color: const Color.fromARGB(6, 0, 0, 0)),
                                borderRadius: BorderRadius.circular(50.0),
                              ),
                              child: ExpansionTile(
                                backgroundColor: Colors.white,
                                iconColor: Colors.grey,
                                title: Text(
                                  listOFSelectedItemc.isEmpty
                                      ? "Symptoms"
                                      : listOFSelectedItemc[0],
                                  style: const TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                                children: <Widget>[
                                  ListView.builder(
                                    physics: NeverScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    itemCount: listOFStrings.length,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return Container(
                                        color: Colors.white,
                                        margin: EdgeInsets.only(bottom: 8.0),
                                        child: _ViewItem(
                                            item: listOFStrings[index],
                                            selected: (val) {
                                              selectedText = val;
                                              if (listOFSelectedItemc
                                                  .contains(val)) {
                                                listOFSelectedItemc.remove(val);
                                              } else {
                                                listOFSelectedItemc.add(val);
                                              }
                                              setState(() {
                                                if (context
                                                        .read<UserData>()
                                                        .listOFSelectedItemc !=
                                                    null)
                                                  print(context
                                                              .read<UserData>()
                                                              .listOFSelectedItemc![0] ==
                                                          null
                                                      ? "true"
                                                      : false);
                                                context
                                                        .read<UserData>()
                                                        .listOFSelectedItemc =
                                                    listOFSelectedItemc;
                                              });
                                            },
                                            itemSelected:
                                                listOFSelectedItemc.contains(
                                                    listOFStrings[index])),
                                      );
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Visibility(
                          visible:
                              listOFSelectedItemc.contains(listOFStrings[14]),
                          child: Column(
                            children: [
                              // TextFormField(
                              //   controller: covisydateControllerg,
                              //   onChanged: (String? value) {
                              //       context.read<UserData>().sympOthersTxt =
                              //         value.toString();
                              //     setState(() {
                              //       _formKey.currentState!.validate();
                              //     });
                              //   },
                              //   decoration: InputDecoration(
                              //     labelText: 'Briefly Describe Symptoms',
                              //     border: OutlineInputBorder(
                              //       borderRadius: BorderRadius.circular(20.0),
                              //     ),
                              //   ),
                              //   onTap: () {if( context.read<UserData>().sympOthersTxt!=null){print( context.read<UserData>().sympOthersTxt);}},
                              // ),
                              TextFormField(
                                controller: covisydateControllerg,
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(20.0)),
                                  ),
                                  labelText: 'Briefly Describe Symptoms',
                                ),
                                onChanged: (String? value) {
                                  context.read<UserData>().sympOthersTxt =
                                      value;
                                  _formKey.currentState!.validate();

                                  // context
                                  //     .read<UserData>()
                                  //     .guarantorEmployerName = value;
                                },
                              ),
                            ],
                          )),
                    ),
                    Visibility(
                      visible: context.read<UserData>().sympCheckCovid == 1,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Is this covid for travelling?',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 15.0),
                          ToggleSwitch(
                            minWidth: 42.0,
                            minHeight: 20.0,
                            customTextStyles: [TextStyle(fontSize: 10)],
                            activeFgColor: Colors.black,
                            inactiveBgColor: Colors.white,
                            dividerColor: Colors.white,
                            inactiveFgColor: Colors.black,
                            activeBgColors: const [
                              [Colors.grey],
                              [Colors.grey]
                            ],
                            initialLabelIndex: context
                                .read<UserData>()
                                .covidTestForTravelCheck,
                            totalSwitches: 2,
                            labels: const [
                              'Yes',
                              'No',
                            ],
                            onToggle: (index) {
                              setState(() {
                                ch5 = index!;
                              });
                              context.read<UserData>().covidTestForTravelCheck =
                                  index!;
                              print('switched to: $index');
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width / 2,
                          child: const Text(
                            overflow: TextOverflow.clip,
                            'Are you employed in healthcare with direct patient contact?',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 15.0),
                        ToggleSwitch(
                          minWidth: 42.0,
                          minHeight: 20.0,
                          customTextStyles: [TextStyle(fontSize: 10)],
                          activeFgColor: Colors.black,
                          inactiveBgColor: Colors.white,
                          dividerColor: Colors.white,
                          inactiveFgColor: Colors.black,
                          activeBgColors: const [
                            [Colors.grey],
                            [Colors.grey],
                            [Colors.grey]
                          ],
                          initialLabelIndex: context
                              .read<UserData>()
                              .employedInHealthCareCheck,
                          totalSwitches: 3,
                          labels: [ 'No','Yes', 'Unknown'],
                          onToggle: (index) {
                            setState(() {
                              ch6 = index!;
                            });
                            context.read<UserData>().employedInHealthCareCheck =
                                index!;
                            print('switched to: $index');
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width / 2,
                          child: const Text(
                            'Have you tested positive for COVID before, if so what date?',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 15.0),
                        ToggleSwitch(
                          minWidth: 42.0,
                          minHeight: 20.0,
                          customTextStyles: [TextStyle(fontSize: 10)],
                          activeFgColor: Colors.black,
                          inactiveBgColor: Colors.white,
                          dividerColor: Colors.white,
                          inactiveFgColor: Colors.black,
                          activeBgColors: const [
                            [Colors.grey],
                            [Colors.grey]
                          ],
                          initialLabelIndex:
                              context.read<UserData>().covidPositiveBeforeCheck,
                          totalSwitches: 2,
                          labels: const [
                            'Yes',
                            'No',
                          ],
                          onToggle: (index) {
                            context.read<UserData>().covidPositiveBeforeCheck =
                                index!;
                            setState(() {
                              ch2 = index;
                            });

                            print('switched to: $index');
                          },
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Visibility(
                      visible:
                          context.read<UserData>().covidPositiveBeforeCheck ==
                              0,
                      child: SizedBox(
                        height: 30,
                        child: TextFormField(
                          controller: covidateController,
                          onChanged: (String? value) {
                            setState(() {
                              _formKey.currentState!.validate();
                            });
                          },
                          decoration: InputDecoration(
                            labelText: 'Date',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                            ),
                          ),
                          onTap: () async {
                            DateTime? dob = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1900),
                                lastDate: DateTime.now());
                            if (dob != null) {
                              context.read<UserData>().covidPositiveBeforeDate =
                                  "${dob.year}-${dob.month < 10 ? "0${dob.month}" : dob.month}-${dob.day < 10 ? "0${dob.day}" : dob.day}T14:21:25.017Z";
                              covidateController.text =
                                  "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                              // Do something with the selected date
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width / 2,
                          child: const Text(
                            'have you been exposed or Had direct Contact with someone with Coronavirus?',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 15.0),
                        ToggleSwitch(
                          minWidth: 42.0,
                          minHeight: 20.0,
                          customTextStyles: [TextStyle(fontSize: 10)],
                          activeFgColor: Colors.black,
                          inactiveBgColor: Colors.white,
                          dividerColor: Colors.white,
                          inactiveFgColor: Colors.black,
                          activeBgColors: const [
                            [Colors.grey],
                            [Colors.grey]
                          ],
                          initialLabelIndex: context
                              .read<UserData>()
                              .exposedDirectContactCovidCheck,
                          totalSwitches: 2,
                          labels: const [
                            'Yes',
                            'No',
                          ],
                          onToggle: (index) {
                            context
                                .read<UserData>()
                                .exposedDirectContactCovidCheck = index!;
                            setState(() {
                              ch3 = index;
                            });

                            print('switched to: $index');
                          },
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Visibility(
                      visible: context
                              .read<UserData>()
                              .exposedDirectContactCovidCheck ==
                          0,
                      child: SizedBox(
                        height: 30,
                        child: TextFormField(
                          controller: directController,
                          onChanged: (String? value) {
                            setState(() {
                              _formKey.currentState!.validate();
                            });
                          },
                          decoration: InputDecoration(
                            labelText: 'Date',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                            ),
                          ),
                          onTap: () async {
                            DateTime? dob = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1900),
                                lastDate: DateTime.now());
                            if (dob != null) {
                              context
                                      .read<UserData>()
                                      .exposedDirectContactCovidDate =
                                  "${dob.year}-${dob.month < 10 ? "0${dob.month}" : dob.month}-${dob.day < 10 ? "0${dob.day}" : dob.day}T14:21:25.017Z";
                              directController.text =
                                  "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                              // Do something with the selected date
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width / 2,
                          child: const Text(
                            'Have you traveled outside of the country within the last two weeks?',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 15.0),
                        ToggleSwitch(
                          minWidth: 42.0,
                          minHeight: 20.0,
                          customTextStyles: [TextStyle(fontSize: 10)],
                          activeFgColor: Colors.black,
                          inactiveBgColor: Colors.white,
                          dividerColor: Colors.white,
                          inactiveFgColor: Colors.black,
                          activeBgColors: const [
                            [Colors.grey],
                            [Colors.grey]
                          ],
                          initialLabelIndex: context
                              .read<UserData>()
                              .outsideCountryTravelCheck,
                          totalSwitches: 2,
                          labels: const [
                            'Yes',
                            'No',
                          ],
                          onToggle: (index) {
                            context.read<UserData>().outsideCountryTravelCheck =
                                index!;
                            setState(() {
                              ch4 = index;
                            });

                            print('switched to: $index');
                          },
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Visibility(
                      visible:
                          context.read<UserData>().outsideCountryTravelCheck ==
                              0,
                      child: Column(
                        children: [
                          SizedBox(
                            height: 30,
                            child: TextFormField(
                              controller: outsideController,
                              onChanged: (String? value) {
                                setState(() {
                                  _formKey.currentState!.validate();
                                });
                              },
                              decoration: InputDecoration(
                                labelText: 'Date',
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                              ),
                              onTap: () async {
                                DateTime? dob = await showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(1900),
                                    lastDate: DateTime.now());
                                if (dob != null) {
                                  context
                                          .read<UserData>()
                                          .outsideCountryTravelDate =
                                      "${dob.year}-${dob.month < 10 ? "0${dob.month}" : dob.month}-${dob.day < 10 ? "0${dob.day}" : dob.day}T14:21:25.017Z";
                                  outsideController.text =
                                      "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                                }
                              },
                            ),
                          ),
                          const SizedBox(height: 10.0),
                          SizedBox(
                            height: 30,
                            child: TextFormField(
                              controller: outsideController1,
                              onChanged: (String? value) {
                                context
                                    .read<UserData>()
                                    .outsideCountryTravelDestination = value;
                                _formKey.currentState!.validate();
                              },
                              decoration: InputDecoration(
                                labelText: 'Travel Destination',
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10.0),
                          SizedBox(
                            height: 30,
                            child: TextFormField(
                              controller: outsideController2,
                              onChanged: (String? value) {
                                context
                                    .read<UserData>()
                                    .outsideCountryTravelDuration = value;
                                _formKey.currentState!.validate();
                              },
                              decoration: InputDecoration(
                                labelText: 'How Long?',
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10.0),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ViewItem extends StatelessWidget {
  String item;
  bool itemSelected;
  final Function(String) selected;

  _ViewItem(
      {required this.item, required this.itemSelected, required this.selected});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Padding(
      padding:
          EdgeInsets.only(left: size.width * .032, right: size.width * .098),
      child: Row(
        children: [
          SizedBox(
            height: 24.0,
            width: 24.0,
            child: Checkbox(
              value: itemSelected,
              onChanged: (val) {
                selected(item);
              },
              activeColor: Colors.blue,
            ),
          ),
          SizedBox(
            width: size.width * .025,
          ),
          Text(
            item,
            style: TextStyle(
              color: Colors.grey,
              fontWeight: FontWeight.w400,
              fontSize: 17.0,
            ),
          ),
        ],
      ),
    );
  }
}
