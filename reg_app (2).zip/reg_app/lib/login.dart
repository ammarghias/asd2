// Import necessary packages
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/pspdfkit_form_example.dart';
import 'package:reg_app/terenfrirstpages/teren8.dart';

class LoginScreen extends StatelessWidget {
  static const String route = '/login';
  String ter="";
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login Screen',
      theme: ThemeData(
        primaryColor: Colors.purple,
      ),
      home: Scaffold(
        body: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/Splash screen.png'),
              fit: BoxFit.cover,
            ),
            borderRadius: BorderRadius.circular(35),
            boxShadow: [
              BoxShadow(
                  //offset: Offset(0, 4),
                  color: Color.fromARGB(255, 78, 78, 78), //edited
                  spreadRadius: 4,
                  blurRadius: 10 //edited
                  )
            ],
          ),
          child: Center(
            // Add your login screen content here
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 233, 233, 233),
                // image: DecorationImage(
                //   image: AssetImage('assets/Splash screen.png'),
                //   fit: BoxFit.cover,
                // ),
                // borderRadius: BorderRadius.circular(35),
                boxShadow: [
                  BoxShadow(
                      //offset: Offset(0, 4),
                      color: Color.fromARGB(255, 78, 78, 78), //edited
                      spreadRadius: 4,
                      blurRadius: 10 //edited
                      )
                ],
              ),
              width: MediaQuery.of(context).size.width * 0.82,
          height: MediaQuery.of(context).size.height * 0.25,
            
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      onChanged: (value){
ter=value;
                      },
                      decoration: InputDecoration(hintText: 'Enter name'),
                    ),
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      decoration: InputDecoration(hintText: 'Enter password'),
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    child: Text('Login'),
                    onPressed: () {
                      if(ter=="8"||ter=="9"||ter=="10"||ter=="17"||ter=="19"||ter=="27"||ter=="28"||ter=="29"||ter=="39"||ter=="40"||ter=="46"||ter=="47"||ter=="48"||ter=="49")
                     { context.read<UserData>().terenid=ter;
                      Navigator.pushNamed(context, '/$ter');
                      }else{
                         context.read<UserData>().terenid="8";
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>  const newpageu8()));
                      }
                       
                      // Add login functionality here
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
