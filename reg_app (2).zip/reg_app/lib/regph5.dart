// Suggestions:
// 1. Use MaterialApp and Scaffold widgets for easier app and UI building
// 2. Use ListView for the drawer items
// 3. Use CircleAvatar for profile picture
// 4. Use InputDecoration for rounded border text fields

import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/regph2.dart';
import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph6.dart';
import 'package:reg_app/regph7.dart';
import 'package:reg_app/regph8.dart';
import 'package:toggle_switch/toggle_switch.dart';

class pereg5 extends StatefulWidget {
  @override
  _pereg5State createState() => _pereg5State();
  static const String route = '/mark';
}

class _pereg5State extends State<pereg5> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  TextEditingController marketingTypeController = TextEditingController();
  String marketingType = "";
  List<String> listOFSelectedItem = [];
  String selectedText = "";
  var phoneNoMaskFormatter2 = new MaskTextInputFormatter(
      mask: '##################',
      filter: {"#": RegExp(r'[0-9\,\.\()\-a-zA-Z]')},
      type: MaskAutoCompletionType.lazy);
  List<String> listOFStringsd = [
    "facebook",
    "mapSearch",
    "googleSearch",
    "website",
    "websiteAds",
    "onlineReviews",
    "twitter",
    "linkedIn",
    "emailBlast",
    "youTube",
    "onlineAdvertisements",
  ];
  List<String> listOFStrings = [
    "tv",
    "billboard",
    "radio",
    "building Sign/DriveBy",
    "brochure",
    "direct Mail",
    "citizens Data",
    "live/Work Nearby",
    "facebook",
    "map Search",
    "google Search",
    "website",
    "website Ads",
    "online Reviews",
    "twitter",
    "linkedIn",
    "email Blast",
    "youTube",
    "online Advertisements",
  ];
  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  TextEditingController t3 = TextEditingController();
  TextEditingController t4 = TextEditingController();
  TextEditingController t5 = TextEditingController();
  TextEditingController t6 = TextEditingController();
  TextEditingController t7 = TextEditingController();
  TextEditingController t8 = TextEditingController();
  TextEditingController t9 = TextEditingController();
  TextEditingController t10 = TextEditingController();
  TextEditingController t11 = TextEditingController();
  TextEditingController t12 = TextEditingController();
  TextEditingController t13 = TextEditingController();
  TextEditingController t14 = TextEditingController();
  TextEditingController t15 = TextEditingController();
  TextEditingController t16 = TextEditingController();
  TextEditingController t17 = TextEditingController();
  TextEditingController t18 = TextEditingController();
  TextEditingController t19 = TextEditingController();
  TextEditingController t20 = TextEditingController();
  TextEditingController t21 = TextEditingController();
  TextEditingController schooler = TextEditingController();
  TextEditingController fm = TextEditingController();
  TextEditingController esm = TextEditingController();
  TextEditingController mg = TextEditingController();
  TextEditingController np = TextEditingController();
  TextEditingController ce = TextEditingController();
   TextEditingController uc = TextEditingController();
  TextEditingController ht = TextEditingController();
  
   int ch1 = 0,numberone=0;
  @override
  void initState() {
    super.initState();
//marketingcheck
  if (context.read<UserData>().marketingcheck != null)
      numberone = context.read<UserData>().marketingcheck!;
    if (context.read<UserData>().refPhysicianName != null)
      t1.text = context.read<UserData>().refPhysicianName!;
    if (context.read<UserData>().refPhysicianPhone != null)
      t2.text = context.read<UserData>().refPhysicianPhone!;
    if (context.read<UserData>().refWorkName != null)
      t3.text = context.read<UserData>().refWorkName!;

    if (context.read<UserData>().refWorkPhone != null)
      t4.text = context.read<UserData>().refWorkPhone!;
    if (context.read<UserData>().refOtherName != null)
      t5.text = context.read<UserData>().refOtherName!;
    if (context.read<UserData>().refOtherPhone != null)
      t6.text = context.read<UserData>().refOtherPhone!;

    if (context.read<UserData>().listOFSelectedItem != null)
      listOFSelectedItem = context.read<UserData>().listOFSelectedItem!;
    // if( context.read<UserData>().guarantorFirstName!=null)
    // t3.text= context.read<UserData>().guarantorFirstName!;

     if (context.read<UserData>().schoolText != null)
       schooler.text = context.read<UserData>().schoolText!;
    if (context.read<UserData>().familyFriendText != null)
      fm.text = context.read<UserData>().familyFriendText!;
    if (context.read<UserData>().employerSentMeText != null)
      esm.text = context.read<UserData>().employerSentMeText!;
    if (context.read<UserData>().magazineText != null)
      mg.text = context.read<UserData>().magazineText!;

    if (context.read<UserData>().newspaperText != null)
      np.text = context.read<UserData>().newspaperText!;
    if (context.read<UserData>().communityEventText != null)
      ce.text = context.read<UserData>().communityEventText!;
  if (context.read<UserData>().urgentCareText != null)
      uc.text = context.read<UserData>().urgentCareText!;
    if (context.read<UserData>().hotelText != null)
      ht.text = context.read<UserData>().hotelText!;
 
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(119, 94, 158, 100),
        title: const Text(
          ' Marketing',
          style: TextStyle(color: Colors.white),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              '',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            onPressed: () {
              if (_formKey.currentState!.validate()) {}
            },
          ),
        ],
      ),
      drawer: Drawer(
        width: 200,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(51, 62, 101, 5),
                Color.fromRGBO(107, 80, 135, 5)
              ],
            ),
          ),
          child: ListView(
            children: <Widget>[
              // const UserAccountsDrawerHeader(
              //   currentAccountPictureSize: Size.square(90.0),
              //   accountName: Text(
              //     '',
              //     style: TextStyle(color: Colors.white),
              //   ),
              //   accountEmail: Text(
              //     '',
              //     style: TextStyle(color: Colors.white),
              //   ),
              //   currentAccountPicture: CircleAvatar(
              //     backgroundColor: Colors.white,
              //     child: Text(
              //       'P',
              //       style: TextStyle(
              //         fontSize: 20.0,
              //         fontWeight: FontWeight.bold,
              //         color: Colors.purple,
              //       ),
              //     ),
              //   ),
              //   decoration: BoxDecoration(
              //     gradient: LinearGradient(
              //       begin: Alignment.topCenter,
              //       end: Alignment.bottomCenter,
              //       colors: [Colors.transparent, Colors.transparent],
              //       //  [Color.fromRGBO(51, 62, 101,10), Color.fromRGBO(51, 62, 101,10)],
              //     ),
              //   ),
              // ),
              // Padding(
              //   padding: const EdgeInsets.all(8.0),
              //   child: Row(
              //     children: [
              //       const Icon(
              //         Icons.image,
              //         color: Colors.white,
              //       ),
              //       const SizedBox(
              //         width: 10,
              //       ),
              //       const Icon(
              //         Icons.edit,
              //         color: Colors.white,
              //       ),
              //     ],
              //   ),
              // ),
              ListTile(
                title: Text(
                  'Patient',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg1()));

                  // TODO: Navigate to patient info page
                },
              ),
              ListTile(
                autofocus: true,
                selected: true,
                focusColor: Colors.white,
                selectedColor: Colors.white,
                enabled: true,
                title: Text(
                  'Physician',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg2()));
                },
              ),
              ListTile(
                title: Text(
                  'COVID-19',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg8()));
                  // TODO: Navigate to COVID-19 info page
                },
              ),
              ListTile(
                title: Text(
                  'Guarantor',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg3()));
                  // TODO: Navigate to guarantor info page
                },
              ),
              ListTile(
                title: Text(
                  'Insurance',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg7()));
                  // TODO: Navigate to insurance info page
                },
              ),
              ListTile(
                title: Text(
                  'Emergency Contact',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg4()));
                  // TODO: Navigate to emergency info page
                },
              ),
              ListTile(
                title: Text(
                  'Marketing',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg5()));
                  // TODO: Navigate to marketing info page
                },
              ),
              ListTile(
                title: Text(
                  'ID Upload',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg6()));
                  // TODO: Navigate to ID upload page
                },
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(

          // color: Color(0xFFC0C0C0),
          child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.grey,
            ],
          ),
        ),
        child: Row(
          children: <Widget>[
            Padding(
                padding: const EdgeInsets.only(
                    left: 10.0, top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          Navigator.of(context).pop();
                          // Navigator.push(context, MaterialPageRoute(builder: (context) => PersonalInfoRegister(),));
                        },
                        child: const Text("BACK"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
            const Spacer(),
            const Expanded(
              child: Padding(
                padding: EdgeInsets.all(18.0),
                child: Text(
                  "",
                  style: TextStyle(
                      // color: Color(0xFFC0C0C0),
                      fontSize: 16.0),
                ),
              ),
            ),
            Padding(
                padding: EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton( 
                        onPressed: () async {
                          context.read<UserData>().facebook =
                              listOFSelectedItem.contains(listOFStrings[8]);
                          context.read<UserData>().mapSearch =
                              listOFSelectedItem.contains(listOFStrings[9]);
                          context.read<UserData>().googleSearch =
                              listOFSelectedItem.contains(listOFStrings[10]);
                          context.read<UserData>().website =
                              listOFSelectedItem.contains(listOFStrings[11]);
                          context.read<UserData>().websiteAds =
                              listOFSelectedItem.contains(listOFStrings[12]);
                          context.read<UserData>().onlineReviews =
                              listOFSelectedItem.contains(listOFStrings[13]);
                          context.read<UserData>().twitter =
                              listOFSelectedItem.contains(listOFStrings[14]);
                          context.read<UserData>().linkedIn =
                              listOFSelectedItem.contains(listOFStrings[15]);
                          context.read<UserData>().emailBlast =
                              listOFSelectedItem.contains(listOFStrings[16]);
                          context.read<UserData>().youTube =
                              listOFSelectedItem.contains(listOFStrings[17]);
                          context.read<UserData>().onlineAdvertisements =
                              listOFSelectedItem.contains(listOFStrings[18]);
                          context.read<UserData>().tv =
                              listOFSelectedItem.contains(listOFStrings[0]);
                          context.read<UserData>().billboard =
                              listOFSelectedItem.contains(listOFStrings[1]);
                          context.read<UserData>().radio =
                              listOFSelectedItem.contains(listOFStrings[2]);
                          context.read<UserData>().buildingSignDriveBy =
                              listOFSelectedItem.contains(listOFStrings[3]);
                          context.read<UserData>().brochure =
                              listOFSelectedItem.contains(listOFStrings[4]);
                          context.read<UserData>().directMail =
                              listOFSelectedItem.contains(listOFStrings[5]);
                          context.read<UserData>().citizensDeTar =
                              listOFSelectedItem.contains(listOFStrings[6]);
                          context.read<UserData>().liveWorkNearby =
                              listOFSelectedItem.contains(listOFStrings[7]);
                          // context.read<UserData>().school =
                          //     listOFSelectedItem.contains(listOFStrings[8]);
                          context.read<UserData>().listOFSelectedItem =
                              listOFSelectedItem;
                          if (numberone == 0) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content:
                                  const Text('Select, How did you find us?'),
                              action: SnackBarAction(
                                label: 'Undo',
                                onPressed: () {
                                  // Some code to undo the change.
                                },
                              ),
                            ));
                          } else {
                            Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => pereg6()));
                          }
                        },
                        child: Text("NEXT"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
          ],
        ),
      )),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'did you find us on the internet?',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(width: 15.0),
                    ToggleSwitch(
                      minWidth: 42.0,
                      minHeight: 20.0,
                      customTextStyles: [const TextStyle(fontSize: 10)],
                      activeFgColor: Colors.black,
                      inactiveBgColor: Colors.white,
                      dividerColor: Colors.white,
                      inactiveFgColor: Colors.black,
                      activeBgColors: const [
                        [Colors.grey],
                        [Colors.grey]
                      ],
                      initialLabelIndex: context.read<UserData>().internetFind,
                      totalSwitches: 2,
                      labels: const [
                        'No',
                        'Yes',
                      ],
                      onToggle: (index) {
                        context.read<UserData>().internetFind = index;
                        setState(() {
                          ch1 = index!;
                        });

                        print('switched to: $index');
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10.0),
              Visibility(
                visible: context.read<UserData>().internetFind == 1,
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Container(
                    // color: Colors.grey,
                    margin: EdgeInsets.only(top: 10.0),
                    decoration: BoxDecoration(
                      border: Border.all(color: Color.fromARGB(255, 0, 0, 0)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: ExpansionTile(
                      maintainState: true,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      clipBehavior: Clip.antiAlias,
                      backgroundColor: Color.fromARGB(255, 254, 254, 254),
                      iconColor: Colors.grey,
                      title: const Text(
                        "How did you find us",
                        style: TextStyle(
                          color: Colors.grey,
                          fontWeight: FontWeight.w400,
                          fontSize: 15.0,
                        ),
                      ),
                      children: <Widget>[
                        ListView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: 11,
                          itemBuilder: (BuildContext context, int index) {
                            return Container(
                              color: Colors.white,
                              margin: const EdgeInsets.only(bottom: 8.0),
                              child: _ViewItem(
                                  item: listOFStrings[index + 8],
                                  selected: (val) {
                                    selectedText = val;
                                    if (listOFSelectedItem.contains(val)) {
                                      // numberone=numberone-1;
                                      listOFSelectedItem.remove(val);
                                    } else {
                                        //  numberone=numberone+1;
                                      listOFSelectedItem.add(val);
                                    }
                                    // selectedList(listOFSelectedItem);
                                    setState(() {
                                    
                                      context
                                              .read<UserData>()
                                              .listOFSelectedItem =
                                          listOFSelectedItem;
                                    });
                                  },
                                  itemSelected: listOFSelectedItem
                                      .contains(listOFStrings[index + 8])),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                  // color: Colors.grey,
                  margin: const EdgeInsets.only(top: 10.0),
                  decoration: BoxDecoration(
                    border: Border.all(color: Color.fromARGB(255, 0, 0, 0)),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: ExpansionTile(
                    maintainState: true,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    clipBehavior: Clip.antiAlias,
                    backgroundColor: const Color.fromARGB(255, 254, 254, 254),
                    iconColor: Colors.grey,
                    title: const Text(
                      // listOFSelectedItem.isEmpty
                      "How else did you hear about us?",
                      // : listOFSelectedItem[0],
                      style: TextStyle(
                        color: Colors.grey,
                        fontWeight: FontWeight.w400,
                        fontSize: 15.0,
                      ),
                    ),
                    children: <Widget>[
                      ListView.builder( 
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: 8,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                            color: Colors.white,
                            margin: const EdgeInsets.only(bottom: 8.0),
                            child: _ViewItem(
                                item: listOFStrings[index],
                                selected: (val) {
                                  selectedText = val;
                                  if (listOFSelectedItem.contains(val)) {
                                      numberone=numberone-1;
                                      context.read<UserData>().marketingcheck=numberone;
                                    listOFSelectedItem.remove(val);
                                  } else {
                                      numberone=numberone+1;
                                      context.read<UserData>().marketingcheck=numberone;
                                    listOFSelectedItem.add(val);
                                  }

                                  setState(() {
                                    context
                                            .read<UserData>()
                                            .listOFSelectedItem =
                                        listOFSelectedItem;
                                  });
                                },
                                itemSelected: listOFSelectedItem
                                    .contains(listOFStrings[index])),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        "More Options",
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                    TextFormField(
                      controller: schooler,
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '########################',
                            filter: {"#": RegExp(r'[a-zA-Z]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      decoration: InputDecoration(
                        labelText: 'School',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().schoolText = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: fm,
                      decoration: InputDecoration(
                        labelText: 'Faimly Friends',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().familyFriendText = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: esm, 
                      decoration: InputDecoration(
                        labelText: 'Employer sent me',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                        context.read<UserData>().employerSentMeText = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: mg,
                      decoration: InputDecoration(
                        labelText: 'Magzine',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().magazineText = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: np,
                      decoration: InputDecoration(
                        labelText: 'News Paper',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                        context.read<UserData>().newspaperText = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: ce,
                      decoration: InputDecoration(
                        labelText: 'Comunity Event',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().communityEventText = value;
                      },
                    ),
                      const SizedBox(height: 10),
                    TextFormField(
                      controller: uc,
                      decoration: InputDecoration(
                        labelText: 'Urgent Care',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().urgentCareText = value;
                      },
                    ),
                      const SizedBox(height: 10),
                    TextFormField(
                      controller: ht,
                      decoration: InputDecoration(
                        labelText: 'Hotel',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().hotelText = value;
                      },
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        "Were you Refered?",
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                    TextFormField(
                      controller: t1,
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '########################',
                            filter: {"#": RegExp(r'[a-zA-Z]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      decoration: InputDecoration(
                        labelText: 'Physician Name',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().refPhysicianName = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: t2,
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '(###) ###-####',
                            filter: {"#": RegExp(r'[0-9]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      decoration: InputDecoration(
                        labelText: 'Physician Cell Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().refPhysicianPhone = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: t3,
                      decoration: InputDecoration(
                        labelText: 'Work',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                        context.read<UserData>().refWorkName = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: t4,
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '(###) ###-####',
                            filter: {"#": RegExp(r'[0-9]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      decoration: InputDecoration(
                        labelText: 'Work Cell Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().refWorkPhone = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: t5,
                      decoration: InputDecoration(
                        labelText: 'Other',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                        context.read<UserData>().refOtherName = value;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: t6,
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '(###) ###-####',
                            filter: {"#": RegExp(r'[0-9]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      decoration: InputDecoration(
                        labelText: 'Other Cell Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().refOtherPhone = value;
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class _ViewItem extends StatelessWidget {
  String item;
  bool itemSelected;
  final Function(String) selected;

  _ViewItem(
      {required this.item, required this.itemSelected, required this.selected});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Padding(
      padding:
          EdgeInsets.only(left: size.width * .032, right: size.width * .098),
      child: Row(
        children: [
          SizedBox(
            height: 24.0,
            width: 24.0,
            child: Checkbox(
              value: itemSelected,
              onChanged: (val) {
                selected(item);
              },
              activeColor: Colors.blue,
            ),
          ),
          SizedBox(
            width: size.width * .025,
          ),
          Text(
            item,
            style: const TextStyle(
              color: Colors.grey,
              fontWeight: FontWeight.w400,
              fontSize: 17.0,
            ),
          ),
        ],
      ),
    );
  }
}
