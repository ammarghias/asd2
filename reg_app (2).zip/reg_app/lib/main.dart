import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:pspdfkit_flutter/pspdfkit.dart';
import 'package:pspdfkit_flutter/widgets/pspdfkit_widget.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/pspdfkit_form_example.dart';
import 'package:reg_app/regph2.dart';
import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph6.dart';
import 'package:reg_app/regph7.dart';
import 'package:reg_app/regph8.dart';
import 'package:reg_app/splash.dart';
import 'package:reg_app/terenfrirstpages/10.dart';
import 'package:reg_app/terenfrirstpages/17.dart';
import 'package:reg_app/terenfrirstpages/19.dart';
import 'package:reg_app/terenfrirstpages/27.dart';
import 'package:reg_app/terenfrirstpages/29.dart';
import 'package:reg_app/terenfrirstpages/46.dart';
import 'package:reg_app/terenfrirstpages/47.dart';
import 'package:reg_app/terenfrirstpages/48.dart';
import 'package:reg_app/terenfrirstpages/9.dart';
import 'package:reg_app/terenfrirstpages/teren40.dart';
import 'package:reg_app/terenfrirstpages/teren8.dart';
import 'package:reg_app/utils/file_utils.dart';
import 'package:reg_app/utils/platform_utils.dart';
import 'login.dart';
import 'terenfrirstpages/39.dart';

const String _documentPath = 'PDFs/PSPDFKit.pdf';
const String _measurementsDocs = 'PDFs/Measurements.pdf';
const String _lockedDocumentPath = 'PDFs/protected.pdf';
const String _imagePath = 'PDFs/PSPDFKit_Image_Example.jpg';
const String _formPath = 'PDFs/Form_example.pdf';
const String _instantDocumentJsonPath = 'PDFs/Instant/instant-document.json';
const String _processedDocumentPath = 'PDFs/Embedded/PSPDFKit-processed.pdf';

const String _pspdfkitFlutterPluginTitle =
    'PSPDFKit Flutter Plugin example app';

const String _basicExample = 'Basic Example';
const String _basicPlatformStyleExample = 'Basic Example using Platform Style';
const String _basicExampleSub = 'Opens a PDF Document.';
const String _basicPlatformStyleExampleSub =
    'Opens a PDF Document using Material page scaffolding for Android, and Cupertino page scaffolding for iOS.';
const String _imageDocument = 'Image Document';
const String _imageDocumentSub = 'Opens an image document.';
const String _darkTheme = 'Dark Theme';
const String _darkThemeSub =
    'Opens a document in night mode with a custom dark theme.';
const String _customConfiguration = 'Custom configuration options';
const String _customConfigurationSub =
    'Opens a document with custom configuration options.';
const String _passwordProtectedDocument =
    'Opens and unlocks a password protected document';
const String _passwordProtectedDocumentSub =
    'Programmatically unlocks a password protected document.';

const String _formExample = 'Programmatic Form Filling Example';
const String _formExampleSub =
    'Programmatically sets and gets the value of a form field using a custom Widget.';
const String _annotationsExample =
    'Programmatically Adds and Removes Annotations';
const String _pdfGenerationExample = 'PDF generation';
const String _pdfGenerationExampleSub =
    'Programmatically generate PDFs from images, templates, and HTML.';
const String _annotationsExampleSub =
    'Programmatically adds and removes annotations using a custom Widget.';
const String _manualSaveExample = 'Manual Save';
const String _saveAsExample = 'Save As';
const String _manualSaveExampleSub =
    'Add a save button at the bottom and disable automatic saving.';
const String _saveAsExampleSub =
    'Embed and save the changes made to a document into a new file';
const String _annotationProcessingExample = 'Process Annotations';
const String _annotationProcessingExampleSub =
    'Programmatically adds and removes annotations using a custom Widget.';
const String _importInstantJsonExample = 'Import Instant Document JSON';
const String _importInstantJsonExampleSub =
    'Shows how to programmatically import Instant Document JSON using a custom Widget.';
const String _widgetExampleFullScreen =
    'Shows two PSPDFKit Widgets simultaneously';
const String _widgetExampleFullScreenSub =
    'Opens two different PDF documents simultaneously using two PSPDFKit Widgets.';

const String _basicExampleGlobal = 'Basic Example';
const String _basicExampleGlobalSub = 'Opens a PDF Document.';
const String _imageDocumentGlobal = 'Image Document';
const String _imageDocumentGlobalSub = 'Opens an image document.';
const String _darkThemeGlobal = 'Dark Theme';
const String _darkThemeGlobalSub =
    'Opens a document in night mode with custom dark theme.';
const String _customConfigurationGlobal = 'Custom configuration options';
const String _customConfigurationGlobalSub =
    'Opens a document with custom configuration options.';
const String _passwordProtectedDocumentGlobal =
    'Opens and unlocks a password protected document';
const String _passwordProtectedDocumentGlobalSub =
    'Programmatically unlocks a password protected document.';
const String _formExampleGlobal = 'Programmatic Form Filling Example';
const String _formExampleGlobalSub =
    'Programmatically set and get the value of a form field.';
const String _importInstantJsonExampleGlobal = 'Import Instant Document JSON';
const String _importInstantJsonExampleGlobalSub =
    'Shows how to programmatically import Instant Document JSON.';
const String _pspdfkitWidgetExamples = 'PSPDFKit Widget Examples';
const String _pspdfkitGlobalPluginExamples = 'PSPDFKit Modal View Examples';

const String _pspdfkitInstantExamples = 'PSPDFKit Instant';
const String _pspdfkitInstantExampleSub =
    'PSPDFKit Instant Synchronisation Example';
const String _measurementTools = 'Measurement tools';
const String _measurementToolsSub = 'PSPDFKit Measurements tools Example';

const String _annotationsPresetCustomization =
    'Annotations Preset Customization';

const String _annotationsPresetCustomizationSub =
    'PSPDFKit Annotations Preset Customization Example';

const String _pspdfkitFor = 'PSPDFKit for';
const double _fontSize = 18.0;
void main() {
  runApp(ChangeNotifierProvider(
      create: (context) => UserData(), child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      themeMode: ThemeMode.light,
      theme: ThemeData(
        visualDensity: VisualDensity.adaptivePlatformDensity,
        primarySwatch: Colors.blue,
        textTheme: const TextTheme(
          bodyLarge: TextStyle(fontSize: 15.0, color: Colors.black),
          bodyMedium: TextStyle(fontSize: 15.0, color: Colors.black),
          labelLarge: TextStyle(fontSize: 15.0, color: Colors.black),
        ),
      ),
      routes: {
        pereg1.route: (context) => pereg1(),
        pereg2.route: (context) => pereg2(),
        pereg3.route: (context) => pereg3(),
        pereg4.route: (context) => pereg4(),
        pereg5.route: (context) => pereg5(),
        pereg6.route: (context) => pereg6(),
        pereg7.route: (context) => const pereg7(),
        pereg8.route: (context) => pereg8(),
        newpageu8.route: (context) => const newpageu8(),
        newpageu9.route: (context) => const newpageu9(),
        newpageu10.route: (context) => const newpageu10(),
        newpageu17.route: (context) => const newpageu17(),
        newpageu19.route: (context) => const newpageu19(),
        newpageu27.route: (context) => const newpageu27(),
        newpageu29.route: (context) => const newpageu29(),
        newpageu39.route: (context) => const newpageu39(),
        newpageu40.route: (context) => const newpageu40(),
        newpageu46.route: (context) => const newpageu46(),
        newpageu47.route: (context) => const newpageu47(),
        newpageu48.route: (context) => const newpageu48(),
        Splash.route:(context) => const Splash(),
                LoginScreen.route:(context) => LoginScreen(),
      },
      debugShowCheckedModeBanner: false,
      title: 'RoverMD',
      initialRoute: "/login",
    );
  }
}
class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  static final ThemeData lightTheme =
      ThemeData(primaryColor: Colors.black, dividerColor: Colors.grey[400]);

  static final ThemeData darkTheme =
      ThemeData(primaryColor: Colors.white, dividerColor: Colors.grey[800]);
  String _frameworkVersion = '';
  ThemeData currentTheme = lightTheme;

  void showDocument() async {
    final extractedDocument = await extractAsset(context, _documentPath);
    await Navigator.of(context).push<dynamic>(MaterialPageRoute<dynamic>(
        builder: (_) => Scaffold(
            extendBodyBehindAppBar: PlatformUtils.isAndroid(),
            // Do not resize the the document view on Android or
            // it won't be rendered correctly when filling forms.
            resizeToAvoidBottomInset: PlatformUtils.isIOS(),
            appBar: AppBar(),
            body: SafeArea(
                top: false,
                bottom: false,
                child: Container(
                    padding: PlatformUtils.isCupertino(context)
                        ? null
                        : const EdgeInsets.only(top: kToolbarHeight),
                    child: PspdfkitWidget(
                        documentPath: extractedDocument.path))))));
  }

  void showDocumentPlatformStyle() async {
    final extractedDocument = await extractAsset(context, _documentPath);

    if (PlatformUtils.isCupertino(context)) {
      await Navigator.of(context).push<dynamic>(CupertinoPageRoute<dynamic>(
          builder: (_) => CupertinoPageScaffold(
              navigationBar: const CupertinoNavigationBar(),
              child: SafeArea(
                  bottom: false,
                  child:
                      PspdfkitWidget(documentPath: extractedDocument.path)))));
    } else {
      await Navigator.of(context).push<dynamic>(MaterialPageRoute<dynamic>(
          builder: (_) => Scaffold(
              extendBodyBehindAppBar: true,
              appBar: AppBar(),
              body: SafeArea(
                  top: false,
                  bottom: false,
                  child: Container(
                      padding: const EdgeInsets.only(top: kToolbarHeight),
                      child: PspdfkitWidget(
                          documentPath: extractedDocument.path))))));
    }
  }

  void showImage() async {
    final extractedImage = await extractAsset(context, _imagePath);
    await Navigator.of(context).push<dynamic>(MaterialPageRoute<dynamic>(
        builder: (_) => Scaffold(
            extendBodyBehindAppBar:
                PlatformUtils.isCupertino(context) ? false : true,
            appBar: AppBar(),
            body: SafeArea(
                top: false,
                bottom: false,
                child: Container(
                    padding: PlatformUtils.isCupertino(context)
                        ? null
                        : const EdgeInsets.only(top: kToolbarHeight),
                    child:
                        PspdfkitWidget(documentPath: extractedImage.path))))));
  }

  void applyDarkTheme() async {
    final extractedDocument = await extractAsset(context, _documentPath);
    await Navigator.of(context).push<dynamic>(MaterialPageRoute<dynamic>(
        builder: (_) => Scaffold(
            extendBodyBehindAppBar:
                PlatformUtils.isCupertino(context) ? false : true,
            appBar: AppBar(),
            body: SafeArea(
                top: false,
                bottom: false,
                child: Container(
                    padding: PlatformUtils.isCupertino(context)
                        ? null
                        : const EdgeInsets.only(top: kToolbarHeight),
                    child: PspdfkitWidget(
                        documentPath: extractedDocument.path,
                        configuration: const {
                          appearanceMode: 'night',
                          androidDarkThemeResource:
                              'PSPDFKit.Theme.Example.Dark'
                        }))))));
  }

  void applyCustomConfiguration() async {
    final extractedDocument = await extractAsset(context, _documentPath);
    await Navigator.of(context).push<dynamic>(MaterialPageRoute<dynamic>(
        builder: (_) => Scaffold(
            resizeToAvoidBottomInset: false,
            extendBodyBehindAppBar:
                PlatformUtils.isCupertino(context) ? false : true,
            appBar: AppBar(),
            body: SafeArea(
                top: false,
                bottom: false,
                child: Container(
                    padding: PlatformUtils.isCupertino(context)
                        ? null
                        : const EdgeInsets.only(top: kToolbarHeight),
                    child: PspdfkitWidget(
                        documentPath: extractedDocument.path,
                        configuration: const {
                          scrollDirection: 'vertical',
                          pageTransition: 'scrollContinuous',
                          spreadFitting: 'fit',
                          userInterfaceViewMode: 'alwaysVisible',
                          androidShowSearchAction: true,
                          inlineSearch: false,
                          showThumbnailBar: 'floating',
                          androidShowThumbnailGridAction: true,
                          androidShowOutlineAction: true,
                          androidShowAnnotationListAction: true,
                          showPageLabels: true,
                          documentLabelEnabled: false,
                          invertColors: false,
                          androidGrayScale: false,
                          startPage: 2,
                          enableAnnotationEditing: true,
                          enableTextSelection: false,
                          androidShowBookmarksAction: false,
                          androidEnableDocumentEditor: false,
                          androidShowShareAction: true,
                          androidShowPrintAction: false,
                          androidShowDocumentInfoView: true,
                          appearanceMode: 'default',
                          androidDefaultThemeResource: 'PSPDFKit.Theme.Example',
                          iOSRightBarButtonItems: [
                            'thumbnailsButtonItem',
                            'activityButtonItem',
                            'searchButtonItem',
                            'annotationButtonItem'
                          ],
                          iOSLeftBarButtonItems: ['settingsButtonItem'],
                          iOSAllowToolbarTitleChange: false,
                          toolbarTitle: 'Custom Title',
                          settingsMenuItems: [
                            'pageTransition',
                            'scrollDirection',
                            'androidTheme',
                            'iOSAppearance',
                            'androidPageLayout',
                            'iOSPageMode',
                            'iOSSpreadFitting',
                            'androidScreenAwake',
                            'iOSBrightness'
                          ],
                          showActionNavigationButtons: false,
                          pageMode: 'double',
                          firstPageAlwaysSingle: true
                        }))))));
  }

  void unlockPasswordProtectedDocument() async {
    final extractedLockedDocument =
        await extractAsset(context, _lockedDocumentPath);
    await Navigator.of(context).push<dynamic>(MaterialPageRoute<dynamic>(
        builder: (_) => Scaffold(
            extendBodyBehindAppBar:
                PlatformUtils.isCupertino(context) ? false : true,
            appBar: AppBar(),
            body: SafeArea(
                top: false,
                bottom: false,
                child: Container(
                    padding: PlatformUtils.isCupertino(context)
                        ? null
                        : const EdgeInsets.only(top: kToolbarHeight),
                    child: PspdfkitWidget(
                        documentPath: extractedLockedDocument.path,
                        configuration: const {password: 'test123'}))))));
  }

  void showFormDocumentExample() async {
    final extractedFormDocument = await extractAsset(context, _formPath);
    await Navigator.of(context).push<dynamic>(MaterialPageRoute<dynamic>(
        builder: (_) => PspdfkitFormExampleWidget(
            documentPath: extractedFormDocument.path,regid: "asd",)));
  }

 
 

  void pushTwoPspdfWidgetsSimultaneously() async {
    try {
      final extractedDocument = await extractAsset(context, _documentPath);
      final extractedFormDocument = await extractAsset(context, _formPath);

      if (PlatformUtils.isCupertino(context)) {
        await Navigator.of(context).push<dynamic>(CupertinoPageRoute<dynamic>(
            builder: (_) => CupertinoPageScaffold(
                navigationBar: const CupertinoNavigationBar(),
                child: SafeArea(
                    bottom: false,
                    child: Column(children: <Widget>[
                      Expanded(
                          child: PspdfkitWidget(
                              documentPath: extractedDocument.path)),
                      Expanded(
                          child: PspdfkitWidget(
                              documentPath: extractedFormDocument.path))
                    ])))));
      } else {
        // This example is only supported in iOS at the moment.
        // Support for Android is coming soon.
      }
    } on PlatformException catch (e) {
      print("Failed to present document: '${e.message}'.");
    }
  }

  void showDocumentGlobal() async {
    final extractedDocument = await extractAsset(context, _documentPath);
    await Pspdfkit.present(extractedDocument.path);
  }

  void showImageGlobal() async {
    final extractedImage = await extractAsset(context, _imagePath);
    await Pspdfkit.present(extractedImage.path);
  }

  void applyDarkThemeGlobal() async {
    final extractedDocument = await extractAsset(context, _documentPath);
    await Pspdfkit.present(extractedDocument.path, configuration: {
      appearanceMode: 'night',
      androidDarkThemeResource: 'PSPDFKit.Theme.Example.Dark'
    });
  }

  void applyCustomConfigurationGlobal() async {
    final extractedDocument = await extractAsset(context, _documentPath);
    await Pspdfkit.present(extractedDocument.path, configuration: {
      scrollDirection: 'vertical',
      pageTransition: 'scrollPerSpread',
      spreadFitting: 'fit',
      userInterfaceViewMode: 'alwaysVisible',
      androidShowSearchAction: true,
      inlineSearch: false,
      showThumbnailBar: 'floating',
      androidShowThumbnailGridAction: true,
      androidShowOutlineAction: true,
      androidShowAnnotationListAction: true,
      showPageLabels: true,
      documentLabelEnabled: false,
      invertColors: false,
      androidGrayScale: false,
      startPage: 2,
      enableAnnotationEditing: true,
      enableTextSelection: false,
      androidShowBookmarksAction: false,
      androidEnableDocumentEditor: false,
      androidShowShareAction: true,
      androidShowPrintAction: false,
      androidShowDocumentInfoView: true,
      appearanceMode: 'default',
      androidDefaultThemeResource: 'PSPDFKit.Theme.Example',
      iOSRightBarButtonItems: [
        'thumbnailsButtonItem',
        'activityButtonItem',
        'searchButtonItem',
        'annotationButtonItem'
      ],
      iOSLeftBarButtonItems: ['settingsButtonItem'],
      iOSAllowToolbarTitleChange: false,
      toolbarTitle: 'Custom Title',
      settingsMenuItems: [
        'pageTransition',
        'scrollDirection',
        'androidTheme',
        'iOSAppearance',
        'androidPageLayout',
        'iOSPageMode',
        'iOSSpreadFitting',
        'androidScreenAwake',
        'iOSBrightness'
      ],
      showActionNavigationButtons: false,
      pageMode: 'double',
      firstPageAlwaysSingle: true
    });
  }

  void unlockPasswordProtectedDocumentGlobal() async {
    final extractedLockedDocument =
        await extractAsset(context, _lockedDocumentPath);
    await Pspdfkit.present(extractedLockedDocument.path,
        configuration: {password: 'test123'});
  }

  void showFormDocumentExampleGlobal() async {
    final formDocument = await extractAsset(context, _formPath);
    await Pspdfkit.present(formDocument.path);

    try {
      await Pspdfkit.setFormFieldValue('Lastname', 'Name_Last');
      await Pspdfkit.setFormFieldValue('0123456789', 'Telephone_Home');
      await Pspdfkit.setFormFieldValue('City', 'City');
      await Pspdfkit.setFormFieldValue('selected', 'Sex.0');
      await Pspdfkit.setFormFieldValue('deselected', 'Sex.1');
      await Pspdfkit.setFormFieldValue('selected', 'HIGH SCHOOL DIPLOMA');
    } on PlatformException catch (e) {
      print("Failed to set form field values '${e.message}'.");
    }

    String? lastName;
    try {
      lastName = await Pspdfkit.getFormFieldValue('Name_Last');
    } on PlatformException catch (e) {
      print("Failed to get form field value '${e.message}'.");
    }

    if (lastName != null) {
      print(
         "Retrieved form field for fully qualified name 'Name_Last' is $lastName.");
    }
  }

  void importInstantJsonExampleGlobal() async {
    final extractedDocument = await extractAsset(context, _documentPath);
    await Pspdfkit.present(extractedDocument.path);

    // Extract a string from a file.
    final annotationsJson = await DefaultAssetBundle.of(context)
        .loadString(_instantDocumentJsonPath);

    try {
      await Pspdfkit.applyInstantJson(annotationsJson);
    } on PlatformException catch (e) {
      print("Failed to import Instant Document JSON '${e.message}'.");
    }
  }

  
  void showMeasurementExampleGlobal(BuildContext context) {
    extractAsset(context, _measurementsDocs).then((value) {
      Pspdfkit.present(value.path,
          measurementScale: MeasurementScale(
              unitFrom: UnitFrom.cm,
              valueFrom: 1,
              unitTo: UnitTo.km,
              valueTo: 10),
          measurementPrecision: MeasurementPrecision.threeDP);
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    initPlatformState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    currentTheme =
        WidgetsBinding.instance.window.platformBrightness == Brightness.light
            ? lightTheme
            : darkTheme;
    setState(() {
      build(context);
    });
    super.didChangePlatformBrightness();
  }

  String frameworkVersion() {
    return '$_pspdfkitFor $_frameworkVersion\n';
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  void initPlatformState() async {
    String? frameworkVersion;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      frameworkVersion = await Pspdfkit.frameworkVersion;
    } on PlatformException {
      frameworkVersion = 'Failed to get platform version. ';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;

    setState(() {
      _frameworkVersion = frameworkVersion ?? '';
    });

    // By default, this example doesn't set a license key, but instead runs in
    // trial mode (which is the default, and which requires no specific
    // initialization). If you want to use a different license key for
    // evaluation (e.g. a production license), you can uncomment the next line
    // and set the license key.
    //
    // To set the license key for both platforms, use:
    // await Pspdfkit.setLicenseKeys("YOUR_FLUTTER_ANDROID_LICENSE_KEY_GOES_HERE",
    // "YOUR_FLUTTER_IOS_LICENSE_KEY_GOES_HERE");
    //
    // To set the license key for the currently running platform, use:
    // await Pspdfkit.setLicenseKey("YOUR_FLUTTER_LICENSE_KEY_GOES_HERE");
  }

  void flutterPdfActivityOnPauseHandler() {
    print('flutterPdfActivityOnPauseHandler');
  }

  void pdfViewControllerWillDismissHandler() {
    print('pdfViewControllerWillDismissHandler');
  }

  void pdfViewControllerDidDismissHandler() {
    print('pdfViewControllerDidDismissHandler');
  }

  @override
  Widget build(BuildContext context) {
    Pspdfkit.flutterPdfActivityOnPause =
        () => flutterPdfActivityOnPauseHandler();
    Pspdfkit.pdfViewControllerWillDismiss =
        () => pdfViewControllerWillDismissHandler();
    Pspdfkit.pdfViewControllerDidDismiss =
        () => pdfViewControllerDidDismissHandler();

    currentTheme = MediaQuery.of(context).platformBrightness == Brightness.light
        ? lightTheme
        : darkTheme;

    final listTiles = <Widget>[
      Container(
          color: Colors.grey[200],
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
          child: Text(_pspdfkitWidgetExamples,
              style: currentTheme.textTheme.headline4?.copyWith(
                  fontSize: _fontSize, fontWeight: FontWeight.bold))),
      ListTile(
          title: const Text(_basicExample),
          subtitle: const Text(_basicExampleSub),
          onTap: () => showDocument()),
      ListTile(
          title: const Text(_imageDocument),
          subtitle: const Text(_imageDocumentSub),
          onTap: () => showImage()),
      ListTile(
          title: const Text(_darkTheme),
          subtitle: const Text(_darkThemeSub),
          onTap: () => applyDarkTheme()),
      ListTile(
          title: const Text(_customConfiguration),
          subtitle: const Text(_customConfigurationSub),
          onTap: () => applyCustomConfiguration()),
      ListTile(
          title: const Text(_passwordProtectedDocument),
          subtitle: const Text(_passwordProtectedDocumentSub),
          onTap: () => unlockPasswordProtectedDocument()),
      ListTile(
          title: const Text(_formExample),
          subtitle: const Text(_formExampleSub),
          onTap: () => showFormDocumentExample()),
     
      // The push two PspdfWidgets simultaneously example is supported by iOS only for now.
      if (PlatformUtils.isCupertino(context))
        ListTile(
            title: const Text(_widgetExampleFullScreen),
            subtitle: const Text(_widgetExampleFullScreenSub),
            onTap: () => pushTwoPspdfWidgetsSimultaneously()),
      ListTile(
          title: const Text(_basicPlatformStyleExample),
          subtitle: const Text(_basicPlatformStyleExampleSub),
          onTap: () => showDocumentPlatformStyle()),
     
     

      Container(
          color: Colors.grey[200],
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
          child: Text(_pspdfkitGlobalPluginExamples,
              style: currentTheme.textTheme.headline4?.copyWith(
                  fontSize: _fontSize, fontWeight: FontWeight.bold))),
      ListTile(
          title: const Text(_basicExampleGlobal),
          subtitle: const Text(_basicExampleGlobalSub),
          onTap: () => showDocumentGlobal()),
      ListTile(
          title: const Text(_imageDocumentGlobal),
          subtitle: const Text(_imageDocumentGlobalSub),
          onTap: () => showImageGlobal()),
      ListTile(
          title: const Text(_customConfigurationGlobal),
          subtitle: const Text(_customConfigurationGlobalSub),
          onTap: () => applyCustomConfigurationGlobal()),
      ListTile(
          title: const Text(_darkThemeGlobal),
          subtitle: const Text(_darkThemeGlobalSub),
          onTap: () => applyDarkThemeGlobal()),
      ListTile(
          title: const Text(_passwordProtectedDocumentGlobal),
          subtitle: const Text(_passwordProtectedDocumentGlobalSub),
          onTap: () => unlockPasswordProtectedDocumentGlobal()),
      ListTile(
          title: const Text(_formExampleGlobal),
          subtitle: const Text(_formExampleGlobalSub),
          onTap: () => showFormDocumentExampleGlobal()),
      ListTile(
          title: const Text(_importInstantJsonExampleGlobal),
          subtitle: const Text(_importInstantJsonExampleGlobalSub),
          onTap: () => importInstantJsonExampleGlobal()),

      ListTile(
          title: const Text(_measurementTools),
          subtitle: const Text(_measurementToolsSub),
          onTap: () => showMeasurementExampleGlobal(context)),
    ];
    return Scaffold(
        appBar: AppBar(title: const Text(_pspdfkitFlutterPluginTitle)),
        body: ExampleListView(currentTheme, frameworkVersion(), listTiles));
  }
}

class ExampleListView extends StatelessWidget {
  final ThemeData themeData;
  final String frameworkVersion;
  final List<Widget> widgets;

  const ExampleListView(this.themeData, this.frameworkVersion, this.widgets,
      {Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.max, children: [
      Container(
          color: Colors.transparent,
          padding: const EdgeInsets.only(top: 24),
          child: Center(
              child: Text(frameworkVersion,
                  style: themeData.textTheme.headline4?.copyWith(
                      fontSize: _fontSize,
                      fontWeight: FontWeight.bold,
                      color: themeData.primaryColor)))),
      Expanded(
          child: ListView.separated(
              itemCount: widgets.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (BuildContext context, int index) => widgets[index]))
    ]);
  }
}
