import 'dart:convert';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_google_places_sdk/flutter_google_places_sdk.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/patientdetails.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/regph2.dart';
import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph6.dart';
import 'package:reg_app/regph7.dart';
import 'package:reg_app/regph8.dart';
import 'package:toggle_switch/toggle_switch.dart';
import 'package:http/http.dart' as http;
import 'adressmodle.dart';
import 'gender.dart';
import 'models.dart';

class pereg1 extends StatefulWidget {
  @override
  _pereg1State createState() => _pereg1State();
  static const String route = '/reg';
}

class _pereg1State extends State<pereg1> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  late petient info1;
  bool collerrace = false;
  String reasonVisitType = "COVID Testing";
  String reasonemergencyType = "Abdominal Pain";
  String orient = "Heterosexual";
  TextEditingController sexController = TextEditingController();
  TextEditingController raceController = TextEditingController();
  TextEditingController ethController = TextEditingController();
  TextEditingController reasonVsitController = TextEditingController();
  TextEditingController specifyReasonController = TextEditingController();
  TextEditingController orientationmController = TextEditingController();
  var phoneNoMaskFormatter = MaskTextInputFormatter(
      mask: '(###) ###-####',
      filter: {"#": RegExp(r'[0-9]')},
      type: MaskAutoCompletionType.lazy);
  bool c1 = false;
  bool c2 = false;
  bool c3 = false;
  bool c4 = false;
  bool c5 = false;
  bool c6 = false;
  bool c7 = false;
  bool c8 = false;
  bool c9 = false;
  bool c10 = false;
  bool c11 = false;
  bool c12 = false;
  String sexType = "Male";
  String genderq = "choose Identity", lanc = "choose Language";
  Gender? selectedGender;
  ethnicxity? selecetedethnicxity;
  List<Gender>? genders;
  racemodle? selecetedrace;
  List<racemodle>? raced;

  List<ethnicxity>? ethnicx;
  TextEditingController streetAddController = TextEditingController();
  TextEditingController streetAddController2 = TextEditingController();
  TextEditingController stateController = TextEditingController();
  TextEditingController zipCodeController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  TextEditingController countryController = TextEditingController();
  TextEditingController countyController = TextEditingController();
  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  TextEditingController t3 = TextEditingController();
  TextEditingController t4 = TextEditingController();
  TextEditingController t5 = TextEditingController();
  TextEditingController t6 = TextEditingController();
  TextEditingController t7 = TextEditingController();
  TextEditingController t8 = TextEditingController();
  TextEditingController t9 = TextEditingController();
  TextEditingController t10 = TextEditingController();
  TextEditingController t11 = TextEditingController();
  TextEditingController t12 = TextEditingController();
  TextEditingController t13 = TextEditingController();
  TextEditingController t14 = TextEditingController();
  TextEditingController t15 = TextEditingController();
  TextEditingController t16 = TextEditingController();
  TextEditingController t17 = TextEditingController();
  TextEditingController t18 = TextEditingController();
  TextEditingController t19 = TextEditingController();
  TextEditingController t20 = TextEditingController();
  TextEditingController t21 = TextEditingController();
  TextEditingController cnfmail = TextEditingController();
  bool toggle1 = false;
  bool toggle2 = false;
  late final FlutterGooglePlacesSdk _places;
  String? _predictLastText;
  bool _predicting = false;
  dynamic _predictErr;
  List<AutocompletePrediction>? _predictions;
  var comp;
  Widget _buildPredictionItem2(AutocompletePrediction item) {
    var co = Color.fromARGB(0, 0, 0, 0);
    return Container(
      color: co,
      child: InkWell(
        focusColor: co,
        onTap: () async {
          setState(() {
            context.read<UserData>().address1 = item.fullText;
            streetAddController2.text = item.fullText;
          });
          setState(() {});
          Navigator.pop(context);
        },
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                item.fullText,
                textAlign: TextAlign.center,
              ),
              const Divider(thickness: 2),
            ]),
      ),
    );
  }

  Widget _buildPredictionItem(AutocompletePrediction item) {
    var co = Color.fromARGB(0, 0, 0, 0);

    return Container(
      color: co,
      child: InkWell(
        focusColor: co,
        onTap: () async {
          comp = fetchAlbum(item.placeId, "98");
          setState(() {
            context.read<UserData>().address1 = item.fullText;
            streetAddController.text = item.fullText;

            _formKey.currentState!.validate();
          });
          setState(() {});
          Navigator.pop(context);
        },
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                item.fullText,
                textAlign: TextAlign.center,
              ),
              const Divider(thickness: 2),
            ]),
      ),
    );
  }

  List<Widget> _buildPredictionWidgets() {
    return [
      TextFormField(
        onChanged: _onPredictTextChanged,
        decoration: InputDecoration(label: Text("Address")),
      ),
      _buildErrorWidget(_predictErr),
      Column(
        mainAxisSize: MainAxisSize.min,
        children: (_predictions ?? [])
            .map(_buildPredictionItem)
            .toList(growable: false),
      ),
    ];
  }

  Widget _buildErrorWidget(dynamic err) {
    final theme = Theme.of(context);
    final errorText = err == null ? '' : err.toString();
    return Text(errorText,
        style: theme.textTheme.bodySmall
            ?.copyWith(color: theme.colorScheme.error));
  }

  addTypeDialog(BuildContext context) {
    _buildPredictionWidgets();

    setState(() {});
  }

  Future<AutoGenerate> fetchAlbum(String placeId, sessionToken) async {
    print("placeiddddd=${placeId}");
    final response = await http.get(Uri.parse(
        'https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeId&fields=address_component&key=AIzaSyBO5TaHOjSZFWhBF0AYpNUSmFh8ozqLRto&sessiontoken=$sessionToken'));
    print(response.body);
    setState(() {});
    if (response.statusCode == 200) {
      print(response.body);

      int ii = AutoGenerate.fromJson(jsonDecode(response.body))
          .result
          .addressComponents
          .length;
      for (int index = 0; index < ii; index++) {
        setState(() {
          if (AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[index]
              .types
              .contains("postal_code")) {
            context.read<UserData>().zipCode =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
            print("hhChIJr_D2o-g-tok" +
                context.read<UserData>().zipCode.toString());
            zipCodeController.text =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
          }
          if (AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[index]
              .types
              .contains("administrative_area_level_1")) {
            context.read<UserData>().state =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
            stateController.text =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
          }
          if (AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[index]
              .types
              .contains("administrative_area_level_2")) {
            context.read<UserData>().city =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
            cityController.text =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
          }
          if (AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[index]
              .types
              .contains("administrative_area_level_2")) {
            context.read<UserData>().county =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
            countyController.text =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
          }
          if (AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[index]
              .types
              .contains("country")) {
            context.read<UserData>().country =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
            countryController.text =
                AutoGenerate.fromJson(jsonDecode(response.body))
                    .result
                    .addressComponents[index]
                    .longName;
          }
        });
      }

      print("newone" +
          AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[1]
              .longName);

      return AutoGenerate.fromJson(jsonDecode(response.body));
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load album');
    }
  }

  void _onPredictTextChanged(String value) {
    print(value);
    setState(() {});
    _predictLastText = value;
    _predict();
  }

  void _predict() async {
    if (_predicting) {
      return;
    }

    final hasContent = _predictLastText?.isNotEmpty ?? false;

    setState(() {
      _predicting = hasContent;
      _predictErr = null;
    });

    if (!hasContent) {
      return;
    }

    try {
      final result = await _places.findAutocompletePredictions(
        _predictLastText!,
        countries: null,
        newSessionToken: false,
        placeTypeFilter: PlaceTypeFilter.ADDRESS,
        // origin: LatLng(lat: 43.12, lng: 95.20),
        locationBias: null,
        locationRestriction: null,
      );

      setState(() {
        print("hhhh" + result.predictions[1].placeId);
        _predictions = result.predictions;
        _predicting = false;
      });
    } catch (err) {
      setState(() {
        _predictErr = err;
        _predicting = false;
      });
    }
  }
  //gps

  Future<List<racemodle>?> raceeController() async {
    try {
      var jsonData = null;
      Uri uri = Uri.parse(
          "https://qa.rovermd.com:7685/api/v2/globalExternal/race/all");
      // Uri uri = Uri.parse("$BaseUrl/gender/find/all");
      print(uri.toString());
      var response = await http.get(uri);
      print("kjhg" + response.toString());
      // print("response---$response");
      if (response.statusCode == 200) {
        jsonData = json.decode(response.body.toString());
        List<dynamic> genderData = jsonData;
        print("jsonData---$jsonData");

        return genderData.map((data) => racemodle.fromJson(data)).toList();
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      print("Error in genderController Funtion: $e");
    }
    return null;
  }

  Future<List<Gender>?> genderController() async {
    try {
      var jsonData = null;
      Uri uri = Uri.parse(
          "https://qa.rovermd.com:7685/api/v2/globalExternal/gender/find/all");
      // Uri uri = Uri.parse("$BaseUrl/gender/find/all");
      print(uri.toString());
      var response = await http.get(uri);
      print("jsonData---$response");
      // print("response---$response");
      if (response.statusCode == 200) {
        jsonData = json.decode(response.body.toString());
        List<dynamic> genderData = jsonData;
        print("jsonData---$jsonData");

        return genderData.map((data) => Gender.fromJson(data)).toList();
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      print("Error in sex Funtion: $e");
    }
    return null;
  }

  Future<List<ethnicxity>?> ethnicytyc() async {
    try {
      var jsonData = null;
      Uri uri = Uri.parse(
          "https://qa.rovermd.com:7685/api/v2/globalExternal/ethnicity/all");
      // Uri uri = Uri.parse("$BaseUrl/gender/find/all");
      print(uri.toString());
      var response =
          await http.get(uri, headers: {"Access-Control-Allow-Origin": "*"});
      // print("response---$response");
      if (response.statusCode == 200) {
        jsonData = json.decode(response.body.toString());
        List<dynamic> genderData = jsonData;
        print("jsonData---$jsonData");

        return genderData.map((data) => ethnicxity.fromJson(data)).toList();
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      print("Error inethnicity Funtion: $e");
    }
    return null;
  }

  void initState() {
    super.initState();

    if (context.read<UserData>().sexualOrientation != null)
      orientationmController.text = context.read<UserData>().sexualOrientation!;
    if (context.read<UserData>().sexualOrientation != null)
      orientationmController.text = context.read<UserData>().sexualOrientation!;
    if (context.read<UserData>().ethnicity != null)
      ethController.text = context.read<UserData>().ethnicity!;
    if (context.read<UserData>().race != null)
      raceController.text = context.read<UserData>().race!;
    if (context.read<UserData>().country != null)
      countryController.text = context.read<UserData>().country!;
    if (context.read<UserData>().county != null)
      countyController.text = context.read<UserData>().county!;
    if (context.read<UserData>().city != null)
      cityController.text = context.read<UserData>().city!;
    if (context.read<UserData>().state != null)
      stateController.text = context.read<UserData>().state!;
    if (context.read<UserData>().zipCode != null)
      zipCodeController.text = context.read<UserData>().zipCode!;
    if (context.read<UserData>().address1 != null)
      streetAddController.text = context.read<UserData>().address1!;
    if (context.read<UserData>().empContact != null)
      t5.text = context.read<UserData>().empContact!;
    if (context.read<UserData>().occupation != null)
      t4.text = context.read<UserData>().occupation!;
    if (context.read<UserData>().employer != null)
      t3.text = context.read<UserData>().employer!;
    if (context.read<UserData>().preferredLanguage != null)
      lanc = context.read<UserData>().preferredLanguage!;
    if (context.read<UserData>().country != null)
      countryController.text = context.read<UserData>().country!;
    if (context.read<UserData>().email != null)
      t2.text = context.read<UserData>().email!;
    if (context.read<UserData>().email != null)
      cnfmail.text = context.read<UserData>().email!;
    if (context.read<UserData>().reasonVisitSpecify != null)
      specifyReasonController.text =
          context.read<UserData>().reasonVisitSpecify!;
    if (context.read<UserData>().reasonVisit != null)
      reasonVsitController.text = context.read<UserData>().reasonVisit!;
    if (context.read<UserData>().phNumber != null)
      t1.text = context.read<UserData>().empContactf!;
    if (context.read<UserData>().genderIdentity != null) if (context
            .read<UserData>()
            .genderIdentity ==
        "Male-to-Female (MTF)Transgender Female/Trans Woman") {
      genderq = "Male-to-Female";
    } else if (context.read<UserData>().genderIdentity ==
        "Female-to-Male (FTM)Transgender Male/Trans Man") {
      genderq = "Female-to-Male";
    } else {
      genderq = context.read<UserData>().genderIdentity!;
    }

    if (context.read<UserData>().sex != null)
      sexController.text = context.read<UserData>().sex!;

    if (context.read<UserData>().accurateConsent != null)
      toggle2 = context.read<UserData>().accurateConsent == null
          ? false
          : context.read<UserData>().accurateConsent == 0
              ? false
              : true;
    if (context.read<UserData>().contactConsent != null)
      toggle1 = context.read<UserData>().contactConsent == null
          ? false
          : context.read<UserData>().contactConsent == 0
              ? false
              : true;

    genderController().then((genders) {
      setState(() {
        this.genders = genders;
      });
    });

    ethnicytyc().then((ethnicxit) {
      setState(() {
        this.ethnicx = ethnicxit;
      });
    });
    raceeController().then((raced) {
      setState(() {
        this.raced = raced;
        print("jkl" + raced.toString());
      });
    });
    _places = FlutterGooglePlacesSdk("AIzaSyBO5TaHOjSZFWhBF0AYpNUSmFh8ozqLRto",
        locale: const Locale('en'));
    _places.isInitialized().then((value) {
      debugPrint('Places Initialized: $value');
    });
  }

  showReasonemergencytDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Color(0xFFC0C0C0),
          scrollable: true,
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Container(
                        child: Radio(
                            value: "COVID Testing",
                            groupValue: reasonVisitType,
                            onChanged: (value) {
                              setState(() {
                                reasonVisitType =
                                    value.toString(); //selected value
                                reasonemergencyType = value.toString();
                                _formKey.currentState!.validate();
                              });
                              // print(value);
                            }),
                      ),
                      Text("COVID Testing"),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Container(
                        child: Radio(
                            value: "Emergency",
                            groupValue: reasonVisitType,
                            onChanged: (value) {
                              print(value);
                              setState(() {
                                reasonVisitType = value.toString();
                                _formKey.currentState!
                                    .validate(); //selected value
                              });
                            }),
                      ),
                      Text("Emergency"),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Container(
                        child: Radio(
                            value: "Sport Physical",
                            groupValue: reasonVisitType,
                            onChanged: (value) {
                              print(value);
                              setState(() {
                                reasonVisitType =
                                    value.toString(); //selected value
                                reasonemergencyType = value.toString();
                                _formKey.currentState!.validate();
                              });
                            }),
                      ),
                      Text("Sport Physical"),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Container(
                        child: Radio(
                            value: "Occmed",
                            groupValue: reasonVisitType,
                            onChanged: (value) {
                              print(value);
                              setState(() {
                                reasonVisitType =
                                    value.toString(); //selected value
                                reasonemergencyType = value.toString();
                                _formKey.currentState!.validate();
                              });
                            }),
                      ),
                      Text("Occmed"),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Container(
                        child: Radio(
                            value: "BBH",
                            groupValue: reasonVisitType,
                            onChanged: (value) {
                              print(value);
                              setState(() {
                                reasonVisitType =
                                    value.toString(); //selected value
                                reasonemergencyType = value.toString();
                                _formKey.currentState!.validate();

                                _formKey.currentState!.validate();
                              });
                            }),
                      ),
                      Text("BBH"),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Container(
                        child: Radio(
                            value: "Other",
                            groupValue: reasonVisitType,
                            onChanged: (value) {
                              print(value);
                              setState(() {
                                reasonVisitType = value.toString();
                                _formKey.currentState!
                                    .validate(); //selected value
                              });
                            }),
                      ),
                      Text("Other"),
                    ],
                  ),
                ],
              );
            },
          ),
          actions: [
            TextButton(
              child: Text('OK'),
              onPressed: () {
                print("reasonVisitType--$reasonVisitType");
                Navigator.pop(context);
                //EasyLoading.show(status: 'Updating Map...');
                setState(() {
                  context.read<UserData>().reasonVisit = reasonVisitType;
                  reasonVsitController.text = reasonVisitType;
                  if (reasonVisitType != "Other" &&
                      reasonVisitType != "Emergency") {
                    specifyReasonController.text = reasonVisitType;
                    context.read<UserData>().reasonVisitSpecify =
                        reasonVisitType;
                    setState(() {
                      _formKey.currentState!.validate();
                    });
                  } else {
                    specifyReasonController.text = "";
                    context.read<UserData>().reasonVisitSpecify =
                        reasonVisitType;
                    setState(() {
                      _formKey.currentState!.validate();
                    });
                  }
                  setState(() {
                    _formKey.currentState!.validate();
                  });
                });
              },
            ),
          ],
        );
      },
    );
  }

  List<String> orintation = [
    "Lesbian or gay",
    "Heterosexual or straight",
    "Bisexual",
    "Other",
    "Unknown",
    "Declined to specify",
    "Test Updated",
  ];
  List<String> listemergency = [
    "Abdominal Pain",
    "Abscess/Cyst",
    "Allergic Reaction/Rash ",
    "Animal Bite",
    "Arm/Leg/Body Pain",
    "Asthma/Allergies",
    "Back Pain",
    "Break or Fractures Burns",
    "Bites/Stings",
    "Bleeding",
    "Breaks/Fractures",
    "Chest Pains",
    "Concussion",
    "Constipation",
    "Cough/Congestion",
    "Cuts and Lacerations",
    "Dehydration",
    "Dental Pain/Tooth",
    "Dental Emergency",
    "Dizziness",
    "Diarrhea",
    "Ear/Nose/Throat",
    "Eyes/Vision",
    "Fever",
    "Flu Like Symptoms",
    "Foreign Body Removal",
    "Fall",
    "Head Injury/Concussion",
    "Headache/Migraine",
    "High/Low Blood Sugar",
    "High/Low Blood Pressure",
    "HIV or STD",
    "Heatstroke",
    "Head Injuries",
    "Motor Vehicle Accident",
    "Migraine",
    "Nausea",
    "Pregnancy",
    "Shortness of Breath",
    "Sinus Infections",
    "Swelling",
    "Urinary",
    "Vomiting Blood",
    "Ingestion/Overdose",
    "Insect Bites and Stings",
    "Weakness/Fatigue",
    "Wound Care",
    "Yeast Infection"
  ];
  orientationDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Color(0xFFC0C0C0),
          scrollable: true,
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return Container(
                height: MediaQuery.of(context).size.height / 4,
                width: 300,
                child: ListView.builder(
                  itemCount: 4,
                  itemBuilder: (context, i) {
                    return Row(
                      children: <Widget>[
                        Container(
                          child: Radio(
                              value: orintation[i],
                              groupValue: orient,
                              onChanged: (value) {
                                setState(() {
                                  orientationmController.text =
                                      value.toString();

                                  orient = value.toString(); //selected value
                                });
                                // print(value);
                              }),
                        ),
                        Text(orintation[i]),
                      ],
                    );
                  },
                ),
              );
            },
          ),
          actions: [
            TextButton(
              child: Text('OK'),
              onPressed: () {
                print("reasonVisitType--$reasonemergencyType");
                Navigator.pop(context);
                setState(() {
                  orientationmController.text = orient;
                  context.read<UserData>().sexualOrientation =
                      orientationmController.text;
                });
              },
            ),
            // Row(
            //   children: <Widget>[
            //     Padding(
            //         padding: EdgeInsets.all(18.0),
            //         child: Container(
            //           decoration: const ShapeDecoration(
            //             shape: StadiumBorder(),
            //             gradient: LinearGradient(
            //                 begin: Alignment.topCenter,
            //                 end: Alignment.bottomCenter,
            //                 colors: [
            //                   Color(0xffEBC248),
            //                   Color(0xffEBA223),
            //                 ]),
            //           ),
            //           child: ElevatedButton(
            //             onPressed: () {
            //               print("reasonVisitType--$reasonemergencyType");
            //               Navigator.pop(context);
            //               setState(() {
            //                  orientationmController.text=orient;
            //                   context.read<UserData>().sexualOrientation = orientationmController.text;
            //               });
            //             },
            //             child: Text(
            //               "Set",
            //               style: TextStyle(color: Colors.black),
            //             ),
            //             style: ElevatedButton.styleFrom(
            //                 tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            //                 primary: Colors.transparent,
            //                 shadowColor: Colors.transparent,
            //                 elevation: 0,
            //                 textStyle: TextStyle(
            //                     fontSize: 16.0, fontWeight: FontWeight.bold)),
            //           ),
            //         )),
            //     Padding(
            //         padding: EdgeInsets.all(18.0),
            //         child: Container(
            //           decoration: ShapeDecoration(
            //             shape: StadiumBorder(),
            //             gradient: LinearGradient(
            //                 begin: Alignment.topCenter,
            //                 end: Alignment.bottomCenter,
            //                 colors: [
            //                   Color(0xffEBC248),
            //                   Color(0xffEBA223),
            //                 ]),
            //           ),
            //           child: ElevatedButton(
            //             onPressed: () {
            //               Navigator.pop(context);
            //             },
            //             child: Text(
            //               "Close",
            //               style: TextStyle(color: Colors.black),
            //             ),
            //             style: ElevatedButton.styleFrom(
            //                 tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            //                 primary: Colors.transparent,
            //                 shadowColor: Colors.transparent,
            //                 elevation: 0,
            //                 textStyle: TextStyle(
            //                     fontSize: 16.0, fontWeight: FontWeight.bold)),
            //           ),
            //         ))
            //   ],
            // )
          ],
        );
      },
    );
  }

  showReasonVisitDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Color(0xFFC0C0C0),
          scrollable: true,
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return Container(
                height: MediaQuery.of(context).size.height / 2,
                width: 300,
                child: ListView.builder(
                  itemCount: 47,
                  itemBuilder: (context, i) {
                    return Row(
                      children: <Widget>[
                        Container(
                          child: Radio(
                              value: listemergency[i],
                              groupValue: reasonemergencyType,
                              onChanged: (value) {
                                setState(() {
                                  reasonemergencyType =
                                      value.toString(); //selected value
                                });
                                // print(value);
                              }),
                        ),
                        Text(listemergency[i]),
                      ],
                    );
                  },
                ),
              );
            },
          ),
          actions: [
            Row(
              children: <Widget>[
                Padding(
                    padding: EdgeInsets.all(18.0),
                    child: Container(
                      decoration: const ShapeDecoration(
                        shape: StadiumBorder(),
                        gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xffEBC248),
                              Color(0xffEBA223),
                            ]),
                      ),
                      child: ElevatedButton(
                        onPressed: () {
                          print("reasonVisitType--$reasonemergencyType");
                          Navigator.pop(context);
                          //EasyLoading.show(status: 'Updating Map...');
                          setState(() {
                            specifyReasonController.text = reasonemergencyType;
                            context.read<UserData>().reasonVisitSpecify =
                                specifyReasonController.text;
                          });
                        },
                        child: Text(
                          "Set",
                          style: TextStyle(color: Colors.black),
                        ),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: TextStyle(
                                fontSize: 16.0, fontWeight: FontWeight.bold)),
                      ),
                    )),
                Padding(
                    padding: EdgeInsets.all(18.0),
                    child: Container(
                      decoration: ShapeDecoration(
                        shape: StadiumBorder(),
                        gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xffEBC248),
                              Color(0xffEBA223),
                            ]),
                      ),
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Close",
                          style: TextStyle(color: Colors.black),
                        ),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: TextStyle(
                                fontSize: 16.0, fontWeight: FontWeight.bold)),
                      ),
                    ))
              ],
            )
          ],
        );
      },
    );
  }

  showSexTypeDialograce(BuildContext context) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Select'),
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: raced == null
                      ? SizedBox.shrink()
                      : ListBody(
                          children: raced!.map((racemodle gender) {
                            return RadioListTile(
                              title: Text(gender.racen),
                              value: gender,
                              groupValue: selecetedrace,
                              onChanged: (racemodle? value) {
                                setState(() {
                                  selecetedrace = value;
                                  context.read<UserData>().race = value!.racen;
                                  raceController.text = selecetedrace!.racen;
                                });
                              },
                            );
                          }).toList(),
                        ),
                );
              },
            ),
            actions: <Widget>[
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop(selecetedrace);
                  raceController.text = selecetedrace!.racen;
                },
              ),
            ],
          );
        }).then((value) {
      // Update the state after the dialog is dismissed
      setState(() {});
    });
  }

  showSexTypeDialogETGH(BuildContext context) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Select'),
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: ethnicx == null
                      ? SizedBox.shrink()
                      : ListBody(
                          children: ethnicx!.map((ethnicxity gender) {
                            return RadioListTile(
                              title: Text(gender.ethni),
                              value: gender,
                              groupValue: selecetedethnicxity,
                              onChanged: (ethnicxity? value) {
                                setState(() {
                                  selecetedethnicxity = value;
                                  context.read<UserData>().ethnicity =
                                      value!.ethni;
                                  context.read<UserData>().ethnicityId =
                                      value.id;
                                });
                              },
                            );
                          }).toList(),
                        ),
                );
              },
            ),
            actions: <Widget>[
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop(selectedGender);
                  ethController.text = selecetedethnicxity!.ethni;
                },
              ),
            ],
          );
        }).then((value) {
      // Update the state after the dialog is dismissed
      setState(() {});
    });
  }

  showSexTypeDialog(BuildContext context) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Select a gender'),
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: genders == null
                      ? SizedBox.shrink()
                      : ListBody(
                          children: genders!.map((Gender gender) {
                            return RadioListTile(
                              title: Text(gender.gender),
                              value: gender,
                              groupValue: selectedGender,
                              onChanged: (Gender? value) {
                                setState(() {
                                  selectedGender = value;
                                  context.read<UserData>().sex = value!.gender;
                                });
                              },
                            );
                          }).toList(),
                        ),
                );
              },
            ),
            actions: <Widget>[
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop(selectedGender);
                  sexController.text = selectedGender!.gender;
                },
              ),
            ],
          );
        }).then((value) {
      // Update the state after the dialog is dismissed
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(119, 94, 158, 100),
        title: const Text(
          'Patient Registration Form',
          style: TextStyle(color: Colors.white),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              '',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                // TODO:  patient info
              }
            },
          ),
        ],
      ),
      drawer: Drawer(
        width: 200,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(51, 62, 101, 5),
                Color.fromRGBO(107, 80, 135, 5)
              ],
            ),
          ),
          child: ListView(
            children: <Widget>[
              ListTile(
                title: Text(
                  'Patient',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg1()));

                  // TODO: Navigate to patient info page
                },
              ),
              ListTile(
                autofocus: true,
                selected: true,
                focusColor: Colors.white,
                selectedColor: Colors.white,
                enabled: true,
                title: Text(
                  'Physician',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg2()));
                },
              ),
              ListTile(
                title: Text(
                  'COVID-19',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg8()));
                  // TODO: Navigate to COVID-19 info page
                },
              ),
              ListTile(
                title: Text(
                  'Guarantor',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg3()));
                  // TODO: Navigate to guarantor info page
                },
              ),
              ListTile(
                title: Text(
                  'Insurance',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg7()));
                  // TODO: Navigate to insurance info page
                },
              ),
              ListTile(
                title: Text(
                  'Emergency Contact',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg4()));
                  // TODO: Navigate to emergency info page
                },
              ),
              ListTile(
                title: Text(
                  'Marketing',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg5()));
                  // TODO: Navigate to marketing info page
                },
              ),
              ListTile(
                title: Text(
                  'ID Upload',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg6()));
                  // TODO: Navigate to ID upload page
                },
              ),
              const Divider(
                color: Colors.white,
              ),
              Positioned(
                top: 500,
                child: ListTile(
                  title: Text(
                    'Patient bundle',
                    style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => patientdetails()));
                    // TODO: Navigate to ID upload page
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(

          // color: Color(0xFFC0C0C0),
          child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.grey,
            ],
          ),
        ),
        child: Row(
          children: <Widget>[
            Padding(
                padding: const EdgeInsets.only(
                    left: 10.0, top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          Navigator.of(context).pop();
                          // Navigator.push(context, MaterialPageRoute(builder: (context) => PersonalInfoRegister(),));
                        },
                        child: const Text("BACK"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
            const Spacer(),
            const Expanded(
              child: Padding(
                padding: EdgeInsets.all(18.0),
                child: Text(
                  "",
                  style: TextStyle(
                      // color: Color(0xFFC0C0C0),
                      fontSize: 16.0),
                ),
              ),
            ),
            Padding(
                padding:
                    const EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          if (_formKey.currentState!.validate()) {
                            if (context.read<UserData>().authorization !=
                                null) {
                              if (context.read<UserData>().accurateConsent ==
                                      1 &&
                                  context.read<UserData>().accurateConsent !=
                                      null) {
                                if (context.read<UserData>().contactConsent ==
                                        1 &&
                                    context.read<UserData>().contactConsent !=
                                        null) {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (context) => pereg2()));
                                } else {
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(SnackBar(
                                    content: const Text(
                                        "Please Check Contact consent"),
                                    action: SnackBarAction(
                                      label: 'Undo',
                                      onPressed: () {
                                        // Some code to undo the change.
                                      },
                                    ),
                                  ));
                                }
                              } else {
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(
                                  content: const Text(
                                      "Please Check releasing your Accurate information consent"),
                                  action: SnackBarAction(
                                    label: 'Undo',
                                    onPressed: () {
                                      // Some code to undo the change.
                                    },
                                  ),
                                ));
                              }
                            } else {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(SnackBar(
                                content: const Text(
                                    "Please Check releasing your medical information consent"),
                                action: SnackBarAction(
                                  label: 'Undo',
                                  onPressed: () {
                                    // Some code to undo the change.
                                  },
                                ),
                              ));
                            }
                          }
                        },
                        child: Text("NEXT"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
          ],
        ),
      )),
      body: Padding(
        padding: const EdgeInsets.only(top: 20),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.grey[200],
          ),
          padding: EdgeInsets.all(20.0),
          child: Form(
            key: _formKey,
            child: ListView(
              children: <Widget>[
                Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: raceController,
                              onChanged: (value) {
                                raceController.text = selecetedrace!.racen;
                              },
                              //showSexTypeDialograce
                              onTap: () {
                                showSexTypeDialograce(context);
                                setState(() {
                                  context.read<UserData>().rs = true;
                                  collerrace = true;
                                });
                              },
                              decoration: InputDecoration(
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                  borderSide: BorderSide(
                                    color: context.read<UserData>().rs == null
                                        ? Color.fromARGB(123, 255, 0, 0)
                                        : context.read<UserData>().rs!
                                            ? Colors.grey
                                            : Color.fromARGB(123, 255, 0, 0),
                                    width: 2.0,
                                  ),
                                ),
                                labelText: "Race",
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                              ),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please enter ';
                                }
                                return null;
                              },
                            ),
                          ),
                          const SizedBox(width: 10.0),
                          Expanded(
                            child: TextFormField(
                              controller: ethController,
                              onChanged: (value) {
                                ethController.text = selecetedethnicxity!.ethni;
                              },
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please enter ';
                                }
                                return null;
                              },
                              //showSexTypeDialograce
                              onTap: () {
                                context.read<UserData>().eth = true;
                                showSexTypeDialogETGH(context);
                              },
                              decoration: InputDecoration(
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                  borderSide: BorderSide(
                                    color: context.read<UserData>().eth == null
                                        ? Color.fromARGB(123, 255, 0, 0)
                                        : context.read<UserData>().eth!
                                            ? Colors.grey
                                            : Color.fromARGB(123, 255, 0, 0),
                                    width: 2.0,
                                  ),
                                ),
                                labelText: "Ethnicity",
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20.0),
                    Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 3),
                            child: TextFormField(
                              controller: sexController,
                              onChanged: (value) {
                                context.read<UserData>().se = true;
                                setState(() {
                                  context.read<UserData>().se = true;
                                });
                                sexController.text = selectedGender!.gender;
                              },
                              validator: (value) {
                                context.read<UserData>().se = true;
                                if (value!.isEmpty) {
                                  return 'Please enterFrs ';
                                }
                                return null;
                              },
                              onTap: () {
                                context.read<UserData>().se = true;
                                showSexTypeDialog(context);
                              },
                              decoration: InputDecoration(
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                  borderSide: BorderSide(
                                    color: context.read<UserData>().se == null
                                        ? Color.fromARGB(123, 255, 0, 0)
                                        : context.read<UserData>().se!
                                            ? Colors.grey
                                            : Color.fromARGB(123, 255, 0, 0),
                                    width: 2.0,
                                  ),
                                ),
                                labelText: 'Sex',
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10.0),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 3),
                            child: TextFormField(
                              controller: orientationmController,
                              onChanged: (value) {
                                setState(() {
                                  _formKey.currentState!.validate();
                                  context.read<UserData>().sexualOrientation =
                                      orientationmController.text;
                                });
                                context.read<UserData>().sexualOrientation =
                                    orientationmController.text;
                              },
                              onTap: () {
                                c3 = true;
                                orientationDialog(context);
                              },
                              decoration: InputDecoration(
                                labelText: 'Sexual Orientation',
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10.0),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: DropdownButtonFormField<String>(
                        value: genderq,
                        decoration: InputDecoration(
                          labelText: 'Gender Identity',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                        items: <String>[
                          'choose Identity',
                          "Male",
                          "Female",
                          "Male-to-Female",
                          "Female-to-Male",
                          "Other",
                          "Unknown",
                          "Choose not to disclose",
                        ].map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                        onChanged: (String? value) {
                          setState(() {
                            c3 = true;
                            _formKey.currentState!.validate();
                          });
                          if (value == "Male-to-Female") {
                            context.read<UserData>().genderIdentity =
                                "Male-to-Female (MTF)Transgender Female/Trans Woman";
                          } else if (value == "Female-to-Male") {
                            context.read<UserData>().genderIdentity =
                                "Female-to-Male (FTM)Transgender Male/Trans Man";
                          } else {
                            context.read<UserData>().genderIdentity = value;
                          }
                        },
                      ),
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      onTap: () {
                        context.read<UserData>().cn = true;
                        setState(() {
                          context.read<UserData>().cn = true;
                        });
                      },
                      controller: t1,
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '(###) ###-####',
                            filter: {"#": RegExp(r'[0-9]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                          borderSide: BorderSide(
                            color: context.read<UserData>().cn == null
                                ? Color.fromARGB(123, 255, 0, 0)
                                : context.read<UserData>().cn!
                                    ? Colors.grey
                                    : Color.fromARGB(123, 255, 0, 0),
                            width: 2.0,
                          ),
                        ),
                        labelText: 'Contact Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      validator: (value) {
                        context.read<UserData>().cn = true;
                        c4 = true;
                        if (value!.length < 14) {
                          print("lenght " + value.length.toString());
                          return 'Please enter your contact number';
                        }
                        print("lenght " + value.length.toString());
                        return null;
                      },
                      onChanged: (String? value) {
                        context.read<UserData>().cn = true;
                        _formKey.currentState!.validate();
                        context.read<UserData>().empContactf = value;
                        context.read<UserData>().phNumber =
                            t1.text.replaceAll(new RegExp(r'[^0-9]'), '');
                        print(context.read<UserData>().phNumber.toString());
                      },
                    ),
                    // const SizedBox(height: 10.0),

                    // showReasonemergencytDialog
                    const SizedBox(height: 10.0),
                    TextFormField(
                      controller: reasonVsitController,
                      onTap: () {
                        showReasonemergencytDialog(context);
                        setState(() {
                          context.read<UserData>().rv = true;
                          context.read<UserData>().sr = true;
                          _formKey.currentState!.validate();
                        });
                      },
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter ';
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                          borderSide: BorderSide(
                            color: context.read<UserData>().rv == null
                                ? Color.fromARGB(123, 255, 0, 0)
                                : context.read<UserData>().rv!
                                    ? Colors.grey
                                    : Color.fromARGB(123, 255, 0, 0),
                            width: 2.0,
                          ),
                        ),
                        labelText: 'Reason for Visit',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        context.read<UserData>().reasonVisit =
                            reasonVsitController.text;
                        setState(() {
                          context.read<UserData>().rv = true;
                          context.read<UserData>().sr = true;
                          context.read<UserData>().reasonVisit =
                              reasonVsitController.text;
                          _formKey.currentState!.validate();
                        });
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      onTap: () {
                        setState(() {
                          context.read<UserData>().sr = true;
                        });
                        context.read<UserData>().reasonVisit =
                            reasonVsitController.text;
                        if (reasonVsitController.text == "Emergency")
                          showReasonVisitDialog(context);
                      },
                      controller: specifyReasonController,
                      validator: (value) {
                        context.read<UserData>().sr = true;
                        if (value!.isEmpty) {
                          return 'Please enter ';
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                          borderSide: BorderSide(
                            color: context.read<UserData>().sr == null
                                ? Color.fromARGB(123, 255, 0, 0)
                                : context.read<UserData>().sr!
                                    ? Colors.grey
                                    : Color.fromARGB(123, 255, 0, 0),
                            width: 2.0,
                          ),
                        ),
                        labelText: 'Specify Reason',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          context.read<UserData>().sr = true;
                          _formKey.currentState!.validate();
                        });
                        setState(() {
                          _formKey.currentState!.validate();
                          context.read<UserData>().reasonVisitSpecify =
                              specifyReasonController.text;
                        });
                        context.read<UserData>().reasonVisitSpecify =
                            specifyReasonController.text;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      controller: t2,
                      validator: (value) => EmailValidator.validate(value!)
                          ? null
                          : "Please enter a valid email",
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                          borderSide: BorderSide(
                            color: context.read<UserData>().em == null
                                ? Color.fromARGB(123, 255, 0, 0)
                                : context.read<UserData>().em!
                                    ? Colors.grey
                                    : Color.fromARGB(123, 255, 0, 0),
                            width: 2.0,
                          ),
                        ),
                        labelText: 'Email',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          context.read<UserData>().em = true;
                          _formKey.currentState!.validate();
                        });
                        context.read<UserData>().email = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      onChanged: (String? value) {
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                        // context.read<UserData>().email = value;
                      },
                      controller: cnfmail,
                      decoration: InputDecoration(
                        labelText: 'Confirm Email',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      validator: (value) => EmailValidator.validate(value!)
                          ? context.read<UserData>().email != value
                              ? "Please enter a valid email"
                              : null
                          : "Please enter a valid email",
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      onTap: () {
                        //gpss
                        setState(() {
                          c9 = true;
                        });
                        showDialog(
                          barrierDismissible: false,
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              backgroundColor: Color(0xFFC0C0C0),
                              scrollable: true,
                              content: StatefulBuilder(
                                builder: (BuildContext context,
                                    StateSetter setState) {
                                  return SizedBox(
                                    height: 350,
                                    width: 500,
                                    child: Column(
                                      children: <Widget>[
                                        TextFormField(
                                          onChanged: (value) {
                                            setState(() {
                                              _onPredictTextChanged(value);
                                            });
                                          },
                                          decoration: const InputDecoration(
                                              label: Text("Address")),
                                        ),
                                        _buildErrorWidget(_predictErr),
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              _formKey.currentState!.validate();
                                            });
                                          },
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: (_predictions ?? [])
                                                .map(_buildPredictionItem)
                                                .toList(growable: false),
                                          ),
                                        ),
                                        ElevatedButton(
                                            onPressed: () {
                                              setState(() {
                                                _formKey.currentState!
                                                    .validate();
                                              });
                                              Navigator.pop(context);
                                              setState(() {
                                                _formKey.currentState!
                                                    .validate();
                                              });
                                            },
                                            child: Text("Close"))
                                      ],
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        );
                        //gps
                      },
                      validator: (value) {
                        context.read<UserData>().ad = true;
                        if (value!.isEmpty) {
                          return 'Please enter ';
                        }
                        return null;
                      },
                      controller: streetAddController,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                          borderSide: BorderSide(
                            color: context.read<UserData>().ad == null
                                ? Color.fromARGB(123, 255, 0, 0)
                                : context.read<UserData>().ad!
                                    ? Colors.grey
                                    : Color.fromARGB(123, 255, 0, 0),
                            width: 2.0,
                          ),
                        ),
                        labelText: 'Address 1',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        context.read<UserData>().ad = true;
                        context.read<UserData>().address1 = value;
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      controller: streetAddController2,
                      onTap: () {
                        context.read<UserData>().ad = true;
                        //gps
                        showDialog(
                          barrierDismissible: false,
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              backgroundColor: Color(0xFFC0C0C0),
                              scrollable: true,
                              content: StatefulBuilder(
                                builder: (BuildContext context,
                                    StateSetter setState) {
                                  return SizedBox(
                                    height: 350,
                                    width: 500,
                                    child: Column(
                                      children: <Widget>[
                                        TextFormField(
                                          onChanged: (value) {
                                            setState(() {
                                              _onPredictTextChanged(value);
                                            });
                                          },
                                          decoration: const InputDecoration(
                                              label: Text("Address")),
                                        ),
                                        _buildErrorWidget(_predictErr),
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {});
                                          },
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: (_predictions ?? [])
                                                .map(_buildPredictionItem2)
                                                .toList(growable: false),
                                          ),
                                        ),
                                        ElevatedButton(
                                            onPressed: () {
                                              context.read<UserData>().ad =
                                                  true;
                                              Navigator.pop(context);
                                            },
                                            child: Text("Close"))
                                      ],
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        );
                        //gps
                      },
                      decoration: InputDecoration(
                        labelText: 'Address 2',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                        context.read<UserData>().address2 = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      validator: (value) {
                        context.read<UserData>().zi = true;
                        if (value!.isEmpty) {
                          return 'Please enter ';
                        }
                        return null;
                      },
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '##########',
                            filter: {"#": RegExp(r'[A-Za-z0-9]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      controller: zipCodeController,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                          borderSide: BorderSide(
                            color: context.read<UserData>().zi == null
                                ? Color.fromARGB(123, 255, 0, 0)
                                : context.read<UserData>().zi!
                                    ? Colors.grey
                                    : Color.fromARGB(123, 255, 0, 0),
                            width: 2.0,
                          ),
                        ),
                        labelText: 'Zip Code',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        context.read<UserData>().zi = true;
                        _formKey.currentState!.validate();

                        context.read<UserData>().zipCode = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      onTap: () {
                        setState(() {
                          context.read<UserData>().ci = true;
                        });
                      },
                      validator: (value) {
                        context.read<UserData>().ci = true;
                        if (value!.isEmpty) {
                          return 'Please enter ';
                        }
                        return null;
                      },
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '########################',
                            filter: {"#": RegExp(r'[a-zA-Z]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      controller: cityController,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                          borderSide: BorderSide(
                            color: context.read<UserData>().ci == null
                                ? Color.fromARGB(123, 255, 0, 0)
                                : context.read<UserData>().ci!
                                    ? Colors.grey
                                    : Color.fromARGB(123, 255, 0, 0),
                            width: 2.0,
                          ),
                        ),
                        labelText: 'City',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        context.read<UserData>().ci = true;
                        _formKey.currentState!.validate();

                        context.read<UserData>().city = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      onTap: () {
                        setState(() {
                          context.read<UserData>().st = true;
                        });
                      },
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter ';
                        }
                        return null;
                      },
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '########################',
                            filter: {"#": RegExp(r'[a-zA-Z]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      controller: stateController,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                          borderSide: BorderSide(
                            color: context.read<UserData>().st == null
                                ? Color.fromARGB(123, 255, 0, 0)
                                : context.read<UserData>().st!
                                    ? Colors.grey
                                    : Color.fromARGB(123, 255, 0, 0),
                            width: 2.0,
                          ),
                        ),
                        labelText: 'State',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().state = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      // validator: (value) {
                      //   if (value!.isEmpty) {
                      //     return 'Please enter ';
                      //   }
                      //   return null;
                      // },
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '########################',
                            filter: {"#": RegExp(r'[a-zA-Z]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      controller: countyController,
                      decoration: InputDecoration(
                        labelText: 'County',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().county = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      // validator: (value) {
                      //   if (value!.isEmpty) {
                      //     return 'Please enter ';
                      //   }
                      //   return null;
                      // },
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '########################',
                            filter: {"#": RegExp(r'[a-zA-Z]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      controller: countryController,
                      decoration: InputDecoration(
                        labelText: 'Country',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().country = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    DropdownButtonFormField<String>(
                      value: lanc,
                      decoration: InputDecoration(
                        labelText: 'Preferred Language',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      items: <String>[
                        'choose Language',
                        'English',
                            'Chinese',
                        'French',
                        'Italian',
                        'Japanese',
                        'Portuguese',
                        'Russian',
                        'Castilian Spanish',
                        'Other',
                        'Unknown'
                      ].map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (String? value) {
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                        context.read<UserData>().preferredLanguage = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      controller: t3,
                      //   validator: (value) {
                      //   if (value!.isEmpty) {
                      //     return 'Please enter ';
                      //   }
                      //   return null;
                      // },
                      decoration: InputDecoration(
                        labelText: 'Patient Employer',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                        context.read<UserData>().employer = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      controller: t4,
                      decoration: InputDecoration(
                        labelText: 'Occupation',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _formKey.currentState!.validate();
                        });
                        context.read<UserData>().occupation = value;
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      controller: t5,
                      onChanged: (String? value) {
                        _formKey.currentState!.validate();

                        context.read<UserData>().empContact = value;
                      },
                         validator: (value) {
                       
                       
                        if (value!.length < 8 && value!.length !=0) {
                          print("lenght " + value.length.toString());
                          return 'Please enter your contact number';
                        }
                        print("lenght " + value.length.toString());
                        return null;
                      },
         
                      inputFormatters: [
                        MaskTextInputFormatter(
                            mask: '##########',
                            filter: {"#": RegExp(r'[0-9]')},
                            type: MaskAutoCompletionType.lazy)
                      ],
                      decoration: InputDecoration(
                        labelText: 'Employer Contact Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10.0),
                    const Text(
                      'Authorization',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18.0,
                      ),
                    ),
                    const SizedBox(height: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width / 2,
                          child: const Text(
                            overflow: TextOverflow.visible,
                            'Do you authorize releasing your medical \ninformation to other facilities?',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10.0),
                        ToggleSwitch(
                          minWidth: 42.0,
                          minHeight: 20.0,
                          customTextStyles: [TextStyle(fontSize: 10)],
                          activeFgColor: Colors.black,
                          inactiveBgColor: Colors.white,
                          dividerColor: Colors.white,
                          inactiveFgColor: Colors.black,
                          activeBgColors: const [
                            [Colors.grey],
                            [Colors.grey]
                          ],
                          initialLabelIndex:
                              context.read<UserData>().authorization,
                          totalSwitches: 2,
                          labels: const [
                            'No',
                            'Yes',
                          ],
                          onToggle: (index) {
                            context.read<UserData>().authorization = index;
                            print('switched to: $index');
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width / 2,
                          child: const Text(
                            'I hereby agree and confirm that all my \ninformation stated above is accurate.',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10.0),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0, 0, 10, 0),
                          child: Checkbox(
                            value: toggle2,
                            onChanged: (newValue) {
                              setState(() {
                                toggle2 = newValue!;
                                context.read<UserData>().accurateConsent =
                                    newValue ? 1 : 0;
                              });
                            },
                          ),
                        )
                        // ToggleSwitch(
                        //   minWidth: 42.0,
                        //   minHeight: 20.0,
                        //   customTextStyles: [TextStyle(fontSize: 10)],
                        //   activeFgColor: Colors.black,
                        //   inactiveBgColor: Colors.white,
                        //   dividerColor: Colors.white,
                        //   inactiveFgColor: Colors.black,
                        //   activeBgColors: const [
                        //     [Colors.grey],
                        //     [Colors.grey]
                        //   ],
                        //   initialLabelIndex:
                        //       context.read<UserData>().accurateConsent,
                        //   totalSwitches: 2,
                        //   labels: const [
                        //     'No',
                        //     'Yes',
                        //   ],
                        //   onToggle: (index) {
                        //     context.read<UserData>().accurateConsent = index;
                        //     print('switched to: $index');
                        //   },
                        // ),
                      ],
                    ),
                    const SizedBox(height: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Consent to contact',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(width: 10.0),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0, 0, 10, 0),
                          child: Checkbox(
                            value: toggle1,
                            onChanged: (newValue) {
                              setState(() {
                                toggle1 = newValue!;
                                context.read<UserData>().contactConsent =
                                    newValue ? 1 : 0;
                              });
                            },
                          ),
                        )
                        // ToggleSwitch(
                        //   minWidth: 42.0,
                        //   minHeight: 20.0,
                        //   activeFgColor: Colors.black,
                        //   customTextStyles: [TextStyle(fontSize: 10)],
                        //   inactiveBgColor: Colors.white,
                        //   dividerColor: Colors.white,
                        //   inactiveFgColor: Colors.black,
                        //   activeBgColors: const [
                        //     [Colors.grey],
                        //     [Colors.grey]
                        //   ],
                        //   initialLabelIndex:
                        //       context.read<UserData>().contactConsent,
                        //   totalSwitches: 2,
                        //   labels: const [
                        //     'No',
                        //     'Yes',
                        //   ],
                        //   onToggle: (index) {
                        //     context.read<UserData>().contactConsent = index;
                        //     print('switched to: $index');
                        //   },
                        // ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
