   import 'package:flutter/material.dart';
import 'package:reg_app/terenfrirstpages/teren8.dart';

class Splash extends StatefulWidget {
 static const String route = '/spl';

  const Splash({super.key});
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    Future.delayed(Duration(seconds: 3), () {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => const newpageu8()));
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Image.asset(
          'assets/Splash screen.png',
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}