class listdart {
  List<Visits>? visits;
  int? patientRegId;
  int? mrn;
  String? patientName;
  String? dob;

  listdart(
      {this.visits, this.patientRegId, this.mrn, this.patientName, this.dob});

  listdart.fromJson(Map<String, dynamic> json) {
    if (json['visits'] != null) {
      visits = <Visits>[];
      json['visits'].forEach((v) {
        visits!.add(new Visits.fromJson(v));
      });
    }
    patientRegId = json['patientRegId'];
    mrn = json['mrn'];
    patientName = json['patientName'];
    dob = json['dob'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.visits != null) {
      data['visits'] = this.visits!.map((v) => v.toJson()).toList();
    }
    data['patientRegId'] = this.patientRegId;
    data['mrn'] = this.mrn;
    data['patientName'] = this.patientName;
    data['dob'] = this.dob;
    return data;
  }
}


class Visits {
  int? visitId;
  String? actNo;
  String? dateOfService;

  Visits({this.visitId, this.actNo, this.dateOfService});

  Visits.fromJson(Map<String, dynamic> json) {
    visitId = json['visitId'];
    actNo = json['actNo'];
    dateOfService = json['dateOfService'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['visitId'] = this.visitId;
    data['actNo'] = this.actNo;
    data['dateOfService'] = this.dateOfService;
    return data;
  }
}
class doctoer {
  int? id;
  String? doctorsFirstName;
  String? doctorsLastName;

  String? npi;

  bool? isDeleted;

  doctoer(
      {this.id,
      this.doctorsFirstName,
 
      this.npi,
     
      this.isDeleted});

  doctoer.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    doctorsFirstName = json['doctorsFirstName'];
    doctorsLastName = json['doctorsLastName'];

    npi = json['npi'];
  
    isDeleted = json['isDeleted'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['doctorsFirstName'] = this.doctorsFirstName;
    data['doctorsLastName'] = this.doctorsLastName;

    data['npi'] = this.npi;
    
    data['isDeleted'] = this.isDeleted;
    return data;
  }
}
class datats {
  String? s1;
  String? s2;
  String? nameLast;
  String? title;
  String? martialStatus;
  String? mailingAddress;
  String? cityStateZip;
  String? phone;
  String? socialSecurity;
  String? dOB;
  String? age;
  String? sexMF;
  String? email;
  String? ethnicity;
  String? employer;
  String? occupation;
  String? emergencyContact;
  String? relationship;
  String? phone2;
  String? primaryCarePhysician;
  String? reasonsforbeingseen;
  String? guarantorResponsibleforbillifpatientisamir;
  String? guarantorDOB;
  String? sexMF2;
  String? guarantorSSN;
  String? addressifdifferent;
  String? guarantorPhone;
  String? employer2;
  String? employerPhone;
  String? employerAddress;
  String? workersCompPolicyYes;
  String? motorVehicleAccidentYes;
  String? dateofAccident;
  String? primaryInsuranceAetnaBetterHealthofTexasTXOther;
  String? subscribersName;
  String? subscribersDOB;
  String? subscribersSSN;
  String? relationshiptopatient;
  String? group;
  String? policy;
  String? secondaryInsuranceOther;
  String? subscribersName2;
  String? subscribersDOB2;
  String? subscribersSSN2;
  String? relationshiptopatient2;
  String? group2;
  String? policy2;
  String? signature;
  String? date;
  String? firstname;
  String? middle;
 
  String? time;
  String? signatureofPatient;
  String? witness;
  String? myrelationshiptothepatientis;
  String? signatureofRelative;
  String? witness2;
  String? undefined;
  String? patientsPrintedName;
  String? undefined2;
  String? signatureofPatient2;
  String? date2;
  String? undefined3;
  String? printedName;
  String? legalAuthoritytoactonbehalfofpatient;
  String? witness3;
  String? dOB2;
  String? relationtomember;
  String? memberIDnumber;
  String? i;
  String? doherebyauthorize;
  String? undefined4;
  String? undefined5;
  String? name;
  String? yES;
  String? healthInsuranceProvider;
  String? subscriber;
  String? subscribersDOB1;

  String? memberID;
  String? effectiveDate;
  String? printedNameofthepersoncompletingthisform;
  String? signature2;
  String? date3;
  String? witness4;
  String? date4;
  String? no;
  String? signatureandDate;
  String? witness5;
  String? fullName;
  String? relation;
  String? fullName2;
  String? relation2;
  String? undefined6;
  String? patientParentGuardianSignature;
  String? date5;
  String? gTECORANGE;
  String? patientSignature;
  String? date6;
  String? i2;
  String? i3;
  String? i4;
  String? i5;
  String?
      nameonanyandallcheckslistingmeasapayeewhicharepresentedtothisofficeforpaymentofan;
  String?
      authorizeGTECOrangetoapplyanycreditbalancesincurredbymetoanyotheroutstandingchargesstill;
  String?
      gTECOrangefortheirservicesThisagreementdoestconstituteanyconsiderationforthisofficetoawait;
  String?
      fortheprotectionoftherightsandinterestsofGTECOrangeandmyHowevershouldanyprovisionofthe;
  String? patientPrintedName;
  String? patientSignature2;
  String? date7;
  String? witness6;
  String? stateofTexasCountyof;
  String? dayof;
  String? year;
  String? undefined7;
  String? taryPublicSignature;
  String? dateofRequest;
  String? undefined8;
  String? nameofGuardianPOA;
  String? undefined9;
  String? lOSSOFJOBBUSINESS;
  String? dECREASEINPAYREVENUEBENEFITS;
  String? dECREASEDJOBHOURS;
  String? cARINGFORSUPPORTINGOTHERSAFFECTED;
  String? fURLOUGHLAIDOFF;
  String? iNCREASEDDEBTEXPENSES;
  String? lOSSOFHOMEDWELLING;
  String? qUARANTINEDCARINGFORQUARANTINEDPERSON;
  String? oTHERbrieflyexplain1;
  String? oTHERbrieflyexplain2;
  String? patientSignature3;
  String? date8;
  String? accountnumbersapprovedforwaiverpleaselistall;
  String? undefined10;
  String? s12;
  String? s22;
  String? waiverapproved;
  String? deferredpaymentapproved;
  String? date9;
  String? undefined11;
  String? on;
  String? undefined12;
  String? patientNameJenkinsBobby;
  String? dOB10201964;
  String?
      iDOTgiveconsenttomyrecordsbeingreleasedtoanyallphysiciansthatrequestthem;
  String? patientRepresentativeSignature;
  String? date10;
  String? nameofPatientRepresentativeprint;
  String? relationshiptoPatient;
  String? yES2;
  String? yES3;
  String? facebook;
  String? tV;
  String? mapSearch;
  String? onlineReviewsGoogleYelpFB;
  String? radio;
  String? googleSearch;
  String? familyFriend;
  String? undefined13;
  String? youTube;
  String? brochure;
  String? gTECOrangecom;
  String? directMail;
  String? linkedIn;
  String? urgentCare;
  String? undefined14;
  String? twitter;
  String? school;
  String? undefined15;
  String? onlineAdvertisements;
  String? newspaperMagazine;
  String? undefined16;
  String? emailBlast;
  String? hotel;
  String? undefined17;
  String? citizensDeTar;
  String? liveWorkDrovenearby;
  String? employerSentMe;
  String? placeofEmployment;
  String? wereyoureferredbyaPhysicianforthisvisitcircle;
  String? patientCell;
  String? receptionInitialsInviteSent;
  String? physician;

  datats(
      {this.s1,
      this.s2,
      this.nameLast,
      this.title,
      this.martialStatus,
      this.mailingAddress,
      this.cityStateZip,
      this.phone,
      this.socialSecurity,
      this.dOB,
      this.age,
      this.sexMF,
      this.email,
      this.ethnicity,
      this.employer,
      this.occupation,
      this.emergencyContact,
      this.relationship,
      this.phone2,
      this.primaryCarePhysician,
      this.reasonsforbeingseen,
      this.guarantorResponsibleforbillifpatientisamir,
      this.guarantorDOB,
      this.sexMF2,
      this.guarantorSSN,
      this.addressifdifferent,
      this.guarantorPhone,
      this.employer2,
      this.employerPhone,
      this.employerAddress,
      this.workersCompPolicyYes,
      this.motorVehicleAccidentYes,
      this.dateofAccident,
      this.primaryInsuranceAetnaBetterHealthofTexasTXOther,
      this.subscribersName,
      this.subscribersDOB,
      this.subscribersSSN,
      this.relationshiptopatient,
      this.group,
      this.policy,
      this.secondaryInsuranceOther,
      this.subscribersName2,
      this.subscribersDOB2,
      this.subscribersSSN2,
      this.relationshiptopatient2,
      this.group2,
      this.policy2,
      this.signature,
      this.date,
      this.firstname,
      this.middle,
   
      this.time,
      this.signatureofPatient,
      this.witness,
      this.myrelationshiptothepatientis,
      this.signatureofRelative,
      this.witness2,
      this.undefined,
      this.patientsPrintedName,
      this.undefined2,
      this.signatureofPatient2,
      this.date2,
      this.undefined3,
      this.printedName,
      this.legalAuthoritytoactonbehalfofpatient,
      this.witness3,
      this.dOB2,
      this.relationtomember,
      this.memberIDnumber,
      this.i,
      this.doherebyauthorize,
      this.undefined4,
      this.undefined5,
      this.name,
      this.yES,
      this.healthInsuranceProvider,
      this.subscriber,
      this.subscribersDOB1,
 
      this.memberID,
      this.effectiveDate,
      this.printedNameofthepersoncompletingthisform,
      this.signature2,
      this.date3,
      this.witness4,
      this.date4,
      this.no,
      this.signatureandDate,
      this.witness5,
      this.fullName,
      this.relation,
      this.fullName2,
      this.relation2,
      this.undefined6,
      this.patientParentGuardianSignature,
      this.date5,
      this.gTECORANGE,
      this.patientSignature,
      this.date6,
      this.i2,
      this.i3,
      this.i4,
      this.i5,
      this.nameonanyandallcheckslistingmeasapayeewhicharepresentedtothisofficeforpaymentofan,
      this.authorizeGTECOrangetoapplyanycreditbalancesincurredbymetoanyotheroutstandingchargesstill,
      this.gTECOrangefortheirservicesThisagreementdoestconstituteanyconsiderationforthisofficetoawait,
      this.fortheprotectionoftherightsandinterestsofGTECOrangeandmyHowevershouldanyprovisionofthe,
      this.patientPrintedName,
      this.patientSignature2,
      this.date7,
      this.witness6,
      this.stateofTexasCountyof,
      this.dayof,
      this.year,
      this.undefined7,
      this.taryPublicSignature,
      this.dateofRequest,
      this.undefined8,
      this.nameofGuardianPOA,
      this.undefined9,
      this.lOSSOFJOBBUSINESS,
      this.dECREASEINPAYREVENUEBENEFITS,
      this.dECREASEDJOBHOURS,
      this.cARINGFORSUPPORTINGOTHERSAFFECTED,
      this.fURLOUGHLAIDOFF,
      this.iNCREASEDDEBTEXPENSES,
      this.lOSSOFHOMEDWELLING,
      this.qUARANTINEDCARINGFORQUARANTINEDPERSON,
      this.oTHERbrieflyexplain1,
      this.oTHERbrieflyexplain2,
      this.patientSignature3,
      this.date8,
      this.accountnumbersapprovedforwaiverpleaselistall,
      this.undefined10,
      this.s12,
      this.s22,
      this.waiverapproved,
      this.deferredpaymentapproved,
      this.date9,
      this.undefined11,
      this.on,
      this.undefined12,
      this.patientNameJenkinsBobby,
      this.dOB10201964,
      this.iDOTgiveconsenttomyrecordsbeingreleasedtoanyallphysiciansthatrequestthem,
      this.patientRepresentativeSignature,
      this.date10,
      this.nameofPatientRepresentativeprint,
      this.relationshiptoPatient,
      this.yES2,
      this.yES3,
      this.facebook,
      this.tV,
      this.mapSearch,
      this.onlineReviewsGoogleYelpFB,
      this.radio,
      this.googleSearch,
      this.familyFriend,
      this.undefined13,
      this.youTube,
      this.brochure,
      this.gTECOrangecom,
      this.directMail,
      this.linkedIn,
      this.urgentCare,
      this.undefined14,
      this.twitter,
      this.school,
      this.undefined15,
      this.onlineAdvertisements,
      this.newspaperMagazine,
      this.undefined16,
      this.emailBlast,
      this.hotel,
      this.undefined17,
      this.citizensDeTar,
      this.liveWorkDrovenearby,
      this.employerSentMe,
      this.placeofEmployment,
      this.wereyoureferredbyaPhysicianforthisvisitcircle,
      this.patientCell,
      this.receptionInitialsInviteSent,
      this.physician});

  datats.fromJson(Map<String, dynamic> json) {
    s1 = json['1'];
    s2 = json['2'];
    nameLast = json['Name_Last'];
    title = json['Title'];
    martialStatus = json['MartialStatus'];
    mailingAddress = json['MailingAddress'];
    cityStateZip = json['CityStateZip'];
    phone = json['Phone'];
    socialSecurity = json['SocialSecurity'];
    dOB = json['DOB'];
    age = json['Age'];
    sexMF = json['SexMF'];
    email = json['Email'];
    ethnicity = json['Ethnicity'];
    employer = json['Employer'];
    occupation = json['Occupation'];
    emergencyContact = json['EmergencyContact'];
    relationship = json['Relationship'];
    phone2 = json['Phone_2'];
    primaryCarePhysician = json['PrimaryCarePhysician'];
    reasonsforbeingseen = json['Reasonsforbeingseen'];
    guarantorResponsibleforbillifpatientisamir =
        json['GuarantorResponsibleforbillifpatientisamir'];
    guarantorDOB = json['GuarantorDOB'];
    sexMF2 = json['SexMF_2'];
    guarantorSSN = json['GuarantorSSN'];
    addressifdifferent = json['Addressifdifferent'];
    guarantorPhone = json['GuarantorPhone'];
    employer2 = json['Employer_2'];
    employerPhone = json['EmployerPhone'];
    employerAddress = json['EmployerAddress'];
    workersCompPolicyYes = json['WorkersCompPolicyYes'];
    motorVehicleAccidentYes = json['MotorVehicleAccidentYes'];
    dateofAccident = json['DateofAccident'];
    primaryInsuranceAetnaBetterHealthofTexasTXOther =
        json['PrimaryInsuranceAetnaBetterHealthofTexasTXOther'];
    subscribersName = json['SubscribersName'];
    subscribersDOB = json['SubscribersDOB'];
    subscribersSSN = json['SubscribersSSN'];
    relationshiptopatient = json['Relationshiptopatient'];
    group = json['Group'];
    policy = json['Policy'];
    secondaryInsuranceOther = json['SecondaryInsuranceOther'];
    subscribersName2 = json['SubscribersName_2'];
    subscribersDOB2 = json['SubscribersDOB_2'];
    subscribersSSN2 = json['SubscribersSSN_2'];
    relationshiptopatient2 = json['Relationshiptopatient_2'];
    group2 = json['Group_2'];
    policy2 = json['Policy_2'];
    signature = json['Signature'];
    date = json['Date'];
    firstname = json['firstname'];
    middle = json['middle'];
    date = json['date'];
    time = json['time'];
    signatureofPatient = json['SignatureofPatient'];
    witness = json['Witness'];
    myrelationshiptothepatientis = json['Myrelationshiptothepatientis'];
    signatureofRelative = json['SignatureofRelative'];
    witness2 = json['Witness_2'];
    undefined = json['undefined'];
    patientsPrintedName = json['PatientsPrintedName'];
    undefined2 = json['undefined_2'];
    signatureofPatient2 = json['SignatureofPatient_2'];
    date2 = json['Date_2'];
    undefined3 = json['undefined_3'];
    printedName = json['PrintedName'];
    legalAuthoritytoactonbehalfofpatient =
        json['LegalAuthoritytoactonbehalfofpatient'];
    witness3 = json['Witness_3'];
    dOB2 = json['DOB_2'];
    relationtomember = json['Relationtomember'];
    memberIDnumber = json['MemberIDnumber'];
    i = json['I'];
    doherebyauthorize = json['doherebyauthorize'];
    undefined4 = json['undefined_4'];
    undefined5 = json['undefined_5'];
    name = json['name'];
    yES = json['YES'];
    healthInsuranceProvider = json['HealthInsuranceProvider'];
    subscriber = json['Subscriber'];
    subscribersDOB1 = json['SubscribersDOB1'];
    subscribersDOB2 = json['SubscribersDOB2'];
    memberID = json['MemberID'];
    effectiveDate = json['EffectiveDate'];
    printedNameofthepersoncompletingthisform =
        json['PrintedNameofthepersoncompletingthisform'];
    signature2 = json['Signature_2'];
    date3 = json['Date_3'];
    witness4 = json['Witness_4'];
    date4 = json['Date_4'];
    no = json['no'];
    signatureandDate = json['SignatureandDate'];
    witness5 = json['Witness_5'];
    fullName = json['FullName'];
    relation = json['Relation'];
    fullName2 = json['FullName_2'];
    relation2 = json['Relation_2'];
    undefined6 = json['undefined_6'];
    patientParentGuardianSignature = json['PatientParentGuardianSignature'];
    date5 = json['Date_5'];
    gTECORANGE = json['GTECORANGE'];
    patientSignature = json['PatientSignature'];
    date6 = json['Date_6'];
    i2 = json['I_2'];
    i3 = json['I_3'];
    i4 = json['I_4'];
    i5 = json['I_5'];
    nameonanyandallcheckslistingmeasapayeewhicharepresentedtothisofficeforpaymentofan =
        json[
            'nameonanyandallcheckslistingmeasapayeewhicharepresentedtothisofficeforpaymentofan'];
    authorizeGTECOrangetoapplyanycreditbalancesincurredbymetoanyotheroutstandingchargesstill =
        json[
            'authorizeGTECOrangetoapplyanycreditbalancesincurredbymetoanyotheroutstandingchargesstill'];
    gTECOrangefortheirservicesThisagreementdoestconstituteanyconsiderationforthisofficetoawait =
        json[
            'GTECOrangefortheirservicesThisagreementdoestconstituteanyconsiderationforthisofficetoawait'];
    fortheprotectionoftherightsandinterestsofGTECOrangeandmyHowevershouldanyprovisionofthe =
        json[
            'fortheprotectionoftherightsandinterestsofGTECOrangeandmyHowevershouldanyprovisionofthe'];
    patientPrintedName = json['PatientPrintedName'];
    patientSignature2 = json['PatientSignature_2'];
    date7 = json['Date_7'];
    witness6 = json['Witness_6'];
    stateofTexasCountyof = json['StateofTexasCountyof'];
    dayof = json['dayof'];
    year = json['year'];
    undefined7 = json['undefined_7'];
    taryPublicSignature = json['taryPublicSignature'];
    dateofRequest = json['DateofRequest'];
    undefined8 = json['undefined_8'];
    nameofGuardianPOA = json['NameofGuardianPOA'];
    undefined9 = json['undefined_9'];
    lOSSOFJOBBUSINESS = json['LOSSOFJOBBUSINESS'];
    dECREASEINPAYREVENUEBENEFITS = json['DECREASEINPAYREVENUEBENEFITS'];
    dECREASEDJOBHOURS = json['DECREASEDJOBHOURS'];
    cARINGFORSUPPORTINGOTHERSAFFECTED =
        json['CARINGFORSUPPORTINGOTHERSAFFECTED'];
    fURLOUGHLAIDOFF = json['FURLOUGHLAIDOFF'];
    iNCREASEDDEBTEXPENSES = json['INCREASEDDEBTEXPENSES'];
    lOSSOFHOMEDWELLING = json['LOSSOFHOMEDWELLING'];
    qUARANTINEDCARINGFORQUARANTINEDPERSON =
        json['QUARANTINEDCARINGFORQUARANTINEDPERSON'];
    oTHERbrieflyexplain1 = json['OTHERbrieflyexplain1'];
    oTHERbrieflyexplain2 = json['OTHERbrieflyexplain2'];
    patientSignature3 = json['PatientSignature_3'];
    date8 = json['Date_8'];
    accountnumbersapprovedforwaiverpleaselistall =
        json['Accountnumbersapprovedforwaiverpleaselistall'];
    undefined10 = json['undefined_10'];
    s12 = json['1_2'];
    s22 = json['2_2'];
    waiverapproved = json['Waiverapproved'];
    deferredpaymentapproved = json['Deferredpaymentapproved'];
    date9 = json['Date_9'];
    undefined11 = json['undefined_11'];
    on = json['on'];
    undefined12 = json['undefined_12'];
    patientNameJenkinsBobby = json['PatientNameJenkinsBobby'];
    dOB10201964 = json['DOB10201964'];
    iDOTgiveconsenttomyrecordsbeingreleasedtoanyallphysiciansthatrequestthem = json[
        'IDOTgiveconsenttomyrecordsbeingreleasedtoanyallphysiciansthatrequestthem'];
    patientRepresentativeSignature = json['PatientRepresentativeSignature'];
    date10 = json['Date_10'];
    nameofPatientRepresentativeprint = json['NameofPatientRepresentativeprint'];
    relationshiptoPatient = json['RelationshiptoPatient'];
    yES2 = json['YES_2'];
    yES3 = json['YES_3'];
    facebook = json['Facebook'];
    tV = json['TV'];
    mapSearch = json['MapSearch'];
    onlineReviewsGoogleYelpFB = json['OnlineReviewsGoogleYelpFB'];
    radio = json['Radio'];
    googleSearch = json['GoogleSearch'];
    familyFriend = json['FamilyFriend'];
    undefined13 = json['undefined_13'];
    youTube = json['YouTube'];
    brochure = json['Brochure'];
    gTECOrangecom = json['GTECOrangecom'];
    directMail = json['DirectMail'];
    linkedIn = json['LinkedIn'];
    urgentCare = json['UrgentCare'];
    undefined14 = json['undefined_14'];
    twitter = json['Twitter'];
    school = json['School'];
    undefined15 = json['undefined_15'];
    onlineAdvertisements = json['OnlineAdvertisements'];
    newspaperMagazine = json['NewspaperMagazine'];
    undefined16 = json['undefined_16'];
    emailBlast = json['EmailBlast'];
    hotel = json['Hotel'];
    undefined17 = json['undefined_17'];
    citizensDeTar = json['CitizensDeTar'];
    liveWorkDrovenearby = json['LiveWorkDrovenearby'];
    employerSentMe = json['EmployerSentMe'];
    placeofEmployment = json['PlaceofEmployment'];
    wereyoureferredbyaPhysicianforthisvisitcircle =
        json['WereyoureferredbyaPhysicianforthisvisitcircle'];
    patientCell = json['PatientCell'];
    receptionInitialsInviteSent = json['ReceptionInitialsInviteSent'];
    physician = json['Physician'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['1'] = this.s1;
    data['2'] = this.s2;
    data['Name_Last'] = this.nameLast;
    data['Title'] = this.title;
    data['MartialStatus'] = this.martialStatus;
    data['MailingAddress'] = this.mailingAddress;
    data['CityStateZip'] = this.cityStateZip;
    data['Phone'] = this.phone;
    data['SocialSecurity'] = this.socialSecurity;
    data['DOB'] = this.dOB;
    data['Age'] = this.age;
    data['SexMF'] = this.sexMF;
    data['Email'] = this.email;
    data['Ethnicity'] = this.ethnicity;
    data['Employer'] = this.employer;
    data['Occupation'] = this.occupation;
    data['EmergencyContact'] = this.emergencyContact;
    data['Relationship'] = this.relationship;
    data['Phone_2'] = this.phone2;
    data['PrimaryCarePhysician'] = this.primaryCarePhysician;
    data['Reasonsforbeingseen'] = this.reasonsforbeingseen;
    data['GuarantorResponsibleforbillifpatientisamir'] =
        this.guarantorResponsibleforbillifpatientisamir;
    data['GuarantorDOB'] = this.guarantorDOB;
    data['SexMF_2'] = this.sexMF2;
    data['GuarantorSSN'] = this.guarantorSSN;
    data['Addressifdifferent'] = this.addressifdifferent;
    data['GuarantorPhone'] = this.guarantorPhone;
    data['Employer_2'] = this.employer2;
    data['EmployerPhone'] = this.employerPhone;
    data['EmployerAddress'] = this.employerAddress;
    data['WorkersCompPolicyYes'] = this.workersCompPolicyYes;
    data['MotorVehicleAccidentYes'] = this.motorVehicleAccidentYes;
    data['DateofAccident'] = this.dateofAccident;
    data['PrimaryInsuranceAetnaBetterHealthofTexasTXOther'] =
        this.primaryInsuranceAetnaBetterHealthofTexasTXOther;
    data['SubscribersName'] = this.subscribersName;
    data['SubscribersDOB'] = this.subscribersDOB;
    data['SubscribersSSN'] = this.subscribersSSN;
    data['Relationshiptopatient'] = this.relationshiptopatient;
    data['Group'] = this.group;
    data['Policy'] = this.policy;
    data['SecondaryInsuranceOther'] = this.secondaryInsuranceOther;
    data['SubscribersName_2'] = this.subscribersName2;
    data['SubscribersDOB_2'] = this.subscribersDOB2;
    data['SubscribersSSN_2'] = this.subscribersSSN2;
    data['Relationshiptopatient_2'] = this.relationshiptopatient2;
    data['Group_2'] = this.group2;
    data['Policy_2'] = this.policy2;
    data['Signature'] = this.signature;
    data['Date'] = this.date;
    data['firstname'] = this.firstname;
    data['middle'] = this.middle;
    data['date'] = this.date;
    data['time'] = this.time;
    data['SignatureofPatient'] = this.signatureofPatient;
    data['Witness'] = this.witness;
    data['Myrelationshiptothepatientis'] = this.myrelationshiptothepatientis;
    data['SignatureofRelative'] = this.signatureofRelative;
    data['Witness_2'] = this.witness2;
    data['undefined'] = this.undefined;
    data['PatientsPrintedName'] = this.patientsPrintedName;
    data['undefined_2'] = this.undefined2;
    data['SignatureofPatient_2'] = this.signatureofPatient2;
    data['Date_2'] = this.date2;
    data['undefined_3'] = this.undefined3;
    data['PrintedName'] = this.printedName;
    data['LegalAuthoritytoactonbehalfofpatient'] =
        this.legalAuthoritytoactonbehalfofpatient;
    data['Witness_3'] = this.witness3;
    data['DOB_2'] = this.dOB2;
    data['Relationtomember'] = this.relationtomember;
    data['MemberIDnumber'] = this.memberIDnumber;
    data['I'] = this.i;
    data['doherebyauthorize'] = this.doherebyauthorize;
    data['undefined_4'] = this.undefined4;
    data['undefined_5'] = this.undefined5;
    data['name'] = this.name;
    data['YES'] = this.yES;
    data['HealthInsuranceProvider'] = this.healthInsuranceProvider;
    data['Subscriber'] = this.subscriber;
    data['SubscribersDOB1'] = this.subscribersDOB1;
    data['SubscribersDOB2'] = this.subscribersDOB2;
    data['MemberID'] = this.memberID;
    data['EffectiveDate'] = this.effectiveDate;
    data['PrintedNameofthepersoncompletingthisform'] =
        this.printedNameofthepersoncompletingthisform;
    data['Signature_2'] = this.signature2;
    data['Date_3'] = this.date3;
    data['Witness_4'] = this.witness4;
    data['Date_4'] = this.date4;
    data['no'] = this.no;
    data['SignatureandDate'] = this.signatureandDate;
    data['Witness_5'] = this.witness5;
    data['FullName'] = this.fullName;
    data['Relation'] = this.relation;
    data['FullName_2'] = this.fullName2;
    data['Relation_2'] = this.relation2;
    data['undefined_6'] = this.undefined6;
    data['PatientParentGuardianSignature'] =
        this.patientParentGuardianSignature;
    data['Date_5'] = this.date5;
    data['GTECORANGE'] = this.gTECORANGE;
    data['PatientSignature'] = this.patientSignature;
    data['Date_6'] = this.date6;
    data['I_2'] = this.i2;
    data['I_3'] = this.i3;
    data['I_4'] = this.i4;
    data['I_5'] = this.i5;
    data['nameonanyandallcheckslistingmeasapayeewhicharepresentedtothisofficeforpaymentofan'] =
        this.nameonanyandallcheckslistingmeasapayeewhicharepresentedtothisofficeforpaymentofan;
    data['authorizeGTECOrangetoapplyanycreditbalancesincurredbymetoanyotheroutstandingchargesstill'] =
        this.authorizeGTECOrangetoapplyanycreditbalancesincurredbymetoanyotheroutstandingchargesstill;
    data['GTECOrangefortheirservicesThisagreementdoestconstituteanyconsiderationforthisofficetoawait'] =
        this.gTECOrangefortheirservicesThisagreementdoestconstituteanyconsiderationforthisofficetoawait;
    data['fortheprotectionoftherightsandinterestsofGTECOrangeandmyHowevershouldanyprovisionofthe'] =
        this.fortheprotectionoftherightsandinterestsofGTECOrangeandmyHowevershouldanyprovisionofthe;
    data['PatientPrintedName'] = this.patientPrintedName;
    data['PatientSignature_2'] = this.patientSignature2;
    data['Date_7'] = this.date7;
    data['Witness_6'] = this.witness6;
    data['StateofTexasCountyof'] = this.stateofTexasCountyof;
    data['dayof'] = this.dayof;
    data['year'] = this.year;
    data['undefined_7'] = this.undefined7;
    data['taryPublicSignature'] = this.taryPublicSignature;
    data['DateofRequest'] = this.dateofRequest;
    data['undefined_8'] = this.undefined8;
    data['NameofGuardianPOA'] = this.nameofGuardianPOA;
    data['undefined_9'] = this.undefined9;
    data['LOSSOFJOBBUSINESS'] = this.lOSSOFJOBBUSINESS;
    data['DECREASEINPAYREVENUEBENEFITS'] = this.dECREASEINPAYREVENUEBENEFITS;
    data['DECREASEDJOBHOURS'] = this.dECREASEDJOBHOURS;
    data['CARINGFORSUPPORTINGOTHERSAFFECTED'] =
        this.cARINGFORSUPPORTINGOTHERSAFFECTED;
    data['FURLOUGHLAIDOFF'] = this.fURLOUGHLAIDOFF;
    data['INCREASEDDEBTEXPENSES'] = this.iNCREASEDDEBTEXPENSES;
    data['LOSSOFHOMEDWELLING'] = this.lOSSOFHOMEDWELLING;
    data['QUARANTINEDCARINGFORQUARANTINEDPERSON'] =
        this.qUARANTINEDCARINGFORQUARANTINEDPERSON;
    data['OTHERbrieflyexplain1'] = this.oTHERbrieflyexplain1;
    data['OTHERbrieflyexplain2'] = this.oTHERbrieflyexplain2;
    data['PatientSignature_3'] = this.patientSignature3;
    data['Date_8'] = this.date8;
    data['Accountnumbersapprovedforwaiverpleaselistall'] =
        this.accountnumbersapprovedforwaiverpleaselistall;
    data['undefined_10'] = this.undefined10;
    data['1_2'] = this.s12;
    data['2_2'] = this.s22;
    data['Waiverapproved'] = this.waiverapproved;
    data['Deferredpaymentapproved'] = this.deferredpaymentapproved;
    data['Date_9'] = this.date9;
    data['undefined_11'] = this.undefined11;
    data['on'] = this.on;
    data['undefined_12'] = this.undefined12;
    data['PatientNameJenkinsBobby'] = this.patientNameJenkinsBobby;
    data['DOB10201964'] = this.dOB10201964;
    data['IDOTgiveconsenttomyrecordsbeingreleasedtoanyallphysiciansthatrequestthem'] =
        this.iDOTgiveconsenttomyrecordsbeingreleasedtoanyallphysiciansthatrequestthem;
    data['PatientRepresentativeSignature'] =
        this.patientRepresentativeSignature;
    data['Date_10'] = this.date10;
    data['NameofPatientRepresentativeprint'] =
        this.nameofPatientRepresentativeprint;
    data['RelationshiptoPatient'] = this.relationshiptoPatient;
    data['YES_2'] = this.yES2;
    data['YES_3'] = this.yES3;
    data['Facebook'] = this.facebook;
    data['TV'] = this.tV;
    data['MapSearch'] = this.mapSearch;
    data['OnlineReviewsGoogleYelpFB'] = this.onlineReviewsGoogleYelpFB;
    data['Radio'] = this.radio;
    data['GoogleSearch'] = this.googleSearch;
    data['FamilyFriend'] = this.familyFriend;
    data['undefined_13'] = this.undefined13;
    data['YouTube'] = this.youTube;
    data['Brochure'] = this.brochure;
    data['GTECOrangecom'] = this.gTECOrangecom;
    data['DirectMail'] = this.directMail;
    data['LinkedIn'] = this.linkedIn;
    data['UrgentCare'] = this.urgentCare;
    data['undefined_14'] = this.undefined14;
    data['Twitter'] = this.twitter;
    data['School'] = this.school;
    data['undefined_15'] = this.undefined15;
    data['OnlineAdvertisements'] = this.onlineAdvertisements;
    data['NewspaperMagazine'] = this.newspaperMagazine;
    data['undefined_16'] = this.undefined16;
    data['EmailBlast'] = this.emailBlast;
    data['Hotel'] = this.hotel;
    data['undefined_17'] = this.undefined17;
    data['CitizensDeTar'] = this.citizensDeTar;
    data['LiveWorkDrovenearby'] = this.liveWorkDrovenearby;
    data['EmployerSentMe'] = this.employerSentMe;
    data['PlaceofEmployment'] = this.placeofEmployment;
    data['WereyoureferredbyaPhysicianforthisvisitcircle'] =
        this.wereyoureferredbyaPhysicianforthisvisitcircle;
    data['PatientCell'] = this.patientCell;
    data['ReceptionInitialsInviteSent'] = this.receptionInitialsInviteSent;
    data['Physician'] = this.physician;
    return data;
  }
}
