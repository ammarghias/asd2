import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter_google_places_sdk/flutter_google_places_sdk.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/regph2.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph6.dart';
import 'package:reg_app/regph7.dart';
import 'package:reg_app/regph8.dart';

import 'adressmodle.dart';

class pereg3 extends StatefulWidget {
  const pereg3({super.key});

  @override
  _pereg3State createState() => _pereg3State();
  static const String route = '/guarantor';
}

class _pereg3State extends State<pereg3> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  final _formKeyq = GlobalKey<FormState>();
  TextEditingController covidateController = TextEditingController();
  var phoneNoMaskFormatter = MaskTextInputFormatter(
      mask: '(###) ###-####',
      filter: {"#": RegExp(r'[0-9]')},
      type: MaskAutoCompletionType.lazy);
  //gps
  TextEditingController streetAddController = TextEditingController();
  TextEditingController stateController = TextEditingController();
  TextEditingController zipCodeController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  late final FlutterGooglePlacesSdk _places;
  String? _predictLastText;
  bool _predicting = false;
  dynamic _predictErr;
  List<AutocompletePrediction>? _predictions;
  var comp;
  Widget _buildPredictionItem(AutocompletePrediction item) {
    var _character;

    var co = const Color.fromARGB(0, 0, 0, 0);
    return Container(
      color: co,
      child: InkWell(
        focusColor: co,
        onTap: () async {
          comp = fetchAlbum(item.placeId, "98");
          setState(() {
            context.read<UserData>().guarantorEmployerAddress1 = item.fullText;
            streetAddController.text = item.fullText;
          });
          setState(() {});
          Navigator.pop(context);
        },
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                item.fullText,
                textAlign: TextAlign.center,
              ),
              const Divider(thickness: 2),
            ]),
      ),
    );
  }

  List<Widget> _buildPredictionWidgets() {
    return [
      TextFormField(
        onChanged: _onPredictTextChanged,
        decoration: const InputDecoration(label: Text("Address")),
      ),
      _buildErrorWidget(_predictErr),
      Column(
        mainAxisSize: MainAxisSize.min,
        children: (_predictions ?? [])
            .map(_buildPredictionItem)
            .toList(growable: false),
      ),
    ];
  }

  Widget _buildErrorWidget(dynamic err) {
    final theme = Theme.of(context);
    final errorText = err == null ? '' : err.toString();
    return Text(errorText,
        style: theme.textTheme.bodySmall
            ?.copyWith(color: theme.colorScheme.error));
  }

  addTypeDialog(BuildContext context) {
    _buildPredictionWidgets();

    setState(() {});
  }

  Future<AutoGenerate> fetchAlbum(String placeId, sessionToken) async {
    final response = await http.get(Uri.parse(
        'https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeId&fields=address_component&key=AIzaSyBO5TaHOjSZFWhBF0AYpNUSmFh8ozqLRto&sessiontoken=$sessionToken'));

    if (response.statusCode == 200) {
      print("apisecess");

      int ii = AutoGenerate.fromJson(jsonDecode(response.body))
          .result
          .addressComponents
          .length;
      for (int index = 0; index < ii; index++) {
        if (AutoGenerate.fromJson(jsonDecode(response.body))
            .result
            .addressComponents[index]
            .types
            .contains("postal_code")) {
          context.read<UserData>().guarantorEmployerZip =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
          zipCodeController.text =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
        }
        if (AutoGenerate.fromJson(jsonDecode(response.body))
            .result
            .addressComponents[index]
            .types
            .contains("administrative_area_level_1")) {
          context.read<UserData>().guarantorEmployerState =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
          stateController.text =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
        }
        if (AutoGenerate.fromJson(jsonDecode(response.body))
            .result
            .addressComponents[index]
            .types
            .contains("administrative_area_level_2")) {
          context.read<UserData>().guarantorEmployerCity =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
          cityController.text = AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[index]
              .longName;
        }
      }

      print("newone" +
          AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[1]
              .longName);

      return AutoGenerate.fromJson(jsonDecode(response.body));
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load album');
    }
  }

  void _onPredictTextChanged(String value) {
    print(value);
    setState(() {});
    _predictLastText = value;
    _predict();
  }

  void _predict() async {
    if (_predicting) {
      return;
    }

    final hasContent = _predictLastText?.isNotEmpty ?? false;

    setState(() {
      _predicting = hasContent;
      _predictErr = null;
    });

    if (!hasContent) {
      return;
    }

    try {
      final result = await _places.findAutocompletePredictions(
        _predictLastText!,
        countries: null,
        newSessionToken: false,
        placeTypeFilter: PlaceTypeFilter.ADDRESS,
        // origin: LatLng(lat: 43.12, lng: 95.20),
        locationBias: null,
        locationRestriction: null,
      );

      setState(() {
        print("hhhh" + result.predictions[1].placeId);
        _predictions = result.predictions;
        _predicting = false;
      });
    } catch (err) {
      setState(() {
        _predictErr = err;
        _predicting = false;
      });
    }
  }

  //gps
  String t1 = "choose";
  String t2 = "choose";
  TextEditingController t3 = TextEditingController();
  TextEditingController t4 = TextEditingController();
  TextEditingController t5 = TextEditingController();
  TextEditingController t6 = TextEditingController();
  TextEditingController t7 = TextEditingController();
  TextEditingController t8 = TextEditingController();
  TextEditingController t9 = TextEditingController();
  TextEditingController t10 = TextEditingController();
  TextEditingController t11 = TextEditingController();
  TextEditingController t12 = TextEditingController();
  TextEditingController t13 = TextEditingController();
  TextEditingController t14 = TextEditingController();
  TextEditingController t15 = TextEditingController();
  TextEditingController t16 = TextEditingController();
  TextEditingController t17 = TextEditingController();
  TextEditingController t18 = TextEditingController();
  TextEditingController t19 = TextEditingController();
  TextEditingController t20 = TextEditingController();
  TextEditingController t21 = TextEditingController();
  void initState() {
    super.initState();

    if (context.read<UserData>().patientMinorCheck != null)
      t1 = context.read<UserData>().patientMinorCheck!;

    if (context.read<UserData>().guarantorCheck != null)
      t2 = context.read<UserData>().guarantorCheck!;

    if (context.read<UserData>().guarantorFirstName != null)
      t3.text = context.read<UserData>().guarantorFirstName!;
    if (context.read<UserData>().guarantorLastName != null)
      t4.text = context.read<UserData>().guarantorLastName!;
    if (context.read<UserData>().guarantorDOB != null)
      t5.text = context
          .read<UserData>()
          .guarantorDOB!
          .replaceAll("T14:21:25.017Z", "");
    if (context.read<UserData>().guarantorPhoneNumber != null)
      t6.text = context.read<UserData>().guarantorPhoneNumber!;
    if (context.read<UserData>().guarantorSSN != null)
      t7.text = context.read<UserData>().guarantorSSN!;
    if (context.read<UserData>().guarantorEmployerName != null)
      t8.text = context.read<UserData>().guarantorEmployerName!;

    if (context.read<UserData>().guarantorEmployerPhoneNumber != null)
      t9.text = context.read<UserData>().guarantorEmployerPhoneNumber!;

    if (context.read<UserData>().guarantorEmployerCity != null)
      cityController.text = context.read<UserData>().guarantorEmployerCity!;

    if (context.read<UserData>().guarantorEmployerState != null)
      stateController.text = context.read<UserData>().guarantorEmployerState!;
    if (context.read<UserData>().guarantorEmployerZip != null)
      zipCodeController.text = context.read<UserData>().guarantorEmployerZip!;
    if (context.read<UserData>().guarantorEmployerAddress1 != null)
      streetAddController.text =
          context.read<UserData>().guarantorEmployerAddress1!;

    if (context.read<UserData>().guarantorEmployerAddress2 != null)
      t11.text = context.read<UserData>().guarantorEmployerAddress2!;
    _places = FlutterGooglePlacesSdk("AIzaSyBO5TaHOjSZFWhBF0AYpNUSmFh8ozqLRto",
        locale: const Locale('en'));
    _places.isInitialized().then((value) {
      debugPrint('Places Initialized: $value');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          backgroundColor: Color.fromRGBO(119, 94, 158, 100),
          title: const Text(
            ' Guarantor',
            style: TextStyle(color: Colors.white),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text(
                '',
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
              onPressed: () {
                if (_formKey.currentState!.validate()) {}
              },
            ),
          ],
        ),
        drawer: Drawer(
          width: 200,
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomCenter,
                colors: [
                  Color.fromRGBO(51, 62, 101, 5),
                  Color.fromRGBO(107, 80, 135, 5)
                ],
              ),
            ),
            child: ListView(
              children: <Widget>[
                // const UserAccountsDrawerHeader(
                //   currentAccountPictureSize: Size.square(90.0),
                //   accountName: Text(
                //     '',
                //     style: TextStyle(color: Colors.white),
                //   ),
                //   accountEmail: Text(
                //     '',
                //     style: TextStyle(color: Colors.white),
                //   ),
                //   currentAccountPicture: CircleAvatar(
                //     backgroundColor: Colors.white,
                //     child: Text(
                //       'P',
                //       style: TextStyle(
                //         fontSize: 20.0,
                //         fontWeight: FontWeight.bold,
                //         color: Colors.purple,
                //       ),
                //     ),
                //   ),
                //   decoration: BoxDecoration(
                //     gradient: LinearGradient(
                //       begin: Alignment.topCenter,
                //       end: Alignment.bottomCenter,
                //       colors: [Colors.transparent, Colors.transparent],
                //       //  [Color.fromRGBO(51, 62, 101,10), Color.fromRGBO(51, 62, 101,10)],
                //     ),
                //   ),
                // ),
                // Padding(
                //   padding: const EdgeInsets.all(8.0),
                //   child: Row(
                //     children: [
                //       const Icon(
                //         Icons.image,
                //         color: Colors.white,
                //       ),
                //       const SizedBox(
                //         width: 10,
                //       ),
                //       const Icon(
                //         Icons.edit,
                //         color: Colors.white,
                //       ),
                //     ],
                //   ),
                // ),
                ListTile(
                  title: Text(
                    'Patient',
                    style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => pereg1()));

                    // TODO: Navigate to patient info page
                  },
                ),
                ListTile(
                  autofocus: true,
                  selected: true,
                  focusColor: Colors.white,
                  selectedColor: Colors.white,
                  enabled: true,
                  title: Text(
                    'Physician',
                    style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => pereg2()));
                  },
                ),
                ListTile(
                  title: Text(
                    'COVID-19',
                    style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => pereg8()));

                    // TODO: Navigate to COVID-19 info page
                  },
                ),
                ListTile(
                  title: Text(
                    'Guarantor',
                    style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => pereg3()));
                    // TODO: Navigate to guarantor info page
                  },
                ),
                ListTile(
                  title: Text(
                    'Insurance',
                    style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => pereg7()));
                    // TODO: Navigate to insurance info page
                  },
                ),
                ListTile(
                  title: Text(
                    'Emergency Contact',
                    style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => pereg4()));
                    // TODO: Navigate to emergency info page
                  },
                ),
                ListTile(
                  title: Text(
                    'Marketing',
                    style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => pereg5()));
                    // TODO: Navigate to marketing info page
                  },
                ),
                ListTile(
                  title: Text(
                    'ID Upload',
                    style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => pereg6()));
                    // TODO: Navigate to ID upload page
                  },
                ),
              ],
            ),
          ),
        ),

// It is recommended to use the TextFormField widget for text input fields as it provides built-in validation features
// Use the DropdownButtonFormField widget for dropdowns to simplify code and provide built-in validation
// We can use the Container widget to set the background color and border radius for the forms

// Dart code block:
        bottomNavigationBar: BottomAppBar(

            // color: Color(0xFFC0C0C0),
            child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.white,
                Colors.grey,
              ],
            ),
          ),
          child: Row(
            children: <Widget>[
              Padding(
                  padding: const EdgeInsets.only(
                      left: 10.0, top: 10.0, bottom: 5.0, right: 10.0),
                  child: Container(
                      decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                        ),
                        gradient: const LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xFF8800FF),
                              Color(0xFFA600FF),
                            ]),
                      ),
                      child: ElevatedButton(
                          onPressed: () async {
                            Navigator.of(context).pop();
                            // Navigator.push(context, MaterialPageRoute(builder: (context) => PersonalInfoRegister(),));
                          },
                          child: const Text("BACK"),
                          style: ElevatedButton.styleFrom(
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              primary: Colors.transparent,
                              shadowColor: Colors.transparent,
                              elevation: 0,
                              textStyle: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black))))),
              const Spacer(),
              const Expanded(
                child: Padding(
                  padding: EdgeInsets.all(18.0),
                  child: Text(
                    "",
                    style: TextStyle(
                        // color: Color(0xFFC0C0C0),
                        fontSize: 16.0),
                  ),
                ),
              ),
              Padding(
                  padding: EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
                  child: Container(
                      decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                        ),
                        gradient: const LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xFF8800FF),
                              Color(0xFFA600FF),
                            ]),
                      ),
                      child: ElevatedButton(
                          onPressed: () async {
                            //sending this get this all from shared pref and send the data

                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => pereg7()));
                          },
                          child: Text("NEXT"),
                          style: ElevatedButton.styleFrom(
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              primary: Colors.transparent,
                              shadowColor: Colors.transparent,
                              elevation: 0,
                              textStyle: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black))))),
            ],
          ),
        )),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                padding: EdgeInsets.all(20),
                // decoration: BoxDecoration(
                //   borderRadius: BorderRadius.circular(10),
                //   border: Border.all(color: Colors.grey),
                // ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      DropdownButtonFormField(
                        value: t1,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'Is the patient a minor?',
                        ),
                        items: [
                          DropdownMenuItem(
                              child: Text('choose'), value: "choose"),
                          DropdownMenuItem(child: Text('Yes'), value: "Yes"),
                          DropdownMenuItem(child: Text('No'), value: "No"),
                        ],
                        onChanged: (value) {
                          context.read<UserData>().patientMinorCheck = value;
                        },
                      ),
                      SizedBox(height: 10),
                      DropdownButtonFormField(
                        value: t2,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'Who is the guarantor?',
                        ),
                        items: [
                          DropdownMenuItem(
                              child: Text('choose'), value: 'choose'),
                          DropdownMenuItem(
                              child: Text("The Patient"), value: "The Patient"),
                          DropdownMenuItem(
                              child: Text("Legal Guardian of the Patient"),
                              value: "Legal Guardian of the Patient"),
                          DropdownMenuItem(
                              child: Text("Parent of the Patient"),
                              value: "Parent of the Patient"),
                          DropdownMenuItem(
                              child: Text("Spouse/partner of the patient"),
                              value: "Spouse/partner of the patient"),
                        ],
                        onChanged: (value) {
                          setState(() {
                            if (value == "The Patient") {
                              print("ghfk");
                              context.read<UserData>().guarantorFirstName =
                                  context.read<UserData>().firstName!;
                              t3.text = context.read<UserData>().firstName!;
                              context.read<UserData>().guarantorLastName =
                                  context.read<UserData>().lastName!;
                              t4.text = context.read<UserData>().lastName!;
                              context.read<UserData>().guarantorDOB =
                                  context.read<UserData>().newdobsubcriber!;
                              t5.text = context
                                  .read<UserData>()
                                  .newdobsubcriber!
                                  .replaceAll("T14:21:25.017Z", "");
                              ;
                            }
                          });

                          context.read<UserData>().guarantorCheck = value;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        onChanged: (String? value) {
                          _formKey.currentState!.validate();

                          context.read<UserData>().guarantorFirstName = value;
                        },
                        inputFormatters: [
                          MaskTextInputFormatter(
                              mask: '#####################',
                              filter: {"#": RegExp(r'[a-zA-Z]')},
                              type: MaskAutoCompletionType.lazy)
                        ],
                        controller: t3,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'First Name',
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field is required';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'Last Name',
                        ),
                        inputFormatters: [
                          MaskTextInputFormatter(
                              mask: '#####################',
                              filter: {"#": RegExp(r'[a-zA-Z]')},
                              type: MaskAutoCompletionType.lazy)
                        ],
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field is required';
                          }
                          return null;
                        },
                        controller: t4,
                        onChanged: (String? value) {
                          _formKey.currentState!.validate();

                          context.read<UserData>().guarantorLastName = value;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        controller: t5,
                        onTap: () async {
                          DateTime? dob = await showDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime(1900),
                              lastDate: DateTime.now());
                          if (dob != null) {
                            context.read<UserData>().guarantorDOB =
                                "${dob.year}-${dob.month < 10 ? "0${dob.month}" : dob.month}-${dob.day < 10 ? "0${dob.day}" : dob.day}T14:21:25.017Z";
                            //   context.read<UserData>().guarantorDOB =
                            // "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                            t5.text =
                                "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                            // Do something with the selected date
                          }
                        },
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'DOB',
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field is required';
                          }
                          return null;
                        },
                        onChanged: (String? value) {
                          setState(() {
                            _formKey.currentState!.validate();
                          });
                          context.read<UserData>().guarantorDOB =
                              covidateController.text;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        controller: t6,
                        inputFormatters: [phoneNoMaskFormatter],
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'Phone Number',
                        ),
                        validator: (value) {
                          if (value!.length < 14) {
                            return 'Please enter your contact number';
                          }
                          return null;
                        },
                        onChanged: (String? value) {
                          _formKey.currentState!.validate();

                          context.read<UserData>().guarantorPhoneNumber = value;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        controller: t7,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'SSN',
                        ),
                        inputFormatters: [
                          MaskTextInputFormatter(
                              mask: '#########',
                              filter: {"#": RegExp(r'[0-9]')},
                              type: MaskAutoCompletionType.lazy)
                        ],
                        //   validator: (value) {
                        //  if (value!.length<9) {
                        //       return 'This field is required';
                        //     }
                        //     return null;
                        //   },
                        onChanged: (String? value) {
                          _formKey.currentState!.validate();

                          context.read<UserData>().guarantorSSN = value;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        inputFormatters: [
                          MaskTextInputFormatter(
                              mask: '########################',
                              filter: {"#": RegExp(r'[a-zA-Z]')},
                              type: MaskAutoCompletionType.lazy)
                        ],
                        controller: t8,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'Employer Name',
                        ),
                        // validator: (value) {
                        //   if (value!.isEmpty) {
                        //     return 'This field is required';
                        //   }
                        //   return null;
                        // },
                        onChanged: (String? value) {
                          _formKey.currentState!.validate();

                          context.read<UserData>().guarantorEmployerName =
                              value;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        controller: t9,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'Employer Phone Number',
                        ),
                        inputFormatters: [phoneNoMaskFormatter],
                        //     validator: (value) {
                        //  if (value!.length<14) {
                        //     return 'Please enter your contact number';
                        //   }
                        //       return null;
                        //     },
                        onChanged: (String? value) {
                          _formKey.currentState!.validate();

                          context
                              .read<UserData>()
                              .guarantorEmployerPhoneNumber = value;
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.white),
                ),
                child: Form(
                  key: _formKeyq,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Guarantor Employer Address',
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 10),
                      TextFormField(
                        controller: cityController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'City',
                        ),
                        inputFormatters: [
                          MaskTextInputFormatter(
                              mask: '########################',
                              filter: {"#": RegExp(r'[a-zA-Z]')},
                              type: MaskAutoCompletionType.lazy)
                        ],
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field is required';
                          }
                          return null;
                        },
                        onChanged: (String? value) {
                          _formKey.currentState!.validate();

                          context.read<UserData>().guarantorEmployerCity =
                              value;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        inputFormatters: [
                          MaskTextInputFormatter(
                              mask: '########################',
                              filter: {"#": RegExp(r'[a-zA-Z]')},
                              type: MaskAutoCompletionType.lazy)
                        ],
                        controller: stateController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'State',
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field is required';
                          }
                          return null;
                        },
                        onChanged: (String? value) {
                          _formKey.currentState!.validate();

                          context.read<UserData>().guarantorEmployerState =
                              value;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        inputFormatters: [
                          MaskTextInputFormatter(
                              mask: '#######',
                              filter: {"#": RegExp(r'[A-Za-z0-9]')},
                              type: MaskAutoCompletionType.lazy)
                        ],
                        controller: zipCodeController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'Zip Code',
                        ),
                        onChanged: (String? value) {
                          _formKey.currentState!.validate();

                          context.read<UserData>().guarantorEmployerZip = value;
                        },
                      ),
                      SizedBox(height: 10),
                      TextFormField(
                        controller: streetAddController,
                        onTap: () {
                          // //gps
                          // showDialog(
                          //   barrierDismissible: false,
                          //   context: context,
                          //   builder: (BuildContext context) {
                          //     return AlertDialog(
                          //       backgroundColor: Color(0xFFC0C0C0),
                          //       scrollable: true,
                          //       content: StatefulBuilder(
                          //         builder: (BuildContext context,
                          //             StateSetter setState) {
                          //           return SizedBox(
                          //             height: 350,
                          //             width: 500,
                          //             child: Column(
                          //               children: <Widget>[
                          //                 TextFormField(
                          //                   onChanged: (value) {
                          //                     setState(() {
                          //                       _onPredictTextChanged(value);
                          //                     });
                          //                   },
                          //                   decoration: const InputDecoration(
                          //                       label: Text("Address")),
                          //                 ),
                          //                 _buildErrorWidget(_predictErr),
                          //                 GestureDetector(
                          //                   onTap: () {
                          //                     setState(() {});
                          //                   },
                          //                   child: Column(
                          //                     mainAxisSize: MainAxisSize.min,
                          //                     children: (_predictions ?? [])
                          //                         .map(_buildPredictionItem)
                          //                         .toList(growable: false),
                          //                   ),
                          //                 ),
                          //                 ElevatedButton(
                          //                     onPressed: () {
                          //                       Navigator.pop(context);
                          //                     },
                          //                     child: Text("Close"))
                          //               ],
                          //             ),
                          //           );
                          //         },
                          //       ),
                          //     );
                          //   },
                          // );
                          //gps
                        },
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'Employer Address 1',
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'This field is required';
                          }
                          return null;
                        },
                        onChanged: (String? value) {
                          setState(() {
                            _formKey.currentState!.validate();
                          });
                          context.read<UserData>().guarantorEmployerAddress1 =
                              value;
                        },
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: t11,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter ';
                          }
                          return null;
                        },
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.0)),
                          ),
                          labelText: 'Employer Address 2',
                        ),
                        onChanged: (String? value) {
                          setState(() {
                            _formKey.currentState!.validate();
                          });
                          context.read<UserData>().guarantorEmployerAddress2 =
                              value;
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ));
  }
}
