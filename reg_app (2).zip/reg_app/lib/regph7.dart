// Suggestions:
// 1. Use MaterialApp and Scaffold widgets for easier app and UI building
// 2. Use ListView for the drawer items
// 3. Use CircleAvatar for profile picture
// 4. Use InputDecoration for rounded border text fields

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/regph2.dart';
import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph6.dart';
import 'package:reg_app/regph8.dart';
import 'package:toggle_switch/toggle_switch.dart';

class UtilityMethods {}

class PriInsurance {
  final int id;
  final String payerName;
  final String payerID;

  PriInsurance({
    required this.id,
    required this.payerName,
    required this.payerID,
  });

  factory PriInsurance.fromJson(Map<String, dynamic> json) {
    return PriInsurance(
      id: json['id'],
      payerName: json['payerName'],
      payerID: json['payerID'],
    );
  }
}

class pereg7 extends StatefulWidget {
  const pereg7({super.key});

  @override
  _pereg7State createState() => _pereg7State();
  static const String route = '/insu';
}

class _pereg7State extends State<pereg7> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  bool swed = true;
  Color fi = Color.fromRGBO(51, 62, 101, 100),
      sec = Colors.white,
      th = Colors.white;
  int ifh = 2;
  int subt = 0;
  TextEditingController meberidcont = TextEditingController();
  TextEditingController priortyc = TextEditingController();

  TextEditingController typesc = TextEditingController();
  TextEditingController payerc = TextEditingController();
  TextEditingController covidateController = TextEditingController();
  TextEditingController groupc = TextEditingController();
  TextEditingController relationc = TextEditingController();
  TextEditingController sfirstnaamec = TextEditingController();
  TextEditingController lastnamec = TextEditingController();
  TextEditingController datebrc = TextEditingController();
  TextEditingController sexc = TextEditingController();
  TextEditingController addressc = TextEditingController();
  TextEditingController cityc = TextEditingController();
  TextEditingController statec = TextEditingController();
  TextEditingController zipcodec = TextEditingController();
  TextEditingController phoneumberc = TextEditingController();
  TextEditingController ssnc = TextEditingController();
  TextEditingController occupationc = TextEditingController();
  TextEditingController namec = TextEditingController();
  TextEditingController addresscc = TextEditingController();
  TextEditingController citycc = TextEditingController();
  TextEditingController statecc = TextEditingController();
  TextEditingController zipcc = TextEditingController();
  TextEditingController phonecc = TextEditingController();
  TextEditingController effectivecc = TextEditingController();
  TextEditingController terminationcc = TextEditingController();
  TextEditingController priInsController = TextEditingController();
  TextEditingController priInsControler = TextEditingController();
  int payerId = 1;
  TextEditingController memIdController = TextEditingController();
  List<PriInsurance>? priIns;
  PriInsurance? selectedIns;

  String t1 = 'choose Priority';
  String t2 = 'choose Type';
  TextEditingController t3 = TextEditingController();
  String t4 = 'choose Relation';
  String t5 = 'choose Sex';
  TextEditingController t6 = TextEditingController();
  TextEditingController t7 = TextEditingController();
  TextEditingController t8 = TextEditingController();
  TextEditingController t9 = TextEditingController();
  TextEditingController t10 = TextEditingController();
  TextEditingController t11 = TextEditingController();
  TextEditingController t12 = TextEditingController();
  TextEditingController t13 = TextEditingController();
  TextEditingController t14 = TextEditingController();
  TextEditingController t15 = TextEditingController();
  TextEditingController t16 = TextEditingController();
  TextEditingController t17 = TextEditingController();
  TextEditingController t18 = TextEditingController();
  TextEditingController t19 = TextEditingController();
  TextEditingController t20 = TextEditingController();
  TextEditingController t21 = TextEditingController();
  TextEditingController t22 = TextEditingController();
  TextEditingController t23 = TextEditingController();
  TextEditingController t24 = TextEditingController();
  TextEditingController t25 = TextEditingController();
  TextEditingController t26 = TextEditingController();
  TextEditingController t27 = TextEditingController();
  TextEditingController t28 = TextEditingController();
  TextEditingController t29 = TextEditingController();
  TextEditingController t30 = TextEditingController();
  TextEditingController t31 = TextEditingController();
  TextEditingController t32 = TextEditingController();
  TextEditingController t33 = TextEditingController();
  TextEditingController t34 = TextEditingController();
  TextEditingController t35 = TextEditingController();
  TextEditingController t36 = TextEditingController();
  int ch1 = 0;
  void initState() {
    super.initState();
    if (context.read<UserData>().firstName != null)
      t34.text = context.read<UserData>().firstName!;
    if (context.read<UserData>().lastName != null)
      t35.text = context.read<UserData>().lastName!;
    if (context.read<UserData>().dob != null)
      t36.text = context.read<UserData>().dob! .replaceAll("T14:21:25.017Z", "");

    if (context.read<UserData>().country != null)
      t23.text = context.read<UserData>().country!;
    if (context.read<UserData>().county != null)
      t24.text = context.read<UserData>().county!;
    if (context.read<UserData>().city != null)
      t25.text = context.read<UserData>().city!;
    if (context.read<UserData>().state != null)
      t26.text = context.read<UserData>().state!;
    if (context.read<UserData>().zipCode != null)
      t27.text = context.read<UserData>().zipCode!;
    if (context.read<UserData>().address1 != null)
      t28.text = context.read<UserData>().address1!;
    if (context.read<UserData>().empContact != null)
      t29.text = context.read<UserData>().empContact!;
    if (context.read<UserData>().occupation != null)
      t30.text = context.read<UserData>().occupation!;
    if (context.read<UserData>().employer != null)
      t31.text = context.read<UserData>().employer!;
    if (context.read<UserData>().country != null)
      t33.text = context.read<UserData>().country!;
    if (context.read<UserData>().phNumber != null)
      t22.text = context.read<UserData>().phNumber!;
    if (context.read<UserData>().priority != null)
      t1 = context.read<UserData>().priority!;

    if (context.read<UserData>().type != null)
      t2 = context.read<UserData>().type!;

    if (context.read<UserData>().payerName != null)
      priInsControler.text = context.read<UserData>().payerName!;
    if (context.read<UserData>().otherInsuranceName != null)
      t3.text = context.read<UserData>().otherInsuranceName!;
    if (context.read<UserData>().memberId != null)
      meberidcont.text = context.read<UserData>().memberId!;
    if (context.read<UserData>().groupNumber != null)
      groupc.text = context.read<UserData>().groupNumber!;
    if (context.read<UserData>().relationToPatient != null)
      t4 = context.read<UserData>().relationToPatient!;
    if (context.read<UserData>().subscriberOccupation != null)
      occupationc.text = context.read<UserData>().subscriberOccupation!;
    if (context.read<UserData>().relationToPatient == "self")
      context.read<UserData>().subscriberOccupation =
          context.read<UserData>().occupation;
    if (context.read<UserData>().subscriberSSN != null)
      ssnc.text = context.read<UserData>().subscriberSSN!;
    if (context.read<UserData>().subscriberContact != null)
      phoneumberc.text = context.read<UserData>().subscriberContact!;
    if (context.read<UserData>().subscriberZip != null)
      zipcodec.text = context.read<UserData>().subscriberZip!;
    if (context.read<UserData>().subscriberState != null)
      statec.text = context.read<UserData>().subscriberState!;
    if (context.read<UserData>().subscriberCity != null)
      cityc.text = context.read<UserData>().subscriberCity!;
    if (context.read<UserData>().subscriberAddress != null)
      addressc.text = context.read<UserData>().subscriberAddress!;
    if (context.read<UserData>().subscriberDOB != null)
      covidateController.text = context.read<UserData>().subscriberDOB!.replaceAll("T14:21:25.017Z", "");
    if (context.read<UserData>().subscriberLastName != null)
      lastnamec.text = context.read<UserData>().subscriberLastName!;
    if (context.read<UserData>().subscriberFirstName != null)
      sfirstnaamec.text = context.read<UserData>().subscriberFirstName!;
    if (context.read<UserData>().subscriberEmployerName != null)
      namec.text = context.read<UserData>().subscriberEmployerName!;
    if (context.read<UserData>().subscriberEmployerAddress != null)
      addresscc.text = context.read<UserData>().subscriberEmployerAddress!;
    if (context.read<UserData>().subscriberEmployerCity != null)
      citycc.text = context.read<UserData>().subscriberEmployerCity!;
    if (context.read<UserData>().subscriberEmployerZip != null)
      statecc.text = context.read<UserData>().subscriberEmployerZip!;
    if (context.read<UserData>().subscriberEmployerZip != null)
      zipcc.text = context.read<UserData>().subscriberEmployerZip!;
    if (context.read<UserData>().subscriberEmployerPhone != null)
      phonecc.text = context.read<UserData>().subscriberEmployerPhone!;
    if (context.read<UserData>().planEffectiveDate != null)
      effectivecc.text = context.read<UserData>().planEffectiveDate!;
    if (context.read<UserData>().planTerminationDate != null)
      terminationcc.text = context.read<UserData>().planTerminationDate!;
    if (context.read<UserData>().subscriberGender != null)
      t5 = context.read<UserData>().subscriberGender!;
  }

  Widget build(BuildContext context) {
    Future<List<PriInsurance>?> priInsController(
        String payerName, int tenantId) async {
      try {
        String BaseUrl =
            "https://qa.rovermd.com:7685/api/v2/sharedExternal/find/max";
        var jsonData = null;
        Uri uri = Uri.parse("$BaseUrl/$payerName");
        final headers = {
          'Content-Type': 'application/json',
          'Charset': 'utf-8',
          'X-TenantID': '$tenantId'
        };
        print("URI HERE-- " + uri.toString());
        var response = await http.get(uri, headers: headers);
        // print(response);
        // print(response.headers);
        if (response.statusCode == 200) {
          jsonData = json.decode(response.body.toString());
          List<dynamic> priInsData = jsonData;
          print("jsonData---$jsonData");

          // return genderData.map((data) => Gender.fromJson(data)).toList();
          return priInsData.map((x) => PriInsurance.fromJson(x)).toList();
        } else {
          throw Exception('Failed to load data');
        }
      } catch (e) {
        print("Error in Pri Insurnace Controller Funtion: $e");
      }
    }

    showPriInsDialog(
        BuildContext context, String payerName, int tenantId) async {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Select Insurance'),
              content:
                  // isLoading ? CircularProgressIndicator() :
                  StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return SingleChildScrollView(
                      child: FutureBuilder(
                    future: priInsController(payerName, tenantId),
                    builder: (context, data) {
                      if (data.hasError) {
                        return Text("Unable to get Data: ${data.error}");
                      } else if (data.hasData) {
                        List<PriInsurance> priIns = data.data!;
                        return ListBody(
                          children: priIns.map((PriInsurance priIns) {
                            return RadioListTile(
                              title: Text(priIns.payerName),
                              value: priIns,
                              groupValue: selectedIns,
                              onChanged: (PriInsurance? value) {
                                setState(() {
                                  context.read<UserData>().payerName =
                                      value!.payerName;
                                  selectedIns = value;
                                });
                              },
                            );
                          }).toList(),
                        );
                      } else {
                        return const Center(child: CircularProgressIndicator());
                      }
                    },
                  ));
                },
              ),
              actions: <Widget>[
                TextButton(
                  child: const Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop(selectedIns);
                    setState(() {
                      priInsControler.text = selectedIns!.payerName;
                      context.read<UserData>().payerName =
                          selectedIns!.payerName;
                      context.read<UserData>().payerid = selectedIns!.id;
                      // payerId = int.parse(selectedIns!.payerID);
                      print("payerIdABID----$payerId");
                      print("payerIdABID----$payerId");
                      print("insurencename" + priInsControler.text);
                      print("insurencename" + priInsControler.text);
                    });
                  },
                ),
              ],
            );
          }).then((value) {
        // Update the state after the dialog is dismissed
        setState(() {});
      });
    }

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(119, 94, 158, 100),
        title: const Text(
          ' Insurance',
          style: TextStyle(color: Colors.white),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              '',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            onPressed: () {
              if (_formKey.currentState!.validate()) {}
            },
          ),
        ],
      ),
      drawer: Drawer(
        width: 200,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(51, 62, 101, 5),
                Color.fromRGBO(107, 80, 135, 5)
              ],
            ),
          ),
          child: ListView(
            children: <Widget>[
              ListTile(
                title: Text(
                  'Patient',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg1()));

                  // TODO: Navigate to patient info page
                },
              ),
              ListTile(
                autofocus: true,
                selected: true,
                focusColor: Colors.white,
                selectedColor: Colors.white,
                enabled: true,
                title: Text(
                  'Physician',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg2()));
                },
              ),
              ListTile(
                title: Text(
                  'COVID-19',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg8()));
                  // TODO: Navigate to COVID-19 info page
                },
              ),
              ListTile(
                title: Text(
                  'Guarantor',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg3()));
                  // TODO: Navigate to guarantor info page
                },
              ),
              ListTile(
                title: Text(
                  'Insurance',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg7()));
                  // TODO: Navigate to insurance info page
                },
              ),
              ListTile(
                title: Text(
                  'Emergency Contact',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg4()));
                  // TODO: Navigate to emergency info page
                },
              ),
              ListTile(
                title: Text(
                  'Marketing',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg5()));
                  // TODO: Navigate to marketing info page
                },
              ),
              ListTile(
                title: Text(
                  'ID Upload',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg6()));
                  // TODO: Navigate to ID upload page
                },
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(

          // color: Color(0xFFC0C0C0),
          child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.grey,
            ],
          ),
        ),
        child: Row(
          children: <Widget>[
            Padding(
                padding: const EdgeInsets.only(
                    left: 10.0, top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          Navigator.of(context).pop();
                          // Navigator.push(context, MaterialPageRoute(builder: (context) => PersonalInfoRegister(),));
                        },
                        child: const Text("BACK"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
            const Spacer(),
            const Expanded(
              child: Padding(
                padding: EdgeInsets.all(18.0),
                child: Text(
                  "",
                  style: TextStyle(
                      // color: Color(0xFFC0C0C0),
                      fontSize: 16.0),
                ),
              ),
            ),
            Padding(
                padding: EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          //  context.read<UserData>().isActive==0
                          // if ( context.read<UserData>().isActive==0) {
                          //   Navigator.of(context).push(MaterialPageRoute(
                          //       builder: (context) => pereg4()));
                          // }else if( context.read<UserData>().isActive==1 ){
                          if (_formKey.currentState!.validate()){
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => pereg4()));}
                                else{ ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content:
                                  const Text('Eneter all the information of Insurance or Subscriber'),
                              action: SnackBarAction(
                                label: 'Undo',
                                onPressed: () {
                                  // Some code to undo the change.
                                },
                              ),
                            ));}
                        },
                        // },
                        child: Text("NEXT"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
          ],
        ),
      )),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Do you have Insurance?',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(width: 15.0),
                        ToggleSwitch(
                          minWidth: 42.0,
                          minHeight: 20.0,
                          customTextStyles: [TextStyle(fontSize: 10)],
                          activeFgColor: Colors.black,
                          inactiveBgColor: Colors.white,
                          dividerColor: Colors.white,
                          inactiveFgColor: Colors.black,
                          activeBgColors: const [
                            [Colors.grey],
                            [Colors.grey]
                          ],
                          initialLabelIndex: context.read<UserData>().isActive,
                          totalSwitches: 2,
                          labels: const [
                            'No',
                            'Yes',
                          ],
                          onToggle: (index) {
                            context.read<UserData>().isActive = index;
                            setState(() {
                              ch1 = index!;
                            });

                            print('switched to: $index');
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Visibility(
                    visible: context.read<UserData>().isActive == 1,
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ElevatedButton(
                                    onPressed: () {
                                      setState(() {
                                        ifh = 2;
                                        fi = Color.fromRGBO(51, 62, 101, 100);
                                        sec = Colors.white;
                                        th = Colors.white;
                                      });
                                    },
                                    child: Text(
                                      "Insurance",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 10,
                                        shadows: [
                                          Shadow(
                                            blurRadius: 15.0, // shadow blur
                                            color: Colors.white, // shadow color
                                            offset: Offset(2.0,
                                                2.0), // how much shadow will be shown
                                          ),
                                        ],
                                      ),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                        enableFeedback: true,
                                        backgroundColor: fi,
                                        // padding: const EdgeInsets.symmetric(
                                        //     horizontal: 50, vertical: 20),
                                        textStyle: const TextStyle(
                                            fontWeight: FontWeight.bold)),
                                  ),
                                  ElevatedButton(
                                      onPressed: () {
                                        setState(() {
                                          ifh = 3;
                                          fi = Colors.white;
                                          sec =
                                              Color.fromRGBO(51, 62, 101, 100);
                                          th = Colors.white;
                                        });
                                      },
                                      child: Text(
                                        "Subscriber",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 10,
                                          shadows: [
                                            Shadow(
                                              blurRadius: 15.0, // shadow blur
                                              color:
                                                  Colors.white, // shadow color
                                              offset: Offset(2.0,
                                                  2.0), // how much shadow will be shown
                                            ),
                                          ],
                                        ),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                          enableFeedback: true,
                                          backgroundColor: sec,
                                          // padding: const EdgeInsets.symmetric(
                                          //     horizontal: 50, vertical: 20),
                                          textStyle: const TextStyle(
                                              fontWeight: FontWeight.bold))),
                                  ElevatedButton(
                                      onPressed: () {
                                        setState(() {
                                          ifh = 4;
                                          fi = Colors.white;
                                          sec = Colors.white;
                                          th = Color.fromRGBO(51, 62, 101, 100);
                                        });
                                      },
                                      child: const Text(
                                        "Employer",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 10,
                                          shadows: [
                                            Shadow(
                                              blurRadius: 15.0, // shadow blur
                                              color:
                                                  Colors.white, // shadow color
                                              offset: Offset(2.0,
                                                  2.0), // how much shadow will be shown
                                            ),
                                          ],
                                        ),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                          enableFeedback: true,
                                          backgroundColor: th,
                                          // padding: const EdgeInsets.symmetric(
                                          //     horizontal: 50, vertical: 20),
                                          textStyle: const TextStyle(
                                              fontWeight: FontWeight.bold)))
                                ],
                              ),
                            ),
                          ),

                          Visibility(
                               maintainState :true,
   maintainAnimation :true,
    // maintainSize :true,
    // maintainSemantics :true,
    // maintainInteractivity:true,
                            visible: ifh == 2,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey[200],
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                padding: EdgeInsets.all(8.0),
                                child: Column(
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: DropdownButtonFormField(
                                        value: t1,
                                        items: <String>[
                                          'choose Priority',
                                          'Primary',
                                          'Secondary',
                                          'Tertiary'
                                        ].map((String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(value),
                                          );
                                        }).toList(),
                                        onChanged: (value) {
                                          t1 = value!;
                                          context.read<UserData>().priority =
                                              value;
                                          if (value == "Primary") {
                                            context.read<UserData>().prid = 1;
                                          } else if (value == "Secondary") {
                                            context.read<UserData>().prid = 2;
                                          } else if (value == "Tertiary") {
                                            context.read<UserData>().prid = 3;
                                          }
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Priority'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: DropdownButtonFormField(
                                        value: t2,
                                        items: <String>[
                                          'choose Type',
                                          'Auto Insurance',
                                          'Government Insurance',
                                          'Health Insurance',
                                          'Worker Compensation',
                                          'Other'
                                        ].map((String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(value),
                                          );
                                        }).toList(),
                                        onChanged: (value) {
                                          t2 = value!;
                                          context.read<UserData>().type = value;
                                          if (value == "Auto Insurance") {
                                            context.read<UserData>().typeid = 3;
                                          } else if (value ==
                                              "Government Insurance") {
                                            context.read<UserData>().typeid = 1;
                                          } else if (value ==
                                              "Health Insurance") {
                                            context.read<UserData>().typeid = 4;
                                          } else if (value ==
                                              "Worker Compensation") {
                                            context.read<UserData>().typeid = 2;
                                          } else if (value == "Other") {
                                            context.read<UserData>().typeid = 5;
                                          }
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Types'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        validator: (value) {
                                          if (value!.isEmpty) {
                                            print("object $value");
                                            return 'Please enter ';
                                          }
                                          return null;
                                        },
                                        onChanged: (text) {
                                          if (text.length == 5) {
                                            showPriInsDialog(context, text, 8);
                                          }
                                          setState(() {
                                            _formKey.currentState!.validate();
                                            context.read<UserData>().payerName =
                                                text;
                                          });
                                          context.read<UserData>().payerName =
                                              text;
                                        },
                                        controller: priInsControler,
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Payers'),
                                      ),
                                    ),
                                    Visibility(
                                      visible:
                                          context.read<UserData>().payerName ==
                                              "Others",
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: TextFormField(
                                          controller: t3,
                                          validator: (value) {
                                            if (value!.isEmpty) {
                                              print("object $value");
                                              return 'Please enter ';
                                            }
                                            return null;
                                          },
                                          onChanged: (String? value) {
                                            _formKey.currentState!.validate();

                                            context
                                                .read<UserData>()
                                                .otherInsuranceName = t3.text;
                                          },
                                          decoration: InputDecoration(
                                              border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                              labelText: 'Other Payer'),
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: meberidcont,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context.read<UserData>().memberId =
                                              meberidcont.text;
                                        },
                                        validator: (value) {
                                          if (value!.isEmpty) {
                                            print("object $value");
                                            return 'Please enter ';
                                          }
                                          return null;
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Member ID'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: groupc,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context.read<UserData>().groupNumber =
                                              value;
                                        },
                                        // validator: (value) {
                                        //   if (value!.isEmpty) {
                                        //     print("object $value");
                                        //     return 'Please enter ';
                                        //   }
                                        //   return null;
                                        // },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Group'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: DropdownButtonFormField(
                                        validator:  (value) {
                                          if (value=="choose Relation") {
                                            print("object $value");
                                            return 'Please enter ';
                                          }
                                          return null;
                                        },
                                        value: t4,
                                        items: <String>[
                                          'choose Relation',
                                          'Self',
                                          'Spouse',
                                          'Child',
                                          'Other'
                                        ].map((String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(value),
                                          );
                                        }).toList(),
                                        onChanged: (value) {
                                            _formKey.currentState!.validate();
                                          t4 = value!;
                                          context
                                              .read<UserData>()
                                              .relationToPatient = value;
                                          setState(() {
                                            if (value == "Self") {
                                              print("selfff");

                                              context
                                                      .read<UserData>()
                                                      .subscriberFirstName =
                                                  context
                                                      .read<UserData>()
                                                      .firstName;

                                              sfirstnaamec.text = context
                                                          .read<UserData>()
                                                          .firstName ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .firstName!;

                                              context
                                                      .read<UserData>()
                                                      .subscriberLastName =
                                                  context
                                                      .read<UserData>()
                                                      .lastName;

                                              lastnamec.text = context
                                                          .read<UserData>()
                                                          .lastName ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .lastName!;

                                              context
                                                      .read<UserData>()
                                                      .subscriberDOB =
                                                  context.read<UserData>().newdobsubcriber;

                                              covidateController.text = context
                                                          .read<UserData>()
                                                          .newdobsubcriber ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .newdobsubcriber!.replaceAll("T14:21:25.017Z", "");

                                              context
                                                      .read<UserData>()
                                                      .subscriberGender =
                                                  context.read<UserData>().sex;

                                              t5 = context
                                                          .read<UserData>()
                                                          .sex ==
                                                      null
                                                  ? "choose Sex"
                                                  : context
                                                      .read<UserData>()
                                                      .sex!;

                                              context
                                                      .read<UserData>()
                                                      .subscriberAddress =
                                                  context
                                                      .read<UserData>()
                                                      .address1;

                                              addressc.text = context
                                                          .read<UserData>()
                                                          .address1 ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .address1!;

                                              context
                                                      .read<UserData>()
                                                      .subscriberCity =
                                                  context.read<UserData>().city;
                                              cityc.text = context
                                                          .read<UserData>()
                                                          .city ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .city!;

                                              context
                                                      .read<UserData>()
                                                      .subscriberState =
                                                  context
                                                      .read<UserData>()
                                                      .state;
                                              statec.text = context
                                                          .read<UserData>()
                                                          .state ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .state!;

                                              context
                                                      .read<UserData>()
                                                      .subscriberZip =
                                                  context
                                                      .read<UserData>()
                                                      .zipCode;

                                              zipcodec.text = context
                                                          .read<UserData>()
                                                          .zipCode ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .zipCode!;

                                              context
                                                      .read<UserData>()
                                                      .subscriberContact =
                                                  context
                                                      .read<UserData>()
                                                      .phNumber;

                                              phoneumberc.text = context
                                                          .read<UserData>()
                                                          .phNumber ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .phNumber!;

                                              context
                                                      .read<UserData>()
                                                      .subscriberSSN =
                                                  context.read<UserData>().ssn;

                                              ssnc.text = context
                                                          .read<UserData>()
                                                          .ssn ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .ssn!;

                                              context
                                                      .read<UserData>()
                                                      .subscriberOccupation =
                                                  context
                                                      .read<UserData>()
                                                      .occupation;

                                              occupationc.text = context
                                                          .read<UserData>()
                                                          .occupation ==
                                                      null
                                                  ? ""
                                                  : context
                                                      .read<UserData>()
                                                      .occupation!;
                                            } else {
                                              context
                                                  .read<UserData>()
                                                  .subscriberOccupation = null;
                                              occupationc.text = "";
                                              context
                                                  .read<UserData>()
                                                  .subscriberSSN = null;
                                              context
                                                  .read<UserData>()
                                                  .subscriberLastName = null;
                                              context
                                                  .read<UserData>()
                                                  .subscriberFirstName = null;
                                              context
                                                  .read<UserData>()
                                                  .subscriberDOB = null;
                                              context
                                                  .read<UserData>()
                                                  .subscriberGender = null;
                                              context
                                                  .read<UserData>()
                                                  .subscriberAddress = null;
                                              context
                                                  .read<UserData>()
                                                  .subscriberCity = null;
                                              context
                                                  .read<UserData>()
                                                  .subscriberState = null;
                                              context
                                                  .read<UserData>()
                                                  .subscriberZip = null;
                                              context
                                                  .read<UserData>()
                                                  .subscriberContact = null;
                                              // if (context.read<UserData>().subscriberOccupation != null)
                                              occupationc.text = "";
                                              // if(context.read<UserData>().relationToPatient=="self")

                                              // if (context.read<UserData>().subscriberSSN != null)
                                              ssnc.text = "";
                                              //  if (context.read<UserData>().subscriberContact != null)
                                              phoneumberc.text = "";
                                              // if (context.read<UserData>().subscriberZip != null)
                                              zipcodec.text = "";
                                              // if (context.read<UserData>().subscriberState != null)
                                              statec.text = "";
                                              // if (context.read<UserData>().subscriberCity != null)
                                              cityc.text = "";
                                              // if (context.read<UserData>().subscriberAddress != null)
                                              addressc.text = "";
                                              // if (context.read<UserData>().subscriberDOB != null)
                                              covidateController.text = "";
                                              // if (context.read<UserData>().subscriberLastName != null)
                                              lastnamec.text = "";
                                              // if (context.read<UserData>().subscriberFirstName != null)
                                              sfirstnaamec.text = "";
                                              // if (context.read<UserData>().subscriberEmployerName != null)
                                              namec.text = "";
                                              // if (context.read<UserData>().subscriberEmployerAddress != null)
                                              addresscc.text = "";
//if (context.read<UserData>().subscriberEmployerCity != null)
                                              citycc.text = "";
                                              // if (context.read<UserData>().subscriberEmployerZip != null)
                                              statecc.text = "";
                                              // if (context.read<UserData>().subscriberEmployerZip != null)
                                              zipcodec.text = "";
                                              // if (context.read<UserData>().subscriberEmployerPhone != null)
                                              phonecc.text = "";
                                              // if (context.read<UserData>().planEffectiveDate != null)
                                              effectivecc.text = "";
                                              //if (context.read<UserData>().planTerminationDate != null)
                                              terminationcc.text = "";
//if (context.read<UserData>().subscriberGender != null)
                                              t5 = "choose Sex";
                                            }
                                          });
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Relation'),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),

                          // Dart code block for Subscriber Information form:

                          Visibility(
                            visible: ifh == 3,
                            maintainState :true,
   maintainAnimation :true,
    // maintainSize :true,
    // maintainSemantics :true,
    // maintainInteractivity:true,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey[200],
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                padding: EdgeInsets.all(8.0),
                                child: Column(
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                         validator: (value) {
                                          if (value!.length < 1) {
                                            print("lenght " +
                                                value!.length.toString());
                                            return 'Please enter name';
                                          }
                                          print("lenght " +
                                              value!.length.toString());
                                          return null;
                                        },
                                        controller: sfirstnaamec,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberFirstName = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '########################',
                                              filter: {
                                                "#": RegExp(r'[a-zA-Z]')
                                              },
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'First Name'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: lastnamec,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberLastName = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '########################',
                                              filter: {
                                                "#": RegExp(r'[a-zA-Z]')
                                              },
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                         validator: (value) {
                                          if (value!.length < 1) {
                                            print("lenght " +
                                                value!.length.toString());
                                            return 'Please enter name';
                                          }
                                          print("lenght " +
                                              value!.length.toString());
                                          return null;
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Last Name'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                         validator: (value) {
                                          if (value!.length < 1) {
                                            print("lenght " +
                                                value!.length.toString());
                                            return 'Please enter name';
                                          }
                                          print("lenght " +
                                              value!.length.toString());
                                          return null;
                                        },
                                        controller: covidateController,
                                        onTap: () async {
                                          DateTime? dob = await showDatePicker(
                                              context: context,
                                              initialDate: DateTime.now(),
                                              firstDate: DateTime(1900),
                                              lastDate: DateTime.now());
                                          if (dob != null) {
                                            context
                                                    .read<UserData>()
                                                    .subscriberDOB =
                                                "${dob.year}-${dob.month < 10 ? "0${dob.month}" : dob.month}-${dob.day < 10 ? "0${dob.day}" : dob.day}T14:21:25.017Z";
                                            covidateController.text =
                                                "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                                            // Do something with the selected date
                                          }
                                        },
                                        onChanged: (String? value) {
                                          setState(() {
                                            _formKey.currentState!.validate();
                                          });
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Date of Birth'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: DropdownButtonFormField(
                                        value: t5,
                                        items: <String>[
                                          'choose Sex',
                                          'Male',
                                          'Female',
                                          'Other'
                                        ].map((String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(value),
                                          );
                                        }).toList(),
                                        onChanged: (value) {
                                            _formKey.currentState!.validate();
                                          t5 = value!;
                                          context
                                              .read<UserData>()
                                              .subscriberGender = value;
                                        },
                                         validator: (value) {
                                          if (value!.length < 1) {
                                            print("lenght " +
                                                value!.length.toString());
                                            return 'Please enter name';
                                          }
                                          print("lenght " +
                                              value!.length.toString());
                                          return null;
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Sex'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: addressc,
                                        onChanged: (String? value) {
                                          setState(() {
                                            _formKey.currentState!.validate();
                                          });
                                          context
                                              .read<UserData>()
                                              .subscriberAddress = value;
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Address'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                          validator: (value) {
                                          if (value!.length < 1) {
                                            print("lenght " +
                                                value!.length.toString());
                                            return 'Please enter name';
                                          }
                                          print("lenght " +
                                              value!.length.toString());
                                          return null;
                                        },
                                        controller: cityc,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberCity = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '########################',
                                              filter: {
                                                "#": RegExp(r'[a-zA-Z]')
                                              },
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'City'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                          validator: (value) {
                                          if (value!.length < 1) {
                                            print("lenght " +
                                                value!.length.toString());
                                            return 'Please enter name';
                                          }
                                          print("lenght " +
                                              value!.length.toString());
                                          return null;
                                        },
                                        controller: statec,
                                        onChanged: (String? valuer) {
                                          context
                                              .read<UserData>()
                                              .subscriberState = valuer;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '########################',
                                              filter: {
                                                "#": RegExp(r'[a-zA-Z]')
                                              },
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'State'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                          validator: (value) {
                                          if (value!.length < 1) {
                                            print("lenght " +
                                                value!.length.toString());
                                            return 'Please enter name';
                                          }
                                          print("lenght " +
                                              value!.length.toString());
                                          return null;
                                        },
                                        controller: zipcodec,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberZip = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '##########',
                                              filter: {
                                                "#": RegExp(r'[A-Za-z0-9]')
                                              },
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Zip Code'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: phoneumberc,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberContact = value;
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Phone Number'),
                                        // validator: (value) {
                                        //   if (value!.length < 14) {
                                        //     print("lenght " + value!.length.toString());
                                        //     return 'Please enter your contact number';
                                        //   }
                                        //   print("lenght " + value!.length.toString());
                                        //   return null;
                                        // },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '(###) ###-####',
                                              filter: {"#": RegExp(r'[0-9]')},
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        validator: (value) {
                                          if (value!.length < 9&&value!.length!=0) {
                                            print("lenght " +
                                                value!.length.toString());
                                            return 'Please enter your ssn number';
                                          }
                                          print("lenght " +
                                              value!.length.toString());
                                          return null;
                                        },
                                        controller: ssnc,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberSSN = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '#########',
                                              filter: {"#": RegExp(r'[0-9]')},
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'SSN'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: occupationc,
                                        onChanged: (String? value) {
                                          setState(() {
                                            _formKey.currentState!.validate();
                                          });
                                          context
                                              .read<UserData>()
                                              .subscriberOccupation = value;
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Occupation'),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),

                          Visibility(
                            visible: ifh == 4,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey[200],
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                padding: EdgeInsets.all(8.0),
                                child: Column(
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: namec,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberEmployerName = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '########################',
                                              filter: {
                                                "#": RegExp(r'[a-zA-Z]')
                                              },
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Name'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: addresscc,
                                        onChanged: (String? value) {
                                          setState(() {
                                            _formKey.currentState!.validate();
                                          });
                                          context
                                                  .read<UserData>()
                                                  .subscriberEmployerAddress =
                                              value;
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Address'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: citycc,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberEmployerCity = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '########################',
                                              filter: {
                                                "#": RegExp(r'[a-zA-Z]')
                                              },
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'City'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: statecc,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();
                                          context
                                              .read<UserData>()
                                              .subscriberEmployerState = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '########################',
                                              filter: {
                                                "#": RegExp(r'[a-zA-Z]')
                                              },
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'State'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: zipcc,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberEmployerZip = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '##########',
                                              filter: {
                                                "#": RegExp(r'[A-Za-z0-9]')
                                              },
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Zip Code'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: phonecc,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .subscriberEmployerPhone = value;
                                        },
                                        inputFormatters: [
                                          MaskTextInputFormatter(
                                              mask: '(###) ###-####',
                                              filter: {"#": RegExp(r'[0-9]')},
                                              type: MaskAutoCompletionType.lazy)
                                        ],
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Phone'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: effectivecc,
                                        onChanged: (String? value) {
                                          _formKey.currentState!.validate();

                                          context
                                              .read<UserData>()
                                              .planEffectiveDate = value;
                                        },
                                        onTap: () async {
                                          DateTime? dob = await showDatePicker(
                                              context: context,
                                              initialDate: DateTime.now(),
                                              firstDate: DateTime(1900),
                                              lastDate: DateTime.now());
                                          if (dob != null) {
                                            context
                                                    .read<UserData>()
                                                    .planEffectiveDate =
                                                "${dob.year}-${dob.month < 10 ? "0${dob.month}" : dob.month}-${dob.day < 10 ? "0${dob.day}" : dob.day}T14:21:25.017Z";
                                            effectivecc.text =
                                                "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                                            // Do something with the selected date
                                          }
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Effective Date'),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: terminationcc,
                                        onChanged: (String? value) {
                                          setState(() {
                                            _formKey.currentState!.validate();
                                          });
                                          context
                                              .read<UserData>()
                                              .planTerminationDate = value;
                                        },
                                        onTap: () async {
                                          DateTime? dob = await showDatePicker(
                                              context: context,
                                              initialDate: DateTime.now(),
                                              firstDate: DateTime(1900),
                                              lastDate: DateTime.now());
                                          if (dob != null) {
                                            context
                                                    .read<UserData>()
                                                    .planTerminationDate =
                                                "${dob.year}-${dob.month < 10 ? "0${dob.month}" : dob.month}-${dob.day < 10 ? "0${dob.day}" : dob.day}T14:21:25.017Z";
                                            terminationcc.text =
                                                "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                                            // Do something with the selected date
                                          }
                                        },
                                        decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            labelText: 'Termination Date'),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        ]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
