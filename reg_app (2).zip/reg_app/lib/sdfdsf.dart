//   //print("kmx" + context.read<UserData>().terenid!);
// // if(genders.!=null)
// // name[127-2].text="";
//     //print("kmx" + context.read<UserData>().terenid!);
// // if(genders!.patientReg?.firstName!=null)
// // name[128-2].text="";
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.internetFind != null) {
//       name[129 - 6].text = genders!.patientMarketingDetails?.internetFind == 1
//           ? "True"
//           : "False";
//     }
//     //print("sdf" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.facebook != null) {
//       name[130 - 6].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.tv != null) {
//       name[174].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.mapSearch != null) {
//       name[132 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.onlineReviews != null) {
//       name[133 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.radio != null) {
//       name[134 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.googleSearch != null) {
//       name[135 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.familyFriend != null) {
//       name[136 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.familyFriendText != null) {
//       name[137 - 7].text = genders!.patientMarketingDetails!.familyFriendText!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.youTube != null) {
//       name[138 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.brochure != null) {
//       name[139 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
// // if(genders!.patientMarketingDetails?.familyFriendText!=null)
// // name[140-3].text="";
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.directMail != null) {
//       name[141 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.linkedIn != null) {
//       name[142 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.urgentCare != null) {
//       name[143 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.urgentCareText != null) {
//       name[144 - 7].text = genders!.patientMarketingDetails!.urgentCareText!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.twitter != null) {
//       name[145 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.school != null) {
//       name[146 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.schoolText != null) {
//       name[147 - 7].text = genders!.patientMarketingDetails!.schoolText!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.onlineAdvertisements != null) {
//       name[148 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.newspaper != null) {
//       name[149 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.newspaperText != null) {
//       name[150 - 7].text = genders!.patientMarketingDetails!.newspaperText!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.emailBlast != null) {
//       name[151 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.hotel != null) {
//       name[152 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.hotelText != null) {
//       name[153 - 7].text = genders!.patientMarketingDetails!.hotelText!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.citizensDeTar != null) {
//       name[154 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.liveWorkNearby != null) {
//       name[155 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.employerSentMe != null) {
//       name[156 - 7].text = "Yes";
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientMarketingDetails?.employerSentMeText != null) {
//       name[157 - 7].text =
//           genders!.patientMarketingDetails!.employerSentMeText!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientReg?.phNumber != null) {
//       name[158 - 7].text = genders!.patientReg!.phNumber!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientPhysicianDetails?.primaryCarePhysicianName != null) {
//       name[159 - 7].text =
//           genders!.patientPhysicianDetails!.primaryCarePhysicianName!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
// // if(genders!.patientPhysicianDetails?.primaryCarePhysicianName!=null)
// // name[160-3].text="";
//     //print("kmx" + context.read<UserData>().terenid!);
// // if(genders.!=null)
// // name[161-3].text="";
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientReg?.firstName != null) {
//       name[162 - 7].text = genders!.patientReg!.firstName!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientReg?.middleInitial != null) {
//       name[163 - 7].text = genders!.patientReg!.middleInitial!;
//     }
//     //print("kmx" + context.read<UserData>().terenid!);
// // if(genders!.patientReg?.middleInitial!=null)
//     name[164 - 7].text = new DateTime.now().toString().substring(0, 10);
//     //print("kmx" + context.read<UserData>().terenid!);
// // if(genders.!=null)
// // name[165-3].text="";
//     //print("kmx" + context.read<UserData>().terenid!);

// // if(genders.!=null)
// // name[166-3].text="";
//     //print("kmx" + context.read<UserData>().terenid!);
//     if (genders!.patientReg?.lastName != null) {
//       name[167 - 7].text = genders!.patientReg!.lastName!;
//     }
//     //print("sdf" + context.read<UserData>().terenid!);
//     if (context.read<UserData>().terenid != null) {
//       name[168 - 7].text = context.read<UserData>().terenid == "8"
//           ? "GTEC Orange"
//           : context.read<UserData>().terenid == "9"
//               ? "Victoria-ER"
//               : context.read<UserData>().terenid == "10"
//                   ? "Excel-ER-Odessa"
//                   : context.read<UserData>().terenid == "17"
//                       ? "Excel ER Nacogdoches"
//                       : context.read<UserData>().terenid == "19"
//                           ? "Hope ER- Lufkin"
//                           : context.read<UserData>().terenid == "27"
//                               ? "Frontline-ER"
//                               : context.read<UserData>().terenid == "28"
//                                   ? "ER-Dallas"
//                                   : context.read<UserData>().terenid == "29"
//                                       ? "Frontline-Richmond"
//                                       : context.read<UserData>().terenid == "39"
//                                           ? "PRO CARE SCHERTZ"
//                                           : context.read<UserData>().terenid ==
//                                                   "40"
//                                               ? "PRO CARE FLORESVILLE"
//                                               : context
//                                                           .read<UserData>()
//                                                           .terenid ==
//                                                       "46"
//                                                   ? "Rice Emergency"
//                                                   : context
//                                                               .read<UserData>()
//                                                               .terenid ==
//                                                           "47"
//                                                       ? "ER Now"
//                                                       : context
//                                                                   .read<
//                                                                       UserData>()
//                                                                   .terenid ==
//                                                               "48"
//                                                           ? "TECC - Pearland"
//                                                           : context
//                                                                       .read<
//                                                                           UserData>()
//                                                                       .terenid ==
//                                                                   "49"
//                                                               ? "FairField Emergency Room"
//                                                               : "";
//       //print("kmx" + context.read<UserData>().terenid!);
//     }
//     if (genders!.patientReg!.firstName != null)
//       name[169 - 7].text =
//           ('${genders!.patientReg!.firstName!} ${genders!.patientReg!.lastName!}');
//     //print("kmx" + context.read<UserData>().terenid!);
//     // if (genders!.patientReg?.firstName != null) {
//       name[169].text ="*";
//     //       ('${genders!.patientReg!.firstName!} ${genders!.patientReg!.lastName!}');
//     // }
//     //print("kmx" + context.read<UserData>().terenid!);
//     // if (genders!.patientReg?.dob != null) {
//     //   name[171 -3].text = genders!.patientReg!.dob!.substring(0, 10);
//     // }
//     //print("ghjk" + context.read<UserData>().terenid!);
// // if(genders.!=null)
// // name[172].text="";
// // if(genders.!=null)
// // name[173].text="";
// // if(genders.!=null)
// // name[174].text="";