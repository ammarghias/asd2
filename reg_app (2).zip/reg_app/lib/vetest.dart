
import 'dart:convert';

pateintdetaiols pateintdetaiolsFromJson(String str) => pateintdetaiols.fromJson(json.decode(str));

String pateintdetaiolsToJson(pateintdetaiols data) => json.encode(data.toJson());

class pateintdetaiols {
    PatientReg? patientReg;
    List<PatientEthnicityList>? patientEthnicityList;
    VisitDetails? recentVisit;
    PatientPhysicianDetails? patientPhysicianDetails;
    PatientCovidDetails? patientCovidDetails;
    PatientGuarantorDetails? patientGuarantorDetails;
    List<PatientInsuranceDetail>? patientHealthInsuranceDetails;
    PatientEmergencyContactDetails? patientEmergencyContactDetails;
    PatientMarketingDetails? patientMarketingDetails;
    PatientDocumentsDetails? patientDocumentsDetails;

    pateintdetaiols({
        this.patientReg,
        this.patientEthnicityList,
        this.recentVisit,
        this.patientPhysicianDetails,
        this.patientCovidDetails,
        this.patientGuarantorDetails,
        this.patientHealthInsuranceDetails,
        this.patientEmergencyContactDetails,
        this.patientMarketingDetails,
        this.patientDocumentsDetails,
    });

    factory pateintdetaiols.fromJson(Map<String, dynamic> json) => pateintdetaiols(
        patientReg: json["patientReg"] == null ? null : PatientReg.fromJson(json["patientReg"]),
        patientEthnicityList: json["patientEthnicityList"] == null ? [] : List<PatientEthnicityList>.from(json["patientEthnicityList"]!.map((x) => PatientEthnicityList.fromJson(x))),
        recentVisit: json["recentVisit"] == null ? null : VisitDetails.fromJson(json["recentVisit"]),
        patientPhysicianDetails: json["patientPhysicianDetails"] == null ? null : PatientPhysicianDetails.fromJson(json["patientPhysicianDetails"]),
        patientCovidDetails: json["patientCovidDetails"] == null ? null : PatientCovidDetails.fromJson(json["patientCovidDetails"]),
        patientGuarantorDetails: json["patientGuarantorDetails"] == null ? null : PatientGuarantorDetails.fromJson(json["patientGuarantorDetails"]),
        patientHealthInsuranceDetails: json["patientHealthInsuranceDetails"] == null ? [] : List<PatientInsuranceDetail>.from(json["patientHealthInsuranceDetails"]!.map((x) => PatientInsuranceDetail.fromJson(x))),
        patientEmergencyContactDetails: json["patientEmergencyContactDetails"] == null ? null : PatientEmergencyContactDetails.fromJson(json["patientEmergencyContactDetails"]),
        patientMarketingDetails: json["patientMarketingDetails"] == null ? null : PatientMarketingDetails.fromJson(json["patientMarketingDetails"]),
        patientDocumentsDetails: json["patientDocumentsDetails"] == null ? null : PatientDocumentsDetails.fromJson(json["patientDocumentsDetails"]),
    );

    Map<String, dynamic> toJson() => {
        "patientReg": patientReg?.toJson(),
        "patientEthnicityList": patientEthnicityList == null ? [] : List<dynamic>.from(patientEthnicityList!.map((x) => x.toJson())),
        "recentVisit": recentVisit?.toJson(),
        "patientPhysicianDetails": patientPhysicianDetails?.toJson(),
        "patientCovidDetails": patientCovidDetails?.toJson(),
        "patientGuarantorDetails": patientGuarantorDetails?.toJson(),
        "patientHealthInsuranceDetails": patientHealthInsuranceDetails == null ? [] : List<dynamic>.from(patientHealthInsuranceDetails!.map((x) => x.toJson())),
        "patientEmergencyContactDetails": patientEmergencyContactDetails?.toJson(),
        "patientMarketingDetails": patientMarketingDetails?.toJson(),
        "patientDocumentsDetails": patientDocumentsDetails?.toJson(),
    };
}

class PatientCovidDetails {
    int? sympCheckCovid;
    int? covidTestForTravelCheck;
    DateTime? dateSympOnset;
    bool? sympFever;
    bool? sympCough;
    bool? sympShortBreath;
    bool? sympFatigue;
    bool? sympMuscBodyAches;
    bool? sympHeadache;
    bool? sympLossTaste;
    bool? sympSoreThroat;
    bool? sympCongestionRunNos;
    bool? sympNauseaVomit;
    bool? sympDiarrhea;
    bool? sympPerPainChest;
    bool? sympNewConfusion;
    bool? sympInabWake;
    bool? sympOthers;
    String? sympOthersTxt;
    int? employedInHealthCareCheck;
    int? covidPositiveBeforeCheck;
    DateTime? covidPositiveBeforeDate;
    int? exposedDirectContactCovidCheck;
    DateTime? exposedDirectContactCovidDate;
    int? outsideCountryTravelCheck;
    DateTime? outsideCountryTravelDate;
    String? outsideCountryTravelDestination;
    String? outsideCountryTravelDuration;

    PatientCovidDetails({
        this.sympCheckCovid,
        this.covidTestForTravelCheck,
        this.dateSympOnset,
        this.sympFever,
        this.sympCough,
        this.sympShortBreath,
        this.sympFatigue,
        this.sympMuscBodyAches,
        this.sympHeadache,
        this.sympLossTaste,
        this.sympSoreThroat,
        this.sympCongestionRunNos,
        this.sympNauseaVomit,
        this.sympDiarrhea,
        this.sympPerPainChest,
        this.sympNewConfusion,
        this.sympInabWake,
        this.sympOthers,
        this.sympOthersTxt,
        this.employedInHealthCareCheck,
        this.covidPositiveBeforeCheck,
        this.covidPositiveBeforeDate,
        this.exposedDirectContactCovidCheck,
        this.exposedDirectContactCovidDate,
        this.outsideCountryTravelCheck,
        this.outsideCountryTravelDate,
        this.outsideCountryTravelDestination,
        this.outsideCountryTravelDuration,
    });

    factory PatientCovidDetails.fromJson(Map<String, dynamic> json) => PatientCovidDetails(
        sympCheckCovid: json["sympCheckCovid"],
        covidTestForTravelCheck: json["covidTestForTravelCheck"],
        dateSympOnset: json["dateSympOnset"] == null ? null : DateTime.parse(json["dateSympOnset"]),
        sympFever: json["sympFever"],
        sympCough: json["sympCough"],
        sympShortBreath: json["sympShortBreath"],
        sympFatigue: json["sympFatigue"],
        sympMuscBodyAches: json["sympMuscBodyAches"],
        sympHeadache: json["sympHeadache"],
        sympLossTaste: json["sympLossTaste"],
        sympSoreThroat: json["sympSoreThroat"],
        sympCongestionRunNos: json["sympCongestionRunNos"],
        sympNauseaVomit: json["sympNauseaVomit"],
        sympDiarrhea: json["sympDiarrhea"],
        sympPerPainChest: json["sympPerPainChest"],
        sympNewConfusion: json["sympNewConfusion"],
        sympInabWake: json["sympInabWake"],
        sympOthers: json["sympOthers"],
        sympOthersTxt: json["sympOthersTxt"],
        employedInHealthCareCheck: json["employedInHealthCareCheck"],
        covidPositiveBeforeCheck: json["covidPositiveBeforeCheck"],
        covidPositiveBeforeDate: json["covidPositiveBeforeDate"] == null ? null : DateTime.parse(json["covidPositiveBeforeDate"]),
        exposedDirectContactCovidCheck: json["exposedDirectContactCovidCheck"],
        exposedDirectContactCovidDate: json["exposedDirectContactCovidDate"] == null ? null : DateTime.parse(json["exposedDirectContactCovidDate"]),
        outsideCountryTravelCheck: json["outsideCountryTravelCheck"],
        outsideCountryTravelDate: json["outsideCountryTravelDate"] == null ? null : DateTime.parse(json["outsideCountryTravelDate"]),
        outsideCountryTravelDestination: json["outsideCountryTravelDestination"],
        outsideCountryTravelDuration: json["outsideCountryTravelDuration"],
    );

    Map<String, dynamic> toJson() => {
        "sympCheckCovid": sympCheckCovid,
        "covidTestForTravelCheck": covidTestForTravelCheck,
        "dateSympOnset": dateSympOnset?.toIso8601String(),
        "sympFever": sympFever,
        "sympCough": sympCough,
        "sympShortBreath": sympShortBreath,
        "sympFatigue": sympFatigue,
        "sympMuscBodyAches": sympMuscBodyAches,
        "sympHeadache": sympHeadache,
        "sympLossTaste": sympLossTaste,
        "sympSoreThroat": sympSoreThroat,
        "sympCongestionRunNos": sympCongestionRunNos,
        "sympNauseaVomit": sympNauseaVomit,
        "sympDiarrhea": sympDiarrhea,
        "sympPerPainChest": sympPerPainChest,
        "sympNewConfusion": sympNewConfusion,
        "sympInabWake": sympInabWake,
        "sympOthers": sympOthers,
        "sympOthersTxt": sympOthersTxt,
        "employedInHealthCareCheck": employedInHealthCareCheck,
        "covidPositiveBeforeCheck": covidPositiveBeforeCheck,
        "covidPositiveBeforeDate": covidPositiveBeforeDate?.toIso8601String(),
        "exposedDirectContactCovidCheck": exposedDirectContactCovidCheck,
        "exposedDirectContactCovidDate": exposedDirectContactCovidDate?.toIso8601String(),
        "outsideCountryTravelCheck": outsideCountryTravelCheck,
        "outsideCountryTravelDate": outsideCountryTravelDate?.toIso8601String(),
        "outsideCountryTravelDestination": outsideCountryTravelDestination,
        "outsideCountryTravelDuration": outsideCountryTravelDuration,
    };
}

class PatientDocumentsDetails {
    int? hasIdFront;
    String? idFrontFileName;
    int? hasInsFront;
    String? insFrontFileName;
    int? hasInsBack;
    String? insBackFileName;

    PatientDocumentsDetails({
        this.hasIdFront,
        this.idFrontFileName,
        this.hasInsFront,
        this.insFrontFileName,
        this.hasInsBack,
        this.insBackFileName,
    });

    factory PatientDocumentsDetails.fromJson(Map<String, dynamic> json) => PatientDocumentsDetails(
        hasIdFront: json["hasIdFront"],
        idFrontFileName: json["idFrontFileName"],
        hasInsFront: json["hasInsFront"],
        insFrontFileName: json["insFrontFileName"],
        hasInsBack: json["hasInsBack"],
        insBackFileName: json["insBackFileName"],
    );

    Map<String, dynamic> toJson() => {
        "hasIdFront": hasIdFront,
        "idFrontFileName": idFrontFileName,
        "hasInsFront": hasInsFront,
        "insFrontFileName": insFrontFileName,
        "hasInsBack": hasInsBack,
        "insBackFileName": insBackFileName,
    };
}

class PatientEmergencyContactDetails {
    String? firstName;
    String? lastName;
    String? phoneNumber;
    String? patientEmergencyRelation;
    String? leaveMessage;
    String? address;
    String? city;
    String? state;
    String? country;
    String? zipCode;

    PatientEmergencyContactDetails({
        this.firstName,
        this.lastName,
        this.phoneNumber,
        this.patientEmergencyRelation,
        this.leaveMessage,
        this.address,
        this.city,
        this.state,
        this.country,
        this.zipCode,
    });

    factory PatientEmergencyContactDetails.fromJson(Map<String, dynamic> json) => PatientEmergencyContactDetails(
        firstName: json["firstName"],
        lastName: json["lastName"],
        phoneNumber: json["phoneNumber"],
        patientEmergencyRelation: json["patientEmergencyRelation"],
        leaveMessage: json["leaveMessage"],
        address: json["address"],
        city: json["city"],
        state: json["state"],
        country: json["country"],
        zipCode: json["zipCode"],
    );

    Map<String, dynamic> toJson() => {
        "firstName": firstName,
        "lastName": lastName,
        "phoneNumber": phoneNumber,
        "patientEmergencyRelation": patientEmergencyRelation,
        "leaveMessage": leaveMessage,
        "address": address,
        "city": city,
        "state": state,
        "country": country,
        "zipCode": zipCode,
    };
}

class PatientEthnicityList {
    int? ethnicityId;
    String? ethnicity;

    PatientEthnicityList({
        this.ethnicityId,
        this.ethnicity,
    });

    factory PatientEthnicityList.fromJson(Map<String, dynamic> json) => PatientEthnicityList(
        ethnicityId: json["ethnicityId"],
        ethnicity: json["ethnicity"],
    );

    Map<String, dynamic> toJson() => {
        "ethnicityId": ethnicityId,
        "ethnicity": ethnicity,
    };
}

class PatientGuarantorDetails {
    String? guarantorCheck;
    String? patientMinorCheck;
    String? guarantorFirstName;
    String? guarantorLastName;
    String? guarantorPhoneNumber;
    String? guarantorSsn;
    String? guarantorEmployerName;
    String? guarantorEmployerPhoneNumber;
    String? guarantorEmployerCity;
    String? guarantorEmployerState;
    String? guarantorEmployerZip;
    String? guarantorEmployerAddress1;
    String? guarantorEmployerAddress2;
    DateTime? guarantorDob;

    PatientGuarantorDetails({
        this.guarantorCheck,
        this.patientMinorCheck,
        this.guarantorFirstName,
        this.guarantorLastName,
        this.guarantorPhoneNumber,
        this.guarantorSsn,
        this.guarantorEmployerName,
        this.guarantorEmployerPhoneNumber,
        this.guarantorEmployerCity,
        this.guarantorEmployerState,
        this.guarantorEmployerZip,
        this.guarantorEmployerAddress1,
        this.guarantorEmployerAddress2,
        this.guarantorDob,
    });

    factory PatientGuarantorDetails.fromJson(Map<String, dynamic> json) => PatientGuarantorDetails(
        guarantorCheck: json["guarantorCheck"],
        patientMinorCheck: json["patientMinorCheck"],
        guarantorFirstName: json["guarantorFirstName"],
        guarantorLastName: json["guarantorLastName"],
        guarantorPhoneNumber: json["guarantorPhoneNumber"],
        guarantorSsn: json["guarantorSSN"],
        guarantorEmployerName: json["guarantorEmployerName"],
        guarantorEmployerPhoneNumber: json["guarantorEmployerPhoneNumber"],
        guarantorEmployerCity: json["guarantorEmployerCity"],
        guarantorEmployerState: json["guarantorEmployerState"],
        guarantorEmployerZip: json["guarantorEmployerZip"],
        guarantorEmployerAddress1: json["guarantorEmployerAddress1"],
        guarantorEmployerAddress2: json["guarantorEmployerAddress2"],
        guarantorDob: json["guarantorDOB"] == null ? null : DateTime.parse(json["guarantorDOB"]),
    );

    Map<String, dynamic> toJson() => {
        "guarantorCheck": guarantorCheck,
        "patientMinorCheck": patientMinorCheck,
        "guarantorFirstName": guarantorFirstName,
        "guarantorLastName": guarantorLastName,
        "guarantorPhoneNumber": guarantorPhoneNumber,
        "guarantorSSN": guarantorSsn,
        "guarantorEmployerName": guarantorEmployerName,
        "guarantorEmployerPhoneNumber": guarantorEmployerPhoneNumber,
        "guarantorEmployerCity": guarantorEmployerCity,
        "guarantorEmployerState": guarantorEmployerState,
        "guarantorEmployerZip": guarantorEmployerZip,
        "guarantorEmployerAddress1": guarantorEmployerAddress1,
        "guarantorEmployerAddress2": guarantorEmployerAddress2,
        "guarantorDOB": guarantorDob?.toIso8601String(),
    };
}

class PatientInsuranceDetail {
    int? id;
    PriorityObj? priorityObj;
    TypeObj? typeObj;
    Insurance? insurance;
    String? memberId;
    String? groupNumber;
    String? relationToPatient;
    String? subscriberFirstName;
    String? subscriberLastName;
    DateTime? subscriberDob;
    String? subscriberGender;
    String? subscriberSsn;
    String? subscriberAddress;
    String? subscriberCity;
    String? subscriberState;
    String? subscriberZip;
    String? subscriberOccupation;
    String? subscriberEmployerName;
    String? subscriberEmployerAddress;
    String? subscriberEmployerCity;
    String? subscriberEmployerState;
    String? subscriberEmployerZip;
    String? subscriberEmployerPhone;
    DateTime? planEffectiveDate;
    int? isDefault;
    int? isActive;
    String? subscriberContact;
    String? otherInsuranceName;
    String? inmateNumber;
    DateTime? planTerminationDate;

    PatientInsuranceDetail({
        this.id,
        this.priorityObj,
        this.typeObj,
        this.insurance,
        this.memberId,
        this.groupNumber,
        this.relationToPatient,
        this.subscriberFirstName,
        this.subscriberLastName,
        this.subscriberDob,
        this.subscriberGender,
        this.subscriberSsn,
        this.subscriberAddress,
        this.subscriberCity,
        this.subscriberState,
        this.subscriberZip,
        this.subscriberOccupation,
        this.subscriberEmployerName,
        this.subscriberEmployerAddress,
        this.subscriberEmployerCity,
        this.subscriberEmployerState,
        this.subscriberEmployerZip,
        this.subscriberEmployerPhone,
        this.planEffectiveDate,
        this.isDefault,
        this.isActive,
        this.subscriberContact,
        this.otherInsuranceName,
        this.inmateNumber,
        this.planTerminationDate,
    });

    factory PatientInsuranceDetail.fromJson(Map<String, dynamic> json) => PatientInsuranceDetail(
        id: json["id"],
        priorityObj: json["priorityObj"] == null ? null : PriorityObj.fromJson(json["priorityObj"]),
        typeObj: json["typeObj"] == null ? null : TypeObj.fromJson(json["typeObj"]),
        insurance: json["insurance"] == null ? null : Insurance.fromJson(json["insurance"]),
        memberId: json["memberId"],
        groupNumber: json["groupNumber"],
        relationToPatient: json["relationToPatient"],
        subscriberFirstName: json["subscriberFirstName"],
        subscriberLastName: json["subscriberLastName"],
        subscriberDob: json["subscriberDOB"] == null ? null : DateTime.parse(json["subscriberDOB"]),
        subscriberGender: json["subscriberGender"],
        subscriberSsn: json["subscriberSSN"],
        subscriberAddress: json["subscriberAddress"],
        subscriberCity: json["subscriberCity"],
        subscriberState: json["subscriberState"],
        subscriberZip: json["subscriberZip"],
        subscriberOccupation: json["subscriberOccupation"],
        subscriberEmployerName: json["subscriberEmployerName"],
        subscriberEmployerAddress: json["subscriberEmployerAddress"],
        subscriberEmployerCity: json["subscriberEmployerCity"],
        subscriberEmployerState: json["subscriberEmployerState"],
        subscriberEmployerZip: json["subscriberEmployerZip"],
        subscriberEmployerPhone: json["subscriberEmployerPhone"],
        planEffectiveDate: json["planEffectiveDate"] == null ? null : DateTime.parse(json["planEffectiveDate"]),
        isDefault: json["isDefault"],
        isActive: json["isActive"],
        subscriberContact: json["subscriberContact"],
        otherInsuranceName: json["otherInsuranceName"],
        inmateNumber: json["inmateNumber"],
        planTerminationDate: json["planTerminationDate"] == null ? null : DateTime.parse(json["planTerminationDate"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "priorityObj": priorityObj?.toJson(),
        "typeObj": typeObj?.toJson(),
        "insurance": insurance?.toJson(),
        "memberId": memberId,
        "groupNumber": groupNumber,
        "relationToPatient": relationToPatient,
        "subscriberFirstName": subscriberFirstName,
        "subscriberLastName": subscriberLastName,
        "subscriberDOB": subscriberDob?.toIso8601String(),
        "subscriberGender": subscriberGender,
        "subscriberSSN": subscriberSsn,
        "subscriberAddress": subscriberAddress,
        "subscriberCity": subscriberCity,
        "subscriberState": subscriberState,
        "subscriberZip": subscriberZip,
        "subscriberOccupation": subscriberOccupation,
        "subscriberEmployerName": subscriberEmployerName,
        "subscriberEmployerAddress": subscriberEmployerAddress,
        "subscriberEmployerCity": subscriberEmployerCity,
        "subscriberEmployerState": subscriberEmployerState,
        "subscriberEmployerZip": subscriberEmployerZip,
        "subscriberEmployerPhone": subscriberEmployerPhone,
        "planEffectiveDate": planEffectiveDate?.toIso8601String(),
        "isDefault": isDefault,
        "isActive": isActive,
        "subscriberContact": subscriberContact,
        "otherInsuranceName": otherInsuranceName,
        "inmateNumber": inmateNumber,
        "planTerminationDate": planTerminationDate?.toIso8601String(),
    };
}

class Insurance {
    int? id;
    String? payerName;

    Insurance({
        this.id,
        this.payerName,
    });

    factory Insurance.fromJson(Map<String, dynamic> json) => Insurance(
        id: json["id"],
        payerName: json["payerName"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "payerName": payerName,
    };
}

class PriorityObj {
    int? id;
    String? priority;

    PriorityObj({
        this.id,
        this.priority,
    });

    factory PriorityObj.fromJson(Map<String, dynamic> json) => PriorityObj(
        id: json["id"],
        priority: json["priority"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "priority": priority,
    };
}

class TypeObj {
    int? id;
    String? type;

    TypeObj({
        this.id,
        this.type,
    });

    factory TypeObj.fromJson(Map<String, dynamic> json) => TypeObj(
        id: json["id"],
        type: json["type"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "type": type,
    };
}

class PatientMarketingDetails {
    int? repeatPatient;
    int? internetFind;
    bool? facebook;
    bool? mapSearch;
    bool? googleSearch;
    bool? website;
    bool? websiteAds;
    bool? onlineReviews;
    bool? twitter;
    bool? linkedIn;
    bool? emailBlast;
    bool? youTube;
    bool? onlineAdvertisements;
    bool? tv;
    bool? billboard;
    bool? radio;
    bool? buildingSignDriveBy;
    bool? brochure;
    bool? directMail;
    bool? citizensDeTar;
    bool? liveWorkNearby;
    bool? school;
    String? schoolText;
    bool? magazine;
    String? magazineText;
    bool? urgentCare;
    String? urgentCareText;
    bool? familyFriend;
    String? familyFriendText;
    bool? newspaper;
    String? newspaperText;
    bool? hotel;
    String? hotelText;
    bool? employerSentMe;
    String? employerSentMeText;
    bool? communityEvent;
    String? communityEventText;
    String? refPhysicianName;
    String? refPhysicianPhone;
    String? refWorkName;
    String? refWorkPhone;
    String? refOtherName;
    String? refOtherPhone;

    PatientMarketingDetails({
        this.repeatPatient,
        this.internetFind,
        this.facebook,
        this.mapSearch,
        this.googleSearch,
        this.website,
        this.websiteAds,
        this.onlineReviews,
        this.twitter,
        this.linkedIn,
        this.emailBlast,
        this.youTube,
        this.onlineAdvertisements,
        this.tv,
        this.billboard,
        this.radio,
        this.buildingSignDriveBy,
        this.brochure,
        this.directMail,
        this.citizensDeTar,
        this.liveWorkNearby,
        this.school,
        this.schoolText,
        this.magazine,
        this.magazineText,
        this.urgentCare,
        this.urgentCareText,
        this.familyFriend,
        this.familyFriendText,
        this.newspaper,
        this.newspaperText,
        this.hotel,
        this.hotelText,
        this.employerSentMe,
        this.employerSentMeText,
        this.communityEvent,
        this.communityEventText,
        this.refPhysicianName,
        this.refPhysicianPhone,
        this.refWorkName,
        this.refWorkPhone,
        this.refOtherName,
        this.refOtherPhone,
    });

    factory PatientMarketingDetails.fromJson(Map<String, dynamic> json) => PatientMarketingDetails(
        repeatPatient: json["repeatPatient"],
        internetFind: json["internetFind"],
        facebook: json["facebook"],
        mapSearch: json["mapSearch"],
        googleSearch: json["googleSearch"],
        website: json["website"],
        websiteAds: json["websiteAds"],
        onlineReviews: json["onlineReviews"],
        twitter: json["twitter"],
        linkedIn: json["linkedIn"],
        emailBlast: json["emailBlast"],
        youTube: json["youTube"],
        onlineAdvertisements: json["onlineAdvertisements"],
        tv: json["tv"],
        billboard: json["billboard"],
        radio: json["radio"],
        buildingSignDriveBy: json["buildingSignDriveBy"],
        brochure: json["brochure"],
        directMail: json["directMail"],
        citizensDeTar: json["citizensDeTar"],
        liveWorkNearby: json["liveWorkNearby"],
        school: json["school"],
        schoolText: json["schoolText"],
        magazine: json["magazine"],
        magazineText: json["magazineText"],
        urgentCare: json["urgentCare"],
        urgentCareText: json["urgentCareText"],
        familyFriend: json["familyFriend"],
        familyFriendText: json["familyFriendText"],
        newspaper: json["newspaper"],
        newspaperText: json["newspaperText"],
        hotel: json["hotel"],
        hotelText: json["hotelText"],
        employerSentMe: json["employerSentMe"],
        employerSentMeText: json["employerSentMeText"],
        communityEvent: json["communityEvent"],
        communityEventText: json["communityEventText"],
        refPhysicianName: json["refPhysicianName"],
        refPhysicianPhone: json["refPhysicianPhone"],
        refWorkName: json["refWorkName"],
        refWorkPhone: json["refWorkPhone"],
        refOtherName: json["refOtherName"],
        refOtherPhone: json["refOtherPhone"],
    );

    Map<String, dynamic> toJson() => {
        "repeatPatient": repeatPatient,
        "internetFind": internetFind,
        "facebook": facebook,
        "mapSearch": mapSearch,
        "googleSearch": googleSearch,
        "website": website,
        "websiteAds": websiteAds,
        "onlineReviews": onlineReviews,
        "twitter": twitter,
        "linkedIn": linkedIn,
        "emailBlast": emailBlast,
        "youTube": youTube,
        "onlineAdvertisements": onlineAdvertisements,
        "tv": tv,
        "billboard": billboard,
        "radio": radio,
        "buildingSignDriveBy": buildingSignDriveBy,
        "brochure": brochure,
        "directMail": directMail,
        "citizensDeTar": citizensDeTar,
        "liveWorkNearby": liveWorkNearby,
        "school": school,
        "schoolText": schoolText,
        "magazine": magazine,
        "magazineText": magazineText,
        "urgentCare": urgentCare,
        "urgentCareText": urgentCareText,
        "familyFriend": familyFriend,
        "familyFriendText": familyFriendText,
        "newspaper": newspaper,
        "newspaperText": newspaperText,
        "hotel": hotel,
        "hotelText": hotelText,
        "employerSentMe": employerSentMe,
        "employerSentMeText": employerSentMeText,
        "communityEvent": communityEvent,
        "communityEventText": communityEventText,
        "refPhysicianName": refPhysicianName,
        "refPhysicianPhone": refPhysicianPhone,
        "refWorkName": refWorkName,
        "refWorkPhone": refWorkPhone,
        "refOtherName": refOtherName,
        "refOtherPhone": refOtherPhone,
    };
}

class PatientPhysicianDetails {
    String? primaryCarePhysicianName;
    String? primaryCarePhysicianCity;
    String? primaryCarePhysicianState;
    String? primaryCarePhysicianZip;
    String? primaryCarePhysicianAddress1;
    String? primaryCarePhysicianAddress2;
    String? specialityCarePhysicianName;
    String? specialityCarePhysicianCity;
    String? specialityCarePhysicianState;
    String? specialityCarePhysicianZip;
    String? specialityCarePhysicianAddress1;
    String? specialityCarePhysicianAddress2;

    PatientPhysicianDetails({
        this.primaryCarePhysicianName,
        this.primaryCarePhysicianCity,
        this.primaryCarePhysicianState,
        this.primaryCarePhysicianZip,
        this.primaryCarePhysicianAddress1,
        this.primaryCarePhysicianAddress2,
        this.specialityCarePhysicianName,
        this.specialityCarePhysicianCity,
        this.specialityCarePhysicianState,
        this.specialityCarePhysicianZip,
        this.specialityCarePhysicianAddress1,
        this.specialityCarePhysicianAddress2,
    });

    factory PatientPhysicianDetails.fromJson(Map<String, dynamic> json) => PatientPhysicianDetails(
        primaryCarePhysicianName: json["primaryCarePhysicianName"],
        primaryCarePhysicianCity: json["primaryCarePhysicianCity"],
        primaryCarePhysicianState: json["primaryCarePhysicianState"],
        primaryCarePhysicianZip: json["primaryCarePhysicianZip"],
        primaryCarePhysicianAddress1: json["primaryCarePhysicianAddress1"],
        primaryCarePhysicianAddress2: json["primaryCarePhysicianAddress2"],
        specialityCarePhysicianName: json["specialityCarePhysicianName"],
        specialityCarePhysicianCity: json["specialityCarePhysicianCity"],
        specialityCarePhysicianState: json["specialityCarePhysicianState"],
        specialityCarePhysicianZip: json["specialityCarePhysicianZip"],
        specialityCarePhysicianAddress1: json["specialityCarePhysicianAddress1"],
        specialityCarePhysicianAddress2: json["specialityCarePhysicianAddress2"],
    );

    Map<String, dynamic> toJson() => {
        "primaryCarePhysicianName": primaryCarePhysicianName,
        "primaryCarePhysicianCity": primaryCarePhysicianCity,
        "primaryCarePhysicianState": primaryCarePhysicianState,
        "primaryCarePhysicianZip": primaryCarePhysicianZip,
        "primaryCarePhysicianAddress1": primaryCarePhysicianAddress1,
        "primaryCarePhysicianAddress2": primaryCarePhysicianAddress2,
        "specialityCarePhysicianName": specialityCarePhysicianName,
        "specialityCarePhysicianCity": specialityCarePhysicianCity,
        "specialityCarePhysicianState": specialityCarePhysicianState,
        "specialityCarePhysicianZip": specialityCarePhysicianZip,
        "specialityCarePhysicianAddress1": specialityCarePhysicianAddress1,
        "specialityCarePhysicianAddress2": specialityCarePhysicianAddress2,
    };
}

class PatientReg {
    String? title;
    String? firstName;
    String? middleInitial;
    String? lastName;
    String? maritalStatus;
    String? dob;
    String? ssn;
    String? race;
    String? sexualOrientation;
    String? genderIdentity;
    String? phNumber;
    String? email;
    String? address1;
    String? address2;
    String? zipCode;
    String? city;
    String? state;
    String? county;
    String? country;
    String? preferredLanguage;
    String? employer;
    String? occupation;
    String? empContact;
    int? epdSync;
    int? isDraft;
    String? registerFrom;
    int? authorization;
    int? hasProfileImage;
    int? contactConsent;
    int? accurateConsent;
    String? profileImageName;
    String? sex;

    PatientReg({
        this.title,
        this.firstName,
        this.middleInitial,
        this.lastName,
        this.maritalStatus,
        this.dob,
        this.ssn,
        this.race,
        this.sexualOrientation,
        this.genderIdentity,
        this.phNumber,
        this.email,
        this.address1,
        this.address2,
        this.zipCode,
        this.city,
        this.state,
        this.county,
        this.country,
        this.preferredLanguage,
        this.employer,
        this.occupation,
        this.empContact,
        this.epdSync,
        this.isDraft,
        this.registerFrom,
        this.authorization,
        this.hasProfileImage,
        this.contactConsent,
        this.accurateConsent,
        this.profileImageName,
        this.sex,
    });

    factory PatientReg.fromJson(Map<String, dynamic> json) => PatientReg(
        title: json["title"],
        firstName: json["firstName"],
        middleInitial: json["middleInitial"],
        lastName: json["lastName"],
        maritalStatus: json["maritalStatus"],
        dob: json["dob"],
        ssn: json["ssn"],
        race: json["race"],
        sexualOrientation: json["sexualOrientation"],
        genderIdentity: json["genderIdentity"],
        phNumber: json["phNumber"],
        email: json["email"],
        address1: json["address1"],
        address2: json["address2"],
        zipCode: json["zipCode"],
        city: json["city"],
        state: json["state"],
        county: json["county"],
        country: json["country"],
        preferredLanguage: json["preferredLanguage"],
        employer: json["employer"],
        occupation: json["occupation"],
        empContact: json["empContact"],
        epdSync: json["epdSync"],
        isDraft: json["isDraft"],
        registerFrom: json["registerFrom"],
        authorization: json["authorization"],
        hasProfileImage: json["hasProfileImage"],
        contactConsent: json["contactConsent"],
        accurateConsent: json["accurateConsent"],
        profileImageName: json["profileImageName"],
        sex: json["sex"],
    );

    Map<String, dynamic> toJson() => {
        "title": title,
        "firstName": firstName,
        "middleInitial": middleInitial,
        "lastName": lastName,
        "maritalStatus": maritalStatus,
        "dob": dob,
        "ssn": ssn,
        "race": race,
        "sexualOrientation": sexualOrientation,
        "genderIdentity": genderIdentity,
        "phNumber": phNumber,
        "email": email,
        "address1": address1,
        "address2": address2,
        "zipCode": zipCode,
        "city": city,
        "state": state,
        "county": county,
        "country": country,
        "preferredLanguage": preferredLanguage,
        "employer": employer,
        "occupation": occupation,
        "empContact": empContact,
        "epdSync": epdSync,
        "isDraft": isDraft,
        "registerFrom": registerFrom,
        "authorization": authorization,
        "hasProfileImage": hasProfileImage,
        "contactConsent": contactConsent,
        "accurateConsent": accurateConsent,
        "profileImageName": profileImageName,
        "sex": sex,
    };
}

class VisitDetails {
    String? reasonVisit;
    String? reasonVisitSpecify;
    int? doctorId;

    VisitDetails({
        this.reasonVisit,
        this.reasonVisitSpecify,
        this.doctorId,
    });

    factory VisitDetails.fromJson(Map<String, dynamic> json) => VisitDetails(
        reasonVisit: json["reasonVisit"],
        reasonVisitSpecify: json["reasonVisitSpecify"],
        doctorId: json["doctorId"],
    );

    Map<String, dynamic> toJson() => {
        "reasonVisit": reasonVisit,
        "reasonVisitSpecify": reasonVisitSpecify,
        "doctorId": doctorId,
    };
}
