class AutoGenerate {
  AutoGenerate({
    required this.htmlAttributions,
    required this.result,
    required this.status,
  });
  late final List<dynamic> htmlAttributions;
  late final Result result;
  late final String status;

  AutoGenerate.fromJson(Map<String, dynamic> json) {
    htmlAttributions =
        List.castFrom<dynamic, dynamic>(json['html_attributions']);
    result = Result.fromJson(json['result']);
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['html_attributions'] = htmlAttributions;
    _data['result'] = result.toJson();
    _data['status'] = status;
    return _data;
  }
}

class Result {
  Result({
    required this.addressComponents,
  });
  late final List<AddressComponents> addressComponents;

  Result.fromJson(Map<String, dynamic> json) {
    addressComponents = List.from(json['address_components'])
        .map((e) => AddressComponents.fromJson(e))
        .toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['address_components'] =
        addressComponents.map((e) => e.toJson()).toList();
    return _data;
  }
}

class AddressComponents {
  AddressComponents({
    required this.longName,
    required this.shortName,
    required this.types,
  });
  late final String longName;
  late final String shortName;
  late final List<String> types;

  AddressComponents.fromJson(Map<String, dynamic> json) {
    longName = json['long_name'];
    shortName = json['short_name'];
    types = List.castFrom<dynamic, String>(json['types']);
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['long_name'] = longName;
    _data['short_name'] = shortName;
    _data['types'] = types;
    return _data;
  }
}
