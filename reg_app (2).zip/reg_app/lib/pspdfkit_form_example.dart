///
///  Copyright © 2018-2023 PSPDFKit GmbH. All rights reserved.
///
///  THIS SOURCE CODE AND ANY ACCOMPANYING DOCUMENTATION ARE PROTECTED BY INTERNATIONAL COPYRIGHT LAW
///  AND MAY NOT BE RESOLD OR REDISTRIBUTED. USAGE IS BOUND TO THE PSPDFKIT LICENSE AGREEMENT.
///  UNAUTHORIZED REPRODUCTION OR DISTRIBUTION IS SUBJECT TO CIVIL AND CRIMINAL PENALTIES.
///  This notice may not be removed from this file.
///

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:pspdfkit_flutter/widgets/pspdfkit_widget_controller.dart';
import 'package:pspdfkit_flutter/widgets/pspdfkit_widget.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/utils/platform_utils.dart';
import 'package:reg_app/vetest.dart';
import 'dart:typed_data';
import 'dart:io' as io;
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart' as pw;
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

typedef PspdfkitFormExampleWidgetCreatedCallback = void Function(
    PspdfkitWidgetController view);

class PspdfkitFormExampleWidget extends StatefulWidget {
  final String documentPath;
  final dynamic configuration;
  final String regid;
  const PspdfkitFormExampleWidget({
    Key? key,
    required this.documentPath,
    required this.regid,
    this.configuration,
  }) : super(key: key);

  @override
  _PspdfkitFormExampleWidgetState createState() =>
      _PspdfkitFormExampleWidgetState();
}

class _PspdfkitFormExampleWidgetState extends State<PspdfkitFormExampleWidget> {
  late PspdfkitWidgetController view;
  pateintdetaiols? genders;
  String buttontext = "sgin page 1";

  Future<pateintdetaiols> fetchData() async {
    var url = Uri.parse(
        'https://qa.rovermd.com:7685/patientExternal/${widget.regid}');
    final response = await http.get(url, headers: {
      'accept': '*/*',
      'X-TenantID': '${context.read<UserData>().terenid}',
    });
    if (response.statusCode == 200) {
      print('${widget.regid}');
      //print(response.body);
      return pateintdetaiols
          .fromJson(jsonDecode(response.body) as Map<String, dynamic>);
      // pateintdetaiols   jsonResponse = json.decode(response.body);
      // return jsonResponse;
    } else {
      //print(response.statusCode);
      throw Exception('Unexpected error occured!');
    }
  }

  initState() {
    super.initState();
    fetchData().then((genders) {
      setState(() {
        this.genders = genders;
      });
    });
  }

  bool skj = false;
  @override
  Widget build(BuildContext context) {
    final PdfViewerController _pdfViewerController = PdfViewerController();

    return Scaffold(
        extendBodyBehindAppBar: PlatformUtils.isAndroid(),
        resizeToAvoidBottomInset: PlatformUtils.isIOS(),
        appBar: AppBar(
          actions: [
            ElevatedButton(
                onPressed: () {
                  _pdfViewerController.jumpToPage(3);
                  final List<PdfFormField> formFields =
                      _pdfViewerController.getFormFields();
                  final PdfSignatureFormField signature =
                      formFields.singleWhere((PdfFormField formField) =>
                              formField.name == 'Signature')
                          as PdfSignatureFormField;

                  if (signature.signature != null) {
                    //print("dhdddascode");
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: const Text('PLZ sign the form first'),
                      action: SnackBarAction(
                        label: 'Undo',
                        onPressed: () {
                          // Some code to undo the change.
                        },
                      ),
                    ));
                  }
                  if (skj) {
                    //print("hascode");
                  } else {
                    //print("dhascode");
                  }
                },
                child: Text("Sign"))
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.fromLTRB(0, 80, 0, 0),
          child: Center(
            child: FutureBuilder<Uint8List>(
              future: generateCertificate(), // async work
              builder:
                  (BuildContext context, AsyncSnapshot<Uint8List> snapshot) {
                switch (snapshot.connectionState) {
                  case ConnectionState.waiting:
                    return const Text('Loading....');
                  default:
                    if (snapshot.hasError) {
                      return Text("");
                    } else {
                      return SfPdfViewer.memory(
                        snapshot.data!,
                        onFormFieldFocusChange: (value) {
                          final List<PdfFormField> formFields =
                              _pdfViewerController.getFormFields();
                          final PdfSignatureFormField signature =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature')
                                  as PdfSignatureFormField;
                          final PdfSignatureFormField signature1 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature of Patient')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature2 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'page3')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature3 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Psignature')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature4 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Psig')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature5 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature and Date')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature6 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'PatientParentGuardian Signature')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature7 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'signature11')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature8 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Patient Signature_2')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature9 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Patient Signature_3')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature10 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature of Patient_2')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature11 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature_2')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature12 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Patient Signature')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature13=
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'signature11')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature14 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Patient Signature_2')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature15 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Patient Signature_3')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature16 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'PatientRepresentative Signature')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature17 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'page15')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature18 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature12')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature19 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature13')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature20 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature14')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature21 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature of Patient')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature22 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature of Patient')
                                  as PdfSignatureFormField; final PdfSignatureFormField signature23 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature of Patient')
                                  as PdfSignatureFormField;
                                   final PdfSignatureFormField signature24 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature of Patient')
                                  as PdfSignatureFormField;
                          buttontext = signature.signature != null
                              ? "sgin next page"
                              : "sgin page one";
                        },
                        onFormFieldValueChanged: (value) {
                          final List<PdfFormField> formFields =
                              _pdfViewerController.getFormFields();
                          final PdfSignatureFormField signature =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature')
                                  as PdfSignatureFormField;
                          final PdfSignatureFormField signature1 =
                              formFields.singleWhere((PdfFormField formField) =>
                                      formField.name == 'Signature of Patient')
                                  as PdfSignatureFormField;
                          buttontext = signature.signature != null
                              ? "sgin next page"
                              : "sgin page one";

                          //print("dhascode");
                          List<PdfFormField> hj = _pdfViewerController
                              .getFormFields as List<PdfFormField>;
                          //print(hj[45].name);
                          skj = hj[45].hashCode == 0 ? false : true;
                        },
                        controller: _pdfViewerController,
                        enableTextSelection: false,
                      );
                    }
                }
              },
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () {
            _pdfViewerController.jumpToPage(1);
            final List<PdfFormField> formFields =
                _pdfViewerController.getFormFields();
            final PdfSignatureFormField signature = formFields.singleWhere(
                    (PdfFormField formField) => formField.name == 'Signature')
                as PdfSignatureFormField;
            final PdfSignatureFormField signature1 = formFields.singleWhere(
                    (PdfFormField formField) =>
                        formField.name == 'Signature of Patient')
                as PdfSignatureFormField;
            buttontext = signature.signature != null
                ? "sgin next page"
                : "sgin page one";
            if (signature.signature != null &&
                _pdfViewerController.pageNumber == 2) {
              signature1.signature = signature.signature;
            } else if (signature.signature != null &&
                _pdfViewerController.pageNumber != 2) {
              if (skj) {
                signature1.signature = signature.signature;
              }
              skj = true;
              _pdfViewerController.jumpToPage(2);
              if (signature1.signature != signature.signature) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: const Text(
                      'PLZ sign the page [2] by pressing the red button'),
                  action: SnackBarAction(
                    label: 'Undo',
                    onPressed: () {
                      // Some code to undo the signature
                    },
                  ),
                ));
              }
            } else {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: const Text(
                    'PLZ eneter the signature in signature field on page [1]'),
                action: SnackBarAction(
                  label: 'Undo',
                  onPressed: () {
                    // Some code to undo the change.
                  },
                ),
              ));
            }
          },
          label: Text("Sign Bundle"),
          backgroundColor: Colors.red,
        ));
  }

  Future<Uint8List> generateCertificate() async {

    ByteData fil = await rootBundle.load('assets/Form_example4.pdf');
   print(fil.lengthInBytes);
    final gender =await genders;
    String teridf = context.read<UserData>().terenid == "8"
        ? "GTEC Orange"
        : context.read<UserData>().terenid == "9"
            ? "Victoria-ER"
            : context.read<UserData>().terenid == "10"
                ? "Excel-ER-Odessa"
                : context.read<UserData>().terenid == "17"
                    ? "Excel ER Nacogdoches"
                    : context.read<UserData>().terenid == "19"
                        ? "Hope ER- Lufkin"
                        : context.read<UserData>().terenid == "27"
                            ? "Frontline-ER"
                            : context.read<UserData>().terenid == "28"
                                ? "ER-Dallas"
                                : context.read<UserData>().terenid == "29"
                                    ? "Frontline-Richmond"
                                    : context.read<UserData>().terenid == "39"
                                        ? "PRO CARE SCHERTZ"
                                        : context.read<UserData>().terenid ==
                                                "40"
                                            ? "PRO CARE FLORESVILLE"
                                            : context
                                                        .read<UserData>()
                                                        .terenid ==
                                                    "46"
                                                ? "Rice Emergency"
                                                : context
                                                            .read<UserData>()
                                                            .terenid ==
                                                        "47"
                                                    ? "ER Now"
                                                    : context
                                                                .read<
                                                                    UserData>()
                                                                .terenid ==
                                                            "48"
                                                        ? "TECC - Pearland"
                                                        : context
                                                                    .read<
                                                                        UserData>()
                                                                    .terenid ==
                                                                "49"
                                                            ? "FairField Emergency Room"
                                                            : "";
    
    ByteData img = await rootBundle.load(context.read<UserData>().terenid == '8'
        ? "assets/8.png"
        : context.read<UserData>().terenid == "9"
            ? "assets/VictoriaLogo.png"
            : context.read<UserData>().terenid == '10'
                ? "assets/10.png"
                : context.read<UserData>().terenid == '17'
                    ? "Excel ER Nacogdoches"
                    : context.read<UserData>().terenid == '19'
                        ? "assets/hope.png"
                        : context.read<UserData>().terenid == '27'
                            ? "assets/27.png"
                            : context.read<UserData>().terenid == '28'
                                ? "assets/28.png"
                                : context.read<UserData>().terenid == '29'
                                    ? "assets/29.png"
                                    : context.read<UserData>().terenid == '39'
                                        ? "assets/39.png"
                                        : context.read<UserData>().terenid ==
                                                '40'
                                            ? "assets/40.png"
                                            : context
                                                        .read<UserData>()
                                                        .terenid ==
                                                    '46'
                                                ? "assets/riceer.png"
                                                : context
                                                            .read<UserData>()
                                                            .terenid ==
                                                        '47'
                                                    ? "assets/47.png"
                                                    : context
                                                                .read<
                                                                    UserData>()
                                                                .terenid ==
                                                            '48'
                                                        ? "assets/48.png"
                                                        : context
                                                                    .read<
                                                                        UserData>()
                                                                    .terenid ==
                                                                '49'
                                                            ? "assets/49.png"
                                                            : "");
    final PdfDocument document =
        PdfDocument(inputBytes: fil.buffer.asUint8List());
   
    final Uint8List imageData = img.buffer.asUint8List();
    final PdfBitmap image = PdfBitmap(imageData);
    for (int i = 0; i < document.pages.count; i++) {
      if (i != 11 && i != 3 && i != 12 && i != 14) {
        final PdfPage pagesd = document.pages[i];
        pagesd.graphics.drawImage(image, const Rect.fromLTWH(10, 10, 100, 70));
      }
    }
//Get the form.
    PdfForm form = document.form;

//Get text box and fill value.
    List<PdfTextBoxField> name = [];

    // PdfSignatureField gotd = document.form.fields[45] as PdfSignatureField;
    //print(gotd.name);
    for (int i = 0; i < form.fields.count; i++) {
     // print("fieldd " + document.form.fields[i].name.toString());
      if (i != 43 &&
          i != 42 &&
          i != 49 &&
          i != 46 &&
          i != 69 &&
           i != 73 &&
          i != 79 &&
          i != 82 &&
          i != 93 &&
          i != 100 &&
          i != 115 &&
          i != 132 &&
          i != 178 &&
         i != 179&&i != 186&&i != 193&&i != 194&&i != 201&&i != 216&&i != 218&&i != 220&&i != 227&&i != 230&&i != 231&&i != 187&&i != 185&&i != 228&&(i <=231)  ) {
        print("fieldd " + document.form.fields[i].name.toString());
        // print("fieldd " + document.form.fields[i].name.toString());
        //print(i);
     name.add(document.form.fields[i] as PdfTextBoxField);
      }
    }

//givingvalues
    if (genders!.patientReg?.title != null) {
      name[0].text = genders!.patientReg!.title!;
    }
    //print("2f" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.maritalStatus != null) {
      name[1].text = genders!.patientReg!.maritalStatus!;
      name[1].readOnly;
    }
    //print("3f" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.email != null) {
      name[2].text = genders!.patientReg!.address1!;
      name[2].readOnly;
    }
    //print("3f" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.city != null &&
        genders!.patientReg?.zipCode != null &&
        genders!.patientReg?.state != null) {
      name[3].text =
          "${genders!.patientReg?.city!} ${genders!.patientReg?.state!} ${genders!.patientReg?.zipCode}";

      name[3].readOnly;
    }
    //print("5f" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.phNumber != null) {
      name[4].text = genders!.patientReg!.phNumber!;
      name[4].readOnly;
    }
    //print("6f" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.ssn != null)
      name[5].text = genders!.patientReg!.ssn!.toString();
    print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[6].text="";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.sex != null) {
      name[7].text = genders!.patientReg!.sex!;
      name[7].readOnly;
    }
    //print("9f" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.email != null) {
      name[8].text = genders!.patientReg!.email!;
      name[8].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientEthnicityList != null) {
      name[9].text = genders!.patientEthnicityList![0].ethnicity!;
      name[9].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.employer != null) {
      name[10].text = genders!.patientReg!.employer!;
      name[10].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.occupation != null) {
      name[11].text = genders!.patientReg!.occupation!;
      name[11].readOnly;
    }
    //print("dfdsfdssdf" + context.read<UserData>().terenid!);
    if (genders!.patientEmergencyContactDetails?.firstName != null) {
      name[12].text =
          ('${genders!.patientEmergencyContactDetails!.firstName!} ${genders!.patientEmergencyContactDetails!.lastName!}');

      name[12].readOnly;
    }
    //print("dfsdf" + context.read<UserData>().terenid!);
    if (genders!.patientEmergencyContactDetails?.patientEmergencyRelation !=
        null) {
      name[13].text =
          genders!.patientEmergencyContactDetails!.patientEmergencyRelation!;
      name[13].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientEmergencyContactDetails?.phoneNumber != null) {
      name[14].text = genders!.patientEmergencyContactDetails!.phoneNumber!;
      name[14].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientPhysicianDetails?.primaryCarePhysicianName != null) {
      name[15].text =
          genders!.patientPhysicianDetails!.primaryCarePhysicianName!;
      name[15].readOnly;
    }
    //print("sdfsdew" + context.read<UserData>().terenid!);
    if (genders!.recentVisit?.reasonVisit != null) {
      name[16].text = genders!.recentVisit!.reasonVisit!;
      name[16].readOnly;
    }
    //print("dffjh" + context.read<UserData>().terenid!);
    if (genders!.patientGuarantorDetails?.guarantorFirstName != null) {
      name[17].text =
          ('${genders!.patientGuarantorDetails!.guarantorFirstName!} ${genders!.patientGuarantorDetails!.guarantorLastName!}');

      name[17].readOnly;
    }
    //print("dffjh" + context.read<UserData>().terenid!);
    if (genders!.patientGuarantorDetails?.guarantorDob != null) {
      name[18].text = genders!.patientGuarantorDetails!.guarantorDob!
          .toString()
          .substring(0, 10);

      name[18].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.patientGuarantorDetails?.gur!=null)
// name[19].text="";
    //print("kmx" + context.read<UserData>().terenid!);
    final now =  "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    if (genders!.patientGuarantorDetails?.guarantorSsn != null) {
      name[20].text = genders!.patientGuarantorDetails!.guarantorSsn!;
      name[20].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientGuarantorDetails?.guarantorEmployerAddress1 != null) {
      name[21].text =
          genders!.patientGuarantorDetails!.guarantorEmployerAddress1!;
      name[21].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientGuarantorDetails?.guarantorPhoneNumber != null) {
      name[22].text = genders!.patientGuarantorDetails!.guarantorPhoneNumber!;
      name[22].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientGuarantorDetails?.guarantorEmployerName != null) {
      name[23].text = genders!.patientGuarantorDetails!.guarantorEmployerName!;
      name[23].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientGuarantorDetails?.guarantorEmployerPhoneNumber !=
        null) {
      name[24].text =
          genders!.patientGuarantorDetails!.guarantorEmployerPhoneNumber!;
      name[24].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientGuarantorDetails?.guarantorEmployerAddress1 != null) {
      name[25].text =
          genders!.patientGuarantorDetails!.guarantorEmployerAddress1!;
      name[25].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.patientGuarantorDetails?.guaran!=null)
name[26].text="NO";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[27].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[28].text="";

    if (genders!.patientHealthInsuranceDetails!.length > 0 &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![0].insurance!.payerName !=
        null) {
      name[168].text =
          genders!.patientHealthInsuranceDetails![0].insurance!.payerName!;
      name[174].readOnly;
    }

    if (genders!.patientHealthInsuranceDetails!.length > 0 &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![0].subscriberFirstName !=
        null) {
      name[30 - 1].text =
          "${genders!.patientHealthInsuranceDetails![0].subscriberFirstName!} ${genders!.patientHealthInsuranceDetails![0].subscriberLastName!}";
      name[29].readOnly;
    }
    //print("asdasd" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 0 &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![0].subscriberDob !=
        null) {
      name[31 - 1].text = genders!
          .patientHealthInsuranceDetails![0].subscriberDob!
          .toString()
          .substring(0, 10);
      name[30].readOnly;
    }
   
    if (genders!.patientHealthInsuranceDetails!.length > 0 &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![0].subscriberSsn !=
        null) {
      name[32 - 1].text =
          genders!.patientHealthInsuranceDetails![0].subscriberSsn!;
      name[31].readOnly;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 0 &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![0].relationToPatient !=
        null) {
      name[33 - 1].text =
          genders!.patientHealthInsuranceDetails![0].relationToPatient!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 0 &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![0].groupNumber !=
        null) {
      name[34 - 1].text =
          genders!.patientHealthInsuranceDetails![0].groupNumber!;
    }
    //print("dgfdgsdgfds" + context.read<UserData>().terenid!);
// if(genders!.patientHealthInsuranceDetails![0].groupNumber!=null)
// name[35-1].text="";
    //print("kmx" + context.read<UserData>().terenid!);
      //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null) {
      if( genders!.patientHealthInsuranceDetails![1].insurance!.payerName != null)
      name[36 - 1].text =
          genders!.patientHealthInsuranceDetails![1].insurance!.payerName!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
      //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null) {
      if( genders!.patientHealthInsuranceDetails![1].subscriberFirstName != null)
      name[37 - 1].text =
          "${genders!.patientHealthInsuranceDetails![1].subscriberFirstName!} ${genders!.patientHealthInsuranceDetails![1].subscriberLastName!}";
    }
    //print("kmx" + context.read<UserData>().terenid!);
      //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null) {
      if( genders!.patientHealthInsuranceDetails![1].subscriberDob != null)
      name[38 - 1].text = genders!
          .patientHealthInsuranceDetails![1].subscriberDob!
          .toString()
          .substring(0, 10);
    }
    //print("kmx" + context.read<UserData>().terenid!);
      //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null) {
      if( genders!.patientHealthInsuranceDetails![1].subscriberSsn != null)
      name[39 - 1].text =
          genders!.patientHealthInsuranceDetails![1].subscriberSsn!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
      //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null) {
      if( genders!.patientHealthInsuranceDetails![1].relationToPatient != null)
      name[40 - 1].text =
          genders!.patientHealthInsuranceDetails![1].relationToPatient!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
      //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null) {
      if( genders!.patientHealthInsuranceDetails![1].groupNumber != null)
      name[41 - 1].text =
          genders!.patientHealthInsuranceDetails![1].groupNumber!;
    }
    //print("dfzgdzfgdfgdfg" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[42-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[173].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[44-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[45-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[46-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[47 - 3].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[48-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[49 - 3].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[50 - 3].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[51 - 3].text =
          ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[52-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[53-2].text="";
    //print("hjkhkj" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.dob != null) {
      name[54 - 3].text = genders!.patientReg!.dob!.substring(0, 10);
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.patientReg?.f=null)
// name[55-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 0 &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![0].memberId !=
        null) {
      name[56 - 3].text = genders!.patientHealthInsuranceDetails![0].memberId!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[57 - 3].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    // if (genders!.patientHealthInsuranceDetails!.length > 0 &&
    //     genders!.patientHealthInsuranceDetails != null) if (genders!
    //         .patientHealthInsuranceDetails![0].insurance!.payerName !=
    //     null)
    if (teridf != null) {
      name[58 - 3].text = teridf;
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[59 - 3].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1&&
        genders!.patientHealthInsuranceDetails != null) {
      name[60 - 3].text = "Yes";
      //print("kmx" + context.read<UserData>().terenid!);
    } else {
      name[60 - 3].text = "No";
      //print("kmx" + context.read<UserData>().terenid!);
    }
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![1].subscriberFirstName !=
        null) {
      name[61 - 3].text =
          genders!.patientHealthInsuranceDetails![1].insurance!.payerName!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![1].subscriberFirstName !=
        null) {
      name[62 - 3].text =
          "${genders!.patientHealthInsuranceDetails![1].subscriberFirstName!} ${genders!.patientHealthInsuranceDetails![1].subscriberLastName!}";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![1].memberId !=
        null) {
      name[63 - 3].text = genders!.patientHealthInsuranceDetails![1].memberId!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![1].subscriberDob !=
        null) {
      name[64 - 3].text = genders!
          .patientHealthInsuranceDetails![1].subscriberDob!
          .toString()
          .substring(0, 10);
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null &&
        genders!.patientHealthInsuranceDetails != null) 
        if (genders!
            .patientHealthInsuranceDetails![1].groupNumber !=
        null) {
      name[65 - 3].text =
          genders!.patientHealthInsuranceDetails![1].groupNumber!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientHealthInsuranceDetails!.length > 1 && genders!.patientHealthInsuranceDetails != null &&
        genders!.patientHealthInsuranceDetails != null) if (genders!
            .patientHealthInsuranceDetails![1].planEffectiveDate !=
        null) {
      name[66 - 3].text = genders!
          .patientHealthInsuranceDetails![1].planEffectiveDate!
          .toString();
    }
    //print("sdf" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[67-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[68 - 3].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[69-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[70 - 3].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[71-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[72-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[73-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[74-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.patientReg?.firstName!=null) {
//   name[75-2].text=('${genders!.patientReg!.firstName!} ${genders!.patientReg!.lastName!}');
// }
    print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[76 - 4].text =
        '${genders!.patientReg!.firstName!} ${genders!.patientReg!.lastName!}';
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[77 - 4].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[77].text = teridf;
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[79 - 4].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[80 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[81 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[82 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[83 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[84 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[85 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[86 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[87 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("hjkhkj" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[88 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[89 - 4].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[90-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);

    name[91].text = "${DateTime.now().year}";
    print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[92-4].text = new DateTime.now().day.toString();
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[93-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[93 - 4].text = new DateTime.now().day.toString();
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[95 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[96-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.=null)
// name[97-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[98-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[99-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[100-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[101-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[102-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[103-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[104-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[105-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[106-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[107-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[108-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    name[109 - 4].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[110-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[111-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[112-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[113-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[114-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[115-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[116-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[117-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
    // name[118 -2].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[119-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[120-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[121-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[122 - 4].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.dob != null) {
      name[123 - 4].text = genders!.patientReg!.dob!.substring(0, 10);
    }
    //print("kmx" + context.read<UserData>().terenid!);
    // if (genders!.patientReg?.authorization != null) {
    //   name[124 - 4].text = genders!.patientReg?.authorization == 1 ? "*" : "";
    // }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.patientReg?.authorization!=null)
    name[125 - 5].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[126 - 6].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[127-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.patientReg?.firstName!=null)
// name[128-2].text="";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.internetFind != null) {
      name[129 - 6].text = genders!.patientMarketingDetails?.internetFind == 1
          ? "True"
          : "False";
    }
    //print("sdf" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.facebook != null) {
      name[130 - 6].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.tv != null) {
      name[174].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.mapSearch != null) {
      name[132 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.onlineReviews != null) {
      name[133 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.radio != null) {
      name[134 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.googleSearch != null) {
      name[135 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.familyFriend != null) {
      name[136 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.familyFriendText != null) {
      name[137 - 7].text = genders!.patientMarketingDetails!.familyFriendText!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.youTube != null) {
      name[138 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.brochure != null) {
      name[139 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.patientMarketingDetails?.familyFriendText!=null)
// name[140-3].text="";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.directMail != null) {
      name[141 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.linkedIn != null) {
      name[142 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.urgentCare != null) {
      name[143 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.urgentCareText != null) {
      name[144 - 7].text = genders!.patientMarketingDetails!.urgentCareText!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.twitter != null) {
      name[145 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.school != null) {
      name[146 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.schoolText != null) {
      name[147 - 7].text = genders!.patientMarketingDetails!.schoolText!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.onlineAdvertisements != null) {
      name[148 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.newspaper != null) {
      name[149 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.newspaperText != null) {
      name[150 - 7].text = genders!.patientMarketingDetails!.newspaperText!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.emailBlast != null) {
      name[151 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.hotel != null) {
      name[152 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.hotelText != null) {
      name[153 - 7].text = genders!.patientMarketingDetails!.hotelText!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.citizensDeTar != null) {
      name[154 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.liveWorkNearby != null) {
      name[155 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.employerSentMe != null) {
      name[156 - 7].text = "Yes";
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientMarketingDetails?.employerSentMeText != null) {
      name[157 - 7].text =
          genders!.patientMarketingDetails!.employerSentMeText!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.phNumber != null) {
      name[158 - 7].text = genders!.patientReg!.phNumber!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientPhysicianDetails?.primaryCarePhysicianName != null) {
      name[159 - 7].text =
          genders!.patientPhysicianDetails!.primaryCarePhysicianName!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.patientPhysicianDetails?.primaryCarePhysicianName!=null)
// name[160-3].text="";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[161-3].text="";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.firstName != null) {
      name[162 - 7].text = genders!.patientReg!.firstName!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.middleInitial != null) {
      name[163 - 7].text = genders!.patientReg!.middleInitial!;
    }
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders!.patientReg?.middleInitial!=null)
    name[164 - 7].text = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //print("kmx" + context.read<UserData>().terenid!);
// if(genders.!=null)
// name[166-7].text=;
    //print("kmx" + context.read<UserData>().terenid!);

// if(genders.!=null)
name[165-7].text= "${DateTime.now().hour.toString()}:${DateTime.now().minute.toString()}";
    //print("kmx" + context.read<UserData>().terenid!);
    if (genders!.patientReg?.lastName != null) {
      name[167 - 7].text = genders!.patientReg!.lastName!;
    }
    //print("sdf" + context.read<UserData>().terenid!);
    if (context.read<UserData>().terenid != null) {
      name[168 - 7].text = context.read<UserData>().terenid == "8"
          ? "GTEC Orange"
          : context.read<UserData>().terenid == "9"
              ? "Victoria-ER"
              : context.read<UserData>().terenid == "10"
                  ? "Excel-ER-Odessa"
                  : context.read<UserData>().terenid == "17"
                      ? "Excel ER Nacogdoches"
                      : context.read<UserData>().terenid == "19"
                          ? "Hope ER- Lufkin"
                          : context.read<UserData>().terenid == "27"
                              ? "Frontline-ER"
                              : context.read<UserData>().terenid == "28"
                                  ? "ER-Dallas"
                                  : context.read<UserData>().terenid == "29"
                                      ? "Frontline-Richmond"
                                      : context.read<UserData>().terenid == "39"
                                          ? "PRO CARE SCHERTZ"
                                          : context.read<UserData>().terenid ==
                                                  "40"
                                              ? "PRO CARE FLORESVILLE"
                                              : context
                                                          .read<UserData>()
                                                          .terenid ==
                                                      "46"
                                                  ? "Rice Emergency"
                                                  : context
                                                              .read<UserData>()
                                                              .terenid ==
                                                          "47"
                                                      ? "ER Now"
                                                      : context
                                                                  .read<
                                                                      UserData>()
                                                                  .terenid ==
                                                              "48"
                                                          ? "TECC - Pearland"
                                                          : context
                                                                      .read<
                                                                          UserData>()
                                                                      .terenid ==
                                                                  "49"
                                                              ? "FairField Emergency Room"
                                                              : "";
      //print("kmx" + context.read<UserData>().terenid!);
    }
    if (genders!.patientReg!.firstName != null)
      name[169 - 7].text =
           ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    //print("kmx" + context.read<UserData>().terenid!);
    // if (genders!.patientReg?.firstName != null) {
      name[169].text ="${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";
    //        ('${genders!.patientReg!.lastName!} ${genders!.patientReg!.firstName!}');
    // }
    //print("kmx" + context.read<UserData>().terenid!);
    // if (genders!.patientReg?.dob != null) {
    //   name[171 -3].text = genders!.patientReg!.dob!.substring(0, 10);
    // }
    //print("ghjk" + context.read<UserData>().terenid!);
// if(genders.!=null)
//  name[168].text="";
// if(genders.!=null)
// name[173].text="";
// if(genders.!=null)
// name[174].text="";

    for (int i = 0; i < name.length; i++) {
      //print("ff " + name[i].name.toString());
   name[i].readOnly =true;
    }
//Save the document.
    final dir = await getTemporaryDirectory();
    final path = "${dir.path}/pdfname.pdf";
    io.File doc = await io.File(path).writeAsBytes(await document.save());

//Dispose the document.
    document.dispose();
    return doc.readAsBytes();
  }
}
