// Suggestions:
// 1. Use MaterialApp and Scaffold widgets for easier app and UI building
// 2. Use ListView for the drawer items
// 3. Use CircleAvatar for profile picture
// 4. Use InputDecoration for rounded border text fields

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter_google_places_sdk/flutter_google_places_sdk.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph6.dart';
import 'package:reg_app/regph7.dart';
import 'package:reg_app/regph8.dart';

import 'adressmodle.dart';

class pereg2 extends StatefulWidget {
  @override
  _pereg2State createState() => _pereg2State();
  static const String route = '/phys';
}

class _pereg2State extends State<pereg2> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  final _formKeyq = GlobalKey<FormState>();

  //gps
  TextEditingController streetAddController = TextEditingController();
  TextEditingController stateController = TextEditingController();
  TextEditingController zipCodeController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  late final FlutterGooglePlacesSdk _places;
  String? _predictLastText;
  bool _predicting = false;
  dynamic _predictErr;
  List<AutocompletePrediction>? _predictions;
  var comp;
  Widget _buildPredictionItem(AutocompletePrediction item) {
    var co = Color.fromARGB(0, 0, 0, 0);
    return Container(
      color: co,
      child: InkWell(
        focusColor: co,
        onTap: () async {
          comp = fetchAlbum(item.placeId, "98");
          setState(() {
            context.read<UserData>().primaryCarePhysicianAddress1 =
                item.fullText;
            streetAddController.text = item.fullText;
          });
          setState(() {});
          Navigator.pop(context);
        },
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                item.fullText,
                textAlign: TextAlign.center,
              ),
              const Divider(thickness: 2),
            ]),
      ),
    );
  }

  List<Widget> _buildPredictionWidgets() {
    return [
      TextFormField(
        onChanged: _onPredictTextChanged,
        decoration: InputDecoration(label: Text("Address")),
      ),
      _buildErrorWidget(_predictErr),
      Column(
        mainAxisSize: MainAxisSize.min,
        children: (_predictions ?? [])
            .map(_buildPredictionItem)
            .toList(growable: false),
      ),
    ];
  }

  Widget _buildErrorWidget(dynamic err) {
    final theme = Theme.of(context);
    final errorText = err == null ? '' : err.toString();
    return Text(errorText,
        style: theme.textTheme.bodySmall
            ?.copyWith(color: theme.colorScheme.error));
  }

  addTypeDialog(BuildContext context) {
    _buildPredictionWidgets();

    setState(() {});
  }

  Future<AutoGenerate> fetchAlbum(String placeId, sessionToken) async {
    final response = await http.get(Uri.parse(
        'https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeId&fields=address_component&key=AIzaSyBO5TaHOjSZFWhBF0AYpNUSmFh8ozqLRto&sessiontoken=$sessionToken'));

    if (response.statusCode == 200) {
      print("apisecess");

      int ii = AutoGenerate.fromJson(jsonDecode(response.body))
          .result
          .addressComponents
          .length;
      for (int index = 0; index < ii; index++) {
        if (AutoGenerate.fromJson(jsonDecode(response.body))
            .result
            .addressComponents[index]
            .types
            .contains("postal_code")) {
          context.read<UserData>().primaryCarePhysicianZip =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
          zipCodeController.text =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
        }
        if (AutoGenerate.fromJson(jsonDecode(response.body))
            .result
            .addressComponents[index]
            .types
            .contains("administrative_area_level_1")) {
          context.read<UserData>().primaryCarePhysicianState =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
          stateController.text =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
        }
        if (AutoGenerate.fromJson(jsonDecode(response.body))
            .result
            .addressComponents[index]
            .types
            .contains("administrative_area_level_2")) {
          context.read<UserData>().primaryCarePhysicianCity =
              AutoGenerate.fromJson(jsonDecode(response.body))
                  .result
                  .addressComponents[index]
                  .longName;
          cityController.text = AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[index]
              .longName;
        }
      }

      print("newone" +
          AutoGenerate.fromJson(jsonDecode(response.body))
              .result
              .addressComponents[1]
              .longName);

      return AutoGenerate.fromJson(jsonDecode(response.body));
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load album');
    }
  }

  void _onPredictTextChanged(String value) {
    print(value);
    setState(() {});
    _predictLastText = value;
    _predict();
  }

  void _predict() async {
    if (_predicting) {
      return;
    }

    final hasContent = _predictLastText?.isNotEmpty ?? false;

    setState(() {
      _predicting = hasContent;
      _predictErr = null;
    });

    if (!hasContent) {
      return;
    }

    try {
      final result = await _places.findAutocompletePredictions(
        _predictLastText!,
        countries: null,
        newSessionToken: false,
        placeTypeFilter: PlaceTypeFilter.ADDRESS,
        // origin: LatLng(lat: 43.12, lng: 95.20),
        locationBias: null,
        locationRestriction: null,
      );

      setState(() {
        print("hhhh" + result.predictions[1].placeId);
        _predictions = result.predictions;
        _predicting = false;
      });
    } catch (err) {
      setState(() {
        _predictErr = err;
        _predicting = false;
      });
    }
  }

  //gps
  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  TextEditingController t3 = TextEditingController();
  TextEditingController t4 = TextEditingController();
  TextEditingController t5 = TextEditingController();
  TextEditingController t6 = TextEditingController();
  TextEditingController t7 = TextEditingController();
  TextEditingController t8 = TextEditingController();
  TextEditingController t9 = TextEditingController();
  TextEditingController t10 = TextEditingController();
  TextEditingController t11 = TextEditingController();
  TextEditingController t12 = TextEditingController();
  TextEditingController t13 = TextEditingController();
  TextEditingController t14 = TextEditingController();
  TextEditingController t15 = TextEditingController();
  TextEditingController t16 = TextEditingController();
  TextEditingController t17 = TextEditingController();
  TextEditingController t18 = TextEditingController();
  TextEditingController t19 = TextEditingController();
  TextEditingController t20 = TextEditingController();
  TextEditingController t21 = TextEditingController();
  void initState() {
    super.initState();

    if (context.read<UserData>().primaryCarePhysicianName != null)
      t1.text = context.read<UserData>().primaryCarePhysicianName!;
    if (context.read<UserData>().primaryCarePhysicianCity != null)
      cityController.text = context.read<UserData>().primaryCarePhysicianCity!;
    if (context.read<UserData>().primaryCarePhysicianState != null)
      t2.text = context.read<UserData>().primaryCarePhysicianState!;
    if (context.read<UserData>().primaryCarePhysicianZip != null)
      zipCodeController.text =
          context.read<UserData>().primaryCarePhysicianZip!;
    if (context.read<UserData>().primaryCarePhysicianAddress1 != null)
      t3.text = context.read<UserData>().primaryCarePhysicianAddress1!;
    if (context.read<UserData>().primaryCarePhysicianAddress2 != null)
      t4.text = context.read<UserData>().primaryCarePhysicianAddress2!;
    if (context.read<UserData>().specialityCarePhysicianName != null)
      t5.text = context.read<UserData>().specialityCarePhysicianName!;
    if (context.read<UserData>().specialityCarePhysicianCity != null)
      t6.text = context.read<UserData>().specialityCarePhysicianCity!;
    if (context.read<UserData>().specialityCarePhysicianState != null)
      t7.text = context.read<UserData>().specialityCarePhysicianState!;
    if (context.read<UserData>().specialityCarePhysicianZip != null)
      t8.text = context.read<UserData>().specialityCarePhysicianZip!;

    if (context.read<UserData>().specialityCarePhysicianAddress1 != null)
      t9.text = context.read<UserData>().specialityCarePhysicianAddress1!;

    if (context.read<UserData>().specialityCarePhysicianAddress2 != null)
      t10.text = context.read<UserData>().specialityCarePhysicianAddress2!;
    _places = FlutterGooglePlacesSdk("AIzaSyBO5TaHOjSZFWhBF0AYpNUSmFh8ozqLRto",
        locale: const Locale('en'));
    _places.isInitialized().then((value) {
      debugPrint('Places Initialized: $value');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(119, 94, 158, 100),
        title: const Text(
          ' Physician',
          style: TextStyle(color: Colors.white),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              '',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            onPressed: () {
              if (_formKey.currentState!.validate()) {}
            },
          ),
        ],
      ),
      drawer: Drawer(
        width: 200,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(51, 62, 101, 5),
                Color.fromRGBO(107, 80, 135, 5)
              ],
            ),
          ),
          child: ListView(
            children: <Widget>[
              // const UserAccountsDrawerHeader(
              //   currentAccountPictureSize: Size.square(90.0),
              //   accountName: Text(
              //     '',
              //     style: TextStyle(color: Colors.white),
              //   ),
              //   accountEmail: Text(
              //     '',
              //     style: TextStyle(color: Colors.white),
              //   ),
              //   currentAccountPicture: CircleAvatar(
              //     backgroundColor: Colors.white,
              //     child: Text(
              //       'P',
              //       style: TextStyle(
              //         fontSize: 20.0,
              //         fontWeight: FontWeight.bold,
              //         color: Colors.purple,
              //       ),
              //     ),
              //   ),
              //   decoration: BoxDecoration(
              //     gradient: LinearGradient(
              //       begin: Alignment.topCenter,
              //       end: Alignment.bottomCenter,
              //       colors: [Colors.transparent, Colors.transparent],
              //       //  [Color.fromRGBO(51, 62, 101,10), Color.fromRGBO(51, 62, 101,10)],
              //     ),
              //   ),
              // ),
              // Padding(
              //   padding: const EdgeInsets.all(8.0),
              //   child: Row(
              //     children: [
              //       const Icon(
              //         Icons.image,
              //         color: Colors.white,
              //       ),
              //       const SizedBox(
              //         width: 10,
              //       ),
              //       const Icon(
              //         Icons.edit,
              //         color: Colors.white,
              //       ),
              //     ],
              //   ),
              // ),
              ListTile(
                title: Text(
                  'Patient',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg1()));

                  // TODO: Navigate to patient info page
                },
              ),
              ListTile(
                autofocus: true,
                selected: true,
                focusColor: Colors.white,
                selectedColor: Colors.white,
                enabled: true,
                title: Text(
                  'Physician',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.popAndPushNamed(context, pereg2.route);
                },
              ),
              ListTile(
                title: Text(
                  'COVID-19',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg8()));
                  // TODO: Navigate to COVID-19 info page
                },
              ),
              ListTile(
                title: Text(
                  'Guarantor',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg3()));
                  // TODO: Navigate to guarantor info page
                },
              ),
              ListTile(
                title: Text(
                  'Insurance',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg7()));
                  // TODO: Navigate to insurance info page
                },
              ),
              ListTile(
                title: Text(
                  'Emergency Contact',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg4()));
                  // TODO: Navigate to emergency info page
                },
              ),
              ListTile(
                title: Text(
                  'Marketing',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg5()));
                  // TODO: Navigate to marketing info page
                },
              ),
              ListTile(
                title: Text(
                  'ID Upload',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg6()));
                  // TODO: Navigate to ID upload page
                },
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
          child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.grey,
            ],
          ),
        ),
        child: Row(
          children: <Widget>[
            Padding(
                padding: const EdgeInsets.only(
                    left: 10.0, top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          Navigator.of(context).pop();
                          // Navigator.push(context, MaterialPageRoute(builder: (context) => PersonalInfoRegister(),));
                        },
                        child: const Text("BACK"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
            const Spacer(),
            const Expanded(
              child: Padding(
                padding: EdgeInsets.all(18.0),
                child: Text(
                  "",
                  style: TextStyle(
                      // color: Color(0xFFC0C0C0),
                      fontSize: 16.0),
                ),
              ),
            ),
            Padding(
                padding: EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          //sending this get this all from shared pref and send the data

                          if (_formKey.currentState!.validate() &&
                              _formKeyq.currentState!.validate()) {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => pereg8()));
                          }
                        },
                        child: Text("NEXT"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
          ],
        ),
      )),
      body: SingleChildScrollView(
        child: SizedBox(
          child: Container(
            color: Colors.grey[200],
            // color: Colors.grey,

            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                          color: Colors.transparent,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(20))),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          const Text(
                            'Primary Care Physician',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 10),
                          Form(
                            key: _formKey,
                            child: Column(
                              children: [
                                TextFormField(
                                  controller: t1,
                                  onChanged: (String? value) {
                                    _formKey.currentState!.validate();

                                    context
                                        .read<UserData>()
                                        .primaryCarePhysicianName = value;
                                  },
                                  inputFormatters: [
                                    MaskTextInputFormatter(
                                        mask: '########################',
                                        filter: {"#": RegExp(r'[a-zA-Z]')},
                                        type: MaskAutoCompletionType.lazy)
                                  ],
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    labelText: 'Physician Name',
                                  ),
                                ),
                                SizedBox(height: 10),
                                TextFormField(
                                  controller: cityController,
                                  inputFormatters: [
                                    MaskTextInputFormatter(
                                        mask: '########################',
                                        filter: {"#": RegExp(r'[a-zA-Z]')},
                                        type: MaskAutoCompletionType.lazy)
                                  ],
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    labelText: 'City',
                                  ),
                                  onChanged: (String? value) {
                                    _formKey.currentState!.validate();

                                    context
                                        .read<UserData>()
                                        .primaryCarePhysicianCity = value;
                                  },
                                ),
                                SizedBox(height: 10),
                                TextFormField(
                                  controller: t2,
                                  inputFormatters: [
                                    MaskTextInputFormatter(
                                        mask: '########################',
                                        filter: {"#": RegExp(r'[a-zA-Z]')},
                                        type: MaskAutoCompletionType.lazy)
                                  ],
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    labelText: 'State',
                                  ),
                                  onChanged: (String? value) {
                                    _formKey.currentState!.validate();

                                    context
                                        .read<UserData>()
                                        .primaryCarePhysicianState = value;
                                  },
                                ),
                                SizedBox(height: 10),
                                TextFormField(
                                  inputFormatters: [
                                    MaskTextInputFormatter(
                                        mask: '##########',
                                        filter: {"#": RegExp(r'[A-Za-z0-9]')},
                                        type: MaskAutoCompletionType.lazy)
                                  ],
                                  controller: zipCodeController,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    labelText: 'Zipcode',
                                  ),
                                  onChanged: (String? value) {
                                    _formKey.currentState!.validate();

                                    context
                                        .read<UserData>()
                                        .primaryCarePhysicianZip = value;
                                  },
                                ),
                                SizedBox(height: 10),
                                TextFormField(
                                  controller: t3,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    labelText: 'Address 1',
                                  ),
                                  onChanged: (String? value) {
                                    setState(() {
                                      _formKey.currentState!.validate();
                                    });
                                    context
                                        .read<UserData>()
                                        .primaryCarePhysicianAddress1 = value;
                                  },
                                ),
                                SizedBox(height: 10),
                                TextFormField(
                                  controller: t4,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    labelText: 'Address 2',
                                  ),
                                  onChanged: (String? value) {
                                    setState(() {
                                      _formKey.currentState!.validate();
                                    });
                                    context
                                        .read<UserData>()
                                        .primaryCarePhysicianAddress2 = value;
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                          color: Colors.transparent,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(20))),
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Text(
                              'Specialty Care Physician',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 10),
                            Form(
                              key: _formKeyq,
                              child: Column(
                                children: [
                                  TextFormField(
                                    controller: t5,
                                    inputFormatters: [
                                      MaskTextInputFormatter(
                                          mask: '########################',
                                          filter: {"#": RegExp(r'[a-zA-Z]')},
                                          type: MaskAutoCompletionType.lazy)
                                    ],
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      labelText: 'Physician Name',
                                    ),
                                    onChanged: (String? value) {
                                      _formKey.currentState!.validate();

                                      context
                                          .read<UserData>()
                                          .specialityCarePhysicianName = value;
                                    },
                                  ),
                                  SizedBox(height: 10),
                                  TextFormField(
                                    controller: t6,
                                    inputFormatters: [
                                      MaskTextInputFormatter(
                                          mask: '########################',
                                          filter: {"#": RegExp(r'[a-zA-Z]')},
                                          type: MaskAutoCompletionType.lazy)
                                    ],
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      labelText: 'City',
                                    ),
                                    onChanged: (String? value) {
                                      _formKey.currentState!.validate();

                                      context
                                          .read<UserData>()
                                          .specialityCarePhysicianCity = value;
                                    },
                                  ),
                                  SizedBox(height: 10),
                                  TextFormField(
                                    inputFormatters: [
                                      MaskTextInputFormatter(
                                          mask: '########################',
                                          filter: {"#": RegExp(r'[a-zA-Z]')},
                                          type: MaskAutoCompletionType.lazy)
                                    ],
                                    controller: t7,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      labelText: 'State',
                                    ),
                                    onChanged: (String? value) {
                                      _formKey.currentState!.validate();

                                      context
                                          .read<UserData>()
                                          .specialityCarePhysicianState = value;
                                    },
                                  ),
                                  SizedBox(height: 10),
                                  TextFormField(
                                    controller: t8,
                                    inputFormatters: [
                                      MaskTextInputFormatter(
                                          mask: '##########',
                                          filter: {"#": RegExp(r'[A-Za-z0-9]')},
                                          type: MaskAutoCompletionType.lazy)
                                    ],
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      labelText: 'Zipcode',
                                    ),
                                    onChanged: (String? value) {
                                      _formKey.currentState!.validate();

                                      context
                                          .read<UserData>()
                                          .specialityCarePhysicianZip = value;
                                    },
                                  ),
                                  SizedBox(height: 10),
                                  TextFormField(
                                    controller: t9,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      labelText: 'Address 1',
                                    ),
                                    onChanged: (String? value) {
                                      setState(() {
                                        _formKey.currentState!.validate();
                                      });
                                      context
                                              .read<UserData>()
                                              .specialityCarePhysicianAddress1 =
                                          value;
                                    },
                                  ),
                                  SizedBox(height: 10),
                                  TextFormField(
                                    controller: t10,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      labelText: 'Address 2',
                                    ),
                                    onChanged: (String? value) {
                                      setState(() {
                                        _formKey.currentState!.validate();
                                      });
                                      context
                                              .read<UserData>()
                                              .specialityCarePhysicianAddress2 =
                                          value;
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
