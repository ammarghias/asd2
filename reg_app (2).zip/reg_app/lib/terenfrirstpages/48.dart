// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'dart:typed_data';
// import 'package:provider/provider.dart';
// import 'package:reg_app/pereg1.dart';
// import 'package:reg_app/provider.dart';
// import 'package:reg_app/regph2.dart';
// import 'package:reg_app/regph3.dart';
// import 'package:reg_app/regph4.dart';
// import 'package:reg_app/regph5.dart';
// import 'package:reg_app/regph6.dart';
// import 'package:reg_app/regph7.dart';

// import '../models.dart';
// import '../regph8.dart';

// class existing {
//   String? message;
//   int? patientRegId;
//   bool? status;

//   existing({this.message, this.patientRegId, this.status});

//   existing.fromJson(Map<String, dynamic> json) {
//     message = json['message'];
//     patientRegId = json['patientRegId'];
//     status = json['status'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['message'] = this.message;
//     data['patientRegId'] = this.patientRegId;
//     data['status'] = this.status;
//     return data;
//   }
// }

// class newpageu48 extends StatefulWidget {
//   const newpageu48({super.key});
//   static const String route = '/48';
//   @override
//   _newpageu48State createState() => _newpageu48State();
// }

// class _newpageu48State extends State<newpageu48> {
//   Image img = const Image(
//     image: AssetImage("assets/illustration.png"),
//     fit: BoxFit.fill,
//   );
//   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
//   final _formKey = GlobalKey<FormState>();
//   TextEditingController DOBCONTRs = TextEditingController();
//   TextEditingController firstNameController = TextEditingController();
//   TextEditingController lastNameController = TextEditingController();
//   TextEditingController dobcontroller = TextEditingController();

//   late petient infop;
// //exsisting

//   Future<existing?> exitingp(
//       String payerName, String lastname, String dob) async {
//     String BaseUrl =
//         "http://192.168.210.9:7778/patientExternal/existingpatientcheck";
//     var jsonData = null;
//     Uri uri = Uri.parse(BaseUrl);
//     final headers = {
//       'Content-Type': 'application/json',
//       'accept': '*/*',
//       'X-TenantID': "48"
//     };
//     print(dob);
//     final body = jsonEncode(<String, String>{
//       "firstName": payerName,
//       "lastName": lastname,
//       "dob": dob
//     });
//     print("URI HERE-- " + uri.toString());
//     var response = await http.post(uri, headers: headers, body: body);
//     print(body.toString());
//     if (response.statusCode == 200) {
//       jsonData = json.decode(response.body.toString());
//       existing priInsData = existing.fromJson(jsonDecode(response.body));
//       print("jsonData45---$jsonData");
//       return priInsData;
//     } else {
//       throw Exception('Failed to load data');
//     }
//   }

//   Future<void> _existing() async {
//     if (firstNameController.text != "" &&
//         lastNameController.text != "" &&
//         DOBCONTRs.text != "") {
//       final newpati = await exitingp(
//           firstNameController.text, lastNameController.text, DOBCONTRs.text);
//       print("itsworki");
//       if (newpati!.status!) {
//         showDialog(
//             barrierDismissible: false,
//             context: context,
//             builder: (BuildContext context) {
//               return AlertDialog(
//                 title: Text('Already Registered'),
//                 content: StatefulBuilder(
//                   builder: (BuildContext context, StateSetter setState) {
//                     return SizedBox(
//                       height: 70,
//                       child: Column(
//                         children: [
//                           Text(
//                             newpati.message!,
//                             style: TextStyle(
//                                 color: Color.fromARGB(255, 0, 34, 255),
//                                 fontSize: 30),
//                           ),
//                           Text('Please proceed to the front desk'),
//                         ],
//                       ),
//                     );
//                   },
//                 ),
//                 actions: <Widget>[
//                   TextButton(
//                     child: Text('OK'),
//                     onPressed: () {
//                       setState(() {});
//                       Navigator.pushReplacement(
//                           context,
//                           MaterialPageRoute(
//                               builder: (context) => const newpageu48()));
//                     },
//                   ),
//                 ],
//               );
//             }).then((value) {
//           // Update the state after the dialog is dismissed
//           setState(() {});
//         });
//         print("jhgf" + newpati.status.toString());
//       }
//     }
//     print("itsworkinfine");
//   }
// //exsisting

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       key: _scaffoldKey,
//       appBar: AppBar(
//         backgroundColor: Color.fromRGBO(119, 94, 158, 100),
//         title: const Text(
//           'Patient Registration Form 48',
//           style: TextStyle(color: Colors.white),
//         ),
//         actions: <Widget>[
//           TextButton(
//             child: const Text(
//               '',
//               style: TextStyle(
//                 color: Colors.white,
//               ),
//             ),
//             onPressed: () {
//               if (_formKey.currentState!.validate()) {
//                 // TODO: Save patient info
//               }
//             },
//           ),
//         ],
//       ),
//       drawer: Drawer(
//         width: 200,
//         child: Container(
//           decoration: const BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topRight,
//               end: Alignment.bottomCenter,
//               colors: [
//                 Color.fromRGBO(51, 62, 101, 5),
//                 Color.fromRGBO(107, 80, 135, 5)
//               ],
//             ),
//           ),
//           child: ListView(
//             children: <Widget>[
//               // const UserAccountsDrawerHeader(
//               //   currentAccountPictureSize: Size.square(90.0),
//               //   accountName: Text(
//               //     '',
//               //     style: TextStyle(color: Colors.white),
//               //   ),
//               //   accountEmail: Text(
//               //     '',
//               //     style: TextStyle(color: Colors.white),
//               //   ),
//               //   currentAccountPicture: CircleAvatar(
//               //     backgroundColor: Colors.white,
//               //     child: Text(
//               //       'P',
//               //       style: TextStyle(
//               //         fontSize: 20.0,
//               //         fontWeight: FontWeight.bold,
//               //         color: Colors.purple,
//               //       ),
//               //     ),
//               //   ),
//               //   decoration: BoxDecoration(
//               //     gradient: LinearGradient(
//               //       begin: Alignment.topCenter,
//               //       end: Alignment.bottomCenter,
//               //       colors: [Colors.transparent, Colors.transparent],
//               //       //  [Color.fromRGBO(51, 62, 101,10), Color.fromRGBO(51, 62, 101,10)],
//               //     ),
//               //   ),
//               // ),
//               // Padding(
//               //   padding: const EdgeInsets.all(8.0),
//               //   child: Row(
//               //     children: [
//               //       const Icon(
//               //         Icons.image,
//               //         color: Colors.white,
//               //       ),
//               //       const SizedBox(
//               //         width: 10,
//               //       ),
//               //       const Icon(
//               //         Icons.edit,
//               //         color: Colors.white,
//               //       ),
//               //     ],
//               //   ),
//               // ),
//               ListTile(
//                 title: Text(
//                   'Patient',
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 onTap: () {
//                   Navigator.of(context)
//                       .push(MaterialPageRoute(builder: (context) => pereg1()));

//                   // TODO: Navigate to patient info page
//                 },
//               ),
//               ListTile(
//                 autofocus: true,
//                 selected: true,
//                 focusColor: Colors.white,
//                 selectedColor: Colors.white,
//                 enabled: true,
//                 title: Text(
//                   'Physician',
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 onTap: () {
//                   Navigator.of(context)
//                       .push(MaterialPageRoute(builder: (context) => pereg2()));
//                 },
//               ),
//               ListTile(
//                 title: Text(
//                   'COVID-19',
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 onTap: () {
//                   Navigator.of(context)
//                       .push(MaterialPageRoute(builder: (context) => pereg8()));
//                   // TODO: Navigate to COVID-19 info page
//                 },
//               ),
//               ListTile(
//                 title: Text(
//                   'Guarantor',
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 onTap: () {
//                   Navigator.of(context)
//                       .push(MaterialPageRoute(builder: (context) => pereg3()));
//                   // TODO: Navigate to guarantor info page
//                 },
//               ),
//               ListTile(
//                 title: Text(
//                   'Insurance',
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 onTap: () {
//                   Navigator.of(context)
//                       .push(MaterialPageRoute(builder: (context) => pereg7()));
//                   // TODO: Navigate to insurance info page
//                 },
//               ),
//               ListTile(
//                 title: Text(
//                   'Emergency Contact',
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 onTap: () {
//                   Navigator.of(context)
//                       .push(MaterialPageRoute(builder: (context) => pereg4()));
//                   // TODO: Navigate to emergency info page
//                 },
//               ),
//               ListTile(
//                 title: Text(
//                   'Marketing',
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 onTap: () {
//                   Navigator.of(context)
//                       .push(MaterialPageRoute(builder: (context) => pereg5()));
//                   // TODO: Navigate to marketing info page
//                 },
//               ),
//               ListTile(
//                 title: Text(
//                   'ID Upload',
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 onTap: () {
//                   Navigator.of(context)
//                       .push(MaterialPageRoute(builder: (context) => pereg6()));
//                   // TODO: Navigate to ID upload page
//                 },
//               ),
//             ],
//           ),
//         ),
//       ),
//       bottomNavigationBar: BottomAppBar(

//           // color: Color(0xFFC0C0C0),
//           child: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//             colors: [
//               Colors.white,
//               Colors.grey,
//             ],
//           ),
//         ),
//         child: Row(
//           children: <Widget>[
//             const Spacer(),
//             const Expanded(
//               child: Padding(
//                 padding: EdgeInsets.all(18.0),
//                 child: Text(
//                   "",
//                   style: TextStyle(
//                       // color: Color(0xFFC0C0C0),
//                       fontSize: 16.0),
//                 ),
//               ),
//             ),
//             Padding(
//                 padding: EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
//                 child: Container(
//                     decoration: ShapeDecoration(
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(18.0),
//                       ),
//                       gradient: const LinearGradient(
//                           begin: Alignment.topCenter,
//                           end: Alignment.bottomCenter,
//                           colors: [
//                             Color(0xFF8800FF),
//                             Color(0xFFA600FF),
//                           ]),
//                     ),
//                     child: ElevatedButton(
//                         onPressed: () {
//                           context.read<UserData>().terenid = "48";
//                           if (_formKey.currentState!.validate()) {
//                             Navigator.of(context).push(MaterialPageRoute(
//                                 builder: (context) => pereg1()));
//                           }

//                           //sending this get this all from shared pref and send the data
//                           print(infop.toString());
//                         },
//                         child: Text("NEXT"),
//                         style: ElevatedButton.styleFrom(
//                             tapTargetSize: MaterialTapTargetSize.shrinkWrap,
//                             primary: Colors.transparent,
//                             shadowColor: Colors.transparent,
//                             elevation: 0,
//                             textStyle: TextStyle(
//                                 fontSize: 18,
//                                 fontWeight: FontWeight.bold,
//                                 color: Colors.black))))),
//           ],
//         ),
//       )),
//       body: Container(
//         decoration: BoxDecoration(
//           color: Colors.grey[200],
//         ),
//         padding: EdgeInsets.all(20.0),
//         child: Form(
//           key: _formKey,
//           child: ListView(
//             children: <Widget>[
//               DropdownButtonFormField<String>(
//                 decoration: InputDecoration(
//                   labelText: 'Title',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(20.0),
//                   ),
//                 ),
//                 items: <String>['Mr', 'Mrs', 'Ms', 'Dr', 'Prof']
//                     .map((String value) {
//                   return DropdownMenuItem<String>(
//                     value: value,
//                     child: Text(value),
//                   );
//                 }).toList(),
//                 onChanged: (String? value) {
//                   setState(() {
//                     _formKey.currentState!.validate();
//                   });
//                   context.read<UserData>().title = value;
//                   infop.title = value;
//                 },
//               ),
//               const SizedBox(height: 10.0),
//               TextFormField(
//                 controller: firstNameController,
//                 keyboardType: TextInputType.name,
//                 onChanged: (String? value) {
//                   setState(() {
//                     _formKey.currentState!.validate();
//                   });
//                   context.read<UserData>().firstName = value;
//                   _existing();
//                 },
//                 decoration: InputDecoration(
//                   labelText: 'First Name',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(20.0),
//                   ),
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Please enter your first name';
//                   }
//                   return null;
//                 },
//               ),
//               const SizedBox(height: 10.0),
//               TextFormField(
//                 //   validator: (value) {
//                 //   if (value!.isEmpty) {
//                 //     return 'Please enter ';
//                 //   }
//                 //   return null;
//                 // },

//                 keyboardType: TextInputType.name,
//                 onChanged: (String? value) {
//                   setState(() {
//                     _formKey.currentState!.validate();
//                   });
//                   context.read<UserData>().middleInitial = value;
//                 },
//                 decoration: InputDecoration(
//                   labelText: 'Middle Name',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(20.0),
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 10.0),
//               TextFormField(
//                 controller: lastNameController,
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Please enter ';
//                   }
//                   return null;
//                 },
//                 keyboardType: TextInputType.name,
//                 onChanged: (String? value) {
//                   setState(() {
//                     _formKey.currentState!.validate();
//                   });
//                   context.read<UserData>().lastName = value;
//                   _existing();
//                 },
//                 decoration: InputDecoration(
//                   labelText: 'Last Name',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(20.0),
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 10.0),
//               DropdownButtonFormField<String>(
//                 onChanged: (String? value) {
//                   setState(() {
//                     _formKey.currentState!.validate();
//                   });
//                   context.read<UserData>().maritalStatus = value;
//                 },
//                 decoration: InputDecoration(
//                   labelText: 'Marital Status',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(20.0),
//                   ),
//                 ),
//                 items: <String>['Single', 'Married', 'Divorced', 'Widowed']
//                     .map((String value) {
//                   return DropdownMenuItem<String>(
//                     value: value,
//                     child: Text(value),
//                   );
//                 }).toList(),
//                 // onChanged: (String? value) {},
//               ),
//               const SizedBox(height: 10.0),

// // No general suggestions.

// // Inserted code block:
//               TextFormField(
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Please enter ';
//                   }
//                   return null;
//                 },
//                 keyboardType: TextInputType.datetime,
//                 controller: DOBCONTRs,
//                 onChanged: (String? value) {
//                   setState(() {
//                     _formKey.currentState!.validate();
//                   });
//                   context.read<UserData>().dob = DOBCONTRs.text;
//                   print(context.read<UserData>().dob);
//                   _existing();
//                 },
//                 decoration: InputDecoration(
//                   labelText: 'Date of Birth',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(20.0),
//                   ),
//                 ),
//                 onTap: () async {
//                   DateTime? dob = await showDatePicker(
//                       context: context,
//                       initialDate: DateTime.now(),
//                       firstDate: DateTime(1900),
//                       lastDate: DateTime.now());

//                   if (dob != null) {
//                     context.read<UserData>().dob =
//                         "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
//                     DOBCONTRs.text =
//                         "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
//                     // Do something with the selected date
//                     setState(() {
//                       _formKey.currentState!.validate();
//                     });
//                     print(context.read<UserData>().dob);
//                     _existing();
//                   }
//                 },
//               ),
//               const SizedBox(height: 10.0),
//               TextFormField(
//                 //   validator: (value) {
//                 //   if (value!.isEmpty) {
//                 //     return 'Please enter ';
//                 //   }
//                 //   return null;
//                 // },
//                 keyboardType: TextInputType.number,
//                 onChanged: (String? value) {
//                   setState(() {
//                     _formKey.currentState!.validate();
//                   });
//                   context.read<UserData>().ssn = value;
//                 },
//                 decoration: InputDecoration(
//                   labelText: 'SSN',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(20.0),
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 10.0),
//               DropdownButtonFormField<String>(
//                 decoration: InputDecoration(
//                   labelText: 'Attending Physician',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(20.0),
//                   ),
//                 ),
//                 items: <String>[
//                   'Dr. Smith',
//                   'Dr. Johnson',
//                   'Dr. Lee',
//                   'Dr. Williams'
//                 ].map((String value) {
//                   return DropdownMenuItem<String>(
//                     value: value,
//                     child: Text(value),
//                   );
//                 }).toList(),
//                 onChanged: (String? value) {
//                   setState(() {
//                     _formKey.currentState!.validate();
//                   });
//                 },
//               ),
//               const SizedBox(height: 10.0),
//               // DropdownButtonFormField<String>(
//               //   decoration: InputDecoration(
//               //     labelText: 'Self-Pay',
//               //     border: OutlineInputBorder(
//               //       borderRadius: BorderRadius.circular(20.0),
//               //     ),
//               //   ),
//               //   items: <String>['Yes', 'No'].map((String value) {
//               //     return DropdownMenuItem<String>(
//               //       value: value,
//               //       child: Text(value),
//               //     );
//               //   }).toList(),
//               //   onChanged: (String? value) {},
//               // ),
//               Column(
//                 children: [
//                   GestureDetector(
//                     onTap: () async {
//                       getImage(ImageSource.camera);
//                     },
//                     child: Container(
//                       width: 200.0,
//                       height: 200.0,
//                       decoration: BoxDecoration(
//                         image: DecorationImage(
//                             fit: BoxFit.cover, image: img.image),
//                         borderRadius: BorderRadius.all(Radius.circular(100.0)),
//                         color: Colors.transparent,
//                       ),
//                     ),
//                   ),
//                   const SizedBox(height: 10.0),
//                   Text("Select Photo"),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Future<void> getImage(ImageSource source) async {
//     final picker = ImagePicker();
//     XFile? pickedFile = await picker.pickImage(source: source);

//     final path = pickedFile!.path;
//     final Uint8List bytes = await pickedFile.readAsBytes();

//     if (pickedFile != null) {
//       setState(() {
//         img = Image(
//           image: Image.memory(bytes).image,
//           fit: BoxFit.cover,
//         );
//       });
//     }
//   }
// }


import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'dart:typed_data';
import 'package:provider/provider.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/regph2.dart';
import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph6.dart';
import 'package:reg_app/regph7.dart';
import '../gender.dart';
import '../models.dart';
import '../patientdetails.dart';
import '../pdfs.dart';
import '../regph8.dart';

class existing {
  String? message;
  int? patientRegId;
  bool? status;
  existing({this.message, this.patientRegId, this.status});
  existing.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    patientRegId = json['patientRegId'];
    status = json['status'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['patientRegId'] = this.patientRegId;
    data['status'] = this.status;
    return data;
  }
}

class newpageu48 extends StatefulWidget {
  const newpageu48({super.key});
  static const String route = '/48';
  @override
  _newpageu48State createState() => _newpageu48State();
}

class _newpageu48State extends State<newpageu48> {
  bool c1 = false;
  bool c2 = false;
  bool c3 = false;
  Image img = const Image(
    image: AssetImage("assets/illustration.png"),
    fit: BoxFit.fill,
  );
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  TextEditingController DOBCONTRs = TextEditingController();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController dobcontroller = TextEditingController();
  TextEditingController tite = TextEditingController();
  TextEditingController midna = TextEditingController();
  TextEditingController marit = TextEditingController();
  TextEditingController ssnm = TextEditingController();
  TextEditingController attendk = TextEditingController();
  Future<existing?> exitingp(
      String payerName, String lastname, String dob) async {
    String BaseUrl =
        "https://qa.rovermd.com:7685/patientExternal/existingpatientcheck";
    var jsonData = null;
    Uri uri = Uri.parse(BaseUrl);
    final headers = {
      'Content-Type': 'application/json',
      'accept': '*/*',
      'X-TenantID': "48"
    };
    print(dob);
    final body = jsonEncode(<String, String>{
      "firstName": payerName,
      "lastName": lastname,
      "dob": dob
    });
    print("URI HERE-- " + uri.toString());
    var response = await http.post(uri, headers: headers, body: body);
    print(body.toString());
    if (response.statusCode == 200) {
      jsonData = json.decode(response.body.toString());
      existing priInsData = existing.fromJson(jsonDecode(response.body));
      print("jsonData45---$jsonData");
      return priInsData;
    } else {
      throw Exception('Failed to load data');
    }
  }

  Future<void> _existing() async {
    if (firstNameController.text != "" &&
        lastNameController.text != "" &&
        DOBCONTRs.text != "") {
      final newpati = await exitingp(
          firstNameController.text, lastNameController.text, DOBCONTRs.text);
      print("itsworki");
      if (newpati!.status!) {
        showDialog(
            barrierDismissible: false,
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text(
                  'Already Registered',
                  overflow: TextOverflow.visible,
                ),
                content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                    return SizedBox(
                      height: 70,
                      child: Column(
                        children: [
                          Text(
                            newpati.message!,
                            style: TextStyle(
                                color: Color.fromARGB(255, 0, 34, 255),
                                fontSize: 30),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width / 2,
                            child: const Text(
                              overflow: TextOverflow.visible,
                              'Please proceed to the front desk',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          Text(''),
                        ],
                      ),
                    );
                  },
                ),
                actions: <Widget>[
                  TextButton(
                    child: Text('OK'),
                    onPressed: () {
                      setState(() {});
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const newpageu48()));
                    },
                  ),
                ],
              );
            }).then((value) {
          // Update the state after the dialog is dismissed
          setState(() {});
        });
        print("jhgf" + newpati.status.toString());
      }
    }
    print("itsworkinfine");
  }

Future<List<Docce>?> genderController() async {
    try {
      var jsonData = null;
      Uri uri = Uri.parse(
          "https://qa.rovermd.com:7685/api/v2/sharedExternal/all");
      // Uri uri = Uri.parse("$BaseUrl/gender/find/all");
      print(uri.toString());
      final headers = {
      'Content-Type': 'application/json',
      'accept': '*/*',
      'X-TenantID': "48"
    };
      var response = await http.get(uri,headers:headers);
      print("jsonData---$response");
      // print("response---$response");
      if (response.statusCode == 200) {
        jsonData = json.decode(response.body.toString());
        List<dynamic> genderData = jsonData;
        print("jsonData---$jsonData");

        return genderData.map((data) => Docce.fromJson(data)).toList();
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      print("Error in sex Funtion: $e");
    }
    return null;
  }
List<Docce>? genders;
  void initState() {
    super.initState();
    if (context.read<UserData>().firstName != null) {
      firstNameController.text = context.read<UserData>().firstName!;
    }
      genderController().then((genders) {
      setState(() {
        this.genders = genders;
      });
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(119, 94, 158, 100),
        title: const Text(
          'Patient Registration Form',
          style: TextStyle(color: Colors.white),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              '',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                // TODO: Save patient info
              }
            },
          ),
        ],
      ),
      drawer: Drawer(
        width: 200,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(51, 62, 101, 5),
                Color.fromRGBO(107, 80, 135, 5)
              ],
            ),
          ),
          child: ListView(
            children: <Widget>[
              ListTile(
                title: Text(
                  'Patient',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg1()));

                  // TODO: Navigate to patient info page
                },
              ),
              ListTile(
                autofocus: true,
                selected: true,
                focusColor: Colors.white,
                selectedColor: Colors.white,
                enabled: true,
                title: Text(
                  'Physician',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg2()));
                },
              ),
              ListTile(
                title: Text(
                  'COVID-19',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg8()));
                  // TODO: Navigate to COVID-19 info page
                },
              ),
              ListTile(
                title: Text(
                  'Guarantor',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg3()));
                  // TODO: Navigate to guarantor info page
                },
              ),
              ListTile(
                title: Text(
                  'Insurance',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg7()));
                  // TODO: Navigate to insurance info page
                },
              ),
              ListTile(
                title: Text(
                  'Emergency Contact',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg4()));
                  // TODO: Navigate to emergency info page
                },
              ),
              ListTile(
                title: Text(
                  'Marketing',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg5()));
                  // TODO: Navigate to marketing info page
                },
              ),
              ListTile(
                title: Text(
                  'ID Upload',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg6()));
                  // TODO: Navigate to ID upload page
                },
              ),
                const Divider(
                color: Colors.white,
              ),
                 Positioned(
                  top:500,
                   child: ListTile(
                                 title: Text(
                    'Patient bundle',
                            
                    style: TextStyle(color: Colors.white),
                                 ),
                                 onTap: () {
                    Navigator.of(context)
                        .push(MaterialPageRoute(builder: (context) => patientdetails()));
                    // TODO: Navigate to ID upload page
                                 },
                               ),
                 ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
          child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.grey,
            ],
          ),
        ),
        child: Row(
          children: <Widget>[
            const Spacer(),
            const Expanded(
              child: Padding(
                padding: EdgeInsets.all(18.0),
                child: Text(
                  "",
                  style: TextStyle(
                      // color: Color(0xFFC0C0C0),
                      fontSize: 16.0),
                ),
              ),
            ),
            Padding(
                padding: EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () {
                          context.read<UserData>().terenid = "48";
                          if (_formKey.currentState!.validate()) {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => pereg1()));
                          }
                        },
                        child: Text("NEXT"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
          ],
        ),
      )),
      body: Container(
        decoration: BoxDecoration(
          color: Colors.grey[200],
        ),
        padding: EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: <Widget>[
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: 'Title',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
                items: <String>[
                  "Mr",
                  "Miss",
                  "Mrs",
                  "Ms",
                ].map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    _formKey.currentState!.validate();
                  });
                  context.read<UserData>().title = value;
                },
              ),
              const SizedBox(height: 10.0),
              TextFormField(
                onTap: () {
                  setState(() {});
                },
                controller: firstNameController,
                keyboardType: TextInputType.name,
                validator: (value) {
                  if (value != null) {
                    c1 = true;
                  }
                  if (value!.isEmpty) {
                    return 'Please enter ';
                  }
                  return null;
                },
                onChanged: (String? value) {
                  _formKey.currentState!.validate();
                  context.read<UserData>().firstName = value;
                  if (value != null) {
                    if(value !=null)
                      context.read<UserData>().fsn=true;
                      else
                        context.read<UserData>().fsn=false;
                    c1 =  context.read<UserData>().fsn==null;
                  }
                  _existing();
                },
                inputFormatters: [
                  MaskTextInputFormatter(
                      mask: '########################',
                      filter: {"#": RegExp(r'[a-zA-Z]')},
                      type: MaskAutoCompletionType.lazy)
                ],
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    borderSide: BorderSide(
                      color:    context.read<UserData>().fsn==null ? Color.fromARGB(123, 255, 0, 0) :context.read<UserData>().fsn! ? Colors.grey: Color.fromARGB(123, 255, 0, 0),
                      width: 2.0,
                    ),
                  ),
                  labelText: 'First Name',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
              ),
              const SizedBox(height: 10.0),
              TextFormField(
                onTap: () {
                  setState(() {});
                },
                controller: midna,
                keyboardType: TextInputType.name,
                onChanged: (String? value) {
                  _formKey.currentState!.validate();
                  context.read<UserData>().middleInitial = value;
                },
                inputFormatters: [
                  MaskTextInputFormatter(
                      mask: '##########################',
                      filter: {"#": RegExp(r'[a-zA-Z]')},
                      type: MaskAutoCompletionType.lazy)
                ],
                decoration: InputDecoration(
                  labelText: 'Middle Name',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
              ),
              const SizedBox(height: 10.0),
              TextFormField(
                onTap: () {
                  setState(() {});
                },
                controller: lastNameController,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter ';
                  }
                  return null;
                },
                keyboardType: TextInputType.name,
                onChanged: (String? value) {
                  _formKey.currentState!.validate();

                  context.read<UserData>().lastName = value;
                  if (value != null) {
                      if(value !=null)
                      context.read<UserData>().lan=true;
                      else
                        context.read<UserData>().lan=false;
                       
                    c2 = true;
                  }
                  _existing();
                },
                inputFormatters: [
                  MaskTextInputFormatter(
                      mask: '#####################',
                      filter: {"#": RegExp(r'[a-zA-Z]')},
                      type: MaskAutoCompletionType.lazy)
                ],
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    borderSide: BorderSide(
                      color:  context.read<UserData>().lan==null ? Color.fromARGB(123, 255, 0, 0) :context.read<UserData>().lan! ? Colors.grey: Color.fromARGB(123, 255, 0, 0),
                      width: 2.0,
                    ),
                  ),
                  labelText: 'Last Name',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
              ),
              const SizedBox(height: 10.0),
              DropdownButtonFormField<String>(
                onChanged: (String? value) {
                  setState(() {
                    _formKey.currentState!.validate();
                  });
                  context.read<UserData>().maritalStatus = value;
                },
                decoration: InputDecoration(
                  labelText: 'Marital Status',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
                items: <String>[
                  "Single",
                  "Mar",
                  "Div",
                  "Sep",
                  "Wid",
                ].map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(
                      value,
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10.0),
              TextFormField(
                keyboardType: TextInputType.datetime,
                controller: DOBCONTRs,
                onChanged: (String? value) {
                  setState(() {
                    if (value != null) {
                     context.read<UserData>().dof = true;
                    }
                    _formKey.currentState!.validate();
                    if (value != null) {
                     context.read<UserData>().dof= true;
                    }
                  });
                  context.read<UserData>().dob = DOBCONTRs.text;
                  print(context.read<UserData>().dob);
                  _existing();
                },
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    borderSide: BorderSide(
                      color: context.read<UserData>().dof==null ? Color.fromARGB(123, 255, 0, 0) :context.read<UserData>().dof! ? Colors.grey: Color.fromARGB(123, 255, 0, 0),
                      width: 2.0,
                    ),
                  ),
                  labelText: 'Date of Birth',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter ';
                  }
                  return null;
                },
                onTap: () async {
                  setState(() {
                    _formKey.currentState!.validate();
                  });
                  DateTime? dob = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime.now());

                  if (dob != null) {
                     context.read<UserData>().dof=true;
                    context.read<UserData>().newdobsubcriber= "${dob.year}-${dob.month < 10 ? "0${dob.month}" : dob.month}-${dob.day < 10 ? "0${dob.day}" : dob.day}T14:21:25.017Z";
                    context.read<UserData>().dob =
                        "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                    DOBCONTRs.text =
                        "${dob.month < 10 ? "0${dob.month}" : dob.month}/${dob.day < 10 ? "0${dob.day}" : dob.day}/${dob.year}";
                    // Do something with the selected date
                    setState(() {
                          context.read<UserData>().dof=true;
                      _formKey.currentState!.validate();
                    });
                    print(context.read<UserData>().dob);
                    _existing();
                  }
                },
              ),
              const SizedBox(height: 10.0),
              TextFormField(
                onTap: () {
                  setState(() {});
                },
                keyboardType: TextInputType.number,
                onChanged: (String? value) {
                  _formKey.currentState!.validate();

                  context.read<UserData>().ssn = value;
                },
                inputFormatters: [
                  MaskTextInputFormatter(
                      mask: '#########',
                      filter: {"#": RegExp(r'[0-9]')},
                      type: MaskAutoCompletionType.lazy)
                ],
                  validator: (value) {
                       
                       
                        if (value!.length < 8 && value!.length !=0) {
                          print("lenght " + value.length.toString());
                          return 'Please enter your contact number';
                        }
                        print("lenght " + value.length.toString());
                        return null;
                      },
                controller: ssnm,
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    borderSide: BorderSide(
                      color: Colors.grey,
                      width: 2.0,
                    ),
                  ),
                  labelText: 'SSN',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
              ),
              const SizedBox(height: 10.0),
             
              if(genders ==null?false:true)
              Visibility(
                visible: genders!=null,
                child: DropdownButtonFormField<Docce>(
                  decoration: InputDecoration(
                    labelText: 'Attending Physician',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  items: genders!.map((Docce value) {
                    return DropdownMenuItem<Docce>(
                      value: value,
                      child: Text(value.name),
                    );
                  }).toList(),
                  onChanged: (Docce? value) {
                    context.read<UserData>().doctorId =value!.id;
                    setState(() {
                      _formKey.currentState!.validate();
                    });
                  },
                ),
              ),
              const SizedBox(height: 10.0),
              Column(
                children: [
                  GestureDetector(
                    onTap: () async {
                      getImage(ImageSource.camera);
                    },
                    child: Container(
                      width: 200.0,
                      height: 200.0,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                            fit: BoxFit.cover, image: img.image),
                        borderRadius: BorderRadius.all(Radius.circular(100.0)),
                        color: Colors.transparent,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text("Select Photo"),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> getImage(ImageSource source) async {
    final picker = ImagePicker();
    XFile? pickedFile = await picker.pickImage(source: source);
    final path = pickedFile!.path;

    context.read<UserData>().profileImageName = pickedFile!.name;
    context.read<UserData>().hasProfileImage = pickedFile == null ? 0 : 1;
    var request = http.MultipartRequest("POST",
        Uri.parse('https://qa.rovermd.com:7685/patientExternal/upload'));
    request.headers.addAll(
      {
        'Content-Type': 'application/json',
        'accept': '*/*',
        'X-TenantID': '${context.read<UserData>().terenid}',
      },
    );
    request.files.add(await http.MultipartFile.fromPath('profile_pic', path));
    request.send().then((response) {
      http.Response.fromStream(response).then((onValue) {
        try {} catch (e) {}
      });
    });
    var response = await request.send();
    if (response.statusCode == 200) print('Uploaded!');
    Uint8List bytes = await pickedFile.readAsBytes();
    String base64string = base64.encode(bytes);
    if (pickedFile != null) {
      setState(() {
        img = Image(
          image: Image.memory(bytes).image,
          fit: BoxFit.cover,
        );
      });
    }
  }
}


