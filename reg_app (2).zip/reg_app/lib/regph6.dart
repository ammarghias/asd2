// Suggestions:
// 1. Use MaterialApp and Scaffold widgets for easier app and UI building
// 2. Use ListView for the drawer items
// 3. Use CircleAvatar for profile picture
// 4. Use InputDecoration for rounded border text fields

import 'dart:convert';
//
//import 'package:http_io/http.dart' as http;

import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/regph2.dart';

import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph4.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph7.dart';
import 'package:reg_app/regph8.dart';

class pereg6 extends StatefulWidget {
  @override
  _pereg6State createState() => _pereg6State();
  static const String route = '/idu';
}

class _pereg6State extends State<pereg6> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  String trre = "";

  Future<void> _existing() async {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
              'Successfully Registered',
              overflow: TextOverflow.visible,
            ),
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SizedBox(
                  height: 70,
                  child: Column(
                    children: [
                      Text(
                        "",
                        style: TextStyle(
                            color: Color.fromARGB(255, 0, 34, 255),
                            fontSize: 30),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width / 2,
                        child: const Text(
                          overflow: TextOverflow.visible,
                          'Please proceed to the front desk',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            actions: <Widget>[
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  setState(() {});
                  Navigator.of(context).pushNamedAndRemoveUntil(
                      '/$trre', (Route<dynamic> route) => false);
                },
              ),
            ],
          );
        }).then((value) {
      // Update the state after the dialog is dismissed
      setState(() {});
    });
  }

  Future<String?> registerPatient(Map<String, dynamic> patientInfo) async {
    String BaseUrl = "https://qa.rovermd.com:7685/patientExternal/register";
    Uri uri = Uri.parse(BaseUrl);
    var response = await http.post(uri,
        headers: {
          'Content-Type': 'application/json',
          'accept': '*/*',
          'X-TenantID': '${context.read<UserData>().terenid}',
        },
        body: jsonEncode(patientInfo));
    print("URI HERE-- " + response.toString());

    print("responseBody--${response.body.toString()}");
    if (response.statusCode == 200) {
      context.read<UserData>().deleteall();

      final jsonData = json.decode(response.body.toString());
      //  Provider.of<UserData>(context, listen: false).dispose();
      if (jsonData['status'] == true) {
      } else {}
    } else {
      // EasyLoading.showError("Unable to save data");
    }
    return response.statusCode.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(119, 94, 158, 100),
        title: const Text(
          ' ID Upload',
          style: TextStyle(color: Colors.white),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              '',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            onPressed: () {
              if (_formKey.currentState!.validate()) {}
            },
          ),
        ],
      ),
      drawer: Drawer(
        width: 200,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(51, 62, 101, 5),
                Color.fromRGBO(107, 80, 135, 5)
              ],
            ),
          ),
          child: ListView(
            children: <Widget>[
              ListTile(
                title: Text(
                  'Patient',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg1()));

                  // TODO: Navigate to patient info page
                },
              ),
              ListTile(
                autofocus: true,
                selected: true,
                focusColor: Colors.white,
                selectedColor: Colors.white,
                enabled: true,
                title: Text(
                  'Physician',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg2()));
                },
              ),
              ListTile(
                title: Text(
                  'COVID-19',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg8()));
                  // TODO: Navigate to COVID-19 info page
                },
              ),
              ListTile(
                title: Text(
                  'Guarantor',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg3()));
                  // TODO: Navigate to guarantor info page
                },
              ),
              ListTile(
                title: Text(
                  'Insurance',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg7()));
                  // TODO: Navigate to insurance info page
                },
              ),
              ListTile(
                title: Text(
                  'Emergency Contact',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg4()));
                  // TODO: Navigate to emergency info page
                },
              ),
              ListTile(
                title: Text(
                  'Marketing',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg5()));
                  // TODO: Navigate to marketing info page
                },
              ),
              ListTile(
                title: Text(
                  'ID Upload',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg6()));
                  // TODO: Navigate to ID upload page
                },
              ),
            ],
          ),
        ),
      ),

// It is recommended to use the TextFormField widget for text input fields as it provides built-in validation features
// Use the DropdownButtonFormField widget for dropdowns to simplify code and provide built-in validation
// We can use the Container widget to set the background color and border radius for the forms

// Dart code block:

// Consider using a Form widget to wrap the input fields for easier validation and submission
// Use TextFormField for text input fields and DropdownButtonFormField for dropdowns

// Dart code block:

// Suggestions:
// - Consider using the Form widget to wrap the input fields for easier validation and submission
// - Use TextFormField for text input fields and DropdownButtonFormField for dropdowns
// - Use the Container widget to set the background color and border radius for the forms

// Dart code block:
      // bottomNavigationBar: BottomAppBar(

      //     // color: Color(0xFFC0C0C0),
      //     child: Container(
      //   decoration: const BoxDecoration(
      //     gradient: LinearGradient(
      //       begin: Alignment.topCenter,
      //       end: Alignment.bottomCenter,
      //       colors: [
      //         Colors.white,
      //         Colors.grey,
      //       ],
      //     ),
      //   ),
      //   child: Row(
      //     children: <Widget>[
      //       Padding(
      //           padding: const EdgeInsets.only(
      //               left: 10.0, top: 10.0, bottom: 5.0, right: 10.0),
      //           child: Container(
      //               decoration: ShapeDecoration(
      //                 shape: RoundedRectangleBorder(
      //                   borderRadius: BorderRadius.circular(18.0),
      //                 ),
      //                 gradient: const LinearGradient(
      //                     begin: Alignment.topCenter,
      //                     end: Alignment.bottomCenter,
      //                     colors: [
      //                       Color(0xFF8800FF),
      //                       Color(0xFFA600FF),
      //                     ]),
      //               ),
      //               child: ElevatedButton(
      //                   onPressed: () async {
      //                     Navigator.of(context).pop();
      //                     // Navigator.push(context, MaterialPageRoute(builder: (context) => PersonalInfoRegister(),));
      //                   },
      //                   child: const Text("BACK"),
      //                   style: ElevatedButton.styleFrom(
      //                       tapTargetSize: MaterialTapTargetSize.shrinkWrap,
      //                       primary: Colors.transparent,
      //                       shadowColor: Colors.transparent,
      //                       elevation: 0,
      //                       textStyle: const TextStyle(
      //                           fontSize: 18,
      //                           fontWeight: FontWeight.bold,
      //                           color: Colors.black))))),
      //       const Spacer(),
      //       const Expanded(
      //         child: Padding(
      //           padding: EdgeInsets.all(18.0),
      //           child: Text(
      //             "",
      //             style: TextStyle(
      //                 // color: Color(0xFFC0C0C0),
      //                 fontSize: 16.0),
      //           ),
      //         ),
      //       ),
      //       Padding(
      //           padding: EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
      //           child: Container(
      //               decoration: ShapeDecoration(
      //                 shape: RoundedRectangleBorder(
      //                   borderRadius: BorderRadius.circular(18.0),
      //                 ),
      //                 gradient: const LinearGradient(
      //                     begin: Alignment.topCenter,
      //                     end: Alignment.bottomCenter,
      //                     colors: [
      //                       Color(0xFF8800FF),
      //                       Color(0xFFA600FF),
      //                     ]),
      //               ),
      //               child: ElevatedButton(
      //                   onPressed: () async {
      //                     //sending this get this all from shared pref and send the data

      //                       Navigator.of(context).push(MaterialPageRoute(
      //                           builder: (context) => pereg7()));

      //                   },
      //                   child: Text("NEXT"),
      //                   style: ElevatedButton.styleFrom(
      //                       tapTargetSize: MaterialTapTargetSize.shrinkWrap,
      //                       primary: Colors.transparent,
      //                       shadowColor: Colors.transparent,
      //                       elevation: 0,
      //                       textStyle: TextStyle(
      //                           fontSize: 18,
      //                           fontWeight: FontWeight.bold,
      //                           color: Colors.black))))),
      //     ],
      //   ),
      // )),

      bottomNavigationBar: BottomAppBar(
          child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.grey,
            ],
          ),
        ),
        child: Row(
          children: <Widget>[
            Padding(
                padding: const EdgeInsets.only(
                    left: 10.0, top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          Navigator.of(context).pop();
                          // Navigator.push(context, MaterialPageRoute(builder: (context) => PersonalInfoRegister(),));
                        },
                        child: const Text("BACK"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
            const Spacer(),
            const Expanded(
              child: Padding(
                padding: EdgeInsets.all(18.0),
                child: Text(
                  "",
                  style: TextStyle(
                      // color: Color(0xFFC0C0C0),
                      fontSize: 16.0),
                ),
              ),
            ),
            Padding(
                padding:
                    const EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          trre = context.read<UserData>().terenid.toString();
                          print("ghjf");
                          Map<String, dynamic> jsonData = {
                            "patientReg": {
                              if (context.read<UserData>().title != null)
                                "title": context.read<UserData>().title,
                              if (context.read<UserData>().firstName != null)
                                "firstName": context.read<UserData>().firstName,
                              if (context.read<UserData>().middleInitial !=
                                  null)
                                "middleInitial":
                                    context.read<UserData>().middleInitial,
                              if (context.read<UserData>().lastName != null)
                                "lastName": context.read<UserData>().lastName,
                              if (context.read<UserData>().maritalStatus !=
                                  null)
                                "maritalStatus":
                                    context.read<UserData>().maritalStatus,
                              if (context.read<UserData>().dob != null)
                                "dob": context.read<UserData>().dob,
                              if (context.read<UserData>().ssn != null)
                                "ssn": context.read<UserData>().ssn,
                              if (context.read<UserData>().race != null)
                                "race": context.read<UserData>().race,
                              if (context.read<UserData>().sexualOrientation !=
                                  null)
                                "sexualOrientation":
                                    context.read<UserData>().sexualOrientation,
                              if (context.read<UserData>().genderIdentity !=
                                  null)
                                "genderIdentity":
                                    context.read<UserData>().genderIdentity,
                              if (context.read<UserData>().phNumber != null)
                                "phNumber": context.read<UserData>().phNumber,
                              if (context.read<UserData>().email != null)
                                "email": context.read<UserData>().email,
                              if (context.read<UserData>().address1 != null)
                                "address1": context.read<UserData>().address1,
                              if (context.read<UserData>().address2 != null)
                                "address2": context.read<UserData>().address2,
                              if (context.read<UserData>().zipCode != null)
                                "zipCode": context.read<UserData>().zipCode,
                              if (context.read<UserData>().city != null)
                                "city": context.read<UserData>().city,
                              if (context.read<UserData>().state != null)
                                "state": context.read<UserData>().state,
                              if (context.read<UserData>().county != null)
                                "county": context.read<UserData>().county,
                              if (context.read<UserData>().country != null)
                                "country": context.read<UserData>().country,
                              if (context.read<UserData>().preferredLanguage !=
                                  null)
                                "preferredLanguage":
                                    context.read<UserData>().preferredLanguage,
                              if (context.read<UserData>().employer != null)
                                "employer": context.read<UserData>().employer,
                              if (context.read<UserData>().occupation != null)
                                "occupation":
                                    context.read<UserData>().occupation,
                              if (context.read<UserData>().empContact != null)
                                "empContact":
                                    context.read<UserData>().empContact,

                              "epdSync": 0,

                              "isDraft": 0,

                              "registerFrom": "External",

                              // context.read<UserData>().registerFrom,
                              // if (context.read<UserData>().authorization != null)
                              "authorization":
                                  context.read<UserData>().authorization,

                              // context.read<UserData>().authorization,

                              // "hasProfileImage": context.read<UserData>().hasProfileImage,

                              "contactConsent": 1,

                              // context.read<UserData>().contactConsent,

                              "accurateConsent": 1,

                              // context.read<UserData>().accurateConsent,
                              if (context.read<UserData>().sex != null)
                                "sex": context.read<UserData>().sex,

                              // "profileImageName": context.read<UserData>().profileImageName
                            },
                            "patientEthnicityList": [
                              {
                                if (context.read<UserData>().ethnicityId !=
                                    null)
                                  "ethnicityId":
                                      context.read<UserData>().ethnicityId,
                                if (context.read<UserData>().ethnicity != null)
                                  "ethnicity":
                                      context.read<UserData>().ethnicity
                              }
                            ],
                            "visitDetails": {
                              if (context.read<UserData>().reasonVisit != null)
                                "reasonVisit":
                                    context.read<UserData>().reasonVisit,
                              if (context.read<UserData>().reasonVisitSpecify !=
                                  null)
                                "reasonVisitSpecify":
                                    context.read<UserData>().reasonVisitSpecify,
                              if (context.read<UserData>().doctorId != null)
                                "doctorId": context.read<UserData>().doctorId
                            },
                            "patientPhysicianDetails": {
                              if (context
                                      .read<UserData>()
                                      .primaryCarePhysicianName !=
                                  null)
                                "primaryCarePhysicianName": context
                                    .read<UserData>()
                                    .primaryCarePhysicianName,
                              if (context
                                      .read<UserData>()
                                      .primaryCarePhysicianCity !=
                                  null)
                                "primaryCarePhysicianCity": context
                                    .read<UserData>()
                                    .primaryCarePhysicianCity,
                              if (context
                                      .read<UserData>()
                                      .primaryCarePhysicianState !=
                                  null)
                                "primaryCarePhysicianState": context
                                    .read<UserData>()
                                    .primaryCarePhysicianState,
                              if (context
                                      .read<UserData>()
                                      .primaryCarePhysicianZip !=
                                  null)
                                "primaryCarePhysicianZip": context
                                    .read<UserData>()
                                    .primaryCarePhysicianZip,
                              if (context
                                      .read<UserData>()
                                      .primaryCarePhysicianAddress1 !=
                                  null)
                                "primaryCarePhysicianAddress1": context
                                    .read<UserData>()
                                    .primaryCarePhysicianAddress1,
                              if (context
                                      .read<UserData>()
                                      .primaryCarePhysicianAddress2 !=
                                  null)
                                "primaryCarePhysicianAddress2": context
                                    .read<UserData>()
                                    .primaryCarePhysicianAddress2,
                              if (context
                                      .read<UserData>()
                                      .specialityCarePhysicianName !=
                                  null)
                                "specialityCarePhysicianName": context
                                    .read<UserData>()
                                    .specialityCarePhysicianName,
                              if (context
                                      .read<UserData>()
                                      .specialityCarePhysicianCity !=
                                  null)
                                "specialityCarePhysicianCity": context
                                    .read<UserData>()
                                    .specialityCarePhysicianCity,
                              if (context
                                      .read<UserData>()
                                      .specialityCarePhysicianState !=
                                  null)
                                "specialityCarePhysicianState": context
                                    .read<UserData>()
                                    .specialityCarePhysicianState,
                              if (context
                                      .read<UserData>()
                                      .specialityCarePhysicianZip !=
                                  null)
                                "specialityCarePhysicianZip": context
                                    .read<UserData>()
                                    .specialityCarePhysicianZip,
                              if (context
                                      .read<UserData>()
                                      .specialityCarePhysicianAddress1 !=
                                  null)
                                "specialityCarePhysicianAddress1": context
                                    .read<UserData>()
                                    .specialityCarePhysicianAddress1,
                              if (context
                                      .read<UserData>()
                                      .specialityCarePhysicianAddress2 !=
                                  null)
                                "specialityCarePhysicianAddress2": context
                                    .read<UserData>()
                                    .specialityCarePhysicianAddress2
                            },
                            if (context.read<UserData>().sympCheckCovid == 1)
                              "patientCovidDetails": {
                                if (context.read<UserData>().sympCheckCovid !=
                                    null)
                                  "sympCheckCovid":
                                      context.read<UserData>().sympCheckCovid,
                                if (context
                                        .read<UserData>()
                                        .covidTestForTravelCheck !=
                                    null)
                                  "covidTestForTravelCheck": context
                                      .read<UserData>()
                                      .covidTestForTravelCheck,
                                if (context.read<UserData>().dateSympOnset !=
                                    null)
                                  "dateSympOnset":
                                      context.read<UserData>().dateSympOnset,
                                if (context.read<UserData>().sympFever != null)
                                  "sympFever":
                                      context.read<UserData>().sympFever,
                                if (context.read<UserData>().sympCough != null)
                                  "sympCough":
                                      context.read<UserData>().sympCough,
                                if (context.read<UserData>().sympShortBreath !=
                                    null)
                                  "sympShortBreath":
                                      context.read<UserData>().sympShortBreath,
                                if (context.read<UserData>().sympFatigue !=
                                    null)
                                  "sympFatigue":
                                      context.read<UserData>().sympFatigue,
                                if (context
                                        .read<UserData>()
                                        .sympMuscBodyAches !=
                                    null)
                                  "sympMuscBodyAches": context
                                      .read<UserData>()
                                      .sympMuscBodyAches,
                                if (context.read<UserData>().sympHeadache !=
                                    null)
                                  "sympHeadache":
                                      context.read<UserData>().sympHeadache,
                                if (context.read<UserData>().sympLossTaste !=
                                    null)
                                  "sympLossTaste":
                                      context.read<UserData>().sympLossTaste,
                                if (context.read<UserData>().sympSoreThroat !=
                                    null)
                                  "sympSoreThroat":
                                      context.read<UserData>().sympSoreThroat,
                                if (context
                                        .read<UserData>()
                                        .sympCongestionRunNos !=
                                    null)
                                  "sympCongestionRunNos": context
                                      .read<UserData>()
                                      .sympCongestionRunNos,
                                if (context.read<UserData>().sympNauseaVomit !=
                                    null)
                                  "sympNauseaVomit":
                                      context.read<UserData>().sympNauseaVomit,
                                if (context.read<UserData>().sympDiarrhea !=
                                    null)
                                  "sympDiarrhea":
                                      context.read<UserData>().sympDiarrhea,
                                if (context.read<UserData>().sympPerPainChest !=
                                    null)
                                  "sympPerPainChest":
                                      context.read<UserData>().sympPerPainChest,
                                if (context.read<UserData>().sympNewConfusion !=
                                    null)
                                  "sympNewConfusion":
                                      context.read<UserData>().sympNewConfusion,
                                if (context.read<UserData>().sympInabWake !=
                                    null)
                                  "sympInabWake":
                                      context.read<UserData>().sympInabWake,
                                if (context.read<UserData>().sympOthers != null)
                                  "sympOthers":
                                      context.read<UserData>().sympOthers,
                                if (context.read<UserData>().sympOthersTxt !=
                                    null)
                                  "sympOthersTxt":
                                      context.read<UserData>().sympOthersTxt,
                                if (context
                                        .read<UserData>()
                                        .employedInHealthCareCheck !=
                                    null)
                                  "employedInHealthCareCheck": context
                                      .read<UserData>()
                                      .employedInHealthCareCheck,
                                if (context
                                        .read<UserData>()
                                        .covidPositiveBeforeCheck !=
                                    null)
                                  "covidPositiveBeforeCheck": context
                                              .read<UserData>()
                                              .covidPositiveBeforeCheck ==
                                          1
                                      ? 0
                                      : 1,
                                if (context
                                            .read<UserData>()
                                            .covidPositiveBeforeDate !=
                                        null &&
                                    context
                                            .read<UserData>()
                                            .covidPositiveBeforeCheck ==
                                        0)
                                  "covidPositiveBeforeDate": context
                                      .read<UserData>()
                                      .covidPositiveBeforeDate,
                                if (context
                                        .read<UserData>()
                                        .exposedDirectContactCovidCheck !=
                                    null)
                                  "exposedDirectContactCovidCheck": context
                                              .read<UserData>()
                                              .exposedDirectContactCovidCheck ==
                                          1
                                      ? 0
                                      : 1,
                                if (context
                                            .read<UserData>()
                                            .exposedDirectContactCovidDate !=
                                        null &&
                                    context
                                            .read<UserData>()
                                            .exposedDirectContactCovidCheck ==
                                        0)
                                  "exposedDirectContactCovidDate": context
                                      .read<UserData>()
                                      .exposedDirectContactCovidDate,
                                if (context
                                        .read<UserData>()
                                        .outsideCountryTravelCheck !=
                                    null)
                                  "outsideCountryTravelCheck": context
                                              .read<UserData>()
                                              .outsideCountryTravelCheck ==
                                          1
                                      ? 0
                                      : 1,
                                if (context
                                            .read<UserData>()
                                            .outsideCountryTravelDate !=
                                        null &&
                                    context
                                            .read<UserData>()
                                            .outsideCountryTravelCheck !=
                                        1)
                                  "outsideCountryTravelDate": context
                                      .read<UserData>()
                                      .outsideCountryTravelDate,
                                if (context
                                            .read<UserData>()
                                            .outsideCountryTravelDestination !=
                                        null &&
                                    context
                                            .read<UserData>()
                                            .outsideCountryTravelCheck !=
                                        1)
                                  "outsideCountryTravelDestination": context
                                      .read<UserData>()
                                      .outsideCountryTravelDestination,
                                if (context
                                            .read<UserData>()
                                            .outsideCountryTravelDuration !=
                                        null &&
                                    context
                                            .read<UserData>()
                                            .outsideCountryTravelCheck !=
                                        1)
                                  "outsideCountryTravelDuration": context
                                      .read<UserData>()
                                      .outsideCountryTravelDuration,
                              },
                            "patientGuarantorDetails": {
                              if (context.read<UserData>().guarantorCheck !=
                                  null)
                                "guarantorCheck":
                                    context.read<UserData>().guarantorCheck,
                              if (context.read<UserData>().patientMinorCheck !=
                                  null)
                                "patientMinorCheck":
                                    context.read<UserData>().patientMinorCheck,
                              if (context.read<UserData>().guarantorFirstName !=
                                  null)
                                "guarantorFirstName":
                                    context.read<UserData>().guarantorFirstName,
                              if (context.read<UserData>().guarantorLastName !=
                                  null)
                                "guarantorLastName":
                                    context.read<UserData>().guarantorLastName,
                              if (context
                                      .read<UserData>()
                                      .guarantorPhoneNumber !=
                                  null)
                                "guarantorPhoneNumber": context
                                    .read<UserData>()
                                    .guarantorPhoneNumber,
                              if (context.read<UserData>().guarantorSSN != null)
                                "guarantorSSN":
                                    context.read<UserData>().guarantorSSN,
                              if (context
                                      .read<UserData>()
                                      .guarantorEmployerName !=
                                  null)
                                "guarantorEmployerName": context
                                    .read<UserData>()
                                    .guarantorEmployerName,
                              if (context
                                      .read<UserData>()
                                      .guarantorEmployerPhoneNumber !=
                                  null)
                                "guarantorEmployerPhoneNumber": context
                                    .read<UserData>()
                                    .guarantorEmployerPhoneNumber,
                              if (context
                                      .read<UserData>()
                                      .guarantorEmployerCity !=
                                  null)
                                "guarantorEmployerCity": context
                                    .read<UserData>()
                                    .guarantorEmployerCity,
                              if (context
                                      .read<UserData>()
                                      .guarantorEmployerState !=
                                  null)
                                "guarantorEmployerState": context
                                    .read<UserData>()
                                    .guarantorEmployerState,
                              if (context
                                      .read<UserData>()
                                      .guarantorEmployerZip !=
                                  null)
                                "guarantorEmployerZip": context
                                    .read<UserData>()
                                    .guarantorEmployerZip,
                              if (context
                                      .read<UserData>()
                                      .guarantorEmployerAddress1 !=
                                  null)
                                "guarantorEmployerAddress1": context
                                    .read<UserData>()
                                    .guarantorEmployerAddress1,
                              if (context
                                      .read<UserData>()
                                      .guarantorEmployerAddress2 !=
                                  null)
                                "guarantorEmployerAddress2": context
                                    .read<UserData>()
                                    .guarantorEmployerAddress2,
                              if (context.read<UserData>().guarantorDOB != null)
                                "guarantorDOB":
                                    context.read<UserData>().guarantorDOB,
                            },
                            if (context.read<UserData>().payerName != null &&
                                context.read<UserData>().isActive == 1)
                              "patientInsuranceDetails": [
                                {
                                  "priorityObj": {
                                    if (context.read<UserData>().prid != null)
                                      "id": context.read<UserData>().prid,
                                    if (context.read<UserData>().priority !=
                                        null)
                                      "priority":
                                          context.read<UserData>().priority,
                                  },
                                  "typeObj": {
                                    if (context.read<UserData>().typeid != null)
                                      "id": context.read<UserData>().typeid,
                                    if (context.read<UserData>().type != null)
                                      "type": context.read<UserData>().type
                                  },
                                  "insurance": {
                                    if (context.read<UserData>().payerid !=
                                        null)
                                      "id": context.read<UserData>().payerid,
                                    if (context.read<UserData>().payerName !=
                                        null)
                                      "payerName":
                                          context.read<UserData>().payerName
                                  },
                                  if (context.read<UserData>().memberId != null)
                                    "memberId":
                                        context.read<UserData>().memberId,
                                  if (context.read<UserData>().groupNumber !=
                                      null)
                                    "groupNumber":
                                        context.read<UserData>().groupNumber,
                                  if (context
                                          .read<UserData>()
                                          .relationToPatient !=
                                      null)
                                    "relationToPatient": context
                                        .read<UserData>()
                                        .relationToPatient,
                                  if (context
                                          .read<UserData>()
                                          .subscriberFirstName !=
                                      null)
                                    "subscriberFirstName": context
                                        .read<UserData>()
                                        .subscriberFirstName,
                                  if (context
                                          .read<UserData>()
                                          .subscriberLastName !=
                                      null)
                                    "subscriberLastName": context
                                        .read<UserData>()
                                        .subscriberLastName,
                                  if (context.read<UserData>().subscriberDOB !=
                                      null)
                                    "subscriberDOB":
                                        context.read<UserData>().subscriberDOB,
                                  if (context
                                          .read<UserData>()
                                          .subscriberGender !=
                                      null)
                                    "subscriberGender": context
                                        .read<UserData>()
                                        .subscriberGender,
                                  if (context.read<UserData>().subscriberSSN !=
                                      null)
                                    "subscriberSSN":
                                        context.read<UserData>().subscriberSSN,
                                  if (context
                                          .read<UserData>()
                                          .subscriberAddress !=
                                      null)
                                    "subscriberAddress": context
                                        .read<UserData>()
                                        .subscriberAddress,
                                  if (context.read<UserData>().subscriberCity !=
                                      null)
                                    "subscriberCity":
                                        context.read<UserData>().subscriberCity,
                                  if (context
                                          .read<UserData>()
                                          .subscriberState !=
                                      null)
                                    "subscriberState": context
                                        .read<UserData>()
                                        .subscriberState,
                                  if (context.read<UserData>().subscriberZip !=
                                      null)
                                    "subscriberZip":
                                        context.read<UserData>().subscriberZip,
                                  if (context
                                          .read<UserData>()
                                          .subscriberOccupation !=
                                      null)
                                    "subscriberOccupation": context
                                        .read<UserData>()
                                        .subscriberOccupation,
                                  if (context
                                          .read<UserData>()
                                          .subscriberEmployerName !=
                                      null)
                                    "subscriberEmployerName": context
                                        .read<UserData>()
                                        .subscriberEmployerName,
                                  if (context
                                          .read<UserData>()
                                          .subscriberEmployerAddress !=
                                      null)
                                    "subscriberEmployerAddress": context
                                        .read<UserData>()
                                        .subscriberEmployerAddress,
                                  if (context
                                          .read<UserData>()
                                          .subscriberEmployerCity !=
                                      null)
                                    "subscriberEmployerCity": context
                                        .read<UserData>()
                                        .subscriberEmployerCity,
                                  if (context
                                          .read<UserData>()
                                          .subscriberEmployerState !=
                                      null)
                                    "subscriberEmployerState": context
                                        .read<UserData>()
                                        .subscriberEmployerState,
                                  if (context
                                          .read<UserData>()
                                          .subscriberEmployerZip !=
                                      null)
                                    "subscriberEmployerZip": context
                                        .read<UserData>()
                                        .subscriberEmployerZip,
                                  if (context
                                          .read<UserData>()
                                          .subscriberEmployerPhone !=
                                      null)
                                    "subscriberEmployerPhone": context
                                        .read<UserData>()
                                        .subscriberEmployerPhone,
                                  if (context
                                          .read<UserData>()
                                          .planEffectiveDate !=
                                      null)
                                    "planEffectiveDate": context
                                        .read<UserData>()
                                        .planEffectiveDate,
                                  "isDefault": 1,
                                  if (context.read<UserData>().isActive != null)
                                    "isActive":
                                        context.read<UserData>().isActive,
                                  if (context
                                          .read<UserData>()
                                          .subscriberContact !=
                                      null)
                                    "subscriberContact": context
                                        .read<UserData>()
                                        .subscriberContact,
                                  if (context
                                          .read<UserData>()
                                          .otherInsuranceName !=
                                      null)
                                    "otherInsuranceName": context
                                        .read<UserData>()
                                        .otherInsuranceName,
                                  if (context.read<UserData>().inmateNumber !=
                                      null)
                                    "inmateNumber":
                                        context.read<UserData>().inmateNumber,
                                  if (context
                                          .read<UserData>()
                                          .planTerminationDate !=
                                      null)
                                    "planTerminationDate": context
                                        .read<UserData>()
                                        .planTerminationDate
                                }
                              ],
                            "patientEmergencyContactDetails": {
                              if (context.read<UserData>().EMfirstName != null)
                                "firstName":
                                    context.read<UserData>().EMfirstName,
                              if (context.read<UserData>().EMlastName != null)
                                "lastName": context.read<UserData>().EMlastName,
                              if (context.read<UserData>().phoneNumber != null)
                                "phoneNumber":
                                    context.read<UserData>().phoneNumber,
                              if (context
                                      .read<UserData>()
                                      .patientEmergencyRelation !=
                                  null)
                                "patientEmergencyRelation": context
                                    .read<UserData>()
                                    .patientEmergencyRelation,
                              if (context.read<UserData>().leaveMessage != null)
                                "leaveMessage":
                                    context.read<UserData>().leaveMessage,
                              if (context.read<UserData>().address != null)
                                "address": context.read<UserData>().address,
                              if (context.read<UserData>().EMcity != null)
                                "city": context.read<UserData>().EMcity,
                              if (context.read<UserData>().EMstate != null)
                                "state": context.read<UserData>().EMstate,
                              if (context.read<UserData>().EMcountry != null)
                                "country": context.read<UserData>().EMcountry,
                              if (context.read<UserData>().EMzipCode != null)
                                "zipCode": context.read<UserData>().EMzipCode,
                            },
                            "patientMarketingDetails": {
                              "repeatPatient": 0,
                              if (context.read<UserData>().internetFind != null)
                                "internetFind":
                                    context.read<UserData>().internetFind,
                              "facebook": context.read<UserData>().facebook,
                              "mapSearch": context.read<UserData>().mapSearch,
                              "googleSearch":
                                  context.read<UserData>().googleSearch,
                              "website": context.read<UserData>().website,
                              "websiteAds": context.read<UserData>().websiteAds,
                              "onlineReviews":
                                  context.read<UserData>().onlineReviews,
                              "twitter": context.read<UserData>().twitter,
                              "linkedIn": context.read<UserData>().linkedIn,
                              "emailBlast": context.read<UserData>().emailBlast,
                              "youTube": context.read<UserData>().youTube,
                              "onlineAdvertisements":
                                  context.read<UserData>().onlineAdvertisements,
                              "tv": context.read<UserData>().tv,
                              "billboard": context.read<UserData>().billboard,
                              "radio": context.read<UserData>().radio,
                              "buildingSignDriveBy":
                                  context.read<UserData>().buildingSignDriveBy,
                              "brochure": context.read<UserData>().brochure,
                              "directMail": context.read<UserData>().directMail,
                              "citizensDeTar":
                                  context.read<UserData>().citizensDeTar,
                              "liveWorkNearby":
                                  context.read<UserData>().liveWorkNearby,
                              if (context.read<UserData>().schoolText != null)
                                "school": true,
                              if (context.read<UserData>().schoolText != null)
                                "schoolText":
                                    context.read<UserData>().schoolText,
                              if (context.read<UserData>().familyFriendText !=
                                  null)
                                "familyFriend": true,
                              if (context.read<UserData>().familyFriendText !=
                                  null)
                                "familyFriendText":
                                    context.read<UserData>().familyFriendText,
                              if (context.read<UserData>().employerSentMeText !=
                                  null)
                                "employerSentMe": true,
                              if (context.read<UserData>().employerSentMeText !=
                                  null)
                                "employerSentMeText":
                                    context.read<UserData>().employerSentMeText,
                              if (context.read<UserData>().magazineText != null)
                                "magazine": true,
                              if (context.read<UserData>().magazineText != null)
                                "magazineText":
                                    context.read<UserData>().magazineText,
                              if (context.read<UserData>().newspaperText !=
                                  null)
                                "newspaper": true,
                              if (context.read<UserData>().newspaperText !=
                                  null)
                                "newspaperText":
                                    context.read<UserData>().newspaperText,
                              if (context.read<UserData>().communityEventText !=
                                  null)
                                "communityEvent": true,
                              if (context.read<UserData>().communityEventText !=
                                  null)
                                "communityEventText":
                                    context.read<UserData>().communityEventText,
                              if (context.read<UserData>().urgentCareText !=
                                  null)
                                "urgentCare": true,
                              if (context.read<UserData>().urgentCareText !=
                                  null)
                                "urgentCareText":
                                    context.read<UserData>().urgentCareText,
                              if (context.read<UserData>().hotelText != null)
                                "hotel": true,
                              if (context.read<UserData>().hotelText != null)
                                "hotelText": context.read<UserData>().hotelText,
                              if (context.read<UserData>().refPhysicianName !=
                                  null)
                                "refPhysicianName":
                                    context.read<UserData>().refPhysicianName,
                              if (context.read<UserData>().refPhysicianPhone !=
                                  null)
                                "refPhysicianPhone":
                                    context.read<UserData>().refPhysicianPhone,
                              if (context.read<UserData>().refWorkName != null)
                                "refWorkName":
                                    context.read<UserData>().refWorkName,
                              if (context.read<UserData>().refWorkPhone != null)
                                "refWorkPhone":
                                    context.read<UserData>().refWorkPhone,
                              if (context.read<UserData>().refOtherName != null)
                                "refOtherName":
                                    context.read<UserData>().refOtherName,
                              if (context.read<UserData>().refOtherPhone !=
                                  null)
                                "refOtherPhone":
                                    context.read<UserData>().refOtherPhone,
                            },
                            // "patientDocumentsDetails": {
                            //   // "hasIdFront": context.read<UserData>().hasIdFront,
                            //   // "idFrontFileName": context.read<UserData>().idFrontFileName,
                            //   // "hasInsFront":context.read<UserData>().hasInsFront,
                            //   // "insFrontFileName": context.read<UserData>().insFrontFileName,
                            //   // "hasInsBack": context.read<UserData>().hasInsBack,
                            //   // "insBackFileName": context.read<UserData>().insBackFileName
                            // }
                          };

                          print(jsonData.toString());
                          String? stat = await registerPatient(jsonData);
                          //  Provider.of<UserData>(context, listen: false).dispose();
                          if (stat == "200") {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content: const Text('successfully registered'),
                              action: SnackBarAction(
                                label: 'Undo',
                                onPressed: () {
                                  // Some code to undo the change.
                                },
                              ),
                            ));
                            _existing();
                            setState(() {
                              Provider.of<UserData>(context, listen: false)
                                  .dispose();
                            });
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content: const Text("failed"),
                              action: SnackBarAction(
                                label: 'Undo',
                                onPressed: () {
                                  // Some code to undo the change.
                                },
                              ),
                            ));
                          }

                          print(jsonData.toString());
                        },
                        child: Text("Submit"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
          ],
        ),
      )),
      body: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: GestureDetector(
                    onTap: () {
                      getImage(ImageSource.camera, 1);
                    },
                    child: Image(
                      image: AssetImage(
                        "assets/Group 2466.png",
                      ),
                      width: MediaQuery.of(context).size.width,
                      fit: BoxFit.fill,
                    )),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: GestureDetector(
                    onTap: () {
                      getImage(ImageSource.camera, 2);
                    },
                    child: Image(
                      image: AssetImage("assets/Group 2467.png"),
                      width: MediaQuery.of(context).size.width,
                      fit: BoxFit.fill,
                    )),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: GestureDetector(
                    onTap: () {
                      getImage(ImageSource.camera, 3);
                    },
                    child: Image(
                      image: AssetImage("assets/Group 2468.png"),
                      width: MediaQuery.of(context).size.width,
                      fit: BoxFit.fill,
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> getImage(ImageSource source, int w) async {
    final picker = ImagePicker();
    XFile? pickedFile = await picker.pickImage(source: source);
    if (w == 1) {
      context.read<UserData>().idFrontFileName = pickedFile!.name;
      context.read<UserData>().hasIdFront = pickedFile == null ? 0 : 1;
    } else if (w == 2) {
      context.read<UserData>().insFrontFileName = pickedFile!.name;
      context.read<UserData>().hasInsFront = pickedFile == null ? 0 : 1;
    } else {
      context.read<UserData>().insBackFileName = pickedFile!.name;
      context.read<UserData>().hasInsBack = pickedFile == null ? 0 : 1;
    }
    // final dio = Dio();
    // dio.httpClientAdapter = BrowserHttpClientAdapter();
    // final formData = FormData.fromMap({
    //   'name': 'file',
    //   'file': await MultipartFile.fromFile(pickedFile.path,
    //       filename: pickedFile.name),
    // });
    // final response = await dio.post(
    //     'https://qa.rovermd.com:7685/patientExternal/upload',
    //     data: formData);
    // print(response.statusCode);
    Uint8List list = await pickedFile.readAsBytes();
    Uint8List bytces = await pickedFile.readAsBytes();
    String base64string = base64.encode(bytces);
    if (pickedFile != null) {
      setState(() {});
    }
  }
}
