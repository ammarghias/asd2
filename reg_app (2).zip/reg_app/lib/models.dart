class petient {
  String? title;
  String? firstName;
  String? middleInitial;
  String? lastName;
  String? maritalStatus;
  String? dob;
  String? ssn;
  String? race;
  String? sexualOrientation;
  String? genderIdentity;
  String? phNumber;
  String? email;
  String? address1;
  String? address2;
  String? zipCode;
  String? city;
  String? state;
  String? county;
  String? country;
  String? preferredLanguage;
  String? employer;
  String? occupation;
  String? empContact;
  int? epdSync;
  int? isDraft;
  String? registerFrom;
  int? authorization;
  int? hasProfileImage;
  int? contactConsent;
  int? accurateConsent;
  String? sex;
  String? profileImageName;

  petient(
      {this.title,
      this.firstName,
      this.middleInitial,
      this.lastName,
      this.maritalStatus,
      this.dob,
      this.ssn,
      this.race,
      this.sexualOrientation,
      this.genderIdentity,
      this.phNumber,
      this.email,
      this.address1,
      this.address2,
      this.zipCode,
      this.city,
      this.state,
      this.county,
      this.country,
      this.preferredLanguage,
      this.employer,
      this.occupation,
      this.empContact,
      this.epdSync,
      this.isDraft,
      this.registerFrom,
      this.authorization,
      this.hasProfileImage,
      this.contactConsent,
      this.accurateConsent,
      this.sex,
      this.profileImageName});

  petient.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    firstName = json['firstName'];
    middleInitial = json['middleInitial'];
    lastName = json['lastName'];
    maritalStatus = json['maritalStatus'];
    dob = json['dob'];
    ssn = json['ssn'];
    race = json['race'];
    sexualOrientation = json['sexualOrientation'];
    genderIdentity = json['genderIdentity'];
    phNumber = json['phNumber'];
    email = json['email'];
    address1 = json['address1'];
    address2 = json['address2'];
    zipCode = json['zipCode'];
    city = json['city'];
    state = json['state'];
    county = json['county'];
    country = json['country'];
    preferredLanguage = json['preferredLanguage'];
    employer = json['employer'];
    occupation = json['occupation'];
    empContact = json['empContact'];
    epdSync = json['epdSync'];
    isDraft = json['isDraft'];
    registerFrom = json['registerFrom'];
    authorization = json['authorization'];
    hasProfileImage = json['hasProfileImage'];
    contactConsent = json['contactConsent'];
    accurateConsent = json['accurateConsent'];
    sex = json['sex'];
    profileImageName = json['profileImageName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title'] = this.title;
    data['firstName'] = this.firstName;
    data['middleInitial'] = this.middleInitial;
    data['lastName'] = this.lastName;
    data['maritalStatus'] = this.maritalStatus;
    data['dob'] = this.dob;
    data['ssn'] = this.ssn;
    data['race'] = this.race;
    data['sexualOrientation'] = this.sexualOrientation;
    data['genderIdentity'] = this.genderIdentity;
    data['phNumber'] = this.phNumber;
    data['email'] = this.email;
    data['address1'] = this.address1;
    data['address2'] = this.address2;
    data['zipCode'] = this.zipCode;
    data['city'] = this.city;
    data['state'] = this.state;
    data['county'] = this.county;
    data['country'] = this.country;
    data['preferredLanguage'] = this.preferredLanguage;
    data['employer'] = this.employer;
    data['occupation'] = this.occupation;
    data['empContact'] = this.empContact;
    data['epdSync'] = this.epdSync;
    data['isDraft'] = this.isDraft;
    data['registerFrom'] = this.registerFrom;
    data['authorization'] = this.authorization;
    data['hasProfileImage'] = this.hasProfileImage;
    data['contactConsent'] = this.contactConsent;
    data['accurateConsent'] = this.accurateConsent;
    data['sex'] = this.sex;
    data['profileImageName'] = this.profileImageName;
    return data;
  }
}

class patientEthnicityList {
  int? ethnicityId;
  String? ethnicity;

  patientEthnicityList({this.ethnicityId, this.ethnicity});

  patientEthnicityList.fromJson(Map<String, dynamic> json) {
    ethnicityId = json['ethnicityId'];
    ethnicity = json['ethnicity'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ethnicityId'] = this.ethnicityId;
    data['ethnicity'] = this.ethnicity;
    return data;
  }
}

class visitDetails {
  String? reasonVisit;
  String? reasonVisitSpecify;
  int? doctorId;

  visitDetails({this.reasonVisit, this.reasonVisitSpecify, this.doctorId});

  visitDetails.fromJson(Map<String, dynamic> json) {
    reasonVisit = json['reasonVisit'];
    reasonVisitSpecify = json['reasonVisitSpecify'];
    doctorId = json['doctorId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['reasonVisit'] = this.reasonVisit;
    data['reasonVisitSpecify'] = this.reasonVisitSpecify;
    data['doctorId'] = this.doctorId;
    return data;
  }
}

class patientPhysicianDetails {
  String? primaryCarePhysicianName;
  String? primaryCarePhysicianCity;
  String? primaryCarePhysicianState;
  String? primaryCarePhysicianZip;
  String? primaryCarePhysicianAddress1;
  String? primaryCarePhysicianAddress2;
  String? specialityCarePhysicianName;
  String? specialityCarePhysicianCity;
  String? specialityCarePhysicianState;
  String? specialityCarePhysicianZip;
  String? specialityCarePhysicianAddress1;
  String? specialityCarePhysicianAddress2;

  patientPhysicianDetails(
      {this.primaryCarePhysicianName,
      this.primaryCarePhysicianCity,
      this.primaryCarePhysicianState,
      this.primaryCarePhysicianZip,
      this.primaryCarePhysicianAddress1,
      this.primaryCarePhysicianAddress2,
      this.specialityCarePhysicianName,
      this.specialityCarePhysicianCity,
      this.specialityCarePhysicianState,
      this.specialityCarePhysicianZip,
      this.specialityCarePhysicianAddress1,
      this.specialityCarePhysicianAddress2});

  patientPhysicianDetails.fromJson(Map<String, dynamic> json) {
    primaryCarePhysicianName = json['primaryCarePhysicianName'];
    primaryCarePhysicianCity = json['primaryCarePhysicianCity'];
    primaryCarePhysicianState = json['primaryCarePhysicianState'];
    primaryCarePhysicianZip = json['primaryCarePhysicianZip'];
    primaryCarePhysicianAddress1 = json['primaryCarePhysicianAddress1'];
    primaryCarePhysicianAddress2 = json['primaryCarePhysicianAddress2'];
    specialityCarePhysicianName = json['specialityCarePhysicianName'];
    specialityCarePhysicianCity = json['specialityCarePhysicianCity'];
    specialityCarePhysicianState = json['specialityCarePhysicianState'];
    specialityCarePhysicianZip = json['specialityCarePhysicianZip'];
    specialityCarePhysicianAddress1 = json['specialityCarePhysicianAddress1'];
    specialityCarePhysicianAddress2 = json['specialityCarePhysicianAddress2'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['primaryCarePhysicianName'] = this.primaryCarePhysicianName;
    data['primaryCarePhysicianCity'] = this.primaryCarePhysicianCity;
    data['primaryCarePhysicianState'] = this.primaryCarePhysicianState;
    data['primaryCarePhysicianZip'] = this.primaryCarePhysicianZip;
    data['primaryCarePhysicianAddress1'] = this.primaryCarePhysicianAddress1;
    data['primaryCarePhysicianAddress2'] = this.primaryCarePhysicianAddress2;
    data['specialityCarePhysicianName'] = this.specialityCarePhysicianName;
    data['specialityCarePhysicianCity'] = this.specialityCarePhysicianCity;
    data['specialityCarePhysicianState'] = this.specialityCarePhysicianState;
    data['specialityCarePhysicianZip'] = this.specialityCarePhysicianZip;
    data['specialityCarePhysicianAddress1'] =
        this.specialityCarePhysicianAddress1;
    data['specialityCarePhysicianAddress2'] =
        this.specialityCarePhysicianAddress2;
    return data;
  }
}

class patientCovidDetails {
  int? sympCheckCovid;
  int? covidTestForTravelCheck;
  String? dateSympOnset;
  bool? sympFever;
  bool? sympCough;
  bool? sympShortBreath;
  bool? sympFatigue;
  bool? sympMuscBodyAches;
  bool? sympHeadache;
  bool? sympLossTaste;
  bool? sympSoreThroat;
  bool? sympCongestionRunNos;
  bool? sympNauseaVomit;
  bool? sympDiarrhea;
  bool? sympPerPainChest;
  bool? sympNewConfusion;
  bool? sympInabWake;
  bool? sympOthers;
  String? sympOthersTxt;
  int? employedInHealthCareCheck;
  int? covidPositiveBeforeCheck;
  String? covidPositiveBeforeDate;
  int? exposedDirectContactCovidCheck;
  String? exposedDirectContactCovidDate;
  int? outsideCountryTravelCheck;
  String? outsideCountryTravelDate;
  String? outsideCountryTravelDestination;
  String? outsideCountryTravelDuration;

  patientCovidDetails(
      {this.sympCheckCovid,
      this.covidTestForTravelCheck,
      this.dateSympOnset,
      this.sympFever,
      this.sympCough,
      this.sympShortBreath,
      this.sympFatigue,
      this.sympMuscBodyAches,
      this.sympHeadache,
      this.sympLossTaste,
      this.sympSoreThroat,
      this.sympCongestionRunNos,
      this.sympNauseaVomit,
      this.sympDiarrhea,
      this.sympPerPainChest,
      this.sympNewConfusion,
      this.sympInabWake,
      this.sympOthers,
      this.sympOthersTxt,
      this.employedInHealthCareCheck,
      this.covidPositiveBeforeCheck,
      this.covidPositiveBeforeDate,
      this.exposedDirectContactCovidCheck,
      this.exposedDirectContactCovidDate,
      this.outsideCountryTravelCheck,
      this.outsideCountryTravelDate,
      this.outsideCountryTravelDestination,
      this.outsideCountryTravelDuration});

  patientCovidDetails.fromJson(Map<String, dynamic> json) {
    sympCheckCovid = json['sympCheckCovid'];
    covidTestForTravelCheck = json['covidTestForTravelCheck'];
    dateSympOnset = json['dateSympOnset'];
    sympFever = json['sympFever'];
    sympCough = json['sympCough'];
    sympShortBreath = json['sympShortBreath'];
    sympFatigue = json['sympFatigue'];
    sympMuscBodyAches = json['sympMuscBodyAches'];
    sympHeadache = json['sympHeadache'];
    sympLossTaste = json['sympLossTaste'];
    sympSoreThroat = json['sympSoreThroat'];
    sympCongestionRunNos = json['sympCongestionRunNos'];
    sympNauseaVomit = json['sympNauseaVomit'];
    sympDiarrhea = json['sympDiarrhea'];
    sympPerPainChest = json['sympPerPainChest'];
    sympNewConfusion = json['sympNewConfusion'];
    sympInabWake = json['sympInabWake'];
    sympOthers = json['sympOthers'];
    sympOthersTxt = json['sympOthersTxt'];
    employedInHealthCareCheck = json['employedInHealthCareCheck'];
    covidPositiveBeforeCheck = json['covidPositiveBeforeCheck'];
    covidPositiveBeforeDate = json['covidPositiveBeforeDate'];
    exposedDirectContactCovidCheck = json['exposedDirectContactCovidCheck'];
    exposedDirectContactCovidDate = json['exposedDirectContactCovidDate'];
    outsideCountryTravelCheck = json['outsideCountryTravelCheck'];
    outsideCountryTravelDate = json['outsideCountryTravelDate'];
    outsideCountryTravelDestination = json['outsideCountryTravelDestination'];
    outsideCountryTravelDuration = json['outsideCountryTravelDuration'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['sympCheckCovid'] = this.sympCheckCovid;
    data['covidTestForTravelCheck'] = this.covidTestForTravelCheck;
    data['dateSympOnset'] = this.dateSympOnset;
    data['sympFever'] = this.sympFever;
    data['sympCough'] = this.sympCough;
    data['sympShortBreath'] = this.sympShortBreath;
    data['sympFatigue'] = this.sympFatigue;
    data['sympMuscBodyAches'] = this.sympMuscBodyAches;
    data['sympHeadache'] = this.sympHeadache;
    data['sympLossTaste'] = this.sympLossTaste;
    data['sympSoreThroat'] = this.sympSoreThroat;
    data['sympCongestionRunNos'] = this.sympCongestionRunNos;
    data['sympNauseaVomit'] = this.sympNauseaVomit;
    data['sympDiarrhea'] = this.sympDiarrhea;
    data['sympPerPainChest'] = this.sympPerPainChest;
    data['sympNewConfusion'] = this.sympNewConfusion;
    data['sympInabWake'] = this.sympInabWake;
    data['sympOthers'] = this.sympOthers;
    data['sympOthersTxt'] = this.sympOthersTxt;
    data['employedInHealthCareCheck'] = this.employedInHealthCareCheck;
    data['covidPositiveBeforeCheck'] = this.covidPositiveBeforeCheck;
    data['covidPositiveBeforeDate'] = this.covidPositiveBeforeDate;
    data['exposedDirectContactCovidCheck'] =
        this.exposedDirectContactCovidCheck;
    data['exposedDirectContactCovidDate'] = this.exposedDirectContactCovidDate;
    data['outsideCountryTravelCheck'] = this.outsideCountryTravelCheck;
    data['outsideCountryTravelDate'] = this.outsideCountryTravelDate;
    data['outsideCountryTravelDestination'] =
        this.outsideCountryTravelDestination;
    data['outsideCountryTravelDuration'] = this.outsideCountryTravelDuration;
    return data;
  }
}

class patientGuarantorDetails {
  String? guarantorCheck;
  String? patientMinorCheck;
  String? guarantorFirstName;
  String? guarantorLastName;
  String? guarantorPhoneNumber;
  String? guarantorSSN;
  String? guarantorEmployerName;
  String? guarantorEmployerPhoneNumber;
  String? guarantorEmployerCity;
  String? guarantorEmployerState;
  String? guarantorEmployerZip;
  String? guarantorEmployerAddress1;
  String? guarantorEmployerAddress2;
  String? guarantorDOB;

  patientGuarantorDetails(
      {this.guarantorCheck,
      this.patientMinorCheck,
      this.guarantorFirstName,
      this.guarantorLastName,
      this.guarantorPhoneNumber,
      this.guarantorSSN,
      this.guarantorEmployerName,
      this.guarantorEmployerPhoneNumber,
      this.guarantorEmployerCity,
      this.guarantorEmployerState,
      this.guarantorEmployerZip,
      this.guarantorEmployerAddress1,
      this.guarantorEmployerAddress2,
      this.guarantorDOB});

  patientGuarantorDetails.fromJson(Map<String, dynamic> json) {
    guarantorCheck = json['guarantorCheck'];
    patientMinorCheck = json['patientMinorCheck'];
    guarantorFirstName = json['guarantorFirstName'];
    guarantorLastName = json['guarantorLastName'];
    guarantorPhoneNumber = json['guarantorPhoneNumber'];
    guarantorSSN = json['guarantorSSN'];
    guarantorEmployerName = json['guarantorEmployerName'];
    guarantorEmployerPhoneNumber = json['guarantorEmployerPhoneNumber'];
    guarantorEmployerCity = json['guarantorEmployerCity'];
    guarantorEmployerState = json['guarantorEmployerState'];
    guarantorEmployerZip = json['guarantorEmployerZip'];
    guarantorEmployerAddress1 = json['guarantorEmployerAddress1'];
    guarantorEmployerAddress2 = json['guarantorEmployerAddress2'];
    guarantorDOB = json['guarantorDOB'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['guarantorCheck'] = this.guarantorCheck;
    data['patientMinorCheck'] = this.patientMinorCheck;
    data['guarantorFirstName'] = this.guarantorFirstName;
    data['guarantorLastName'] = this.guarantorLastName;
    data['guarantorPhoneNumber'] = this.guarantorPhoneNumber;
    data['guarantorSSN'] = this.guarantorSSN;
    data['guarantorEmployerName'] = this.guarantorEmployerName;
    data['guarantorEmployerPhoneNumber'] = this.guarantorEmployerPhoneNumber;
    data['guarantorEmployerCity'] = this.guarantorEmployerCity;
    data['guarantorEmployerState'] = this.guarantorEmployerState;
    data['guarantorEmployerZip'] = this.guarantorEmployerZip;
    data['guarantorEmployerAddress1'] = this.guarantorEmployerAddress1;
    data['guarantorEmployerAddress2'] = this.guarantorEmployerAddress2;
    data['guarantorDOB'] = this.guarantorDOB;
    return data;
  }
}

class patientMarketingDetails {
  int? repeatPatient;
  int? internetFind;
  bool? facebook;
  bool? mapSearch;
  bool? googleSearch;
  bool? website;
  bool? websiteAds;
  bool? onlineReviews;
  bool? twitter;
  bool? linkedIn;
  bool? emailBlast;
  bool? youTube;
  bool? onlineAdvertisements;
  bool? tv;
  bool? billboard;
  bool? radio;
  bool? buildingSignDriveBy;
  bool? brochure;
  bool? directMail;
  bool? citizensDeTar;
  bool? liveWorkNearby;
  bool? school;
  String? schoolText;
  bool? magazine;
  String? magazineText;
  bool? urgentCare;
  String? urgentCareText;
  bool? familyFriend;
  String? familyFriendText;
  bool? newspaper;
  String? newspaperText;
  bool? hotel;
  String? hotelText;
  bool? employerSentMe;
  String? employerSentMeText;
  bool? communityEvent;
  String? communityEventText;
  String? refPhysicianName;
  String? refPhysicianPhone;
  String? refWorkName;
  String? refWorkPhone;
  String? refOtherName;
  String? refOtherPhone;

  patientMarketingDetails(
      {this.repeatPatient,
      this.internetFind,
      this.facebook,
      this.mapSearch,
      this.googleSearch,
      this.website,
      this.websiteAds,
      this.onlineReviews,
      this.twitter,
      this.linkedIn,
      this.emailBlast,
      this.youTube,
      this.onlineAdvertisements,
      this.tv,
      this.billboard,
      this.radio,
      this.buildingSignDriveBy,
      this.brochure,
      this.directMail,
      this.citizensDeTar,
      this.liveWorkNearby,
      this.school,
      this.schoolText,
      this.magazine,
      this.magazineText,
      this.urgentCare,
      this.urgentCareText,
      this.familyFriend,
      this.familyFriendText,
      this.newspaper,
      this.newspaperText,
      this.hotel,
      this.hotelText,
      this.employerSentMe,
      this.employerSentMeText,
      this.communityEvent,
      this.communityEventText,
      this.refPhysicianName,
      this.refPhysicianPhone,
      this.refWorkName,
      this.refWorkPhone,
      this.refOtherName,
      this.refOtherPhone});

  patientMarketingDetails.fromJson(Map<String, dynamic> json) {
    repeatPatient = json['repeatPatient'];
    internetFind = json['internetFind'];
    facebook = json['facebook'];
    mapSearch = json['mapSearch'];
    googleSearch = json['googleSearch'];
    website = json['website'];
    websiteAds = json['websiteAds'];
    onlineReviews = json['onlineReviews'];
    twitter = json['twitter'];
    linkedIn = json['linkedIn'];
    emailBlast = json['emailBlast'];
    youTube = json['youTube'];
    onlineAdvertisements = json['onlineAdvertisements'];
    tv = json['tv'];
    billboard = json['billboard'];
    radio = json['radio'];
    buildingSignDriveBy = json['buildingSignDriveBy'];
    brochure = json['brochure'];
    directMail = json['directMail'];
    citizensDeTar = json['citizensDeTar'];
    liveWorkNearby = json['liveWorkNearby'];
    school = json['school'];
    schoolText = json['schoolText'];
    magazine = json['magazine'];
    magazineText = json['magazineText'];
    urgentCare = json['urgentCare'];
    urgentCareText = json['urgentCareText'];
    familyFriend = json['familyFriend'];
    familyFriendText = json['familyFriendText'];
    newspaper = json['newspaper'];
    newspaperText = json['newspaperText'];
    hotel = json['hotel'];
    hotelText = json['hotelText'];
    employerSentMe = json['employerSentMe'];
    employerSentMeText = json['employerSentMeText'];
    communityEvent = json['communityEvent'];
    communityEventText = json['communityEventText'];
    refPhysicianName = json['refPhysicianName'];
    refPhysicianPhone = json['refPhysicianPhone'];
    refWorkName = json['refWorkName'];
    refWorkPhone = json['refWorkPhone'];
    refOtherName = json['refOtherName'];
    refOtherPhone = json['refOtherPhone'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['repeatPatient'] = this.repeatPatient;
    data['internetFind'] = this.internetFind;
    data['facebook'] = this.facebook;
    data['mapSearch'] = this.mapSearch;
    data['googleSearch'] = this.googleSearch;
    data['website'] = this.website;
    data['websiteAds'] = this.websiteAds;
    data['onlineReviews'] = this.onlineReviews;
    data['twitter'] = this.twitter;
    data['linkedIn'] = this.linkedIn;
    data['emailBlast'] = this.emailBlast;
    data['youTube'] = this.youTube;
    data['onlineAdvertisements'] = this.onlineAdvertisements;
    data['tv'] = this.tv;
    data['billboard'] = this.billboard;
    data['radio'] = this.radio;
    data['buildingSignDriveBy'] = this.buildingSignDriveBy;
    data['brochure'] = this.brochure;
    data['directMail'] = this.directMail;
    data['citizensDeTar'] = this.citizensDeTar;
    data['liveWorkNearby'] = this.liveWorkNearby;
    data['school'] = this.school;
    data['schoolText'] = this.schoolText;
    data['magazine'] = this.magazine;
    data['magazineText'] = this.magazineText;
    data['urgentCare'] = this.urgentCare;
    data['urgentCareText'] = this.urgentCareText;
    data['familyFriend'] = this.familyFriend;
    data['familyFriendText'] = this.familyFriendText;
    data['newspaper'] = this.newspaper;
    data['newspaperText'] = this.newspaperText;
    data['hotel'] = this.hotel;
    data['hotelText'] = this.hotelText;
    data['employerSentMe'] = this.employerSentMe;
    data['employerSentMeText'] = this.employerSentMeText;
    data['communityEvent'] = this.communityEvent;
    data['communityEventText'] = this.communityEventText;
    data['refPhysicianName'] = this.refPhysicianName;
    data['refPhysicianPhone'] = this.refPhysicianPhone;
    data['refWorkName'] = this.refWorkName;
    data['refWorkPhone'] = this.refWorkPhone;
    data['refOtherName'] = this.refOtherName;
    data['refOtherPhone'] = this.refOtherPhone;
    return data;
  }
}

class patientDocumentsDetails {
  int? hasIdFront;
  String? idFrontFileName;
  int? hasInsFront;
  String? insFrontFileName;
  int? hasInsBack;
  String? insBackFileName;

  patientDocumentsDetails(
      {this.hasIdFront,
      this.idFrontFileName,
      this.hasInsFront,
      this.insFrontFileName,
      this.hasInsBack,
      this.insBackFileName});

  patientDocumentsDetails.fromJson(Map<String, dynamic> json) {
    hasIdFront = json['hasIdFront'];
    idFrontFileName = json['idFrontFileName'];
    hasInsFront = json['hasInsFront'];
    insFrontFileName = json['insFrontFileName'];
    hasInsBack = json['hasInsBack'];
    insBackFileName = json['insBackFileName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['hasIdFront'] = this.hasIdFront;
    data['idFrontFileName'] = this.idFrontFileName;
    data['hasInsFront'] = this.hasInsFront;
    data['insFrontFileName'] = this.insFrontFileName;
    data['hasInsBack'] = this.hasInsBack;
    data['insBackFileName'] = this.insBackFileName;
    return data;
  }
}

class patientEmergencyContactDetails {
  String? firstName;
  String? lastName;
  String? phoneNumber;
  String? patientEmergencyRelation;
  String? leaveMessage;
  String? address;
  String? city;
  String? state;
  String? country;
  String? zipCode;

  patientEmergencyContactDetails(
      {this.firstName,
      this.lastName,
      this.phoneNumber,
      this.patientEmergencyRelation,
      this.leaveMessage,
      this.address,
      this.city,
      this.state,
      this.country,
      this.zipCode});

  patientEmergencyContactDetails.fromJson(Map<String, dynamic> json) {
    firstName = json['firstName'];
    lastName = json['lastName'];
    phoneNumber = json['phoneNumber'];
    patientEmergencyRelation = json['patientEmergencyRelation'];
    leaveMessage = json['leaveMessage'];
    address = json['address'];
    city = json['city'];
    state = json['state'];
    country = json['country'];
    zipCode = json['zipCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['phoneNumber'] = this.phoneNumber;
    data['patientEmergencyRelation'] = this.patientEmergencyRelation;
    data['leaveMessage'] = this.leaveMessage;
    data['address'] = this.address;
    data['city'] = this.city;
    data['state'] = this.state;
    data['country'] = this.country;
    data['zipCode'] = this.zipCode;
    return data;
  }
}

class insurancee {
  int? id;
  PriorityObj? priorityObj;
  TypeObj? typeObj;
  Insurance? insurance;
  String? memberId;
  String? groupNumber;
  String? relationToPatient;
  String? subscriberFirstName;
  String? subscriberLastName;
  String? subscriberDOB;
  String? subscriberGender;
  String? subscriberSSN;
  String? subscriberAddress;
  String? subscriberCity;
  String? subscriberState;
  String? subscriberZip;
  String? subscriberOccupation;
  String? subscriberEmployerName;
  String? subscriberEmployerAddress;
  String? subscriberEmployerCity;
  String? subscriberEmployerState;
  String? subscriberEmployerZip;
  String? subscriberEmployerPhone;
  String? planEffectiveDate;
  int? isDefault;
  int? isActive;
  String? subscriberContact;
  String? otherInsuranceName;
  String? inmateNumber;
  String? planTerminationDate;

  insurancee(
      {this.id,
      this.priorityObj,
      this.typeObj,
      this.insurance,
      this.memberId,
      this.groupNumber,
      this.relationToPatient,
      this.subscriberFirstName,
      this.subscriberLastName,
      this.subscriberDOB,
      this.subscriberGender,
      this.subscriberSSN,
      this.subscriberAddress,
      this.subscriberCity,
      this.subscriberState,
      this.subscriberZip,
      this.subscriberOccupation,
      this.subscriberEmployerName,
      this.subscriberEmployerAddress,
      this.subscriberEmployerCity,
      this.subscriberEmployerState,
      this.subscriberEmployerZip,
      this.subscriberEmployerPhone,
      this.planEffectiveDate,
      this.isDefault,
      this.isActive,
      this.subscriberContact,
      this.otherInsuranceName,
      this.inmateNumber,
      this.planTerminationDate});

  insurancee.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    priorityObj = json['priorityObj'] != null
        ? new PriorityObj.fromJson(json['priorityObj'])
        : null;
    typeObj =
        json['typeObj'] != null ? new TypeObj.fromJson(json['typeObj']) : null;
    insurance = json['insurance'] != null
        ? new Insurance.fromJson(json['insurance'])
        : null;
    memberId = json['memberId'];
    groupNumber = json['groupNumber'];
    relationToPatient = json['relationToPatient'];
    subscriberFirstName = json['subscriberFirstName'];
    subscriberLastName = json['subscriberLastName'];
    subscriberDOB = json['subscriberDOB'];
    subscriberGender = json['subscriberGender'];
    subscriberSSN = json['subscriberSSN'];
    subscriberAddress = json['subscriberAddress'];
    subscriberCity = json['subscriberCity'];
    subscriberState = json['subscriberState'];
    subscriberZip = json['subscriberZip'];
    subscriberOccupation = json['subscriberOccupation'];
    subscriberEmployerName = json['subscriberEmployerName'];
    subscriberEmployerAddress = json['subscriberEmployerAddress'];
    subscriberEmployerCity = json['subscriberEmployerCity'];
    subscriberEmployerState = json['subscriberEmployerState'];
    subscriberEmployerZip = json['subscriberEmployerZip'];
    subscriberEmployerPhone = json['subscriberEmployerPhone'];
    planEffectiveDate = json['planEffectiveDate'];
    isDefault = json['isDefault'];
    isActive = json['isActive'];
    subscriberContact = json['subscriberContact'];
    otherInsuranceName = json['otherInsuranceName'];
    inmateNumber = json['inmateNumber'];
    planTerminationDate = json['planTerminationDate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.priorityObj != null) {
      data['priorityObj'] = this.priorityObj!.toJson();
    }
    if (this.typeObj != null) {
      data['typeObj'] = this.typeObj!.toJson();
    }
    if (this.insurance != null) {
      data['insurance'] = this.insurance!.toJson();
    }
    data['memberId'] = this.memberId;
    data['groupNumber'] = this.groupNumber;
    data['relationToPatient'] = this.relationToPatient;
    data['subscriberFirstName'] = this.subscriberFirstName;
    data['subscriberLastName'] = this.subscriberLastName;
    data['subscriberDOB'] = this.subscriberDOB;
    data['subscriberGender'] = this.subscriberGender;
    data['subscriberSSN'] = this.subscriberSSN;
    data['subscriberAddress'] = this.subscriberAddress;
    data['subscriberCity'] = this.subscriberCity;
    data['subscriberState'] = this.subscriberState;
    data['subscriberZip'] = this.subscriberZip;
    data['subscriberOccupation'] = this.subscriberOccupation;
    data['subscriberEmployerName'] = this.subscriberEmployerName;
    data['subscriberEmployerAddress'] = this.subscriberEmployerAddress;
    data['subscriberEmployerCity'] = this.subscriberEmployerCity;
    data['subscriberEmployerState'] = this.subscriberEmployerState;
    data['subscriberEmployerZip'] = this.subscriberEmployerZip;
    data['subscriberEmployerPhone'] = this.subscriberEmployerPhone;
    data['planEffectiveDate'] = this.planEffectiveDate;
    data['isDefault'] = this.isDefault;
    data['isActive'] = this.isActive;
    data['subscriberContact'] = this.subscriberContact;
    data['otherInsuranceName'] = this.otherInsuranceName;
    data['inmateNumber'] = this.inmateNumber;
    data['planTerminationDate'] = this.planTerminationDate;
    return data;
  }
}

class PriorityObj {
  int? id;
  String? priority;

  PriorityObj({this.id, this.priority});

  PriorityObj.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    priority = json['priority'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['priority'] = this.priority;
    return data;
  }
}

class TypeObj {
  int? id;
  String? type;

  TypeObj({this.id, this.type});

  TypeObj.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    type = json['type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['type'] = this.type;
    return data;
  }
}

class Insurance {
  int? id;
  String? payerName;

  Insurance({this.id, this.payerName});

  Insurance.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    payerName = json['payerName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['payerName'] = this.payerName;
    return data;
  }
}
