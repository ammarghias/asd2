import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import 'package:reg_app/pereg1.dart';
import 'package:reg_app/provider.dart';
import 'package:reg_app/regph2.dart';
import 'package:reg_app/regph3.dart';
import 'package:reg_app/regph5.dart';
import 'package:reg_app/regph6.dart';
import 'package:reg_app/regph7.dart';
import 'package:reg_app/regph8.dart';
import 'gender.dart';
class pereg4 extends StatefulWidget {
  @override
  _pereg4State createState() => _pereg4State();
  static const String route = '/emc';
}
class _pereg4State extends State<pereg4> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  TextEditingController reltc = TextEditingController();
  List<relationd>? relationf;
  relationd? selecetedre;
  Future<List<relationd>?> reController() async {
    try {
      var jsonData = null;
      Uri uri = Uri.parse(
          "https://qa.rovermd.com:7685/api/v2/globalExternal/relations/all");
      // Uri uri = Uri.parse("$BaseUrl/gender/find/all");
      print(uri.toString());
      var response = await http.get(uri, headers: {'accept': '*/*'});
      // print("response---$response");
      if (response.statusCode == 200) {
        jsonData = json.decode(response.body.toString());
        List<dynamic> genderData = jsonData;
        print("jsonData---$jsonData");

        return genderData.map((data) => relationd.fromJson(data)).toList();
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      print("Error in relation Funtion: $e");
    }
    return null;
  }

  showSexTypeDialograce(BuildContext context) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Select'),
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: relationf == null
                      ? SizedBox.shrink()
                      : ListBody(
                          children: relationf!.map((relationd gender) {
                            return RadioListTile(
                              title: Text(gender.name),
                              value: gender,
                              groupValue: selecetedre,
                              onChanged: (relationd? value) {
                                setState(() {
                                  selecetedre = value;
                                  context
                                      .read<UserData>()
                                      .patientEmergencyRelation = value!.name;
                                  reltc.text = selecetedre!.name;
                                });
                              },
                            );
                          }).toList(),
                        ),
                );
              },
            ),
            actions: <Widget>[
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop(selecetedre);
                  reltc.text = selecetedre!.name;
                },
              ),
            ],
          );
        }).then((value) {
      // Update the state after the dialog is dismissed
      setState(() {});
    });
  }

  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  TextEditingController t3 = TextEditingController();
  TextEditingController t4 = TextEditingController();
  TextEditingController t5 = TextEditingController();
  TextEditingController t6 = TextEditingController();
  TextEditingController t7 = TextEditingController();
  TextEditingController t8 = TextEditingController();
  TextEditingController t9 = TextEditingController();
  TextEditingController t10 = TextEditingController();
  TextEditingController t11 = TextEditingController();
  TextEditingController t12 = TextEditingController();
  TextEditingController t13 = TextEditingController();
  TextEditingController t14 = TextEditingController();
  TextEditingController t15 = TextEditingController();
  TextEditingController t16 = TextEditingController();
  TextEditingController t17 = TextEditingController();
  TextEditingController t18 = TextEditingController();
  TextEditingController t19 = TextEditingController();
  TextEditingController t20 = TextEditingController();
  TextEditingController t21 = TextEditingController();
  bool c1 = false;
  bool c2 = false;
  bool c3 = false;
  @override
  void initState() {
    super.initState();
    reController().then((relationf) {
      setState(() {
        this.relationf = relationf;
      });
    });

    if (context.read<UserData>().EMfirstName != null)
      t1.text = context.read<UserData>().EMfirstName!;
    if (context.read<UserData>().EMlastName != null)
      t2.text = context.read<UserData>().EMlastName!;
    if (context.read<UserData>().phoneNumber != null)
      t3.text = context.read<UserData>().phoneNumber!;
    if (context.read<UserData>().patientEmergencyRelation != null)
      reltc.text = context.read<UserData>().patientEmergencyRelation!;
    if (context.read<UserData>().address != null)
      t4.text = context.read<UserData>().address!;
    if (context.read<UserData>().EMcity != null)
      t5.text = context.read<UserData>().EMcity!;
    if (context.read<UserData>().EMstate != null)
      t6.text = context.read<UserData>().EMstate!;
    if (context.read<UserData>().EMzipCode != null)
      t7.text = context.read<UserData>().EMzipCode!;
    if (context.read<UserData>().EMcountry != null)
      t8.text = context.read<UserData>().EMcountry!;
 if (context.read<UserData>().leaveMessage != null)
      t8.text = context.read<UserData>().leaveMessage!;

      //  context.read<UserData>().leaveMessage
    // if( context.read<UserData>().guarantorFirstName!=null)
    // t3.text= context.read<UserData>().guarantorFirstName!;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(119, 94, 158, 100),
        title: const Text(
          ' Emergency Contact',
          style: TextStyle(color: Colors.white),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              '',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            onPressed: () {
              if (_formKey.currentState!.validate()) {}
            },
          ),
        ],
      ),
      drawer: Drawer(
        width: 200,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(51, 62, 101, 5),
                Color.fromRGBO(107, 80, 135, 5)
              ],
            ),
          ),
          child: ListView(
            children: <Widget>[
              // const UserAccountsDrawerHeader(
              //   currentAccountPictureSize: Size.square(90.0),
              //   accountName: Text(
              //     '',
              //     style: TextStyle(color: Colors.white),
              //   ),
              //   accountEmail: Text(
              //     '',
              //     style: TextStyle(color: Colors.white),
              //   ),
              //   currentAccountPicture: CircleAvatar(
              //     backgroundColor: Colors.white,
              //     child: Text(
              //       'P',
              //       style: TextStyle(
              //         fontSize: 20.0,
              //         fontWeight: FontWeight.bold,
              //         color: Colors.purple,
              //       ),
              //     ),
              //   ),
              //   decoration: BoxDecoration(
              //     gradient: LinearGradient(
              //       begin: Alignment.topCenter,
              //       end: Alignment.bottomCenter,
              //       colors: [Colors.transparent, Colors.transparent],
              //       //  [Color.fromRGBO(51, 62, 101,10), Color.fromRGBO(51, 62, 101,10)],
              //     ),
              //   ),
              // ),
              // Padding(
              //   padding: const EdgeInsets.all(8.0),
              //   child: Row(
              //     children: [
              //       const Icon(
              //         Icons.image,
              //         color: Colors.white,
              //       ),
              //       const SizedBox(
              //         width: 10,
              //       ),
              //       const Icon(
              //         Icons.edit,
              //         color: Colors.white,
              //       ),
              //     ],
              //   ),
              // ),
              ListTile(
                title: Text(
                  'Patient',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg1()));

                  // TODO: Navigate to patient info page
                },
              ),
              ListTile(
                autofocus: true,
                selected: true,
                focusColor: Colors.white,
                selectedColor: Colors.white,
                enabled: true,
                title: Text(
                  'Physician',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg2()));
                },
              ),
              ListTile(
                title: Text(
                  'COVID-19',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg8()));
                  // TODO: Navigate to COVID-19 info page
                },
              ),
              ListTile(
                title: Text(
                  'Guarantor',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg3()));
                  // TODO: Navigate to guarantor info page
                },
              ),
              ListTile(
                title: Text(
                  'Insurance',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg7()));
                  // TODO: Navigate to insurance info page
                },
              ),
              ListTile(
                title: Text(
                  'Emergency Contact',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg4()));
                  // TODO: Navigate to emergency info page
                },
              ),
              ListTile(
                title: Text(
                  'Marketing',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg5()));
                  // TODO: Navigate to marketing info page
                },
              ),
              ListTile(
                title: Text(
                  'ID Upload',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => pereg6()));
                  // TODO: Navigate to ID upload page
                },
              ),
            ],
          ),
        ),
      ),

// It is recommended to use the TextFormField widget for text input fields as it provides built-in validation features
// Use the DropdownButtonFormField widget for dropdowns to simplify code and provide built-in validation
// We can use the Container widget to set the background color and border radius for the forms

// Dart code block:

// Consider using a Form widget to wrap the input fields for easier validation and submission
// Use TextFormField for text input fields and DropdownButtonFormField for dropdowns

// Dart code block:
      bottomNavigationBar: BottomAppBar(

          // color: Color(0xFFC0C0C0),
          child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.grey,
            ],
          ),
        ),
        child: Row(
          children: <Widget>[
            Padding(
                padding: const EdgeInsets.only(
                    left: 10.0, top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          Navigator.of(context).pop();
                          // Navigator.push(context, MaterialPageRoute(builder: (context) => PersonalInfoRegister(),));
                        },
                        child: const Text("BACK"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
            const Spacer(),
            const Expanded(
              child: Padding(
                padding: EdgeInsets.all(18.0),
                child: Text(
                  "",
                  style: TextStyle(
                      // color: Color(0xFFC0C0C0),
                      fontSize: 16.0),
                ),
              ),
            ),
            Padding(
                padding: EdgeInsets.only(top: 10.0, bottom: 5.0, right: 10.0),
                child: Container(
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF8800FF),
                            Color(0xFFA600FF),
                          ]),
                    ),
                    child: ElevatedButton(
                        onPressed: () async {
                          //sending this get this all from shared pref and send the data
                          if (_formKey.currentState!.validate()) {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => pereg5()));
                          }
                        },
                        child: Text("NEXT"),
                        style: ElevatedButton.styleFrom(
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            primary: Colors.transparent,
                            shadowColor: Colors.transparent,
                            elevation: 0,
                            textStyle: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black))))),
          ],
        ),
      )),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Container(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                TextFormField(
                  onTap: () {
                    setState(() {
                      context.read<UserData>().esn= true;
                    });
                  },
                  controller: t1,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                      borderSide: BorderSide(
                        color:
                           context.read<UserData>().esn==null ? Color.fromARGB(123, 255, 0, 0) :context.read<UserData>().esn! ? Colors.grey: Color.fromARGB(123, 255, 0, 0),
                        width: 2.0,
                      ),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText: 'First Name',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      context.read<UserData>().esn = true;
                      return 'Please enter your first name';
                    }
                    return null;
                  },
                  inputFormatters: [
                    MaskTextInputFormatter(
                        mask: '##########################',
                        filter: {"#": RegExp(r'[a-zA-Z]')},
                        type: MaskAutoCompletionType.lazy)
                  ],
                  onChanged: (String? value) {
                     context.read<UserData>().esn = true;
                    _formKey.currentState!.validate();

                    context.read<UserData>().EMfirstName = value;
                  },
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  onTap: () {
                    setState(() {
                       context.read<UserData>().esn = true;
                      context.read<UserData>().eln= true;
                    });
                  },
                  controller: t2,
                  inputFormatters: [
                    MaskTextInputFormatter(
                        mask: '##########################',
                        filter: {"#": RegExp(r'[a-zA-Z]')},
                        type: MaskAutoCompletionType.lazy)
                  ],
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                      borderSide: BorderSide(
                        color:
                            context.read<UserData>().eln==null ? Color.fromARGB(123, 255, 0, 0) :context.read<UserData>().eln! ? Colors.grey: Color.fromARGB(123, 255, 0, 0),
                        width: 2.0,
                      ),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText: 'Last Name',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                       context.read<UserData>().esn = true;
                      context.read<UserData>().eln = true;
                      return 'Please enter your last name';
                    }
                    return null;
                  },
                  onChanged: (String? value) {
                     context.read<UserData>().esn= true;
                     context.read<UserData>().eln = true;
                    _formKey.currentState!.validate();

                    context.read<UserData>().EMlastName = value;
                  },
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  onTap: () {
                    setState(() {
                       context.read<UserData>().esn= true;
                       context.read<UserData>().eln = true;
                      context.read<UserData>().epn = true;
                    });
                  },
                  controller: t3,
                  inputFormatters: [
                    MaskTextInputFormatter(
                        mask: '(###) ###-####',
                        filter: {"#": RegExp(r'[0-9]')},
                        type: MaskAutoCompletionType.lazy)
                  ],
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                      borderSide: BorderSide(
                        color:
                           context.read<UserData>().epn==null ? Color.fromARGB(123, 255, 0, 0) :context.read<UserData>().epn! ? Colors.grey: Color.fromARGB(123, 255, 0, 0),
                        width: 2.0,
                      ),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText: 'Phone Number',
                  ),
                  validator: (value) {
                    if (value!.length < 14) {
                       context.read<UserData>().esn= true;
                       context.read<UserData>().eln = true;
                      context.read<UserData>().epn = true;
                      return 'Please enter your contact number';
                    }

                    return null;
                  },
                  onChanged: (String? value) {
                     context.read<UserData>().esn= true;
                       context.read<UserData>().eln = true;
                      context.read<UserData>().epn = true;
                    _formKey.currentState!.validate();

                    context.read<UserData>().phoneNumber = value;
                  },
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  controller: reltc,
                  onTap: () {
                    setState(() {
                      context.read<UserData>().esn= true;
                       context.read<UserData>().eln = true;
                      context.read<UserData>().epn = true;
                    });
                    showSexTypeDialograce(context);
                  },
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText: 'Relationship with Patient',
                  ),
                  onChanged: (String? value) {
                    setState(() {
                      _formKey.currentState!.validate();
                    });
                    context.read<UserData>().patientEmergencyRelation = value;
                  },
                ),
                SizedBox(height: 10.0),
                DropdownButtonFormField(
                
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText:context.read<UserData>().leaveMessage!=null?context.read<UserData>().leaveMessage: 'Leave Message',
                  ),
                  items: [
                    DropdownMenuItem(
                      value: 'Yes',
                      child: Text('Yes'),
                    ),
                    DropdownMenuItem(
                      value: 'No',
                      child: Text('No'),
                    ),
                  ],
                  // validator: (value) {
                  //   if (value == null || value.isEmpty) {
                  //     return 'Please select an option';
                  //   }
                  //   return null;
                  // },
                  onChanged: (String? value) {
                    setState(() {
                      _formKey.currentState!.validate();
                    });
                    context.read<UserData>().leaveMessage = value;
                  },
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  controller: t4,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText: 'Address',
                  ),
                  // validator: (value) {
                  //   if (value == null || value.isEmpty) {
                  //     return 'Please enter your address';
                  //   }
                  //   return null;
                  // },
                  onChanged: (String? value) {
                    setState(() {
                      _formKey.currentState!.validate();
                    });
                    context.read<UserData>().address = value;
                  },
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  controller: t5,
                  inputFormatters: [
                    MaskTextInputFormatter(
                        mask: '########################',
                        filter: {"#": RegExp(r'[a-zA-Z]')},
                        type: MaskAutoCompletionType.lazy)
                  ],
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText: 'City',
                  ),
                  // validator: (value) {
                  //   if (value == null || value.isEmpty) {
                  //     return 'Please enter your city';
                  //   }
                  //   return null;
                  // },
                  onChanged: (String? value) {
                    _formKey.currentState!.validate();

                    context.read<UserData>().EMcity = value;
                  },
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  controller: t6,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText: 'State',
                  ),
                  inputFormatters: [
                    MaskTextInputFormatter(
                        mask: '########################',
                        filter: {"#": RegExp(r'[a-zA-Z]')},
                        type: MaskAutoCompletionType.lazy)
                  ],
                  // validator: (value) {
                  //   if (value == null || value.isEmpty) {
                  //     return 'Please enter your state';
                  //   }
                  //   return null;
                  // },
                  onChanged: (String? value) {
                    _formKey.currentState!.validate();

                    context.read<UserData>().EMstate = value;
                  },
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  controller: t7,
                  inputFormatters: [
                    MaskTextInputFormatter(
                        mask: '#######',
                        filter: {"#": RegExp(r'[A-Za-z0-9]')},
                        type: MaskAutoCompletionType.lazy)
                  ],
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText: 'Zip Code',
                  ),
                  onChanged: (String? value) {
                    _formKey.currentState!.validate();

                    context.read<UserData>().EMzipCode = value;
                  },
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  controller: t8,
                  inputFormatters: [
                    MaskTextInputFormatter(
                        mask: '########################',
                        filter: {"#": RegExp(r'[a-zA-Z]')},
                        type: MaskAutoCompletionType.lazy)
                  ],
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    labelText: 'Country',
                  ),
                  // validator: (value) {
                  //   if (value == null || value.isEmpty) {
                  //     return 'Please enter your country';
                  //   }
                  //   return null;
                  // },
                  onChanged: (String? value) {
                    _formKey.currentState!.validate();

                    context.read<UserData>().EMcountry = value;
                  },
                ),
                SizedBox(height: 10.0),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
